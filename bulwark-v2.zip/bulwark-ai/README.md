# Bulwark AI Assistant

A chat assistant for **every Bulwark function** (vulnerabilities, incidents, plans, approvals, execution, analytics), built as two independent projects. The `/insights` and `/scans` API modules the MCP tools call live in `bulwark-api/src/bulwark/modules/` (registered in `main.py`; settings in `bulwark-api/.env`).

```
bulwark-ai/
  bulwark-mcp-server/   MCP server: 60 tools. A thin client: every tool is a call to the Bulwark REST API, nothing else
  bulwark-chat-agent/   LangGraph agent: Gemini Flash + Gemini embeddings, talks to the MCP server, asks a human before changing anything
  docker-compose.yml    runs both next to an existing Bulwark API (not exercised in the build sandbox)
```

```
 you / web chat ──► chat agent (LangGraph) ──MCP over HTTP──► MCP server ──REST only (caller's JWT)──► Bulwark API ──► PostgreSQL
                      │  Gemini Flash (reasoning)                                                          │ existing modules + /insights, /scans
                      │  Gemini embedding (tool selection)                                                 ├──Gemini embedding + pgvector (semantic search)
                      └─ human approval before any write                                                   └──scan-ingestor CLI + Kafka (scan workbooks)
```

**Only Gemini is used**: `gemini-2.5-flash` for the chat model and `gemini-embedding-001` (768-d) for embeddings.

## How the pieces fit
| | MCP server | Chat agent |
|---|---|---|
| Job | Owns the *capabilities*: each Bulwark function is one tool with typed arguments, a clear description and a read/write flag | Owns the *conversation*: understands the question, picks tools, plans, asks for approval, explains the result |
| Talks to | Only the Bulwark REST API | The MCP server, Gemini |
| Identity | Forwards the caller's JWT to the Bulwark API, so the API's role checks decide what is allowed | Sends the user's JWT with every MCP call |
| Reusable by | Any MCP client (Claude Desktop, MCP Inspector, other agents) | The terminal CLI and the HTTP API for a chat widget |

## Quick start (local)
```bash
# 0. Bulwark API + PostgreSQL running as usual (bulwark-api/README.md), pgvector installed
# 1. MCP server
# 0b. bulwark-api/.env needs GEMINI_API_KEY and SCAN_INBOX / SCAN_INGESTOR_DIR / SCAN_INGESTOR_CMD (see bulwark-api/.env.example)
cd bulwark-mcp-server && cp .env.example .env      # set BULWARK_API_URL
pip install -e ".[dev]" && bulwark-mcp             # http://127.0.0.1:8765/mcp   (health: /health)
# 2. Chat agent
cd ../bulwark-chat-agent && cp .env.example .env   # set GEMINI_API_KEY, BULWARK_JWT_SECRET (= bulwark-api JWT_SECRET)
pip install -e ".[dev]"
bulwark-chat --user ravi --roles ANALYST,OPERATOR  # terminal chat as a development user
bulwark-chat-server                                # or the HTTP API on :8800 for a web widget
```

## Safety model
1. **Roles**: every call reaches the Bulwark API with the *user's own* JWT. The assistant can never do more than that person could in the UI.
2. **Human approval**: any tool the MCP server marks as a write (`readOnlyHint=false`, and any tool with no annotation) pauses the graph and asks the person. Declined means nothing runs and the model is told so.
3. **Bulwark's own rules still apply**: reviewer cannot approve their own submission, plans lock on submit, one open incident per vulnerability, execution only for approved incidents.
4. **One door**: the MCP server has no database, Gemini or subprocess access (a test fails the build if one appears). Every read and write goes through the REST API, so validation, roles and the audit log always apply.
5. **Scan files**: the API accepts only plain `*.xlsx` names inside its configured inbox folder; no paths; ingest needs role ANALYST and is written to the audit log.

## What was tested
- New API modules (`bulwark-api/tests/test_insights_scans.py`): 3 tests on a real PostgreSQL 16 + pgvector (lookup, briefing, risk report, audit, solution search, semantic incident search, scan validate/ingest, role and path-traversal checks). Gemini is replaced by an offline embedder in tests.
- MCP server: 16 tests with a mocked Bulwark API, run with the DB driver uninstalled, plus the no-direct-access guard.
- Chat agent: 24 offline tests (approval gate, tool selection, memory, HTTP API) with a scripted stand-in for Gemini.
- End to end (5 tests): the real Bulwark API with the new modules mounted, on the sample database; the MCP server over HTTP and over stdio; and the agent graph driving the real tools: reads, role denial after approval, a declined change that leaves data untouched, an approved change and its revert.
- All 60 tool schemas convert to Gemini function declarations without errors.
- **Not tested here**: live Gemini calls (no API key or route in the build sandbox), real Kafka, Docker, and the real scan-ingestor (a fake CLI stood in). The existing `bulwark-api/tests/test_flow.py` has one assertion (`solutions_pending_review == 1`) that fails on your original code too, with or without the new files.

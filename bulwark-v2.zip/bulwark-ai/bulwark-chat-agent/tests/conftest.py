import asyncio
import hashlib
import math
import sys

import pytest
from langchain_core.language_models import BaseChatModel
from langchain_core.messages import AIMessage
from langchain_core.outputs import ChatGeneration, ChatResult
from langchain_core.tools import StructuredTool
from pydantic import Field

from bulwark_agent.config import Settings


def pytest_asyncio_loop_factories(config, item):
    """psycopg (chat history on PostgreSQL) cannot use Windows' default Proactor loop; the stdio MCP tests need it."""
    if sys.platform == "win32" and item.module.__name__.endswith("test_history"):
        return {"selector": asyncio.SelectorEventLoop}
    return {"default": asyncio.new_event_loop}


class ScriptedModel(BaseChatModel):
    """Stands in for Gemini Flash. `script` items are AIMessage or callable(messages) -> AIMessage; records the tools bound each call."""
    script: list = Field(default_factory=list)
    seen_tools: list = Field(default_factory=list)
    seen_messages: list = Field(default_factory=list)

    @property
    def _llm_type(self) -> str:
        return "scripted"

    def bind_tools(self, tools, **kw):
        self.seen_tools.append([getattr(t, "name", None) for t in tools])
        return self

    def _generate(self, messages, stop=None, run_manager=None, **kw):
        self.seen_messages.append(list(messages))
        item = self.script.pop(0)
        return ChatResult(generations=[ChatGeneration(message=item(messages) if callable(item) else item)])


def call(name, args, id_="c1"):
    return AIMessage(content="", tool_calls=[{"name": name, "args": args, "id": id_, "type": "tool_call"}])


def calls(*items):
    return AIMessage(content="", tool_calls=[{"name": n, "args": a, "id": f"c{i}", "type": "tool_call"} for i, (n, a) in enumerate(items)])


class FakeEmbedder:
    """Hashed bag of words (tests only)."""
    fail = False

    @staticmethod
    def vec(text):
        v = [0.0] * 256
        for w in "".join(c if c.isalnum() else " " for c in text.lower()).split():
            v[int(hashlib.md5(w.encode()).hexdigest(), 16) % 256] += 1
        n = math.sqrt(sum(x * x for x in v)) or 1
        return [x / n for x in v]

    async def adocs(self, texts):
        return [self.vec(t) for t in texts]

    async def aquery(self, text):
        if self.fail:
            raise RuntimeError("embedding outage")
        return self.vec(text)


@pytest.fixture
def side_effects():
    return []


@pytest.fixture
def tools(side_effects):
    async def get_incident(incident: str) -> str:
        return f"{incident}: OPEN, 3 assets"

    async def approve_incident(incident: str) -> str:
        side_effects.append(("approve", incident))
        return f"approved {incident}"

    async def close_incident(incident: str) -> str:
        side_effects.append(("close", incident))
        return f"closed {incident}"

    async def boom(x: str) -> str:
        raise RuntimeError("database is on fire")

    async def big(x: str) -> str:
        return "x" * 50_000

    async def no_metadata_tool(x: str) -> str:
        side_effects.append(("unknown-risk", x))
        return "done"

    def mk(fn, desc, meta):
        return StructuredTool.from_function(coroutine=fn, name=fn.__name__, description=desc, metadata=meta)

    ro = {"readOnlyHint": True}
    return [mk(get_incident, "Get full details of one incident by code", ro),
            mk(approve_incident, "Approve the submitted plan of an incident", {"readOnlyHint": False, "title": "Approve incident plan"}),
            mk(close_incident, "Close an incident permanently", {"readOnlyHint": False, "destructiveHint": True, "title": "Close incident"}),
            mk(boom, "A tool that fails", ro), mk(big, "Returns a huge payload", ro), mk(no_metadata_tool, "Tool without annotations", None)]


@pytest.fixture
def settings():
    return Settings(_env_file=None, gemini_api_key="k", tool_top_k=3, max_history_messages=40, tool_output_max_chars=500)

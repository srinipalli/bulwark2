import pytest
from jose import jwt

from bulwark_agent.auth import mint_dev_token
from bulwark_agent.config import Settings
from bulwark_agent.llm import build_llm
from bulwark_agent.mcp_tools import connection_config, is_write


def test_models_are_gemini_flash_and_gemini_embedding_by_default():
    s = Settings(_env_file=None)
    assert s.gemini_chat_model == "gemini-2.5-flash" and s.gemini_embed_model == "gemini-embedding-001" and s.embed_dim == 768
    llm = build_llm(Settings(_env_file=None, gemini_api_key="fake-key"))
    assert "gemini-2.5-flash" in llm.model
    with pytest.raises(RuntimeError, match="GEMINI_API_KEY"):
        build_llm(Settings(_env_file=None))


def test_http_connection_forwards_the_users_token():
    c = connection_config(Settings(_env_file=None, mcp_url="http://mcp:8765/mcp"), "abc")["bulwark"]
    assert c["transport"] == "streamable_http" and c["url"] == "http://mcp:8765/mcp" and c["headers"] == {"Authorization": "Bearer abc"}


def test_stdio_connection_passes_the_token_through_the_environment():
    c = connection_config(Settings(_env_file=None, mcp_transport="stdio"), "abc")["bulwark"]
    assert c["transport"] == "stdio" and c["env"]["BULWARK_API_TOKEN"] == "abc" and c["args"][-2:] == ["--transport", "stdio"]


def test_dev_token_has_the_claims_the_bulwark_api_expects():
    s = Settings(_env_file=None, bulwark_jwt_secret="secret")
    claims = jwt.decode(mint_dev_token(s, "ravi.kumar", ["ANALYST", "OPERATOR"]), "secret", algorithms=["HS256"])
    assert claims["roles"] == ["ANALYST", "OPERATOR"] and claims["name"] == "Ravi Kumar" and claims["email"] == "ravi.kumar@example.com" and claims["sub"]
    with pytest.raises(RuntimeError, match="BULWARK_JWT_SECRET"):
        mint_dev_token(Settings(_env_file=None), "x", [])


def test_is_write_fails_closed(tools):
    by = {t.name: is_write(t) for t in tools}
    assert by["get_incident"] is False and by["approve_incident"] is True and by["no_metadata_tool"] is True

"""End-to-end against the REAL stack: Bulwark API (+ worker data) <- Bulwark MCP server (HTTP) <- this agent graph.
Only the LLM is scripted (Gemini needs a key and network). Opt-in:

  E2E_MCP_URL=http://127.0.0.1:8765/mcp E2E_JWT_SECRET=<bulwark-api JWT_SECRET> pytest tests/test_e2e_real_stack.py

Needs the sample data set (bulwark-api/sql/02_sample_data.sql): INC-55 (open, no plan), INC-48 (open, 3-step plan), INC-53 (pending approval)."""
import os

import pytest
from langchain_core.messages import AIMessage, ToolMessage
from langgraph.checkpoint.memory import MemorySaver

from bulwark_agent.agent import create_agent
from bulwark_agent.auth import mint_dev_token
from bulwark_agent.config import Settings
from bulwark_agent.runner import resume_turn, start_turn
from conftest import FakeEmbedder, ScriptedModel, call

pytestmark = pytest.mark.skipif(not os.environ.get("E2E_MCP_URL"), reason="set E2E_MCP_URL and E2E_JWT_SECRET to run against the real stack")


def settings():
    return Settings(_env_file=None, gemini_api_key="k", mcp_url=os.environ.get("E2E_MCP_URL", ""), bulwark_jwt_secret=os.environ.get("E2E_JWT_SECRET", ""),
                    tool_top_k=12)


async def agent_for(script, roles=("ANALYST", "OPERATOR")):
    s = settings()
    model = ScriptedModel(script=script)
    a = await create_agent(s, mint_dev_token(s, "e2e.user", list(roles)), llm=model, embedder=FakeEmbedder(), checkpointer=MemorySaver())
    return a, a.config("e2e"), model


def tool_msgs(state):
    return [m for m in state.values["messages"] if isinstance(m, ToolMessage)]


async def test_all_tools_arrive_with_read_write_annotations():
    a, _, _ = await agent_for([])
    assert len(a.tools) >= 55
    ro = {t.name for t in a.tools if (t.metadata or {}).get("readOnlyHint")}
    assert {"explain_incident", "semantic_search_incidents", "portfolio_risk_report", "get_audit_trail", "list_incidents"} <= ro
    assert not ({"approve_incident", "run_full_plan", "ingest_scan_workbook"} & ro)


async def test_read_tools_return_real_data_through_mcp():
    a, cfg, _ = await agent_for([call("explain_incident", {"incident": "INC-48"}, "1"), AIMessage("done")])
    r = await start_turn(a.graph, cfg, "tell me about INC-48")
    assert r.pending is None and r.tools_called == ["explain_incident"]
    content = tool_msgs(await a.graph.aget_state(cfg))[0].content
    assert "CVE-2023-22515" in content and "Upgrade Confluence Data Center" in content and '"next_actions"' in content


async def test_database_backed_tools_work():
    a, cfg, _ = await agent_for([call("get_audit_trail", {"entity_type": "incident", "entity": "INC-48", "limit": 3}, "1"), call("portfolio_risk_report", {"top_n": 2}, "2"), AIMessage("ok")])
    await start_turn(a.graph, cfg, "history of INC-48 and risk report")
    msgs = tool_msgs(await a.graph.aget_state(cfg))
    assert msgs[0].content.startswith("[{") and "incident.plan_replaced" in msgs[0].content
    assert "oldest_open_incidents" in msgs[1].content


async def test_roles_are_enforced_by_the_bulwark_api_even_after_the_human_approves():
    a, cfg, _ = await agent_for([call("approve_incident", {"incident": "INC-53"}), AIMessage("You are not allowed.")], roles=("ANALYST",))
    r = await start_turn(a.graph, cfg, "approve INC-53")
    assert r.pending[0]["tool"] == "approve_incident"
    await resume_turn(a.graph, cfg, True)
    tm = tool_msgs(await a.graph.aget_state(cfg))[0]
    assert tm.status == "error" and "Not allowed" in tm.content


async def test_declined_change_leaves_data_untouched_and_approved_change_is_applied_then_reverted():
    a, cfg, _ = await agent_for([
        call("copy_incident_plan", {"incident": "INC-55", "source_incident": "INC-48"}, "1"), AIMessage("Left it alone."),              # declined
        call("copy_incident_plan", {"incident": "INC-55", "source_incident": "INC-48"}, "2"), call("get_incident", {"incident": "INC-55"}, "3"), AIMessage("Copied."),
        call("clear_incident_plan", {"incident": "INC-55"}, "4"), AIMessage("Cleared.")])                                                # cleanup
    await start_turn(a.graph, cfg, "copy INC-48's plan to INC-55")
    await resume_turn(a.graph, cfg, False)
    check = await agent_for([call("get_incident", {"incident": "INC-55"}), AIMessage("x")])
    await start_turn(check[0].graph, check[1], "show INC-55")
    assert '"plan":[]' in tool_msgs(await check[0].graph.aget_state(check[1]))[0].content

    await start_turn(a.graph, cfg, "yes copy it")
    r = await resume_turn(a.graph, cfg, True)
    assert r.reply == "Copied."
    assert "Upgrade Confluence Data Center" in [m for m in tool_msgs(await a.graph.aget_state(cfg)) if m.name == "get_incident"][-1].content

    await start_turn(a.graph, cfg, "now clear it again")
    assert (await resume_turn(a.graph, cfg, True)).reply == "Cleared."

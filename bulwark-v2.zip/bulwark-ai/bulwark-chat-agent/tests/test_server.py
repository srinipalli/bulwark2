import httpx
import pytest
from langchain_core.messages import AIMessage

from bulwark_agent.agent import create_agent
from bulwark_agent.history import MemoryChatStore
from bulwark_agent.server import create_app
from conftest import FakeEmbedder, ScriptedModel, call


@pytest.fixture
def store():
    return MemoryChatStore()


@pytest.fixture
async def client(settings, tools, side_effects, store):
    scripts = {}

    async def factory(token, saver):
        scripts[token] = ScriptedModel(script=[call("approve_incident", {"incident": "INC-57"}), AIMessage("Approved.")] * 2)
        return await create_agent(settings, token, llm=scripts[token], embedder=FakeEmbedder(), tools=tools, checkpointer=saver)

    app = create_app(settings, agent_factory=factory, store=store)
    async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url="http://t") as c:
        yield c


A, B = {"Authorization": "Bearer user-a"}, {"Authorization": "Bearer user-b"}


async def test_requires_a_bearer_token(client):
    assert (await client.post("/chat", json={"message": "hi"})).status_code == 401
    assert (await client.get("/health")).json() == {"status": "ok"}


async def test_chat_then_confirm_flow(client, side_effects):
    r = (await client.post("/chat", json={"message": "approve INC-57"}, headers=A)).json()
    assert r["reply"] is None and r["pending"][0]["tool"] == "approve_incident" and side_effects == []
    r2 = (await client.post("/chat/confirm", json={"thread_id": r["thread_id"], "approve": True}, headers=A)).json()
    assert r2["reply"] == "Approved." and side_effects == [("approve", "INC-57")]


async def test_steps_report_each_task_and_its_status(client):
    r = (await client.post("/chat", json={"message": "approve INC-57"}, headers=A)).json()
    assert r["steps"] == [{"id": "c1", "tool": "approve_incident", "args": {"incident": "INC-57"}, "status": "awaiting_approval"}]
    r2 = (await client.post("/chat/confirm", json={"thread_id": r["thread_id"], "approve": True}, headers=A)).json()
    assert r2["steps"] == [{"id": "c1", "tool": "approve_incident", "status": "done"}]


async def test_declined_step_is_reported_as_declined(client, side_effects):
    r = (await client.post("/chat", json={"message": "approve INC-57"}, headers=A)).json()
    r2 = (await client.post("/chat/confirm", json={"thread_id": r["thread_id"], "approve": False}, headers=A)).json()
    assert r2["steps"][0]["status"] == "declined" and side_effects == []


async def test_model_error_after_an_approved_change_is_readable_and_retryable(settings, tools, side_effects, store):
    def gemini_429(_messages):
        raise RuntimeError("429 RESOURCE_EXHAUSTED: quota exceeded")

    async def factory(token, saver):
        llm = ScriptedModel(script=[call("approve_incident", {"incident": "INC-149"}), gemini_429, AIMessage("INC-149 is approved.")])
        return await create_agent(settings, token, llm=llm, embedder=FakeEmbedder(), tools=tools, checkpointer=saver)

    app = create_app(settings, agent_factory=factory, store=store)
    async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url="http://t") as c:
        r = (await c.post("/chat", json={"message": "approve INC-149"}, headers=A)).json()
        bad = await c.post("/chat/confirm", json={"thread_id": r["thread_id"], "approve": True}, headers={**A, "Origin": "http://localhost:3100"})
        assert bad.status_code == 502 and bad.headers["access-control-allow-origin"] == "http://localhost:3100"   # browser can read it
        d = bad.json()["detail"]
        assert "429" in d["message"] and d["retryable"] and d["steps"] == [{"id": "c1", "tool": "approve_incident", "status": "done"}]
        assert side_effects == [("approve", "INC-149")]                    # the change ran once, before the model error
        assert (await c.post("/chat/confirm", json={"thread_id": r["thread_id"], "approve": True}, headers=A)).status_code == 409
        ok = (await c.post("/chat/retry", json={"thread_id": r["thread_id"]}, headers=A)).json()
        assert ok["reply"] == "INC-149 is approved." and side_effects == [("approve", "INC-149")]   # retry does not repeat it
        assert (await c.post("/chat/retry", json={"thread_id": r["thread_id"]}, headers=A)).status_code == 409


async def test_cors_allows_the_web_uis(client):
    pre = await client.options("/chat", headers={"Origin": "http://localhost:3000", "Access-Control-Request-Method": "POST",
                                                 "Access-Control-Request-Headers": "authorization,content-type"})
    assert pre.status_code == 200 and pre.headers["access-control-allow-origin"] == "http://localhost:3000"


async def test_users_cannot_resume_each_others_conversations(client, side_effects):
    r = (await client.post("/chat", json={"message": "approve INC-57"}, headers=A)).json()
    other = await client.post("/chat/confirm", json={"thread_id": r["thread_id"], "approve": True}, headers=B)
    assert other.status_code == 409 and side_effects == []                         # B has no such pending conversation


async def test_confirm_without_pending_is_a_conflict_and_tools_are_listed(client):
    assert (await client.post("/chat/confirm", json={"thread_id": "nope", "approve": True}, headers=A)).status_code == 409
    assert "approve_incident" in (await client.get("/tools", headers=A)).json()

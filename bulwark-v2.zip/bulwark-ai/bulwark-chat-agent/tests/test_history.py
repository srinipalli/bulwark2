"""Saved conversations: survive a server restart and a new sign-in, are private per user, and reopen with tasks and pending approvals.

Runs offline against the in-memory store. The same scenarios run against PostgreSQL when TEST_CHAT_DATABASE_URL is set:
a throw-away schema is created from sql/01_chat_history.sql and dropped afterwards."""
import os
import uuid
from pathlib import Path

import httpx
import pytest
from jose import jwt
from langchain_core.messages import AIMessage
from pydantic import SecretStr

from bulwark_agent.agent import create_agent
from bulwark_agent.history import ChatStore, MemoryChatStore, pg_url
from bulwark_agent.server import create_app
from conftest import FakeEmbedder, ScriptedModel, call

SECRET = "s3cret"
PG_URL = os.environ.get("TEST_CHAT_DATABASE_URL", "")
SQL = Path(__file__).resolve().parents[1] / "sql" / "01_chat_history.sql"


def tok(sub, secret=SECRET, name="x"):
    return {"Authorization": "Bearer " + jwt.encode({"sub": sub, "email": f"{name}@x.io", "name": name, "roles": ["APPROVER"]}, secret, algorithm="HS256")}


@pytest.fixture(scope="module", params=["memory"] + (["postgres"] if PG_URL else []))
def backend(request):
    return request.param


@pytest.fixture
async def stores(backend):
    """Factory for 'server runs' that share one database: memory = the same store object, postgres = new pools on one schema."""
    if backend == "memory":
        shared = MemoryChatStore()

        async def make():
            return shared
        yield make
        return
    import psycopg
    schema = f"bulwark_chat_test_{uuid.uuid4().hex[:8]}"
    script = SQL.read_text().replace("bulwark_chat", schema)
    async with await psycopg.AsyncConnection.connect(pg_url(PG_URL), autocommit=True, prepare_threshold=None) as conn:
        await conn.execute(script)
    opened = []

    async def make():
        st = await ChatStore.open(PG_URL, schema)
        opened.append(st)
        return st
    try:
        yield make
    finally:
        for st in opened:
            await st.close()
        async with await psycopg.AsyncConnection.connect(pg_url(PG_URL), autocommit=True, prepare_threshold=None) as conn:
            await conn.execute(f'DROP SCHEMA "{schema}" CASCADE')


class Server:
    """One 'run' of bulwark-chat-server: its own app, agents and model; the conversation store is what survives."""

    def __init__(self, settings, tools, store, script=None):
        self.s = settings.model_copy(update={"bulwark_jwt_secret": SecretStr(SECRET)})
        self.tools, self.store = tools, store
        self.script = script or [call("approve_incident", {"incident": "INC-57"}), AIMessage("INC-57 is approved.")] * 3

    async def __aenter__(self):
        async def factory(token, saver):
            llm = ScriptedModel(script=list(self.script))
            return await create_agent(self.s, token, llm=llm, embedder=FakeEmbedder(), tools=self.tools, checkpointer=saver)

        app = create_app(self.s, agent_factory=factory, store=self.store)
        self.client = httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url="http://t")
        return self.client

    async def __aexit__(self, *exc):
        await self.client.aclose()


async def test_history_survives_restart_and_new_sign_in_and_reopens_with_tasks(settings, tools, side_effects, stores):
    async with Server(settings, tools, await stores()) as c:
        r = (await c.post("/chat", json={"message": "approve   INC-57 please"}, headers=tok("u-1"))).json()
        await c.post("/chat/confirm", json={"thread_id": r["thread_id"], "approve": True}, headers=tok("u-1"))

    async with Server(settings, tools, await stores()) as c:          # restarted server, and a fresh token of the same user
        again = tok("u-1", name="renamed")
        lst = (await c.get("/threads", headers=again)).json()
        assert [(t["thread_id"], t["title"]) for t in lst] == [(r["thread_id"], "approve INC-57 please")]
        t = (await c.get(f"/threads/{r['thread_id']}", headers=again)).json()
        assert t["messages"] == [
            {"role": "user", "text": "approve   INC-57 please"},
            {"role": "assistant", "text": "INC-57 is approved.", "pending": None,
             "steps": [{"id": "c1", "tool": "approve_incident", "args": {"incident": "INC-57"}, "status": "done"}]}]
        assert t["pending"] is False and t["retryable"] is False
        # the conversation goes on where it stopped
        nxt = (await c.post("/chat", json={"message": "and again", "thread_id": r["thread_id"]}, headers=again)).json()
        assert nxt["pending"][0]["tool"] == "approve_incident"
        assert len((await c.get(f"/threads/{r['thread_id']}", headers=again)).json()["messages"]) == 4


async def test_pending_approval_survives_restart(settings, tools, side_effects, stores):
    async with Server(settings, tools, await stores()) as c:
        r = (await c.post("/chat", json={"message": "approve INC-57"}, headers=tok("u-1"))).json()
        assert r["pending"] and side_effects == []
    async with Server(settings, tools, await stores(), script=[AIMessage("INC-57 is approved.")]) as c:   # model only has to answer
        t = (await c.get(f"/threads/{r['thread_id']}", headers=tok("u-1"))).json()
        assert t["pending"] is True and t["messages"][1]["pending"][0]["tool"] == "approve_incident"
        assert t["messages"][1]["steps"][0]["status"] == "awaiting_approval"
        done = (await c.post("/chat/confirm", json={"thread_id": r["thread_id"], "approve": True}, headers=tok("u-1"))).json()
        assert done["reply"] == "INC-57 is approved." and side_effects == [("approve", "INC-57")]


async def test_conversations_are_private_and_tokens_are_verified(settings, tools, side_effects, stores):
    async with Server(settings, tools, await stores()) as c:
        r = (await c.post("/chat", json={"message": "approve INC-57"}, headers=tok("u-1"))).json()
        assert (await c.get("/threads", headers=tok("u-2"))).json() == []
        assert (await c.get(f"/threads/{r['thread_id']}", headers=tok("u-2"))).status_code == 404
        assert (await c.post("/chat/confirm", json={"thread_id": r["thread_id"], "approve": True}, headers=tok("u-2"))).status_code == 409
        assert (await c.get("/threads", headers=tok("u-1", secret="forged"))).status_code == 401     # same sub, wrong signature
        assert side_effects == []


async def test_delete_removes_the_conversation(settings, tools, side_effects, stores):
    async with Server(settings, tools, await stores()) as c:
        a = (await c.post("/chat", json={"message": "first"}, headers=tok("u-1"))).json()
        b = (await c.post("/chat", json={"message": "second"}, headers=tok("u-1"))).json()
        assert [t["title"] for t in (await c.get("/threads", headers=tok("u-1"))).json()] == ["second", "first"]
        assert (await c.delete(f"/threads/{a['thread_id']}", headers=tok("u-2"))).status_code == 404
        assert (await c.delete(f"/threads/{a['thread_id']}", headers=tok("u-1"))).status_code == 204
        assert [t["thread_id"] for t in (await c.get("/threads", headers=tok("u-1"))).json()] == [b["thread_id"]]
        assert (await c.get(f"/threads/{a['thread_id']}", headers=tok("u-1"))).status_code == 404


async def test_missing_tables_give_a_clear_message():
    if not PG_URL:
        pytest.skip("set TEST_CHAT_DATABASE_URL to run against PostgreSQL")
    with pytest.raises(RuntimeError, match="01_chat_history.sql"):
        await ChatStore.open(PG_URL, f"no_such_schema_{uuid.uuid4().hex[:6]}")

from langchain_core.messages import AIMessage, HumanMessage, SystemMessage, ToolMessage
from langgraph.checkpoint.memory import MemorySaver

from bulwark_agent.agent import create_agent
from bulwark_agent.runner import resume_turn, start_turn
from conftest import FakeEmbedder, ScriptedModel, call, calls


async def make(settings, tools, script, **over):
    for k, v in over.items():
        setattr(settings, k, v)
    model = ScriptedModel(script=script)
    agent = await create_agent(settings, "tok", llm=model, embedder=FakeEmbedder(), tools=tools, checkpointer=MemorySaver())
    return agent, model, agent.config("t1")


async def test_read_tool_runs_without_asking(settings, tools):
    agent, model, cfg = await make(settings, tools, [call("get_incident", {"incident": "INC-57"}), AIMessage("INC-57 is open with 3 assets.")])
    r = await start_turn(agent.graph, cfg, "what is INC-57?")
    assert r.pending is None and r.reply == "INC-57 is open with 3 assets." and r.tools_called == ["get_incident"]
    state = await agent.graph.aget_state(cfg)
    assert any(isinstance(m, ToolMessage) and "OPEN, 3 assets" in m.content for m in state.values["messages"])


async def test_write_tool_pauses_and_runs_once_after_approval(settings, tools, side_effects):
    agent, model, cfg = await make(settings, tools, [call("approve_incident", {"incident": "INC-57"}), AIMessage("Approved INC-57.")])
    r = await start_turn(agent.graph, cfg, "approve INC-57")
    assert r.reply is None and side_effects == []
    assert r.pending == [{"id": "c1", "tool": "approve_incident", "title": "Approve incident plan", "args": {"incident": "INC-57"}, "destructive": False}]
    r = await resume_turn(agent.graph, cfg, True)
    assert side_effects == [("approve", "INC-57")] and r.reply == "Approved INC-57." and r.pending is None


async def test_declined_write_changes_nothing_and_model_is_told(settings, tools, side_effects):
    agent, model, cfg = await make(settings, tools, [call("close_incident", {"incident": "INC-9"}), AIMessage("Okay, I left INC-9 as it is.")])
    r = await start_turn(agent.graph, cfg, "close INC-9")
    assert r.pending[0]["destructive"] is True
    r = await resume_turn(agent.graph, cfg, False)
    assert side_effects == [] and r.reply.startswith("Okay")
    tm = [m for m in (await agent.graph.aget_state(cfg)).values["messages"] if isinstance(m, ToolMessage)][0]
    assert tm.status == "error" and "declined" in tm.content


async def test_two_writes_in_one_step_ask_once_and_run_exactly_once_each(settings, tools, side_effects):
    agent, model, cfg = await make(settings, tools, [calls(("approve_incident", {"incident": "INC-1"}), ("close_incident", {"incident": "INC-2"})), AIMessage("Both done.")])
    r = await start_turn(agent.graph, cfg, "approve INC-1 and close INC-2")
    assert len(r.pending) == 2 and side_effects == []
    await resume_turn(agent.graph, cfg, True)
    assert side_effects == [("approve", "INC-1"), ("close", "INC-2")]       # no duplicates from the node re-running after the interrupt


async def test_mixed_read_and_write_declined_still_returns_the_read(settings, tools, side_effects):
    agent, model, cfg = await make(settings, tools, [calls(("get_incident", {"incident": "INC-1"}), ("approve_incident", {"incident": "INC-1"})), AIMessage("ok")])
    await start_turn(agent.graph, cfg, "look at INC-1 and approve it")
    await resume_turn(agent.graph, cfg, False)
    msgs = [m for m in (await agent.graph.aget_state(cfg)).values["messages"] if isinstance(m, ToolMessage)]
    assert side_effects == [] and {m.name: m.status for m in msgs} == {"get_incident": "success", "approve_incident": "error"}


async def test_confirmation_can_be_switched_off(settings, tools, side_effects):
    agent, model, cfg = await make(settings, tools, [call("approve_incident", {"incident": "INC-5"}), AIMessage("done")], require_confirmation=False)
    r = await start_turn(agent.graph, cfg, "approve INC-5")
    assert r.pending is None and side_effects == [("approve", "INC-5")]


async def test_tool_without_annotations_is_treated_as_a_write(settings, tools, side_effects):
    agent, model, cfg = await make(settings, tools, [call("no_metadata_tool", {"x": "1"}), AIMessage("done")])
    r = await start_turn(agent.graph, cfg, "run it")
    assert r.pending and side_effects == []                                  # fail closed


async def test_tool_errors_and_unknown_tools_go_back_to_the_model(settings, tools):
    agent, model, cfg = await make(settings, tools, [calls(("boom", {"x": "1"}), ("does_not_exist", {})), AIMessage("That failed; sorry.")])
    r = await start_turn(agent.graph, cfg, "do the failing thing")
    assert r.reply == "That failed; sorry."
    msgs = {m.name: m for m in (await agent.graph.aget_state(cfg)).values["messages"] if isinstance(m, ToolMessage)}
    assert "database is on fire" in msgs["boom"].content and msgs["boom"].status == "error"
    assert "Unknown tool" in msgs["does_not_exist"].content


async def test_huge_tool_output_is_truncated(settings, tools):
    agent, model, cfg = await make(settings, tools, [call("big", {"x": "1"}), AIMessage("ok")])
    await start_turn(agent.graph, cfg, "huge")
    tm = [m for m in (await agent.graph.aget_state(cfg)).values["messages"] if isinstance(m, ToolMessage)][0]
    assert len(tm.content) < 700 and "truncated" in tm.content


async def test_only_relevant_tools_are_offered_plus_core_and_sticky(settings, tools):
    agent, model, cfg = await make(settings, tools, [call("close_incident", {"incident": "INC-3"}), AIMessage("asked"), AIMessage("fine")], tool_top_k=1)
    await start_turn(agent.graph, cfg, "close this incident permanently")
    offered = model.seen_tools[0]
    assert "get_incident" in offered and "close_incident" in offered          # core + best match
    assert "big" not in offered and "boom" not in offered
    await resume_turn(agent.graph, cfg, False)
    await start_turn(agent.graph, cfg, "huge payload please")                 # new question about another tool ...
    assert "close_incident" in model.seen_tools[-1]                           # ... but tools used earlier in the chat stay available


async def test_embedding_outage_falls_back_to_all_tools(settings, tools):
    agent, model, cfg = await make(settings, tools, [AIMessage("hi")], tool_top_k=1)
    agent.graph.nodes  # graph built
    FakeEmbedder.fail = True
    try:
        await start_turn(agent.graph, cfg, "hello")
    finally:
        FakeEmbedder.fail = False
    assert sorted(model.seen_tools[0]) == sorted(t.name for t in tools)


async def test_conversation_memory_and_system_prompt(settings, tools):
    agent, model, cfg = await make(settings, tools, [AIMessage("Hello Ravi."), AIMessage("Your name is Ravi.")])
    await start_turn(agent.graph, cfg, "my name is Ravi")
    await start_turn(agent.graph, cfg, "what is my name?")
    second = model.seen_messages[-1]
    assert isinstance(second[0], SystemMessage) and "Bulwark Assistant" in second[0].content
    assert [m.content for m in second if isinstance(m, HumanMessage)] == ["my name is Ravi", "what is my name?"]


async def test_long_history_is_trimmed_to_start_on_a_human_message(settings, tools):
    agent, model, cfg = await make(settings, tools, [AIMessage(f"a{i}") for i in range(8)], max_history_messages=3)
    for i in range(8):
        await start_turn(agent.graph, cfg, f"question {i}")
    sent = model.seen_messages[-1]
    assert isinstance(sent[1], HumanMessage) and len(sent) <= 4 and sent[-1].content == "question 7"


async def test_mcp_content_blocks_are_flattened_and_compacted(settings):
    from langchain_core.tools import StructuredTool

    async def fn(x: str):
        return [{"type": "text", "text": '{\n  "a": 1,\n  "b": [1, 2]\n}', "id": "lc_1"}], None
    t = StructuredTool.from_function(coroutine=fn, name="mcp_like", description="returns MCP content blocks", metadata={"readOnlyHint": True},
                                     response_format="content_and_artifact")
    agent, model, cfg = await make(settings, [t], [call("mcp_like", {"x": "1"}), AIMessage("ok")])
    await start_turn(agent.graph, cfg, "go")
    tm = [m for m in (await agent.graph.aget_state(cfg)).values["messages"] if isinstance(m, ToolMessage)][0]
    assert tm.content == '{"a":1,"b":[1,2]}'


async def test_list_results_become_one_json_array(settings):
    from langchain_core.tools import StructuredTool

    async def fn(x: str):
        return [{"type": "text", "text": '{\n "n": 1\n}'}, {"type": "text", "text": '{\n "n": 2\n}'}], None
    t = StructuredTool.from_function(coroutine=fn, name="lister", description="returns a list", metadata={"readOnlyHint": True}, response_format="content_and_artifact")
    agent, model, cfg = await make(settings, [t], [call("lister", {"x": "1"}), AIMessage("ok")])
    await start_turn(agent.graph, cfg, "go")
    tm = [m for m in (await agent.graph.aget_state(cfg)).values["messages"] if isinstance(m, ToolMessage)][0]
    assert tm.content == '[{"n":1},{"n":2}]'

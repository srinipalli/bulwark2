"""Saved conversations for the HTTP server.

PostgreSQL (CHAT_DATABASE_URL, schema CHAT_DB_SCHEMA = bulwark_chat; tables from sql/01_chat_history.sql) holds
  * the LangGraph checkpoints (full conversation state, incl. a change still waiting for approval), and
  * chat_threads: per user the thread id, a title (first question) and the last update - the "Recent chats" list.
Threads belong to a user key: the verified JWT subject (see server.user_key). Nobody can list or open another user's chats.
MemoryChatStore is the same thing in memory (tests, or no database configured).
"""
from __future__ import annotations

import logging

from langchain_core.messages import AIMessage, HumanMessage, ToolMessage
from langgraph.checkpoint.memory import MemorySaver

from .graph import text_of
from .runner import step_status

log = logging.getLogger("bulwark_agent")
TABLES = ("chat_threads", "checkpoints", "checkpoint_blobs", "checkpoint_writes", "checkpoint_migrations")
COLS = ("thread_id", "title", "created_at", "updated_at")


def _title(title: str | None) -> str:
    return " ".join((title or "New chat").split())[:80]


def _row(r: dict) -> dict:
    return {k: (r[k].isoformat(timespec="seconds") if hasattr(r[k], "isoformat") else r[k]) for k in COLS}


def pg_url(url: str) -> str:
    """Accept the Bulwark API style URL too (postgresql+asyncpg://...)."""
    for prefix in ("postgresql+asyncpg://", "postgresql+psycopg://", "postgres://"):
        if url.startswith(prefix):
            return "postgresql://" + url[len(prefix):]
    return url


class ChatStore:
    """PostgreSQL store. Open with `await ChatStore.open(url, schema)`; tables must exist (sql/01_chat_history.sql)."""

    def __init__(self, pool, saver):
        self.pool, self.saver = pool, saver

    @classmethod
    async def open(cls, url: str, schema: str = "bulwark_chat") -> ChatStore:
        from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver
        from psycopg import sql
        from psycopg.rows import dict_row
        from psycopg_pool import AsyncConnectionPool

        async def configure(conn):                                      # every pooled connection works in the chat schema
            await conn.execute(sql.SQL("SET search_path TO {}").format(sql.Identifier(schema)))

        pool = AsyncConnectionPool(pg_url(url), min_size=1, max_size=10, open=False, configure=configure,
                                   kwargs={"autocommit": True, "prepare_threshold": None, "row_factory": dict_row})
        await pool.open(wait=True, timeout=30)
        async with pool.connection() as conn:
            found = {r["t"] for r in await (await conn.execute(
                "SELECT table_name AS t FROM information_schema.tables WHERE table_schema = %s", (schema,))).fetchall()}
        missing = [t for t in TABLES if t not in found]
        if missing:
            await pool.close()
            raise RuntimeError(f"Chat history tables missing in schema '{schema}': {', '.join(missing)}. "
                               "Run bulwark-chat-agent/sql/01_chat_history.sql against the database first.")
        return cls(pool, AsyncPostgresSaver(pool))

    async def close(self) -> None:
        await self.pool.close()

    async def _q(self, query: str, params: tuple, fetch: str | None = None):
        async with self.pool.connection() as conn:
            cur = await conn.execute(query, params)
            if fetch == "one":
                return await cur.fetchone()
            if fetch == "all":
                return await cur.fetchall()
            return cur.rowcount

    async def touch(self, user: str, thread_id: str, title: str | None = None) -> None:
        """Create the thread entry (title = first question) or move it to the top of the list."""
        await self._q("INSERT INTO chat_threads (user_key, thread_id, title) VALUES (%s, %s, %s) "
                      "ON CONFLICT (user_key, thread_id) DO UPDATE SET updated_at = now()", (user, thread_id, _title(title)))

    async def get(self, user: str, thread_id: str) -> dict | None:
        r = await self._q("SELECT thread_id, title, created_at, updated_at FROM chat_threads WHERE user_key = %s AND thread_id = %s",
                          (user, thread_id), "one")
        return _row(r) if r else None

    async def list(self, user: str, limit: int) -> list[dict]:
        rows = await self._q("SELECT thread_id, title, created_at, updated_at FROM chat_threads WHERE user_key = %s "
                             "ORDER BY updated_at DESC, created_at DESC LIMIT %s", (user, limit), "all")
        return [_row(r) for r in rows]

    async def delete(self, user: str, thread_id: str, state_key: str) -> bool:
        n = await self._q("DELETE FROM chat_threads WHERE user_key = %s AND thread_id = %s", (user, thread_id))
        if n:
            await self.saver.adelete_thread(state_key)
        return n > 0


class MemoryChatStore:
    """Same interface, nothing persisted (tests; or the server without CHAT_DATABASE_URL)."""

    def __init__(self):
        self.saver = MemorySaver()
        self.rows: dict[tuple[str, str], dict] = {}
        self._clock = 0

    def _now(self) -> str:
        from datetime import datetime, timedelta, timezone
        self._clock += 1                                                # strictly increasing, so ordering is stable
        return (datetime(2026, 1, 1, tzinfo=timezone.utc) + timedelta(seconds=self._clock)).isoformat(timespec="seconds")

    async def close(self) -> None:
        pass

    async def touch(self, user: str, thread_id: str, title: str | None = None) -> None:
        now, r = self._now(), self.rows.get((user, thread_id))
        if r:
            r["updated_at"] = now
        else:
            self.rows[(user, thread_id)] = {"thread_id": thread_id, "title": _title(title), "created_at": now, "updated_at": now}

    async def get(self, user: str, thread_id: str) -> dict | None:
        r = self.rows.get((user, thread_id))
        return dict(r) if r else None

    async def list(self, user: str, limit: int) -> list[dict]:
        mine = [dict(r) for (u, _), r in self.rows.items() if u == user]
        return sorted(mine, key=lambda r: r["updated_at"], reverse=True)[:limit]

    async def delete(self, user: str, thread_id: str, state_key: str) -> bool:
        if self.rows.pop((user, thread_id), None) is None:
            return False
        await self.saver.adelete_thread(state_key)
        return True


async def open_store(url: str, schema: str):
    if not url:
        log.warning("CHAT_DATABASE_URL is not set: chat history is kept in memory only and lost on restart.")
        return MemoryChatStore()
    return await ChatStore.open(url, schema)


def transcript(messages: list, pending: list[dict] | None = None) -> list[dict]:
    """Conversation state -> what the chat UI shows: user messages, and per answer the tasks (tool calls with status) and the reply."""
    out: list[dict] = []
    turn: dict | None = None
    for m in messages:
        if isinstance(m, HumanMessage):
            out.append({"role": "user", "text": text_of(m)})
            turn = None
        elif isinstance(m, AIMessage):
            if turn is None:
                turn = {"role": "assistant", "text": None, "steps": [], "pending": None}
                out.append(turn)
            turn["steps"] += [{"id": c["id"], "tool": c["name"], "args": c["args"], "status": "planned"} for c in m.tool_calls]
            if not m.tool_calls and text_of(m).strip():
                turn["text"] = text_of(m)
        elif isinstance(m, ToolMessage) and turn is not None:
            for st in turn["steps"]:
                if st["id"] == m.tool_call_id:
                    st["status"], detail = step_status(m)
                    if detail:
                        st["detail"] = detail
    if pending and turn is not None:
        ids = {a["id"] for a in pending}
        turn["pending"] = pending
        for st in turn["steps"]:
            if st["id"] in ids:
                st["status"] = "awaiting_approval"
    return out

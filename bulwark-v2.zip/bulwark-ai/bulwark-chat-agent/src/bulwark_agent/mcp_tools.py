"""Connect to the Bulwark MCP server and turn its tools into LangChain tools. The caller's JWT travels in the Authorization header,
so every action runs as that user."""
from __future__ import annotations

import shlex
from pathlib import Path

from langchain_core.tools import BaseTool
from langchain_mcp_adapters.client import MultiServerMCPClient

from .config import Settings


def connection_config(s: Settings, token: str) -> dict:
    if s.mcp_transport == "stdio":
        import os

        return {"bulwark": {"transport": "stdio", "command": s.mcp_stdio_command, "args": shlex.split(s.mcp_stdio_args),
                            "cwd": str(Path(s.mcp_stdio_cwd).expanduser().resolve()), "env": {**os.environ, "BULWARK_API_TOKEN": token}}}
    return {"bulwark": {"transport": "streamable_http", "url": s.mcp_url, "headers": {"Authorization": f"Bearer {token}"}}}


async def load_tools(s: Settings, token: str) -> list[BaseTool]:
    return await MultiServerMCPClient(connection_config(s, token)).get_tools()


def is_write(t: BaseTool) -> bool:
    """Fail closed: a tool is read-only only if the MCP server says so (annotations.readOnlyHint)."""
    return not bool((t.metadata or {}).get("readOnlyHint", False))

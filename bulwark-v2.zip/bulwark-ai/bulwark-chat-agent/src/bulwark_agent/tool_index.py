"""Tool retrieval. The MCP server exposes ~60 tools; offering all of them on every turn wastes tokens and confuses the model.
Each tool's name + description is embedded once (Gemini); per question we offer the closest tools plus a small core set and
the tools already used in this conversation (so follow-ups such as "yes, do it" keep working)."""
from __future__ import annotations

import hashlib

from langchain_core.tools import BaseTool

from .embeddings import Embedder

CORE_TOOLS = ("explain_incident", "list_incidents", "get_incident", "get_dashboard_summary")
_cache: dict[str, list[float]] = {}                       # sha(text) -> vector, shared by all users of the process


def tool_text(t: BaseTool) -> str:
    title = (t.metadata or {}).get("title") or ""
    return f"{t.name.replace('_', ' ')}. {title}. {t.description}".strip()


def cosine(a: list[float], b: list[float]) -> float:
    return sum(x * y for x, y in zip(a, b))


class ToolIndex:
    def __init__(self, tools: list[BaseTool], embedder: Embedder, core: tuple[str, ...] = CORE_TOOLS):
        self.tools, self.embedder = {t.name: t for t in tools}, embedder
        self.core = [c for c in core if c in self.tools]
        self._vecs: dict[str, list[float]] = {}

    async def build(self) -> "ToolIndex":
        texts = {n: tool_text(t) for n, t in self.tools.items()}
        key = {n: hashlib.sha256(x.encode()).hexdigest() for n, x in texts.items()}
        todo = [n for n in texts if key[n] not in _cache]
        if todo:
            for n, v in zip(todo, await self.embedder.adocs([texts[n] for n in todo])):
                _cache[key[n]] = v
        self._vecs = {n: _cache[key[n]] for n in texts}
        return self

    async def select(self, query: str, k: int, sticky: list[str] | None = None) -> list[str]:
        """Names of the tools to offer: core + sticky + the k most similar. Falls back to every tool if embedding fails."""
        if not self._vecs:
            await self.build()
        try:
            q = await self.embedder.aquery(query[:2000] or "help")
        except Exception:                                                  # noqa: BLE001 - embedding outage must not stop the chat
            return list(self.tools)
        ranked = sorted(self._vecs, key=lambda n: -cosine(q, self._vecs[n]))
        out: list[str] = []
        for n in [*self.core, *(sticky or []), *ranked[:k]]:
            if n in self.tools and n not in out:
                out.append(n)
        return out

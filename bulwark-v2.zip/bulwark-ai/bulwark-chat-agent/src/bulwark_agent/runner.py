"""Run one conversation turn (and resume after a human decision). Shared by the CLI and the HTTP server."""
from __future__ import annotations

from dataclasses import dataclass, field

from langchain_core.messages import AIMessage, HumanMessage
from langgraph.types import Command

from .graph import DECLINED, text_of


@dataclass
class TurnResult:
    reply: str | None = None
    pending: list[dict] | None = None            # write actions waiting for the human: [{id, tool, title, args, destructive}]
    tools_called: list[str] = field(default_factory=list)
    # every tool call of this turn in order: {id, tool, args, status: planned|awaiting_approval|done|failed|declined, detail?}
    # after a resume only the calls that ran are reported (without args); a client merges them by id
    steps: list[dict] = field(default_factory=list)


class TurnError(Exception):
    """The turn stopped on an error (e.g. a Gemini outage or rate limit). `steps` are the tool calls seen before it;
    the conversation is checkpointed at the last completed node, so retry_turn() continues from there."""

    def __init__(self, cause: Exception, steps: list[dict]):
        super().__init__(f"{type(cause).__name__}: {cause}")
        self.steps = steps


def step_status(m) -> tuple[str, str | None]:
    """ToolMessage -> (done | failed | declined, error detail)."""
    if getattr(m, "status", None) != "error":
        return "done", None
    text = text_of(m)
    return ("declined", None) if text.startswith(DECLINED) else ("failed", text[:300])


async def _drive(graph, cfg: dict, payload) -> TurnResult:
    called: list[str] = []
    steps: dict[str, dict] = {}                                              # insertion order = execution order
    try:
        async for chunk in graph.astream(payload, cfg, stream_mode="updates"):
            for node, upd in chunk.items():
                if node == "agent":
                    for m in upd["messages"]:
                        for c in getattr(m, "tool_calls", []):
                            called.append(c["name"])
                            steps[c["id"]] = {"id": c["id"], "tool": c["name"], "args": c["args"], "status": "planned"}
                elif node == "tools":
                    for m in upd["messages"]:
                        st = steps.setdefault(m.tool_call_id, {"id": m.tool_call_id, "tool": m.name})
                        st["status"], detail = step_status(m)
                        if detail:
                            st["detail"] = detail
    except Exception as e:                                                   # noqa: BLE001 - reported with the steps that did run
        raise TurnError(e, list(steps.values())) from e
    snap = await graph.aget_state(cfg)
    pend = [i.value for t in snap.tasks for i in t.interrupts]
    if pend:
        actions = [a for p in pend for a in p["actions"]]
        for a in actions:
            if a["id"] in steps:
                steps[a["id"]]["status"] = "awaiting_approval"
        return TurnResult(pending=actions, tools_called=called, steps=list(steps.values()))
    last = next((m for m in reversed(snap.values["messages"]) if isinstance(m, AIMessage)), None)
    return TurnResult(reply=text_of(last) if last else "", tools_called=called, steps=list(steps.values()))


async def start_turn(graph, cfg: dict, text: str) -> TurnResult:
    return await _drive(graph, cfg, {"messages": [HumanMessage(text)]})


async def resume_turn(graph, cfg: dict, approve: bool) -> TurnResult:
    return await _drive(graph, cfg, Command(resume={"approve": approve}))


async def can_retry(graph, cfg: dict) -> bool:
    """True when the last run stopped on an error: a node is still due and no approval is waiting."""
    snap = await graph.aget_state(cfg)
    return bool(snap.next) and not any(t.interrupts for t in snap.tasks)


async def retry_turn(graph, cfg: dict) -> TurnResult:
    return await _drive(graph, cfg, None)                                     # None = re-run the node that failed

"""HTTP API for a web chat widget:
   POST   /chat          {"message": "...", "thread_id": "optional"}   -> {"thread_id", "reply" | "pending": [...actions], "steps"}
   POST   /chat/confirm  {"thread_id": "...", "approve": true|false}   -> same shape
   POST   /chat/retry    {"thread_id": "..."}                          -> same shape; continues a turn that stopped on an error
   GET    /threads                                                     -> the caller's saved conversations, newest first
   GET    /threads/{id}                                                -> one conversation: messages (with tasks), pending approval, retryable
   DELETE /threads/{id}
   GET    /health, GET /tools
A turn that fails (e.g. Gemini rate limit) answers 502 {"detail": {"message", "retryable", "steps"}} - as JSON, so browsers see it.
Send the user's Bulwark JWT as 'Authorization: Bearer <jwt>'. It is forwarded to the MCP server and on to the Bulwark API.
Conversations are saved in PostgreSQL (CHAT_DATABASE_URL, schema bulwark_chat - sql/01_chat_history.sql) under the token's
verified subject (BULWARK_JWT_SECRET), so they survive restarts and new sign-ins of the same user."""
from __future__ import annotations

import asyncio
import hashlib
import logging
import sys
import uuid
from collections import OrderedDict
from contextlib import asynccontextmanager

from fastapi import Depends, FastAPI, Header, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from jose import JWTError, jwt
from pydantic import BaseModel

from .agent import Agent, create_agent
from .config import Settings, get_settings
from .history import ChatStore, MemoryChatStore, open_store, transcript
from .runner import TurnError, TurnResult, can_retry, resume_turn, retry_turn, start_turn

log = logging.getLogger("bulwark_agent")


class ChatIn(BaseModel):
    message: str
    thread_id: str | None = None


class ConfirmIn(BaseModel):
    thread_id: str
    approve: bool


class RetryIn(BaseModel):
    thread_id: str


def _out(thread_id: str, r: TurnResult) -> dict:
    return {"thread_id": thread_id, "reply": r.reply, "pending": r.pending, "tools_called": r.tools_called, "steps": r.steps}


async def _turn(thread_id: str, run) -> dict:
    """Errors become a JSON 502 (an unhandled exception would bypass CORS and look like 'server unreachable' in a browser)."""
    try:
        return _out(thread_id, await run())
    except TurnError as e:
        log.exception("turn failed (thread %s)", thread_id)
        raise HTTPException(502, {"message": f"The assistant stopped on an error: {str(e)[:300]}", "retryable": True, "steps": e.steps}) from e


def user_key(s: Settings, token: str) -> str:
    """Who owns the saved conversations. With BULWARK_JWT_SECRET the token is verified like the Bulwark API does and the
    user's id (sub) is the key, so history follows the user across sign-ins. Without it, the token itself is the key."""
    secret = s.bulwark_jwt_secret.get_secret_value()
    if not secret:
        return "tok:" + hashlib.sha256(token.encode()).hexdigest()[:24]
    try:
        return "sub:" + str(jwt.decode(token, secret, algorithms=[s.bulwark_jwt_algorithm], options={"verify_aud": False})["sub"])
    except (JWTError, KeyError) as e:
        raise HTTPException(401, "Invalid or expired token - sign in again.") from e


def create_app(s: Settings | None = None, agent_factory=None, store: ChatStore | MemoryChatStore | None = None) -> FastAPI:
    """agent_factory(token, checkpointer) -> Agent (tests pass a scripted one); store defaults to PostgreSQL at CHAT_DATABASE_URL."""
    s = s or get_settings()
    agents: OrderedDict[str, Agent] = OrderedDict()                    # one agent (tool list + graph) per token, newest 32 kept
    factory = agent_factory or (lambda token, saver: create_agent(s, token, checkpointer=saver))
    holder = {"store": store}
    opening = asyncio.Lock()

    async def chat_store() -> ChatStore | MemoryChatStore:
        async with opening:
            if holder["store"] is None:
                try:
                    holder["store"] = await open_store(s.chat_database_url.get_secret_value(), s.chat_db_schema)
                except Exception as e:                                # noqa: BLE001
                    log.exception("chat history database unavailable")
                    raise HTTPException(503, f"Chat history database unavailable: {str(e)[:300]}") from e
        return holder["store"]

    @asynccontextmanager
    async def lifespan(_: FastAPI):
        if store is None:                                             # fail fast at start-up (missing tables, wrong URL)
            await chat_store()
        yield
        if holder["store"] is not None and store is None:
            await holder["store"].close()

    app = FastAPI(title="Bulwark chat agent", version="1.0.0", lifespan=lifespan)
    if s.cors_origins:                                                # browser callers: bulwark-ui, bulwark-agent-ui
        app.add_middleware(CORSMiddleware, allow_origins=s.cors_origins, allow_methods=["GET", "POST", "DELETE"],
                           allow_headers=["Authorization", "Content-Type"])

    async def current(authorization: str | None = Header(None)) -> tuple[Agent, str, ChatStore]:
        if not authorization or not authorization.lower().startswith("bearer "):
            raise HTTPException(401, "Send 'Authorization: Bearer <Bulwark JWT>'.")
        token = authorization[7:].strip()
        user = user_key(s, token)
        st = await chat_store()
        tk = hashlib.sha256(token.encode()).hexdigest()[:16]
        if tk not in agents:
            try:
                agents[tk] = await factory(token, st.saver)
            except Exception as e:                                    # noqa: BLE001
                raise HTTPException(502, f"Cannot start the agent (MCP server / Gemini): {str(e)[:200]}") from e
            while len(agents) > 32:
                agents.popitem(last=False)
        agents.move_to_end(tk)
        return agents[tk], user, st

    def cfg(agent: Agent, user: str, thread_id: str) -> dict:
        return agent.config(f"{user}:{thread_id}", s.recursion_limit)      # namespaced per user: nobody can read another's chat

    @app.get("/health")
    async def health():
        return {"status": "ok"}

    @app.get("/tools")
    async def tools(c=Depends(current)):
        return sorted(t.name for t in c[0].tools)

    @app.post("/chat")
    async def chat(body: ChatIn, c=Depends(current)):
        agent, user, st = c
        tid = body.thread_id or uuid.uuid4().hex
        await st.touch(user, tid, body.message)                       # listed even if this first turn fails
        try:
            return await _turn(tid, lambda: start_turn(agent.graph, cfg(agent, user, tid), body.message))
        finally:
            await st.touch(user, tid)

    @app.post("/chat/confirm")
    async def confirm(body: ConfirmIn, c=Depends(current)):
        agent, user, st = c
        conf = cfg(agent, user, body.thread_id)
        snap = await agent.graph.aget_state(conf)
        if not any(t.interrupts for t in snap.tasks):
            raise HTTPException(409, "Nothing is waiting for confirmation in this conversation.")
        try:
            return await _turn(body.thread_id, lambda: resume_turn(agent.graph, conf, body.approve))
        finally:
            await st.touch(user, body.thread_id)

    @app.post("/chat/retry")
    async def retry(body: RetryIn, c=Depends(current)):
        agent, user, st = c
        conf = cfg(agent, user, body.thread_id)
        if not await can_retry(agent.graph, conf):
            raise HTTPException(409, "Nothing to retry in this conversation.")
        try:
            return await _turn(body.thread_id, lambda: retry_turn(agent.graph, conf))
        finally:
            await st.touch(user, body.thread_id)

    @app.get("/threads")
    async def threads(c=Depends(current)):
        _, user, st = c
        return await st.list(user, s.history_limit)

    @app.get("/threads/{thread_id}")
    async def thread(thread_id: str, c=Depends(current)):
        agent, user, st = c
        row = await st.get(user, thread_id)
        if row is None:
            raise HTTPException(404, "No such conversation.")
        snap = await agent.graph.aget_state(cfg(agent, user, thread_id))
        pending = [a for t in snap.tasks for i in t.interrupts for a in i.value["actions"]]
        return {**row, "messages": transcript((snap.values or {}).get("messages", []), pending),
                "pending": bool(pending), "retryable": bool(snap.next) and not pending}

    @app.delete("/threads/{thread_id}", status_code=204)
    async def delete_thread(thread_id: str, c=Depends(current)):
        _, user, st = c
        if not await st.delete(user, thread_id, f"{user}:{thread_id}"):
            raise HTTPException(404, "No such conversation.")

    return app


def main() -> None:
    import uvicorn

    s = get_settings()
    server = uvicorn.Server(uvicorn.Config(create_app(s), host=s.agent_host, port=s.agent_port))
    if sys.platform != "win32":
        server.run()
        return
    # Windows: psycopg (chat history) cannot use the default Proactor loop, so run on a selector loop. That loop cannot
    # start subprocesses, so the MCP server must be reached over HTTP (the default), not started via stdio.
    if s.mcp_transport == "stdio":
        raise SystemExit("On Windows bulwark-chat-server needs MCP_TRANSPORT=streamable_http (start bulwark-mcp separately).")
    asyncio.run(server.serve(), loop_factory=asyncio.SelectorEventLoop)


if __name__ == "__main__":
    main()

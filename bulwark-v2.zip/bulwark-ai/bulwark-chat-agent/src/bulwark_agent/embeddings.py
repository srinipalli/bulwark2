"""Gemini embeddings (gemini-embedding-001) - used to pick the right tools for each question. The only embedding provider."""
from __future__ import annotations

import math
from typing import Protocol

from .config import Settings


class Embedder(Protocol):
    async def adocs(self, texts: list[str]) -> list[list[float]]: ...
    async def aquery(self, text: str) -> list[float]: ...


def normalize(v: list[float]) -> list[float]:
    n = math.sqrt(sum(x * x for x in v)) or 1.0
    return [x / n for x in v]


class GeminiEmbedder:
    def __init__(self, s: Settings):
        from langchain_google_genai import GoogleGenerativeAIEmbeddings

        key = s.gemini_api_key.get_secret_value()
        if not key:
            raise RuntimeError("GEMINI_API_KEY is not set (free key: https://aistudio.google.com/apikey)")
        self._e = GoogleGenerativeAIEmbeddings(model=f"models/{s.gemini_embed_model}", google_api_key=key, output_dimensionality=s.embed_dim)

    async def adocs(self, texts):
        out: list[list[float]] = []
        for i in range(0, len(texts), 100):                              # API limit: 100 texts per request
            out += await self._e.aembed_documents(texts[i:i + 100], task_type="RETRIEVAL_DOCUMENT")
        return [normalize(v) for v in out]

    async def aquery(self, text):
        return normalize(await self._e.aembed_query(text, task_type="RETRIEVAL_QUERY"))

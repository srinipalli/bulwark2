"""Wire everything for one signed-in user."""
from __future__ import annotations

from dataclasses import dataclass

from langchain_core.language_models import BaseChatModel
from langchain_core.tools import BaseTool
from langgraph.checkpoint.memory import MemorySaver

from .config import Settings
from .embeddings import Embedder, GeminiEmbedder
from .graph import build_graph
from .llm import build_llm
from .mcp_tools import load_tools
from .tool_index import ToolIndex


@dataclass
class Agent:
    graph: object
    tools: list[BaseTool]

    def config(self, thread_id: str, recursion_limit: int = 25) -> dict:
        return {"configurable": {"thread_id": thread_id}, "recursion_limit": recursion_limit}


async def create_agent(s: Settings, token: str, *, llm: BaseChatModel | None = None, embedder: Embedder | None = None,
                       tools: list[BaseTool] | None = None, checkpointer=None) -> Agent:
    tools = tools if tools is not None else await load_tools(s, token)
    index = await ToolIndex(tools, embedder or GeminiEmbedder(s)).build()
    graph = build_graph(llm or build_llm(s), tools, index, s, checkpointer or MemorySaver())
    return Agent(graph=graph, tools=tools)

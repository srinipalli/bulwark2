"""Gemini Flash is the only chat model."""
from __future__ import annotations

from langchain_google_genai import ChatGoogleGenerativeAI

from .config import Settings


def build_llm(s: Settings) -> ChatGoogleGenerativeAI:
    key = s.gemini_api_key.get_secret_value()
    if not key:
        raise RuntimeError("GEMINI_API_KEY is not set (free key: https://aistudio.google.com/apikey)")
    return ChatGoogleGenerativeAI(model=s.gemini_chat_model, google_api_key=key, temperature=0.1, max_retries=3, timeout=90)

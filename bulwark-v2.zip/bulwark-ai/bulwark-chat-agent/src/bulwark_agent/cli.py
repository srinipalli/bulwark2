"""Terminal chat:   bulwark-chat                                   (asks who you are: paste a JWT, or a dev user name + roles)
                   bulwark-chat --token <jwt>                     (any user, token from your identity provider / the Bulwark UI)
                   bulwark-chat --user ravi --roles ANALYST,OPERATOR   (dev: mint a token for any name, needs BULWARK_JWT_SECRET)"""
from __future__ import annotations

import argparse
import asyncio
import getpass
import json
import uuid

from jose import jwt

from .agent import create_agent
from .auth import mint_dev_token
from .config import Settings, get_settings
from .runner import TurnError, can_retry, resume_turn, retry_turn, start_turn

ROLES = ("ADMIN", "ANALYST", "APPROVER", "OPERATOR", "VIEWER")


def _show_actions(actions: list[dict]) -> None:
    print("\n  The assistant wants to change data:")
    for a in actions:
        print(f"   - {a['title']}{'  [DESTRUCTIVE]' if a['destructive'] else ''}: {json.dumps(a['args'], default=str)}")


def _roles(text: str) -> list[str]:
    roles = [r.strip().upper() for r in text.split(",") if r.strip()]
    bad = [r for r in roles if r not in ROLES]
    if bad or not roles:
        raise SystemExit(f"Unknown roles {', '.join(bad) or '(none)'}; use a comma separated list of {', '.join(ROLES)}.")
    return roles


def _ask_identity(s: Settings) -> str:
    print("Sign in to Bulwark.")
    token = getpass.getpass("  Paste your Bulwark JWT (input hidden), or press Enter for a development login: ").strip()
    if token:
        return token
    if not s.bulwark_jwt_secret.get_secret_value():
        raise SystemExit("Development login needs BULWARK_JWT_SECRET in .env (same value as JWT_SECRET in bulwark-api/.env).")
    default = getpass.getuser()
    user = input(f"  User name [{default}]: ").strip() or default
    roles = input(f"  Roles, comma separated ({','.join(ROLES)}) [VIEWER]: ").strip() or "VIEWER"
    return mint_dev_token(s, user, _roles(roles))


def identity(s: Settings, a) -> str:
    """Explicit flags win over BULWARK_TOKEN in .env; with none of them the user is asked."""
    if a.token:
        return a.token.strip()
    if a.user:
        return mint_dev_token(s, a.user, _roles(a.roles))
    return s.bulwark_token.get_secret_value() or _ask_identity(s)


def _who(token: str) -> str:
    try:
        c = jwt.get_unverified_claims(token)                                 # display only - the Bulwark API verifies the token
    except Exception:                                                        # noqa: BLE001
        return "unknown user (token could not be read; the API will decide)"
    return f"{c.get('name') or c.get('email') or c.get('sub')} ({', '.join(c.get('roles') or []) or 'no roles'})"


async def amain(a) -> None:
    s = get_settings()
    token = identity(s, a)
    agent = await create_agent(s, token)
    cfg, n_tools = agent.config(a.thread or uuid.uuid4().hex, s.recursion_limit), len(agent.tools)
    print(f"\nBulwark Assistant - signed in as {_who(token)}. Gemini {s.gemini_chat_model}, {n_tools} tools via MCP. Type 'exit' to quit.\n")
    while True:
        try:
            text = input("you> ").strip()
        except (EOFError, KeyboardInterrupt):
            break
        if text.lower() in ("exit", "quit"):
            break
        if not text:
            continue
        try:
            retrying = text.lower() == "retry" and await can_retry(agent.graph, cfg)
            res = await (retry_turn(agent.graph, cfg) if retrying else start_turn(agent.graph, cfg, text))
            while res.pending:
                _show_actions(res.pending)
                ok = a.yes or input("  Approve? [y/N] ").strip().lower() in ("y", "yes")
                res = await resume_turn(agent.graph, cfg, ok)
        except TurnError as e:
            print(f"\n  The assistant stopped on an error: {str(e)[:300]}\n  Type 'retry' to continue from the last completed step.\n")
            continue
        if res.tools_called and a.verbose:
            print(f"  (tools: {', '.join(res.tools_called)})")
        print(f"\nbulwark> {res.reply}\n")


def main() -> None:
    p = argparse.ArgumentParser(description="Bulwark chat agent (terminal). With no --token / --user / BULWARK_TOKEN it asks who you are.")
    p.add_argument("--token", help="Bulwark JWT of the user to act as (from your identity provider or the Bulwark UI)")
    p.add_argument("--user", help="dev: any user name to mint a token for (needs BULWARK_JWT_SECRET)")
    p.add_argument("--roles", default="VIEWER", help=f"dev: comma separated roles for --user ({','.join(ROLES)})")
    p.add_argument("--thread", help="conversation id (resume a conversation in this process)")
    p.add_argument("--yes", action="store_true", help="auto-approve write actions (use with care)")
    p.add_argument("-v", "--verbose", action="store_true")
    asyncio.run(amain(p.parse_args()))


if __name__ == "__main__":
    main()

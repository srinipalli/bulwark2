"""The LangGraph agent.

   START -> route_tools -> agent -> (tool calls?) -> tools -> agent ... -> END
              |              |                         |
   Gemini embeddings     Gemini Flash       human approval (interrupt) before any write tool

route_tools  embeds the question and keeps only the relevant tools (see tool_index.py)
agent        Gemini Flash with those tools bound
tools        runs read tools directly; pauses with interrupt() for write tools, then runs them only if the human approved
"""
from __future__ import annotations

import json
from typing import Annotated, Any

from langchain_core.language_models import BaseChatModel
from langchain_core.messages import AIMessage, HumanMessage, SystemMessage, ToolMessage, trim_messages
from langchain_core.tools import BaseTool
from langgraph.checkpoint.base import BaseCheckpointSaver
from langgraph.graph import END, START, MessagesState, StateGraph
from langgraph.types import interrupt

from .config import Settings
from .mcp_tools import is_write
from .prompts import system_prompt
from .tool_index import ToolIndex

DECLINED = "The user declined this action. Nothing was changed. Do not retry unless they ask again."


def _merge_used(old: list[str] | None, new: list[str] | None) -> list[str]:
    out = [x for x in (old or []) if x not in (new or [])] + list(new or [])
    return out[-8:]                                                       # sticky set stays small


class State(MessagesState):
    active_tools: list[str]
    used_tools: Annotated[list[str], _merge_used]


def text_of(m: Any) -> str:
    c = getattr(m, "content", m)
    if isinstance(c, str):
        return c
    return "".join(b.get("text", "") if isinstance(b, dict) else str(b) for b in c if not (isinstance(b, dict) and b.get("type") == "thinking"))


def _tool_text(content: Any) -> str:
    """MCP results arrive as content blocks (a list result = one block per item) holding pretty-printed JSON.
    Flatten to one compact JSON value (an array when there are several blocks) so the model reads it cheaply and unambiguously."""
    if isinstance(content, str):
        parts = [content]
    else:
        parts = [b.get("text", "") if isinstance(b, dict) else str(b) for b in content if not (isinstance(b, dict) and b.get("type") != "text")]
    try:
        vals = [json.loads(p) for p in parts]
    except ValueError:
        return "\n".join(parts)
    return json.dumps(vals[0] if len(vals) == 1 else vals, separators=(",", ":"), ensure_ascii=False)


def _clip(text: str, n: int) -> str:
    return text if len(text) <= n else text[:n] + f"\n...[truncated {len(text) - n} characters; ask for a narrower query]"


def _query_for(messages: list) -> str:
    humans = [text_of(m) for m in messages if isinstance(m, HumanMessage)]
    return (humans[-1] + ("\n" + humans[-2][:300] if len(humans) > 1 and len(humans[-1]) < 60 else "")) if humans else ""


def build_graph(llm: BaseChatModel, tools: list[BaseTool], index: ToolIndex, s: Settings, checkpointer: BaseCheckpointSaver | None = None):
    by_name = {t.name: t for t in tools}

    async def route_tools(state: State):
        names = await index.select(_query_for(state["messages"]), s.tool_top_k, state.get("used_tools"))
        return {"active_tools": names}

    async def agent(state: State):
        bound = [by_name[n] for n in state.get("active_tools") or by_name if n in by_name]
        history = trim_messages(state["messages"], strategy="last", token_counter=len, max_tokens=s.max_history_messages,
                                start_on="human", include_system=False, allow_partial=False)
        resp = await llm.bind_tools(bound).ainvoke([SystemMessage(system_prompt()), *history])
        if not resp.tool_calls and not text_of(resp).strip():
            resp = AIMessage(content="I could not produce an answer for that. Could you rephrase or give a bit more detail?")
        return {"messages": [resp]}

    async def run_tools(state: State):
        calls = state["messages"][-1].tool_calls
        writes = [c for c in calls if c["name"] in by_name and is_write(by_name[c["name"]])]
        declined = False
        if writes and s.require_confirmation:
            # Phase 1 (no side effects, so re-running this node after the resume is safe): ask the human once for all changes in this step.
            ans = interrupt({"kind": "confirm_write", "actions": [
                {"id": c["id"], "tool": c["name"], "title": (by_name[c["name"]].metadata or {}).get("title") or c["name"], "args": c["args"],
                 "destructive": bool((by_name[c["name"]].metadata or {}).get("destructiveHint"))} for c in writes]})
            declined = not (ans.get("approve") if isinstance(ans, dict) else bool(ans))
        out: list[ToolMessage] = []
        for c in calls:                                                       # Phase 2: execute
            t = by_name.get(c["name"])
            if t is None:
                out.append(ToolMessage(content=f"Unknown tool '{c['name']}'.", tool_call_id=c["id"], name=c["name"], status="error"))
            elif declined and is_write(t):
                out.append(ToolMessage(content=DECLINED, tool_call_id=c["id"], name=c["name"], status="error"))
            else:
                try:
                    r = await t.ainvoke(c)
                    msg = r if isinstance(r, ToolMessage) else ToolMessage(content=str(r), tool_call_id=c["id"], name=c["name"])
                    msg.content = _clip(_tool_text(msg.content), s.tool_output_max_chars)
                    out.append(msg)
                except Exception as e:                                       # noqa: BLE001 - tool failures go back to the model
                    out.append(ToolMessage(content=f"Tool error: {str(e)[:500]}", tool_call_id=c["id"], name=c["name"], status="error"))
        return {"messages": out, "used_tools": [c["name"] for c in calls if c["name"] in by_name]}

    def after_agent(state: State):
        return "tools" if getattr(state["messages"][-1], "tool_calls", None) else END

    g = StateGraph(State)
    g.add_node("route_tools", route_tools)
    g.add_node("agent", agent)
    g.add_node("tools", run_tools)
    g.add_edge(START, "route_tools")
    g.add_edge("route_tools", "agent")
    g.add_conditional_edges("agent", after_agent, {"tools": "tools", END: END})
    g.add_edge("tools", "agent")
    return g.compile(checkpointer=checkpointer)

"""Development helper: mint a Bulwark JWT (claims: sub, email, name, roles) signed with the Bulwark API's JWT secret.
Production tokens come from your identity provider - set BULWARK_TOKEN instead."""
from __future__ import annotations

import uuid

from jose import jwt

from .config import Settings


def mint_dev_token(s: Settings, user: str, roles: list[str]) -> str:
    secret = s.bulwark_jwt_secret.get_secret_value()
    if not secret:
        raise RuntimeError("BULWARK_JWT_SECRET is not set (same value as JWT_SECRET in bulwark-api/.env).")
    return jwt.encode({"sub": str(uuid.uuid5(uuid.NAMESPACE_DNS, user)), "email": f"{user}@example.com", "name": user.replace(".", " ").title(),
                       "roles": roles}, secret, algorithm="HS256")

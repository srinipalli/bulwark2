"""Bulwark chat agent (LangGraph + Gemini)."""

import logging

# Gemini's schema converter logs "Key '$defs' is not supported, ignoring" for nested tool arguments after it has already inlined them. Harmless noise.
logging.getLogger("langchain_google_genai._function_utils").setLevel(logging.ERROR)

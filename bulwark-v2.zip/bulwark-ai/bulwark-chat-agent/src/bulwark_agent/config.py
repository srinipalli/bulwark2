from functools import lru_cache
from pathlib import Path

from pydantic import SecretStr
from pydantic_settings import BaseSettings, SettingsConfigDict

ROOT = Path(__file__).resolve().parents[2]          # bulwark-chat-agent/


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=ROOT / ".env", extra="ignore")

    gemini_api_key: SecretStr = SecretStr("")
    gemini_chat_model: str = "gemini-2.5-flash"
    gemini_embed_model: str = "gemini-embedding-001"
    embed_dim: int = 768

    mcp_transport: str = "streamable_http"
    mcp_url: str = "http://127.0.0.1:8765/mcp"
    mcp_stdio_command: str = "python"
    mcp_stdio_args: str = "-m bulwark_mcp --transport stdio"
    mcp_stdio_cwd: str = "../bulwark-mcp-server"

    bulwark_token: SecretStr = SecretStr("")
    bulwark_jwt_secret: SecretStr = SecretStr("")      # = bulwark-api JWT_SECRET: dev tokens (CLI) and verifying callers (server)
    bulwark_jwt_algorithm: str = "HS256"               # = bulwark-api JWT_ALGORITHM

    require_confirmation: bool = True
    tool_top_k: int = 14
    max_history_messages: int = 40
    tool_output_max_chars: int = 6000
    recursion_limit: int = 25
    agent_host: str = "127.0.0.1"
    agent_port: int = 8800
    cors_origins: list[str] = ["http://localhost:3000", "http://localhost:3100"]   # bulwark-ui, bulwark-agent-ui
    # saved conversations of the HTTP server: the Bulwark PostgreSQL database (tables: sql/01_chat_history.sql).
    # Use the session pooler / direct port (5432). Empty = kept in memory only (lost on restart).
    chat_database_url: SecretStr = SecretStr("")
    chat_db_schema: str = "bulwark_chat"
    history_limit: int = 50                                                           # conversations listed under "Recent chats"


@lru_cache
def get_settings() -> Settings:
    return Settings()

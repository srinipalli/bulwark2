# Bulwark Chat Agent

A LangGraph agent that lets people run Bulwark by chatting. **Gemini only**: `gemini-2.5-flash` thinks and calls tools, `gemini-embedding-001` selects which tools to show it. All capabilities come from the separate [bulwark-mcp-server](../bulwark-mcp-server).

```
START ─► route_tools ─► agent ─┬─ no tool call ─► END
         (Gemini embedding:    │
          pick relevant tools) └─ tool calls ─► tools ─► agent ...
                                                │
                       read tools run directly; write tools pause with interrupt():
                       the human sees the exact call and approves or declines, only then it runs
```

| Node | What it does |
|---|---|
| `route_tools` | The MCP server has 60 tools. The question (plus the previous one for short follow-ups) is embedded with Gemini; the closest `TOOL_TOP_K` tools, a small core set and tools already used in this chat are offered. If the embedding call fails, all tools are offered. |
| `agent` | Gemini Flash with those tools bound, a system prompt with Bulwark rules, and the last `MAX_HISTORY_MESSAGES` messages (memory per `thread_id`). |
| `tools` | Executes calls. Write tools (`readOnlyHint=false`, or no annotation) first `interrupt()` with the exact actions; all writes of one step are asked once, and nothing runs before the answer, so resuming never repeats a side effect. Errors and declines go back to the model as tool messages. Large outputs are truncated and flattened to compact JSON. |

## Run
```bash
cp .env.example .env     # GEMINI_API_KEY, BULWARK_JWT_SECRET (dev), MCP_URL
pip install -e ".[dev]"
# the MCP server must be running (or set MCP_TRANSPORT=stdio to let the agent start it)
bulwark-chat                                           # terminal; asks who you are: paste a JWT, or Enter for a dev login (any name + roles)
bulwark-chat --token <jwt>                             # act as whoever the token belongs to (e.g. the token you use in the Bulwark UI)
bulwark-chat --user ravi --roles ANALYST,OPERATOR      # dev shortcut for any name; add -v to see tools called, --yes to auto-approve (careful)
bulwark-chat-server                                    # HTTP API on :8800
```
Production identity: set `BULWARK_TOKEN` (CLI) or send `Authorization: Bearer <jwt>` (server) with a token from your identity provider.

Example conversation
```
you> what needs my attention?                      -> get_attention_items / get_dashboard_summary
you> explain INC-48                                -> explain_incident (briefing + suggested next steps)
you> find incidents about confluence access bugs   -> semantic_search_incidents (Gemini embeddings + pgvector)
you> copy the plan of INC-48 to INC-55             -> copy_incident_plan  ... "Approve? [y/N]"
you> which fix handles an OpenSSL buffer overrun?  -> find_solutions_for_problem
you> who changed INC-48 and when?                  -> get_audit_trail
```

## HTTP API (for a web chat widget)
| Endpoint | Body | Returns |
|---|---|---|
| `POST /chat` | `{"message": "...", "thread_id": "optional"}` | `{thread_id, reply, pending, tools_called, steps}`; `pending` lists write actions waiting for a decision; `steps` lists each tool call in order with `status` planned / awaiting_approval / done / failed / declined |
| `POST /chat/confirm` | `{"thread_id": "...", "approve": true}` | same shape (the turn continues after the decision) |
| `POST /chat/retry` | `{"thread_id": "..."}` | same shape; continues a turn that stopped on an error (502 `{"detail": {message, retryable, steps}}`), without repeating finished steps |
| `GET /threads` | | the caller's saved conversations `[{thread_id, title, created_at, updated_at}]`, newest first |
| `GET /threads/{id}` | | one conversation: `messages` (user text; per answer the tasks with status and the reply), `pending`, `retryable` |
| `DELETE /threads/{id}` | | 204 |
| `GET /tools`, `GET /health` | | tool names / status |

Browser apps must be listed in `CORS_ORIGINS` (default: bulwark-ui on :3000 and bulwark-agent-ui on :3100). The web chat is `../../bulwark-agent-ui`.
**Chat history (PostgreSQL).** Conversations are saved in the Bulwark database, in their own schema `bulwark_chat`:
`chat_threads` (the "Recent chats" list: user, thread, title, created/updated) plus the LangGraph checkpointer tables
`checkpoints`, `checkpoint_blobs`, `checkpoint_writes`, `checkpoint_migrations` (the full conversation state, including an
approval that is still waiting). They survive restarts, and several server instances can share them.
```bash
psql "<database url>" -f sql/01_chat_history.sql     # once; idempotent. Undo: DROP SCHEMA bulwark_chat CASCADE
```
Set `CHAT_DATABASE_URL` (the Bulwark `DATABASE_URL` works; `+asyncpg` is accepted) - use the **session pooler / direct port
5432**, not a transaction pooler. The server checks the tables at start-up and names the script if they are missing; it never
creates tables itself. Without `CHAT_DATABASE_URL` history is kept in memory only (a warning is logged).
Chats belong to the token's user: the server verifies the JWT with `BULWARK_JWT_SECRET` / `BULWARK_JWT_ALGORITHM` exactly like the
Bulwark API and files them under its `sub`, so a user sees the same history after signing in again and nobody can open another
user's chats (forged tokens get 401). Without `BULWARK_JWT_SECRET` chats are filed per token.
On Windows the server runs on a selector event loop (psycopg needs it), so the MCP server must be reached over HTTP
(the default), not `MCP_TRANSPORT=stdio`. The CLI keeps its conversation in memory only.
Tests: `TEST_CHAT_DATABASE_URL=<url> pytest tests/test_history.py` also runs the history tests on PostgreSQL in a throw-away schema.

## Layout
```
src/bulwark_agent/
  graph.py       the LangGraph (state, nodes, approval gate)       tool_index.py  Gemini-embedding tool retrieval
  agent.py       wiring: MCP tools + index + graph + checkpointer   mcp_tools.py   MCP client (HTTP / stdio), read-write detection
  llm.py         Gemini Flash only                                  embeddings.py  Gemini embedding only
  runner.py      start_turn / resume_turn (shared by CLI + server)  prompts.py     system prompt
  cli.py  server.py  auth.py (dev JWT)  config.py
tests/           24 offline tests + 5 end-to-end tests (opt-in)
```

## Tests
```bash
pytest -q          # offline: scripted stand-in for Gemini; covers approval gate, tool routing, memory, trimming, HTTP API
# against the real stack (Bulwark API + sample data + MCP server running):
E2E_MCP_URL=http://127.0.0.1:8765/mcp E2E_JWT_SECRET=<bulwark-api JWT_SECRET> pytest -q tests/test_e2e_real_stack.py
```
The end-to-end tests use a scripted model so no Gemini key is needed; they exercise the real MCP transport, real tools, real API role checks and the real database.

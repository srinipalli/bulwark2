-- Bulwark Assistant chat history (bulwark-chat-server).
-- Everything lives in its own schema, bulwark_chat, next to (not inside) the Bulwark tables.
-- Run once against the Bulwark database:   psql "$DATABASE_URL" -f sql/01_chat_history.sql
-- Safe to run again (IF NOT EXISTS / ON CONFLICT). Undo: see the bottom of this file.

CREATE SCHEMA IF NOT EXISTS bulwark_chat;
SET search_path TO bulwark_chat;

-- ---------------------------------------------------------------------------------------------
-- 1. "Recent chats": one row per conversation and user.
--    user_key = 'sub:<JWT subject>' (verified with BULWARK_JWT_SECRET), or 'tok:<token hash>' when no secret is configured.
--    thread_id is the id the UI uses; the conversation state below is stored under '<user_key>:<thread_id>'.
-- ---------------------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS chat_threads (
    user_key    TEXT        NOT NULL,
    thread_id   TEXT        NOT NULL,
    title       TEXT        NOT NULL,                    -- first question, max 80 characters
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (user_key, thread_id)
);
CREATE INDEX IF NOT EXISTS chat_threads_recent_idx ON chat_threads (user_key, updated_at DESC);

COMMENT ON TABLE chat_threads IS 'Bulwark Assistant: saved conversations per user (Recent chats)';

-- ---------------------------------------------------------------------------------------------
-- 2. Conversation state: the LangGraph Postgres checkpointer tables (langgraph-checkpoint-postgres 3.x).
--    Messages, tool calls/results and a change still waiting for approval are all in here.
--    Same DDL as the library's own migrations 0-9; they are marked as applied in checkpoint_migrations,
--    so the application never has to create or alter tables itself.
-- ---------------------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS checkpoint_migrations (
    v INTEGER PRIMARY KEY
);

CREATE TABLE IF NOT EXISTS checkpoints (
    thread_id            TEXT  NOT NULL,
    checkpoint_ns        TEXT  NOT NULL DEFAULT '',
    checkpoint_id        TEXT  NOT NULL,
    parent_checkpoint_id TEXT,
    type                 TEXT,
    checkpoint           JSONB NOT NULL,
    metadata             JSONB NOT NULL DEFAULT '{}',
    PRIMARY KEY (thread_id, checkpoint_ns, checkpoint_id)
);

CREATE TABLE IF NOT EXISTS checkpoint_blobs (
    thread_id     TEXT  NOT NULL,
    checkpoint_ns TEXT  NOT NULL DEFAULT '',
    channel       TEXT  NOT NULL,
    version       TEXT  NOT NULL,
    type          TEXT  NOT NULL,
    blob          BYTEA,
    PRIMARY KEY (thread_id, checkpoint_ns, channel, version)
);

CREATE TABLE IF NOT EXISTS checkpoint_writes (
    thread_id     TEXT    NOT NULL,
    checkpoint_ns TEXT    NOT NULL DEFAULT '',
    checkpoint_id TEXT    NOT NULL,
    task_id       TEXT    NOT NULL,
    idx           INTEGER NOT NULL,
    channel       TEXT    NOT NULL,
    type          TEXT,
    blob          BYTEA   NOT NULL,
    task_path     TEXT    NOT NULL DEFAULT '',
    PRIMARY KEY (thread_id, checkpoint_ns, checkpoint_id, task_id, idx)
);

CREATE INDEX IF NOT EXISTS checkpoints_thread_id_idx       ON checkpoints (thread_id);
CREATE INDEX IF NOT EXISTS checkpoint_blobs_thread_id_idx  ON checkpoint_blobs (thread_id);
CREATE INDEX IF NOT EXISTS checkpoint_writes_thread_id_idx ON checkpoint_writes (thread_id);

INSERT INTO checkpoint_migrations (v) SELECT generate_series(0, 9) ON CONFLICT (v) DO NOTHING;

RESET search_path;

-- ---------------------------------------------------------------------------------------------
-- Undo (deletes all saved chats):
--   DROP SCHEMA bulwark_chat CASCADE;
-- ---------------------------------------------------------------------------------------------

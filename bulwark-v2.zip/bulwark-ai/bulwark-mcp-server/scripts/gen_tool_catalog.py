"""Print the tool catalog as markdown tables (keeps the README honest):  python scripts/gen_tool_catalog.py"""
import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from bulwark_mcp import server  # noqa: E402,F401
from bulwark_mcp.registry import mcp  # noqa: E402

AREA = {"dashboard": "Dashboard & users", "vulnerabilities": "Vulnerabilities", "assets": "Assets", "incidents": "Incidents", "solutions": "Solutions",
        "approvals": "Approvals", "execution": "Execution", "insights": "Insights (served by /insights API)", "scans": "Scan ingestion (served by /scans API)"}


async def main():
    groups: dict[str, list] = {}
    for t in await mcp.list_tools():
        mod = mcp._tool_manager._tools[t.name].fn.__module__.rsplit(".", 1)[-1]
        groups.setdefault(AREA[mod], []).append(t)
    for area in AREA.values():
        if area not in groups:
            continue
        print(f"\n**{area}**\n\n| Tool | Access | What it does |\n|---|---|---|")
        for t in groups[area]:
            doc = " ".join((t.description or "").split()).replace("|", "/")
            doc = doc[:doc.find(". ") + 1] if 0 < doc.find(". ") <= 170 else (doc[:167] + "..." if len(doc) > 170 else doc)
            print(f"| `{t.name}` | {'read' if t.annotations.readOnlyHint else 'WRITE'} | {doc} |")


asyncio.run(main())

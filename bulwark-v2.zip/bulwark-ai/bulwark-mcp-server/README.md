# Bulwark MCP Server

Exposes Bulwark as **60 MCP tools**. It is a **thin REST client**: every tool calls the Bulwark API and nothing else. There is no database connection, no Gemini call and no subprocess in this server.

* **Existing endpoints**: typed wrappers over the Bulwark API. They accept what people say (`INC-57`, `CVE-2024-1234`, an asset name, a solution title) and resolve it to the UUIDs the API needs.
* **New functionality** (semantic incident search, solution finder, portfolio risk report, audit trail, one-call incident briefing, scan workbook validation and ingestion) lives in the Bulwark API as two modules, `/insights` and `/scans` (`bulwark-api/src/bulwark/modules/`); the MCP tools for them are just calls to those endpoints.

Every tool is flagged `readOnlyHint` true/false so clients can ask a human before running a write.

## Run
```bash
cp .env.example .env            # only BULWARK_API_URL (and BULWARK_API_TOKEN for stdio)
pip install -e ".[dev]"
bulwark-mcp                     # streamable HTTP on http://127.0.0.1:8765/mcp  (GET /health)
bulwark-mcp --transport stdio   # for desktop MCP clients (set BULWARK_API_TOKEN)
```
**Identity.** Over HTTP the caller sends `Authorization: Bearer <Bulwark JWT>`; the server forwards it to the Bulwark API unchanged, so roles are enforced by the API. Over stdio it uses `BULWARK_API_TOKEN`.
Mint a development token with `python scripts/dev_token.py` in `bulwark-api`, or use the agent's `--user/--roles` flags.

**Use it from another MCP client** (stdio example, e.g. Claude Desktop):
```json
{"mcpServers": {"bulwark": {"command": "python", "args": ["-m", "bulwark_mcp", "--transport", "stdio"],
  "cwd": "/path/to/bulwark-mcp-server", "env": {"BULWARK_API_URL": "http://localhost:8000", "BULWARK_API_TOKEN": "<jwt>"}}}}
```

## Layout
```
src/bulwark_mcp/
  server.py      entry point (stdio | streamable-http), /health
  registry.py    the FastMCP instance + read_tool / write_tool decorators
  api.py         async REST client, per-call JWT, readable error mapping (401/403/404/422)
  resolve.py     INC-57 / CVE id / asset name / solution title / user name -> UUID (INC codes via GET /insights/incidents/lookup)
  shape.py       compact list shapes (saves LLM tokens)
  tools/         dashboard, vulnerabilities, assets, incidents, solutions, approvals, execution, insights, scans
tests/           mocked-API tests + a guard test that fails if a DB driver, Gemini SDK or subprocess import appears
scripts/gen_tool_catalog.py   regenerates the table below
```

## Tools

**Dashboard & users**

| Tool | Access | What it does |
|---|---|---|
| `get_dashboard_summary` | read | Headline numbers: open incidents, incidents pending approval, solutions pending review, jobs running/queued/failed, active vulnerabilities, assets patched (%), invento... |
| `get_attention_items` | read | Incidents that need attention first (highest severity / least progress). |
| `list_users` | read | Users known to Bulwark (id, name) - needed to assign an incident to someone. |

**Vulnerabilities**

| Tool | Access | What it does |
|---|---|---|
| `list_vulnerabilities` | read | Search the vulnerability register (CVE id / title text). |
| `get_vulnerability` | read | Full detail of one vulnerability. |
| `create_vulnerability` | WRITE | Register a vulnerability manually (role ANALYST). |
| `update_vulnerability` | WRITE | Edit a vulnerability (role ANALYST). |
| `set_vulnerability_active` | WRITE | Activate or deactivate a vulnerability (role ANALYST). |

**Assets**

| Tool | Access | What it does |
|---|---|---|
| `list_assets` | read | Asset inventory: search name / hostname / OS / team, filter by environment, type, owner team. |
| `get_asset` | read | Full detail of an asset incl. |
| `get_asset_facets` | read | Distinct environments, owner teams and OS names present in the inventory. |
| `create_asset` | WRITE | Add an asset to the inventory. |
| `update_asset` | WRITE | Edit inventory fields of an asset. |
| `set_asset_active` | WRITE | Activate or deactivate an asset. |

**Incidents**

| Tool | Access | What it does |
|---|---|---|
| `list_incidents` | read | Search incidents (title / description / CVE id text); filter by status, severity, assignee. |
| `get_incident` | read | Full incident: assets with status, plan steps, approval, editable flag, allowed next statuses. |
| `get_similar_incidents` | read | Earlier incidents the recommender found similar (vector search), with similarity score and the plan they used. |
| `get_ai_plan` | read | The current AI plan (Gemini) for an incident: outcome, confidence, rationale, ordered steps and solution drafts. |
| `create_incident` | WRITE | Open an incident for a vulnerability (CVE id or UUID). |
| `update_incident` | WRITE | Edit title / description / severity / assignee of an incident (only while editable). |
| `replace_incident_assets` | WRITE | Set the full list of impacted assets (names or UUIDs). |
| `exclude_incident_asset` | WRITE | Exclude one asset from an incident (it no longer counts for resolution). |
| `set_incident_plan` | WRITE | Replace the incident's ordered plan. |
| `clear_incident_plan` | WRITE | Remove all plan steps from an incident (only while editable). |
| `copy_incident_plan` | WRITE | Replace this incident's plan with the plan (solutions, order, on-failure) of another incident, e.g. |
| `apply_ai_plan` | WRITE | Apply the current AI-suggested plan to the incident (role ANALYST). |
| `dismiss_ai_plan` | WRITE | Dismiss the current AI-suggested plan (optionally say why). |
| `submit_incident_for_approval` | WRITE | Lock the plan and send it to approvers. |
| `change_incident_status` | WRITE | Manual status change. |
| `close_incident` | WRITE | Close an incident (finished; a new scan finding can open a new one). |

**Solutions**

| Tool | Access | What it does |
|---|---|---|
| `list_solutions` | read | Solution catalog (the fixes that plans are built from). |
| `get_solution` | read | Solution with all versions (job spec, timeout, retries, status). |
| `suggest_solutions` | read | The API's built-in keyword-overlap suggestions of APPROVED solutions for an incident. |
| `create_solution` | WRITE | Create a solution (role ANALYST). |
| `update_solution` | WRITE | Edit a solution (role ANALYST). |
| `retire_solution` | WRITE | Retire a solution so planners no longer get it offered (role APPROVER). |

**Approvals**

| Tool | Access | What it does |
|---|---|---|
| `get_approvals_summary` | read | How many incident approvals and solution reviews are waiting. |
| `list_incident_approvals` | read | Plans submitted for approval (default: waiting ones), with the submitted plan steps. |
| `list_solution_reviews` | read | Solution versions waiting for (or past) review. |
| `approve_incident` | WRITE | Approve the submitted plan of an incident (role APPROVER). |
| `reject_incident` | WRITE | Reject the submitted plan; the incident returns to editing. |
| `approve_solution_review` | WRITE | Approve a pending solution version so it can be used in plans. |
| `reject_solution_review` | WRITE | Reject a pending solution version. |
| `request_solution_changes` | WRITE | Send a pending solution version back to its author with a comment explaining what to change. |

**Execution**

| Tool | Access | What it does |
|---|---|---|
| `list_executable_incidents` | read | Incidents that are approved / in progress / resolved - the ones the Execution page can run or show. |
| `get_execution_grid` | read | Step x asset matrix for an incident: each cell WAITING / QUEUED / RUNNING / SUCCEEDED / FAILED / CANCELLED, plus can_run. |
| `run_plan_step` | WRITE | Queue one plan step on all impacted assets (or only the named ones) - role OPERATOR. |
| `run_full_plan` | WRITE | Run the rest of the plan on all (or the named) assets - role OPERATOR. |
| `list_runs` | read | Job runs, newest first; filter by incident and/or status. |
| `get_run` | read | One run with incident, step, solution, asset and error. |
| `get_run_logs` | read | Log lines of a run (stdout/stderr). |
| `cancel_run` | WRITE | Cancel a queued or running job (role OPERATOR). |

**Insights (served by /insights API)**

| Tool | Access | What it does |
|---|---|---|
| `semantic_search_incidents` | read | Find incidents by MEANING, not keywords (Gemini embeddings + pgvector cosine, done by the Bulwark API). |
| `find_solutions_for_problem` | read | Rank the APPROVED solution catalog against a free-text problem statement by meaning (done by the Bulwark API). |
| `portfolio_risk_report` | read | Management view: open incidents by severity and status, the oldest open incidents, assets carrying the most active vulnerabilities, mean time to resolve (last 90 days)... |
| `get_audit_trail` | read | Who changed what and when (append-only audit log). |
| `explain_incident` | read | One-call briefing on an incident: what it is, impacted assets by status, the plan, approval state, the best similar incidents, the AI plan, execution progress, and the... |

**Scan ingestion (served by /scans API)**

| Tool | Access | What it does |
|---|---|---|
| `list_scan_workbooks` | read | The .xlsx scan workbooks waiting in the scan inbox folder of the Bulwark API host. |
| `validate_scan_workbook` | read | Dry run of the scan ingestor on one workbook: parses it and reports valid / rejected rows, touching nothing. |
| `ingest_scan_workbook` | WRITE | Run the real scan ingestor on one workbook: upserts vulnerabilities and assets, creates one incident per vulnerability and publishes the events to Kafka. |

## The /insights and /scans endpoints behind the new tools
| Tool | Bulwark API endpoint |
|---|---|
| `semantic_search_incidents` | `GET /insights/incidents/search` |
| `find_solutions_for_problem` | `GET /insights/solutions/search` |
| `portfolio_risk_report` | `GET /insights/risk-report` |
| `get_audit_trail` | `GET /insights/audit` |
| `explain_incident` | `GET /insights/incidents/{INC-57 or uuid}/briefing` |
| (every `INC-<n>` reference) | `GET /insights/incidents/lookup?code=` |
| `list_scan_workbooks`, `validate_scan_workbook`, `ingest_scan_workbook` | `GET /scans/workbooks`, `POST /scans/validate`, `POST /scans/ingest` (role ANALYST) |

Gemini embeddings, pgvector queries and the scan-ingestor CLI therefore run **inside the Bulwark API**, configured in its own `.env` (`GEMINI_API_KEY`, `SCAN_INBOX`, ...). See `bulwark-api/.env.example`.

## Tests
```bash
pytest -q       # 16 tests with a mocked Bulwark API; no database, no network, no Gemini key
```

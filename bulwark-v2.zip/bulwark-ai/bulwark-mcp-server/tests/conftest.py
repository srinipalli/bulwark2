import json

import httpx
import pytest

from bulwark_mcp import server  # noqa: F401  (registers tools)
from bulwark_mcp.api import BulwarkApi, get_api, set_api
from bulwark_mcp.config import Settings
from bulwark_mcp.registry import mcp


class FakeBulwark:
    """Routes (method, path) -> callable(request) -> (status, json). Records every request."""

    def __init__(self):
        self.routes, self.calls = {}, []

    def on(self, method, path, response, status=200):
        self.routes[(method, path)] = (status, response)

    def handler(self, request: httpx.Request) -> httpx.Response:
        path = request.url.path.removeprefix("/api/v1")
        body = json.loads(request.content) if request.content else None
        self.calls.append({"method": request.method, "path": path, "params": dict(request.url.params), "body": body,
                           "auth": request.headers.get("authorization")})
        hit = self.routes.get((request.method, path))
        if hit is None:
            return httpx.Response(404, json={"error": {"code": "not_found", "message": f"no route {request.method} {path}"}})
        status, resp = hit
        if callable(resp):
            resp = resp(request)
            if isinstance(resp, tuple):                     # a callable may answer (status, body)
                status, resp = resp
        return httpx.Response(status, json=resp)


@pytest.fixture
def settings(monkeypatch):
    s = Settings(_env_file=None, bulwark_api_url="http://bulwark.test", bulwark_api_token="test-token")
    monkeypatch.setattr("bulwark_mcp.config.get_settings", lambda: s)
    for mod in ("api", "resolve"):
        monkeypatch.setattr(f"bulwark_mcp.{mod}.get_settings", lambda: s, raising=False)
    return s


@pytest.fixture
async def fake(settings):
    f = FakeBulwark()
    set_api(BulwarkApi(settings, transport=httpx.MockTransport(f.handler)))
    yield f
    await get_api().aclose()
    set_api(None)


async def call(name: str, **args):
    """Call a tool in-process exactly as an MCP client would, return the structured result."""
    res = await mcp.call_tool(name, args)
    if isinstance(res, tuple):
        res = res[1]
        return res.get("result", res) if isinstance(res, dict) else res
    if isinstance(res, dict):
        return res.get("result", res)
    return json.loads(res[0].text)

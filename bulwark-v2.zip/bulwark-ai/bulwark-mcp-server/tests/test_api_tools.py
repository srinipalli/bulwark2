import pytest
from conftest import call
from mcp.server.fastmcp.exceptions import ToolError

from bulwark_mcp.registry import mcp

INC = {"id": "11111111-1111-4111-8111-111111111111", "code": "INC-57", "title": "Patch log4j", "severity": "CRITICAL", "status": "OPEN",
       "description": "d", "vulnerability": {"id": "v1", "cve_id": "CVE-2021-44228", "title": "log4j", "is_active": True}, "assignee": None,
       "assets_count": 2, "plan_steps": 0, "patched_count": 0, "created_at": "2026-10-01T00:00:00Z", "updated_at": "2026-10-02T00:00:00Z"}
DETAIL = {**INC, "editable": True, "allowed_statuses": ["PENDING_APPROVAL", "CLOSED"], "plan": [], "approval": None,
          "assets": [{"incident_asset_id": "ia-1", "asset": {"id": "a-1", "name": "web-01", "asset_type": "SYSTEM", "environment": "prod"}, "status": "PENDING", "last_error": None},
                     {"incident_asset_id": "ia-2", "asset": {"id": "a-2", "name": "web-02", "asset_type": "SYSTEM", "environment": "prod"}, "status": "FAILED", "last_error": "boom"}]}
PAGE = {"items": [INC], "total": 1, "page": 1, "size": 20}


def lookup(fake):
    """Teach the fake API the code -> id endpoint every INC-<n> reference goes through."""
    def handler(req):
        code = req.url.params["code"]
        if code == "INC-57":
            return {"id": INC["id"], "code": "INC-57", "title": INC["title"], "status": INC["status"]}
        return 404, {"error": {"code": "not_found", "message": f"Incident {code} not found"}}
    fake.on("GET", "/insights/incidents/lookup", handler)


async def test_every_tool_declares_read_or_write():
    tools = await mcp.list_tools()
    assert len(tools) >= 55
    assert all(t.annotations is not None and t.annotations.readOnlyHint is not None for t in tools)
    writes = {t.name for t in tools if not t.annotations.readOnlyHint}
    assert {"approve_incident", "run_full_plan", "create_incident", "ingest_scan_workbook", "close_incident"} <= writes
    assert not ({"explain_incident", "semantic_search_incidents", "get_audit_trail", "portfolio_risk_report"} & writes)


async def test_token_is_forwarded_and_lists_are_slim(fake):
    fake.on("GET", "/incidents", PAGE)
    r = await call("list_incidents", status="OPEN", severity="CRITICAL")
    assert fake.calls[0]["auth"] == "Bearer test-token"
    assert fake.calls[0]["params"]["status"] == "OPEN"
    assert r["items"][0] == {"id": INC["id"], "code": "INC-57", "title": "Patch log4j", "severity": "CRITICAL", "status": "OPEN",
                             "cve_id": "CVE-2021-44228", "assets": 2, "plan_steps": 0, "patched": 0, "assignee": None, "updated_at": INC["updated_at"]}


async def test_missing_token_is_a_clear_error(fake, settings, monkeypatch):
    monkeypatch.setattr(settings, "bulwark_api_token", type(settings.bulwark_api_token)(""))
    with pytest.raises(ToolError, match="No Bulwark token"):
        await call("get_dashboard_summary")


@pytest.mark.parametrize("status,msg,expect", [(403, {"error": {"code": "forbidden", "message": "Requires one of roles: OPERATOR"}}, "Not allowed"),
                                               (401, {"error": {"message": "x"}}, "Not authenticated"),
                                               (422, {"detail": [{"loc": ["body", "reason"], "msg": "too short"}]}, "reason: too short")])
async def test_api_errors_become_readable(fake, status, msg, expect):
    fake.on("GET", "/dashboard/summary", msg, status)
    with pytest.raises(ToolError, match=expect):
        await call("get_dashboard_summary")


async def test_incident_code_resolves_through_the_lookup_endpoint(fake):
    lookup(fake)
    fake.on("GET", f"/incidents/{INC['id']}", DETAIL)
    r = await call("get_incident", incident="INC-57")
    assert r["code"] == "INC-57"
    assert fake.calls[-1]["path"] == f"/incidents/{INC['id']}"
    with pytest.raises(ToolError, match="not found"):
        await call("get_incident", incident="INC-999")


async def test_approve_incident_finds_the_pending_approval_by_code(fake):
    lookup(fake)
    fake.on("GET", "/approvals/incidents", {"items": [{"id": "ap-1", "status": "PENDING", "incident_id": INC["id"], "incident_code": "INC-57",
                "incident_title": "t", "severity": "CRITICAL", "cve_id": "CVE-1", "assets_count": 2, "plan": [{"step_no": 1, "title": "Patch"}],
                "requested_by": "ravi", "requested_at": "x", "decided_by": None, "comment": None}], "total": 1, "page": 1, "size": 100})
    fake.on("POST", "/approvals/incidents/ap-1/approve", {"id": "ap-1", "status": "APPROVED", "incident_id": INC["id"], "incident_code": "INC-57",
            "incident_title": "t", "severity": "CRITICAL", "cve_id": "CVE-1", "assets_count": 2, "plan": [], "requested_by": "ravi", "requested_at": "x",
            "decided_by": "me", "comment": "ok"})
    r = await call("approve_incident", incident="INC-57", comment="ok")
    assert r["status"] == "APPROVED"
    assert fake.calls[-1]["body"] == {"comment": "ok"}


async def test_run_step_maps_asset_names_to_incident_asset_ids(fake):
    lookup(fake)
    fake.on("GET", f"/incidents/{INC['id']}", DETAIL)
    fake.on("POST", f"/execution/incidents/{INC['id']}/steps/2/run", [{"incident_asset_id": "ia-2", "asset_name": "web-02", "outcome": "QUEUED"}])
    await call("run_plan_step", incident="INC-57", step_no=2, assets=["web-02"])
    assert fake.calls[-1]["body"] == {"incident_asset_ids": ["ia-2"]}
    with pytest.raises(ToolError, match="not part of this incident"):
        await call("run_plan_step", incident="INC-57", step_no=1, assets=["db-09"])


async def test_set_plan_resolves_solution_titles(fake):
    lookup(fake)
    fake.on("GET", "/solutions", {"items": [{"id": "s-1", "title": "Patch OpenSSL"}], "total": 1, "page": 1, "size": 50})
    fake.on("PUT", f"/incidents/{INC['id']}/plan", DETAIL)
    await call("set_incident_plan", incident="INC-57", steps=[{"solution": "Patch OpenSSL", "on_failure": "STOP_ALL"}])
    assert fake.calls[-1]["body"] == {"steps": [{"solution_id": "s-1", "on_failure": "STOP_ALL"}]}


async def test_apply_ai_plan_uses_the_current_plan_id(fake):
    lookup(fake)
    fake.on("GET", f"/incidents/{INC['id']}/ai-plan", {"plan_id": "plan-9"})
    fake.on("POST", f"/incidents/{INC['id']}/ai-plan/apply", DETAIL)
    await call("apply_ai_plan", incident="INC-57")
    assert fake.calls[-1]["body"] == {"plan_id": "plan-9"}


async def test_explain_incident_calls_the_briefing_endpoint(fake):
    brief = {"incident": {"code": "INC-57"}, "assets": {"count": 2, "by_status": {"PENDING": 1, "FAILED": 1}, "failed": []}, "next_actions": ["x"]}
    fake.on("GET", "/insights/incidents/INC-57/briefing", brief)
    fake.on("GET", f"/insights/incidents/{INC['id']}/briefing", brief)
    assert (await call("explain_incident", incident="INC-57"))["assets"]["count"] == 2
    assert (await call("explain_incident", incident=INC["id"]))["incident"]["code"] == "INC-57"
    assert [c["path"] for c in fake.calls] == ["/insights/incidents/INC-57/briefing", f"/insights/incidents/{INC['id']}/briefing"]
    assert all(c["auth"] == "Bearer test-token" for c in fake.calls)


async def test_search_and_report_tools_are_plain_rest_calls(fake):
    fake.on("GET", "/insights/incidents/search", {"query": "q", "results": [{"code": "INC-12", "similarity": 0.9}], "embedding_model": "m"})
    fake.on("GET", "/insights/solutions/search", [{"title": "Upgrade OpenSSL", "score": 0.8}])
    fake.on("GET", "/insights/risk-report", {"oldest_open_incidents": []})
    r = await call("semantic_search_incidents", query="java rce", limit=3, status="OPEN", min_similarity=0.2)
    assert r["results"][0]["code"] == "INC-12"
    assert fake.calls[-1]["params"] == {"q": "java rce", "limit": "3", "min_similarity": "0.2", "status": "OPEN"}
    assert (await call("find_solutions_for_problem", problem="openssl", limit=2))[0]["title"] == "Upgrade OpenSSL"
    assert fake.calls[-1]["params"] == {"q": "openssl", "limit": "2"}
    await call("portfolio_risk_report", top_n=3)
    assert fake.calls[-1]["params"] == {"top_n": "3"}


async def test_audit_trail_resolves_the_code_then_asks_the_api(fake):
    lookup(fake)
    fake.on("GET", "/insights/audit", [{"id": 1, "action": "incident.plan_replaced"}])
    r = await call("get_audit_trail", entity_type="incident", entity="INC-57", limit=5)
    assert r[0]["action"] == "incident.plan_replaced"
    assert fake.calls[-1]["params"] == {"limit": "5", "entity_type": "incident", "entity_id": INC["id"]}
    with pytest.raises(ToolError, match="entity_type"):
        await call("get_audit_trail", entity="INC-57")


async def test_scan_tools_call_the_scans_endpoints(fake):
    fake.on("GET", "/scans/workbooks", [{"file": "a.xlsx", "size_kb": 1.0}])
    fake.on("POST", "/scans/validate", {"file": "a.xlsx", "exit_code": 0})
    fake.on("POST", "/scans/ingest", {"file": "a.xlsx", "exit_code": 0})
    assert (await call("list_scan_workbooks"))[0]["file"] == "a.xlsx"
    await call("validate_scan_workbook", file_name="a.xlsx")
    await call("ingest_scan_workbook", file_name="a.xlsx")
    assert [(c["method"], c["path"], c["body"]) for c in fake.calls[1:]] == [
        ("POST", "/scans/validate", {"file_name": "a.xlsx"}), ("POST", "/scans/ingest", {"file_name": "a.xlsx"})]
    fake.on("POST", "/scans/ingest", {"error": {"code": "forbidden", "message": "Requires one of roles: ANALYST"}}, 403)
    with pytest.raises(ToolError, match="Not allowed"):
        await call("ingest_scan_workbook", file_name="a.xlsx")


def test_mcp_server_has_no_direct_infrastructure_access():
    """The MCP server is a REST client only: no database driver, no Gemini SDK, no subprocess, no shell."""
    import re
    from pathlib import Path
    src = Path(__file__).resolve().parents[1] / "src" / "bulwark_mcp"
    banned = re.compile(r"^\s*(?:import|from)\s+(psycopg|asyncpg|sqlalchemy|google|subprocess|kafka|confluent_kafka|os\.system)\b", re.MULTILINE)
    offenders = [f.name for f in src.rglob("*.py") if banned.search(f.read_text()) or "create_subprocess" in f.read_text()]
    assert offenders == []
    assert not (src / "db.py").exists() and not (src / "embeddings.py").exists()

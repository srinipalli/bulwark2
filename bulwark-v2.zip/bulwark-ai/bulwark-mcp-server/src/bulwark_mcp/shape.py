"""Compact shapes for list results: an LLM does not need every column, and long lists cost tokens."""
from __future__ import annotations


def page(data: dict, fn) -> dict:
    return {"total": data["total"], "page": data["page"], "size": data["size"], "items": [fn(x) for x in data["items"]]}


def incident_row(i: dict) -> dict:
    return {"id": i["id"], "code": i["code"], "title": i["title"], "severity": i["severity"], "status": i["status"],
            "cve_id": (i.get("vulnerability") or {}).get("cve_id"), "assets": i.get("assets_count"),
            "plan_steps": i.get("plan_steps"), "patched": i.get("patched_count"),
            "assignee": (i.get("assignee") or {}).get("full_name"), "updated_at": i.get("updated_at")}


def vuln_row(v: dict) -> dict:
    oi = v.get("open_incident") or {}
    return {"id": v["id"], "cve_id": v["cve_id"], "title": v["title"], "severity": v["severity"], "cvss": v.get("cvss_score"),
            "is_active": v["is_active"], "source": v.get("source"), "assets": [a["name"] for a in v.get("assets", [])][:10],
            "assets_count": len(v.get("assets", [])), "open_incident": oi.get("code"), "open_incident_status": oi.get("status")}


def asset_row(a: dict) -> dict:
    return {"id": a["id"], "name": a["name"], "type": a["asset_type"], "environment": a["environment"],
            "os": " ".join(x for x in (a.get("os_name"), a.get("os_version")) if x) or None, "owner_team": a.get("owner_team"),
            "is_active": a["is_active"], "vulnerabilities": a.get("vulnerabilities_count"), "open_incidents": a.get("open_incidents_count")}


def solution_row(s: dict) -> dict:
    return {"id": s["id"], "title": s["title"], "status": s["status"], "latest_version": s["latest_version_no"],
            "has_approved_version": s["has_approved_version"], "executor": s["executor"], "risk": s["risk_level"],
            "retired": s["is_retired"], "description": (s.get("description") or "")[:200] or None}


def incident_approval_row(a: dict) -> dict:
    return {"approval_id": a["id"], "status": a["status"], "incident": a["incident_code"], "incident_id": a["incident_id"],
            "title": a["incident_title"], "severity": a["severity"], "cve_id": a["cve_id"], "assets": a["assets_count"],
            "plan": [f"{p.get('step_no')}. {p.get('title')}" for p in a.get("plan", [])], "requested_by": a.get("requested_by"),
            "requested_at": a["requested_at"], "decided_by": a.get("decided_by"), "comment": a.get("comment")}


def solution_review_row(r: dict) -> dict:
    return {"review_id": r["id"], "status": r["status"], "solution": r["title"], "solution_id": r["solution_id"],
            "version": r["version_no"], "executor": r["executor"], "risk": r["risk_level"], "requested_by": r.get("requested_by"),
            "requested_at": r["requested_at"], "reviewer": r.get("reviewer"), "comment": r.get("comment")}


def run_row(r: dict) -> dict:
    return {"id": r["id"], "incident_id": r["incident_id"], "status": r["status"], "attempt": r["attempt"], "exit_code": r.get("exit_code"),
            "error": r.get("error_message"), "queued_at": r["queued_at"], "started_at": r.get("started_at"), "finished_at": r.get("finished_at"),
            **({"incident": r["incident_code"], "step": r["step_no"], "solution": r["solution_title"], "asset": r["asset_name"]} if "asset_name" in r else {})}

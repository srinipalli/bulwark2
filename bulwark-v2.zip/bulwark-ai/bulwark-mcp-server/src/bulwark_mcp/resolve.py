"""Turn what people say ("INC-57", "CVE-2024-1234", "web-01", "Patch OpenSSL") into the UUIDs the API needs."""
from __future__ import annotations

import re
from uuid import UUID

from mcp.server.fastmcp import Context
from mcp.server.fastmcp.exceptions import ToolError

from .api import get_api


def is_uuid(s: str) -> bool:
    try:
        UUID(s.strip())
        return True
    except ValueError:
        return False


async def incident_id(ctx: Context, ref: str) -> str:
    """'INC-57', '57' or a UUID -> incident UUID."""
    ref = ref.strip()
    if is_uuid(ref):
        return ref
    m = re.fullmatch(r"(?i)(?:inc[-\s]?)?(\d+)", ref)
    if not m:
        raise ToolError("Give the incident as a code like INC-57 or as its UUID.")
    data = await get_api().get("/insights/incidents/lookup", ctx, code=f"INC-{int(m.group(1))}")      # served by the Bulwark API
    return data["id"]


async def vulnerability_id(ctx: Context, ref: str) -> str:
    """CVE id (exact) or UUID -> vulnerability UUID."""
    ref = ref.strip()
    if is_uuid(ref):
        return ref
    data = await get_api().get("/vulnerabilities", ctx, q=ref, size=50)
    exact = [v for v in data["items"] if v["cve_id"].lower() == ref.lower()]
    if exact:
        return exact[0]["id"]
    if len(data["items"]) == 1:
        return data["items"][0]["id"]
    raise ToolError(f"Vulnerability '{ref}' not found" + (f" (or ambiguous: {len(data['items'])} matches)." if data["items"] else "."))


async def asset_id(ctx: Context, ref: str) -> str:
    """Asset name (exact) or UUID -> asset UUID."""
    ref = ref.strip()
    if is_uuid(ref):
        return ref
    data = await get_api().get("/assets/inventory", ctx, q=ref, size=50)
    exact = [a for a in data["items"] if a["name"].lower() == ref.lower()]
    if exact:
        return exact[0]["id"]
    if len(data["items"]) == 1:
        return data["items"][0]["id"]
    raise ToolError(f"Asset '{ref}' not found" + (f" (or ambiguous: {len(data['items'])} matches)." if data["items"] else "."))


async def solution_id(ctx: Context, ref: str) -> str:
    """Solution title (exact) or UUID -> solution UUID."""
    ref = ref.strip()
    if is_uuid(ref):
        return ref
    data = await get_api().get("/solutions", ctx, q=ref, size=50)
    exact = [s for s in data["items"] if s["title"].lower() == ref.lower()]
    if exact:
        return exact[0]["id"]
    if len(data["items"]) == 1:
        return data["items"][0]["id"]
    raise ToolError(f"Solution '{ref}' not found" + (f" (or ambiguous: {len(data['items'])} matches)." if data["items"] else "."))


async def user_id(ctx: Context, ref: str) -> str:
    """User name / e-mail fragment or UUID -> user UUID."""
    ref = ref.strip()
    if is_uuid(ref):
        return ref
    users = await get_api().get("/users", ctx)
    hits = [u for u in users if ref.lower() in u["full_name"].lower() or ref.lower() == str(u.get("email", "")).lower()]
    exact = [u for u in hits if u["full_name"].lower() == ref.lower()]
    hits = exact or hits
    if len(hits) == 1:
        return hits[0]["id"]
    raise ToolError(f"User '{ref}' " + ("is ambiguous: " + ", ".join(u["full_name"] for u in hits[:5]) if hits else "not found."))


async def incident_asset_ids(ctx: Context, incident_uuid: str, refs: list[str] | None) -> list[str] | None:
    """Asset names / asset UUIDs / incident_asset UUIDs of ONE incident -> incident_asset ids (None = all assets)."""
    if not refs:
        return None
    detail = await get_api().get(f"/incidents/{incident_uuid}", ctx)
    out = []
    for ref in refs:
        r = ref.strip().lower()
        hit = [a for a in detail["assets"] if r in (a["incident_asset_id"].lower(), a["asset"]["id"].lower(), a["asset"]["name"].lower())]
        if not hit:
            raise ToolError(f"Asset '{ref}' is not part of this incident. Its assets: " + ", ".join(a["asset"]["name"] for a in detail["assets"][:20]))
        out.append(hit[0]["incident_asset_id"])
    return out

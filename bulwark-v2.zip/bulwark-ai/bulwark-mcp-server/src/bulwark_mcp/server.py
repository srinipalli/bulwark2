"""Entry point:  bulwark-mcp [--transport stdio|streamable-http] [--host H] [--port P]"""
from __future__ import annotations

import argparse
import logging

from starlette.requests import Request
from starlette.responses import JSONResponse

from . import tools  # noqa: F401  (registers the tools)
from .config import get_settings
from .registry import mcp


@mcp.custom_route("/health", methods=["GET"])
async def health(_: Request) -> JSONResponse:
    return JSONResponse({"status": "ok", "tools": len(await mcp.list_tools())})


def main() -> None:
    s = get_settings()
    ap = argparse.ArgumentParser(description="Bulwark MCP server")
    ap.add_argument("--transport", choices=["stdio", "streamable-http"], default=s.mcp_transport)
    ap.add_argument("--host", default=s.mcp_host)
    ap.add_argument("--port", type=int, default=s.mcp_port)
    a = ap.parse_args()
    logging.basicConfig(level=logging.INFO)
    mcp.settings.host, mcp.settings.port = a.host, a.port
    mcp.run(transport=a.transport)


if __name__ == "__main__":
    main()

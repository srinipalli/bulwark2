from __future__ import annotations

from typing import Literal

from mcp.server.fastmcp import Context

from .. import resolve
from ..api import get_api
from ..registry import read_tool, write_tool
from ..shape import page, run_row

RunStatus = Literal["QUEUED", "RUNNING", "SUCCEEDED", "FAILED", "CANCELLED"]


@read_tool("Executable incidents")
async def list_executable_incidents(ctx: Context) -> list[dict]:
    """Incidents that are approved / in progress / resolved - the ones the Execution page can run or show."""
    return await get_api().get("/execution/incidents", ctx)


@read_tool("Execution grid")
async def get_execution_grid(ctx: Context, incident: str) -> dict:
    """Step x asset matrix for an incident: each cell WAITING / QUEUED / RUNNING / SUCCEEDED / FAILED / CANCELLED, plus can_run."""
    g = await get_api().get(f"/execution/incidents/{await resolve.incident_id(ctx, incident)}/grid", ctx)
    return {"incident": g["incident"], "can_run": g["can_run"],
            "steps": [f"{s['step_no']}. {s['title']} (v{s['version_no']}, {s['executor']}, on failure {s['on_failure']})" for s in g["steps"]],
            "assets": [{"asset": r["asset_name"], "environment": r["environment"], "status": r["status"],
                        "steps": {c["step_no"]: c["status"] + (f" - {c['error_message']}" if c.get("error_message") else "") for c in r["cells"]}}
                       for r in g["rows"]]}


@write_tool("Run one plan step")
async def run_plan_step(ctx: Context, incident: str, step_no: int, assets: list[str] | None = None) -> list[dict]:
    """Queue one plan step on all impacted assets (or only the named ones) - role OPERATOR. Idempotent: an existing live or succeeded run is
    returned, never duplicated; re-running after a FAILED run queues a retry. The worker executes it."""
    iid = await resolve.incident_id(ctx, incident)
    body = {"incident_asset_ids": await resolve.incident_asset_ids(ctx, iid, assets)}
    return await get_api().post(f"/execution/incidents/{iid}/steps/{step_no}/run", ctx, body if body["incident_asset_ids"] else None)


@write_tool("Run the whole plan")
async def run_full_plan(ctx: Context, incident: str, assets: list[str] | None = None) -> list[dict]:
    """Run the rest of the plan on all (or the named) assets - role OPERATOR. Each asset continues with its next step after a success."""
    iid = await resolve.incident_id(ctx, incident)
    body = {"incident_asset_ids": await resolve.incident_asset_ids(ctx, iid, assets)}
    return await get_api().post(f"/execution/incidents/{iid}/run", ctx, body if body["incident_asset_ids"] else None)


@read_tool("List job runs")
async def list_runs(ctx: Context, incident: str | None = None, status: RunStatus | None = None, page_no: int = 1, size: int = 20) -> dict:
    """Job runs, newest first; filter by incident and/or status."""
    iid = await resolve.incident_id(ctx, incident) if incident else None
    return page(await get_api().get("/execution/runs", ctx, incident_id=iid, status=status, page=page_no, size=min(size, 100)), run_row)


@read_tool("Get job run")
async def get_run(ctx: Context, run_id: str) -> dict:
    """One run with incident, step, solution, asset and error."""
    return run_row(await get_api().get(f"/execution/runs/{run_id}", ctx))


@read_tool("Job run logs")
async def get_run_logs(ctx: Context, run_id: str, after_id: int = 0, limit: int = 100) -> list[dict]:
    """Log lines of a run (stdout/stderr). Pass the last id you saw as after_id to continue."""
    return await get_api().get(f"/execution/runs/{run_id}/logs", ctx, after_id=after_id, limit=max(1, min(limit, 500)))


@write_tool("Cancel job run", destructive=True)
async def cancel_run(ctx: Context, run_id: str) -> dict:
    """Cancel a queued or running job (role OPERATOR)."""
    return run_row(await get_api().post(f"/execution/runs/{run_id}/cancel", ctx))

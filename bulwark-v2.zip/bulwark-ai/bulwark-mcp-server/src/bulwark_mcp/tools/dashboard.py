from mcp.server.fastmcp import Context

from ..api import get_api
from ..registry import read_tool


@read_tool("Dashboard summary")
async def get_dashboard_summary(ctx: Context) -> dict:
    """Headline numbers: open incidents, incidents pending approval, solutions pending review, jobs running/queued/failed,
    active vulnerabilities, assets patched (%), inventory size."""
    return await get_api().get("/dashboard/summary", ctx)


@read_tool("Items needing attention")
async def get_attention_items(ctx: Context, limit: int = 10) -> list[dict]:
    """Incidents that need attention first (highest severity / least progress). limit 1-50."""
    return await get_api().get("/dashboard/attention", ctx, limit=max(1, min(limit, 50)))


@read_tool("List Bulwark users")
async def list_users(ctx: Context) -> list[dict]:
    """Users known to Bulwark (id, name) - needed to assign an incident to someone."""
    return await get_api().get("/users", ctx)

from __future__ import annotations

from typing import Literal

from mcp.server.fastmcp import Context
from mcp.server.fastmcp.exceptions import ToolError
from pydantic import BaseModel

from .. import resolve
from ..api import get_api
from ..registry import read_tool, write_tool
from ..shape import incident_row, page

Severity = Literal["LOW", "MEDIUM", "HIGH", "CRITICAL"]
IncStatus = Literal["OPEN", "PENDING_APPROVAL", "APPROVED", "REJECTED", "IN_PROGRESS", "RESOLVED", "CLOSED"]


class PlanStepArg(BaseModel):
    solution: str                                              # solution title or UUID (must have an APPROVED version)
    on_failure: Literal["STOP_ASSET", "CONTINUE", "STOP_ALL"] = "STOP_ASSET"


@read_tool("List incidents")
async def list_incidents(ctx: Context, q: str | None = None, status: IncStatus | None = None, severity: Severity | None = None,
                         assignee: str | None = None, page_no: int = 1, size: int = 20) -> dict:
    """Search incidents (title / description / CVE id text); filter by status, severity, assignee. Newest first."""
    aid = await resolve.user_id(ctx, assignee) if assignee else None
    data = await get_api().get("/incidents", ctx, q=q, status=status, severity=severity, assignee_id=aid, page=page_no, size=min(size, 100))
    return page(data, incident_row)


@read_tool("Get incident")
async def get_incident(ctx: Context, incident: str) -> dict:
    """Full incident: assets with status, plan steps, approval, editable flag, allowed next statuses. `incident` = INC-57 or UUID."""
    return await get_api().get(f"/incidents/{await resolve.incident_id(ctx, incident)}", ctx)


@read_tool("Similar incidents with plans")
async def get_similar_incidents(ctx: Context, incident: str) -> list[dict]:
    """Earlier incidents the recommender found similar (vector search), with similarity score and the plan they used."""
    return await get_api().get(f"/incidents/{await resolve.incident_id(ctx, incident)}/similar", ctx)


@read_tool("AI-suggested plan")
async def get_ai_plan(ctx: Context, incident: str) -> dict | None:
    """The current AI plan (Gemini) for an incident: outcome, confidence, rationale, ordered steps and solution drafts. null if none yet."""
    return await get_api().get(f"/incidents/{await resolve.incident_id(ctx, incident)}/ai-plan", ctx)


@write_tool("Create incident")
async def create_incident(ctx: Context, vulnerability: str, title: str | None = None, description: str | None = None,
                          severity: Severity | None = None, assignee: str | None = None, assets: list[str] | None = None) -> dict:
    """Open an incident for a vulnerability (CVE id or UUID). Defaults: title, severity and assets come from the vulnerability. One open incident per vulnerability."""
    body = {"vulnerability_id": await resolve.vulnerability_id(ctx, vulnerability), "title": title, "description": description, "severity": severity}
    if assignee:
        body["assignee_id"] = await resolve.user_id(ctx, assignee)
    if assets:
        body["asset_ids"] = [await resolve.asset_id(ctx, a) for a in assets]
    return await get_api().post("/incidents", ctx, {k: v for k, v in body.items() if v is not None})


@write_tool("Update incident")
async def update_incident(ctx: Context, incident: str, title: str | None = None, description: str | None = None,
                          severity: Severity | None = None, assignee: str | None = None) -> dict:
    """Edit title / description / severity / assignee of an incident (only while editable)."""
    body = {"title": title, "description": description, "severity": severity}
    body = {k: v for k, v in body.items() if v is not None}
    if assignee:
        body["assignee_id"] = await resolve.user_id(ctx, assignee)
    return await get_api().patch(f"/incidents/{await resolve.incident_id(ctx, incident)}", ctx, body)


@write_tool("Replace incident assets")
async def replace_incident_assets(ctx: Context, incident: str, assets: list[str]) -> dict:
    """Set the full list of impacted assets (names or UUIDs). Only while the incident is editable."""
    ids = [await resolve.asset_id(ctx, a) for a in assets]
    return await get_api().put(f"/incidents/{await resolve.incident_id(ctx, incident)}/assets", ctx, {"asset_ids": ids})


@write_tool("Exclude asset from incident")
async def exclude_incident_asset(ctx: Context, incident: str, asset: str, reason: str) -> dict:
    """Exclude one asset from an incident (it no longer counts for resolution). A reason is required."""
    iid = await resolve.incident_id(ctx, incident)
    (ia,) = await resolve.incident_asset_ids(ctx, iid, [asset]) or [None]
    if not ia:
        raise ToolError("Say which asset to exclude.")
    return await get_api().post(f"/incidents/{iid}/assets/{ia}/exclude", ctx, {"reason": reason})


@write_tool("Set incident plan")
async def set_incident_plan(ctx: Context, incident: str, steps: list[PlanStepArg]) -> dict:
    """Replace the incident's ordered plan. Each step names an APPROVED solution (title or UUID) and what to do on failure."""
    iid = await resolve.incident_id(ctx, incident)
    body = {"steps": [{"solution_id": await resolve.solution_id(ctx, s.solution), "on_failure": s.on_failure} for s in steps]}
    return await get_api().put(f"/incidents/{iid}/plan", ctx, body)


@write_tool("Clear incident plan", destructive=True)
async def clear_incident_plan(ctx: Context, incident: str) -> dict:
    """Remove all plan steps from an incident (only while editable)."""
    return await get_api().delete(f"/incidents/{await resolve.incident_id(ctx, incident)}/plan", ctx)


@write_tool("Copy plan from another incident")
async def copy_incident_plan(ctx: Context, incident: str, source_incident: str) -> dict:
    """Replace this incident's plan with the plan (solutions, order, on-failure) of another incident, e.g. a similar one."""
    iid, src = await resolve.incident_id(ctx, incident), await resolve.incident_id(ctx, source_incident)
    return await get_api().post(f"/incidents/{iid}/plan/copy-from", ctx, {"source_incident_id": src})


@write_tool("Apply AI plan")
async def apply_ai_plan(ctx: Context, incident: str) -> dict:
    """Apply the current AI-suggested plan to the incident (role ANALYST). It still has to be submitted and approved afterwards."""
    iid = await resolve.incident_id(ctx, incident)
    plan = await get_api().get(f"/incidents/{iid}/ai-plan", ctx)
    if not plan:
        raise ToolError("This incident has no AI plan yet.")
    return await get_api().post(f"/incidents/{iid}/ai-plan/apply", ctx, {"plan_id": plan["plan_id"]})


@write_tool("Dismiss AI plan")
async def dismiss_ai_plan(ctx: Context, incident: str, comment: str | None = None) -> dict | None:
    """Dismiss the current AI-suggested plan (optionally say why)."""
    iid = await resolve.incident_id(ctx, incident)
    plan = await get_api().get(f"/incidents/{iid}/ai-plan", ctx)
    if not plan:
        raise ToolError("This incident has no AI plan yet.")
    return await get_api().post(f"/incidents/{iid}/ai-plan/dismiss", ctx, {"plan_id": plan["plan_id"], "comment": comment})


@write_tool("Submit incident for approval")
async def submit_incident_for_approval(ctx: Context, incident: str) -> dict:
    """Lock the plan and send it to approvers. Needs at least one plan step and one asset."""
    return await get_api().post(f"/incidents/{await resolve.incident_id(ctx, incident)}/submit", ctx)


@write_tool("Change incident status")
async def change_incident_status(ctx: Context, incident: str, status: Literal["OPEN", "PENDING_APPROVAL", "RESOLVED", "CLOSED"],
                                 comment: str | None = None) -> dict:
    """Manual status change. Allowed moves are listed in get_incident -> allowed_statuses."""
    return await get_api().post(f"/incidents/{await resolve.incident_id(ctx, incident)}/status", ctx, {"status": status, "comment": comment})


@write_tool("Close incident", destructive=True)
async def close_incident(ctx: Context, incident: str) -> dict:
    """Close an incident (finished; a new scan finding can open a new one)."""
    return await get_api().post(f"/incidents/{await resolve.incident_id(ctx, incident)}/close", ctx)

from __future__ import annotations

from typing import Literal

from mcp.server.fastmcp import Context

from .. import resolve
from ..api import get_api
from ..registry import read_tool, write_tool
from ..shape import asset_row, page


@read_tool("List assets")
async def list_assets(ctx: Context, q: str | None = None, environment: str | None = None, asset_type: Literal["SYSTEM", "APPLICATION"] | None = None,
                      owner_team: str | None = None, is_active: bool | None = None, page_no: int = 1, size: int = 20) -> dict:
    """Asset inventory: search name / hostname / OS / team, filter by environment, type, owner team. Includes vulnerability and open-incident counts."""
    data = await get_api().get("/assets/inventory", ctx, q=q, environment=environment, asset_type=asset_type, owner_team=owner_team,
                               is_active=is_active, page=page_no, size=min(size, 100))
    return page(data, asset_row)


@read_tool("Get asset")
async def get_asset(ctx: Context, asset: str) -> dict:
    """Full detail of an asset incl. its vulnerabilities and incidents. `asset` = name or UUID."""
    return await get_api().get(f"/assets/{await resolve.asset_id(ctx, asset)}", ctx)


@read_tool("Asset filter values")
async def get_asset_facets(ctx: Context) -> dict:
    """Distinct environments, owner teams and OS names present in the inventory."""
    return await get_api().get("/assets/facets", ctx)


@write_tool("Create asset")
async def create_asset(ctx: Context, name: str, asset_type: Literal["SYSTEM", "APPLICATION"], environment: str, hostname: str | None = None,
                       os_name: str | None = None, os_version: str | None = None, owner_team: str | None = None) -> dict:
    """Add an asset to the inventory."""
    body = {"name": name, "asset_type": asset_type, "environment": environment, "hostname": hostname, "os_name": os_name,
            "os_version": os_version, "owner_team": owner_team}
    return asset_row(await get_api().post("/assets", ctx, {k: v for k, v in body.items() if v is not None}))


@write_tool("Update asset")
async def update_asset(ctx: Context, asset: str, environment: str | None = None, hostname: str | None = None, os_name: str | None = None,
                       os_version: str | None = None, owner_team: str | None = None) -> dict:
    """Edit inventory fields of an asset. Only the fields you pass change."""
    body = {"environment": environment, "hostname": hostname, "os_name": os_name, "os_version": os_version, "owner_team": owner_team}
    return asset_row(await get_api().patch(f"/assets/{await resolve.asset_id(ctx, asset)}", ctx, {k: v for k, v in body.items() if v is not None}))


@write_tool("Activate / deactivate asset")
async def set_asset_active(ctx: Context, asset: str, active: bool) -> dict:
    """Activate or deactivate an asset."""
    aid = await resolve.asset_id(ctx, asset)
    return asset_row(await get_api().post(f"/assets/{aid}/{'activate' if active else 'deactivate'}", ctx))

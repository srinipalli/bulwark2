from __future__ import annotations

from typing import Literal

from mcp.server.fastmcp import Context

from .. import resolve
from ..api import get_api
from ..registry import read_tool, write_tool
from ..shape import page, solution_row

Executor = Literal["ANSIBLE", "AWS_SSM", "SHELL", "HTTP"]
Risk = Literal["LOW", "MEDIUM", "HIGH"]
SolStatus = Literal["REVIEW_PENDING", "APPROVED", "REJECTED", "CHANGES_REQUESTED", "RETIRED"]


@read_tool("List solutions")
async def list_solutions(ctx: Context, q: str | None = None, status: SolStatus | None = None, page_no: int = 1, size: int = 20) -> dict:
    """Solution catalog (the fixes that plans are built from). Status = status of the latest version."""
    return page(await get_api().get("/solutions", ctx, q=q, status=status, page=page_no, size=min(size, 100)), solution_row)


@read_tool("Get solution")
async def get_solution(ctx: Context, solution: str) -> dict:
    """Solution with all versions (job spec, timeout, retries, status). `solution` = title or UUID."""
    return await get_api().get(f"/solutions/{await resolve.solution_id(ctx, solution)}", ctx)


@read_tool("Suggest solutions for an incident (keyword baseline)")
async def suggest_solutions(ctx: Context, incident: str, limit: int = 5) -> list[dict]:
    """The API's built-in keyword-overlap suggestions of APPROVED solutions for an incident. For meaning-based matching use find_solutions_for_problem."""
    return await get_api().get("/solutions/suggestions", ctx, incident_id=await resolve.incident_id(ctx, incident), limit=max(1, min(limit, 20)))


@write_tool("Create solution")
async def create_solution(ctx: Context, title: str, executor: Executor, description: str | None = None, job_spec: dict | None = None,
                          applies_to: str | None = None, risk_level: Risk = "MEDIUM", requires_reboot: bool = False,
                          timeout_seconds: int = 1800, max_retries: int = 0) -> dict:
    """Create a solution (role ANALYST). It starts as REVIEW_PENDING and can be used in plans only after a reviewer approves it."""
    body = {"title": title, "executor": executor, "description": description, "job_spec": job_spec or {}, "applies_to": applies_to,
            "risk_level": risk_level, "requires_reboot": requires_reboot, "timeout_seconds": timeout_seconds, "max_retries": max_retries}
    return solution_row(await get_api().post("/solutions", ctx, {k: v for k, v in body.items() if v is not None}))


@write_tool("Update solution (new version)")
async def update_solution(ctx: Context, solution: str, title: str | None = None, description: str | None = None, executor: Executor | None = None,
                          job_spec: dict | None = None, applies_to: str | None = None, risk_level: Risk | None = None,
                          requires_reboot: bool | None = None, timeout_seconds: int | None = None, max_retries: int | None = None) -> dict:
    """Edit a solution (role ANALYST). Creates a new version that goes back to review; plans keep the version they were approved with."""
    body = {"title": title, "description": description, "executor": executor, "job_spec": job_spec, "applies_to": applies_to,
            "risk_level": risk_level, "requires_reboot": requires_reboot, "timeout_seconds": timeout_seconds, "max_retries": max_retries}
    return solution_row(await get_api().patch(f"/solutions/{await resolve.solution_id(ctx, solution)}", ctx, {k: v for k, v in body.items() if v is not None}))


@write_tool("Retire solution", destructive=True)
async def retire_solution(ctx: Context, solution: str) -> dict:
    """Retire a solution so planners no longer get it offered (role APPROVER)."""
    return solution_row(await get_api().post(f"/solutions/{await resolve.solution_id(ctx, solution)}/retire", ctx))

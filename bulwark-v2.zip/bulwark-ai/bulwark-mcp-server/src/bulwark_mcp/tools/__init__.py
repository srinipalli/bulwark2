"""Importing this package registers every tool on the shared FastMCP instance."""
from . import approvals, assets, dashboard, execution, incidents, insights, scans, solutions, vulnerabilities  # noqa: F401

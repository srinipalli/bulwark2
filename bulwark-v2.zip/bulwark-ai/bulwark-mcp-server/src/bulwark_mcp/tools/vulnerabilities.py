from __future__ import annotations

from typing import Literal

from mcp.server.fastmcp import Context

from .. import resolve
from ..api import get_api
from ..registry import read_tool, write_tool
from ..shape import page, vuln_row

Severity = Literal["LOW", "MEDIUM", "HIGH", "CRITICAL"]


@read_tool("List vulnerabilities")
async def list_vulnerabilities(ctx: Context, q: str | None = None, severity: Severity | None = None, is_active: bool | None = None,
                               page_no: int = 1, size: int = 20) -> dict:
    """Search the vulnerability register (CVE id / title text). Filter by severity and active flag. Newest first."""
    data = await get_api().get("/vulnerabilities", ctx, q=q, severity=severity, is_active=is_active, page=page_no, size=min(size, 100))
    return page(data, vuln_row)


@read_tool("Get vulnerability")
async def get_vulnerability(ctx: Context, vulnerability: str) -> dict:
    """Full detail of one vulnerability. `vulnerability` = CVE id (CVE-2024-1234) or UUID."""
    return await get_api().get(f"/vulnerabilities/{await resolve.vulnerability_id(ctx, vulnerability)}", ctx)


@write_tool("Create vulnerability")
async def create_vulnerability(ctx: Context, cve_id: str, title: str, severity: Severity, description: str | None = None,
                               cvss_score: float | None = None, source: str = "MANUAL", assets: list[str] | None = None) -> dict:
    """Register a vulnerability manually (role ANALYST). `assets` = affected asset names or UUIDs."""
    ids = [await resolve.asset_id(ctx, a) for a in assets or []]
    body = {"cve_id": cve_id, "title": title, "severity": severity, "description": description, "cvss_score": cvss_score,
            "source": source, "asset_ids": ids}
    return vuln_row(await get_api().post("/vulnerabilities", ctx, {k: v for k, v in body.items() if v is not None}))


@write_tool("Update vulnerability")
async def update_vulnerability(ctx: Context, vulnerability: str, title: str | None = None, description: str | None = None,
                               severity: Severity | None = None, cvss_score: float | None = None, assets: list[str] | None = None) -> dict:
    """Edit a vulnerability (role ANALYST). Only the fields you pass change; `assets` replaces the affected-asset list."""
    body = {"title": title, "description": description, "severity": severity, "cvss_score": cvss_score}
    body = {k: v for k, v in body.items() if v is not None}
    if assets is not None:
        body["asset_ids"] = [await resolve.asset_id(ctx, a) for a in assets]
    return vuln_row(await get_api().patch(f"/vulnerabilities/{await resolve.vulnerability_id(ctx, vulnerability)}", ctx, body))


@write_tool("Activate / deactivate vulnerability")
async def set_vulnerability_active(ctx: Context, vulnerability: str, active: bool) -> dict:
    """Activate or deactivate a vulnerability (role ANALYST). Inactive ones cannot get incidents; one with an open incident cannot be deactivated."""
    vid = await resolve.vulnerability_id(ctx, vulnerability)
    return vuln_row(await get_api().post(f"/vulnerabilities/{vid}/{'activate' if active else 'deactivate'}", ctx))

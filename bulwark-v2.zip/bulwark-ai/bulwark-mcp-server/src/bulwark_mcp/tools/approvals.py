from __future__ import annotations

from typing import Literal

from mcp.server.fastmcp import Context
from mcp.server.fastmcp.exceptions import ToolError

from .. import resolve
from ..api import get_api
from ..registry import read_tool, write_tool
from ..shape import incident_approval_row, page, solution_review_row


@read_tool("Approvals summary")
async def get_approvals_summary(ctx: Context) -> dict:
    """How many incident approvals and solution reviews are waiting."""
    return await get_api().get("/approvals/summary", ctx)


@read_tool("List incident approvals")
async def list_incident_approvals(ctx: Context, status: Literal["PENDING", "APPROVED", "REJECTED", "CANCELLED"] = "PENDING",
                                  page_no: int = 1, size: int = 20) -> dict:
    """Plans submitted for approval (default: waiting ones), with the submitted plan steps."""
    return page(await get_api().get("/approvals/incidents", ctx, status=status, page=page_no, size=min(size, 100)), incident_approval_row)


@read_tool("List solution reviews")
async def list_solution_reviews(ctx: Context, status: Literal["PENDING", "APPROVED", "REJECTED", "CHANGES_REQUESTED"] = "PENDING",
                                page_no: int = 1, size: int = 20) -> dict:
    """Solution versions waiting for (or past) review."""
    return page(await get_api().get("/approvals/solutions", ctx, status=status, page=page_no, size=min(size, 100)), solution_review_row)


async def _pending_incident_approval(ctx: Context, ref: str) -> str:
    ref = ref.strip()
    inc = None if resolve.is_uuid(ref) else await resolve.incident_id(ctx, ref)
    data = await get_api().get("/approvals/incidents", ctx, status="PENDING", size=100)
    for a in data["items"]:
        if ref == a["id"] or ref.lower() == a["incident_id"].lower() or (inc and inc == a["incident_id"]):
            return a["id"]
    raise ToolError(f"No pending approval found for '{ref}'. Check list_incident_approvals.")


async def _pending_solution_review(ctx: Context, ref: str) -> str:
    ref = ref.strip()
    data = await get_api().get("/approvals/solutions", ctx, status="PENDING", size=100)
    hits = [r for r in data["items"] if ref in (r["id"], r["solution_id"], r["solution_version_id"]) or r["title"].lower() == ref.lower()]
    if len(hits) == 1:
        return hits[0]["id"]
    raise ToolError(f"{'Several' if hits else 'No'} pending solution reviews match '{ref}'. Check list_solution_reviews.")


@write_tool("Approve incident plan")
async def approve_incident(ctx: Context, incident: str, comment: str | None = None) -> dict:
    """Approve the submitted plan of an incident (role APPROVER). `incident` = code (INC-57), incident UUID or approval id."""
    aid = await _pending_incident_approval(ctx, incident)
    return incident_approval_row(await get_api().post(f"/approvals/incidents/{aid}/approve", ctx, {"comment": comment} if comment else None))


@write_tool("Reject incident plan")
async def reject_incident(ctx: Context, incident: str, comment: str) -> dict:
    """Reject the submitted plan; the incident returns to editing. A comment (min 3 chars) is required."""
    aid = await _pending_incident_approval(ctx, incident)
    return incident_approval_row(await get_api().post(f"/approvals/incidents/{aid}/reject", ctx, {"comment": comment}))


@write_tool("Approve solution version")
async def approve_solution_review(ctx: Context, solution: str, comment: str | None = None) -> dict:
    """Approve a pending solution version so it can be used in plans. `solution` = title, solution UUID or review id."""
    rid = await _pending_solution_review(ctx, solution)
    return solution_review_row(await get_api().post(f"/approvals/solutions/{rid}/approve", ctx, {"comment": comment} if comment else None))


@write_tool("Reject solution version")
async def reject_solution_review(ctx: Context, solution: str, comment: str) -> dict:
    """Reject a pending solution version. A comment is required."""
    rid = await _pending_solution_review(ctx, solution)
    return solution_review_row(await get_api().post(f"/approvals/solutions/{rid}/reject", ctx, {"comment": comment}))


@write_tool("Request changes on solution")
async def request_solution_changes(ctx: Context, solution: str, comment: str) -> dict:
    """Send a pending solution version back to its author with a comment explaining what to change."""
    rid = await _pending_solution_review(ctx, solution)
    return solution_review_row(await get_api().post(f"/approvals/solutions/{rid}/request-changes", ctx, {"comment": comment}))

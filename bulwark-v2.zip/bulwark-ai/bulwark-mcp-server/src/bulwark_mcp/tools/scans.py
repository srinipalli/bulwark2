"""Scan workbook tools. The Bulwark API (bulwark/modules/scans) runs the scan ingestor; these tools only call /scans endpoints."""
from __future__ import annotations

from mcp.server.fastmcp import Context

from ..api import get_api
from ..registry import read_tool, write_tool

SCAN_TIMEOUT = 660.0          # the API allows the ingestor 10 minutes


@read_tool("List scan workbooks")
async def list_scan_workbooks(ctx: Context) -> list[dict]:
    """The .xlsx scan workbooks waiting in the scan inbox folder of the Bulwark API host."""
    return await get_api().get("/scans/workbooks", ctx)


@read_tool("Validate scan workbook")
async def validate_scan_workbook(ctx: Context, file_name: str) -> dict:
    """Dry run of the scan ingestor on one workbook: parses it and reports valid / rejected rows, touching nothing. Needs role ANALYST."""
    return await get_api().post("/scans/validate", ctx, {"file_name": file_name}, timeout=SCAN_TIMEOUT)


@write_tool("Ingest scan workbook")
async def ingest_scan_workbook(ctx: Context, file_name: str) -> dict:
    """Run the real scan ingestor on one workbook: upserts vulnerabilities and assets, creates one incident per vulnerability and publishes the
    events to Kafka. Validate first. A file that was already processed is skipped. Needs role ANALYST."""
    return await get_api().post("/scans/ingest", ctx, {"file_name": file_name}, timeout=SCAN_TIMEOUT)

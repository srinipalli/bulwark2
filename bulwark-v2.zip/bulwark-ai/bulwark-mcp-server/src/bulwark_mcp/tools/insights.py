"""Analytics and semantic search. The logic lives in the Bulwark API (bulwark/modules/insights, delivered in bulwark-ai/mcpapi);
these tools only call its /insights endpoints - no database, no Gemini, nothing but REST."""
from __future__ import annotations

from typing import Literal
from urllib.parse import quote

from mcp.server.fastmcp import Context
from mcp.server.fastmcp.exceptions import ToolError

from .. import resolve
from ..api import get_api
from ..registry import read_tool


@read_tool("Semantic incident search")
async def semantic_search_incidents(ctx: Context, query: str, limit: int = 5, status: str | None = None, min_similarity: float = 0.0) -> dict:
    """Find incidents by MEANING, not keywords (Gemini embeddings + pgvector cosine, done by the Bulwark API).
    Example: 'remote code execution in a java web framework'. Returns similarity 0-1 (higher = closer). Incidents that were never embedded are not searchable."""
    params = {"q": query, "limit": max(1, min(limit, 20)), "min_similarity": min_similarity}
    if status:
        params["status"] = status
    return await get_api().get("/insights/incidents/search", ctx, **params)


@read_tool("Find solutions for a problem")
async def find_solutions_for_problem(ctx: Context, problem: str, limit: int = 5) -> list[dict]:
    """Rank the APPROVED solution catalog against a free-text problem statement by meaning (done by the Bulwark API).
    Use it to answer 'what fixes this?' or to pick plan steps. Only solutions with an approved version are considered."""
    return await get_api().get("/insights/solutions/search", ctx, q=problem, limit=max(1, min(limit, 20)))


@read_tool("Portfolio risk report")
async def portfolio_risk_report(ctx: Context, top_n: int = 5) -> dict:
    """Management view: open incidents by severity and status, the oldest open incidents, assets carrying the most active
    vulnerabilities, mean time to resolve (last 90 days) and failed jobs in the last 7 days."""
    return await get_api().get("/insights/risk-report", ctx, top_n=max(1, min(top_n, 20)))


@read_tool("Audit trail")
async def get_audit_trail(ctx: Context, entity_type: Literal["incident", "vulnerability", "solution", "asset", "approval"] | None = None,
                          entity: str | None = None, limit: int = 20) -> list[dict]:
    """Who changed what and when (append-only audit log). With entity_type + entity (INC-57 / CVE id / name / UUID) you get that record's history,
    with neither you get the latest activity across Bulwark."""
    params: dict = {"limit": max(1, min(limit, 100))}
    if entity_type:
        params["entity_type"] = entity_type
    if entity:
        if not entity_type:
            raise ToolError("Give entity_type together with entity.")
        params["entity_id"] = (await resolve.incident_id(ctx, entity) if entity_type == "incident" else
                               await resolve.vulnerability_id(ctx, entity) if entity_type == "vulnerability" else
                               await resolve.solution_id(ctx, entity) if entity_type == "solution" else
                               await resolve.asset_id(ctx, entity) if entity_type == "asset" else entity)
    return await get_api().get("/insights/audit", ctx, **params)


@read_tool("Explain incident")
async def explain_incident(ctx: Context, incident: str) -> dict:
    """One-call briefing on an incident: what it is, impacted assets by status, the plan, approval state, the best similar incidents, the AI plan,
    execution progress, and the sensible next actions for its current status. incident = INC-57 or a UUID."""
    return await get_api().get(f"/insights/incidents/{quote(incident.strip(), safe='')}/briefing", ctx)

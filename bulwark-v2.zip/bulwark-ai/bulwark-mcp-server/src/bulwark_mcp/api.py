"""Thin async client for the existing Bulwark REST API. Every call carries the *caller's* JWT."""
from __future__ import annotations

import json
from typing import Any

import httpx
from mcp.server.fastmcp import Context
from mcp.server.fastmcp.exceptions import ToolError

from .config import Settings, get_settings


def resolve_token(ctx: Context | None, settings: Settings | None = None) -> str:
    """HTTP transport: forward the caller's Authorization header. stdio / tests: BULWARK_API_TOKEN."""
    settings = settings or get_settings()
    if ctx is not None:
        try:
            req = ctx.request_context.request
        except (ValueError, AttributeError):          # no active request (stdio)
            req = None
        if req is not None:
            h = req.headers.get("authorization", "")
            if h.lower().startswith("bearer ") and h[7:].strip():
                return h[7:].strip()
    tok = settings.bulwark_api_token.get_secret_value()
    if tok:
        return tok
    raise ToolError("No Bulwark token: send 'Authorization: Bearer <jwt>' with the MCP request, or set BULWARK_API_TOKEN (stdio).")


def _clean(params: dict | None) -> dict | None:
    return {k: (str(v).lower() if isinstance(v, bool) else v) for k, v in (params or {}).items() if v is not None} or None


def explain_error(r: httpx.Response) -> str:
    try:
        body = r.json()
    except ValueError:
        body = None
    msg = ""
    if isinstance(body, dict):
        if isinstance(body.get("error"), dict):
            msg = body["error"].get("message", "")
        elif "detail" in body:
            d = body["detail"]
            msg = "; ".join(f"{'.'.join(str(x) for x in e.get('loc', [])[1:])}: {e.get('msg')}" for e in d) if isinstance(d, list) else str(d)
    msg = msg or (r.text or "")[:300]
    if r.status_code == 401:
        return "Not authenticated: the Bulwark token is missing, invalid or expired."
    if r.status_code == 403:
        return f"Not allowed for this user's roles. {msg}".strip()
    if r.status_code == 404:
        return f"Not found. {msg}".strip()
    return f"Bulwark API {r.status_code}: {msg}"


class BulwarkApi:
    def __init__(self, settings: Settings | None = None, transport: httpx.AsyncBaseTransport | None = None):
        self.settings = settings or get_settings()
        self._client = httpx.AsyncClient(base_url=self.settings.bulwark_api_url.rstrip("/") + "/api/v1",
                                         timeout=self.settings.request_timeout_seconds, transport=transport)

    async def request(self, method: str, path: str, ctx: Context | None, *, params: dict | None = None, body: Any = None,
                      timeout: float | None = None) -> Any:
        headers = {"Authorization": f"Bearer {resolve_token(ctx, self.settings)}"}
        try:
            r = await self._client.request(method, path, params=_clean(params), json=body, headers=headers,
                                          **({"timeout": timeout} if timeout else {}))
        except httpx.HTTPError as e:
            raise ToolError(f"Cannot reach the Bulwark API at {self.settings.bulwark_api_url}: {e.__class__.__name__}") from e
        if r.status_code >= 400:
            raise ToolError(explain_error(r))
        if not r.content:
            return None
        try:
            return r.json()
        except json.JSONDecodeError:
            return r.text

    def get(self, path, ctx, **params):
        return self.request("GET", path, ctx, params=params)

    def post(self, path, ctx, body=None, timeout: float | None = None, **params):
        return self.request("POST", path, ctx, params=params, body=body, timeout=timeout)

    def put(self, path, ctx, body=None):
        return self.request("PUT", path, ctx, body=body)

    def patch(self, path, ctx, body=None):
        return self.request("PATCH", path, ctx, body=body)

    def delete(self, path, ctx):
        return self.request("DELETE", path, ctx)

    async def aclose(self):
        await self._client.aclose()


_api: BulwarkApi | None = None


def get_api() -> BulwarkApi:
    global _api
    if _api is None:
        _api = BulwarkApi()
    return _api


def set_api(api: BulwarkApi | None) -> None:
    global _api
    _api = api

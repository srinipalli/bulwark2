"""The single FastMCP instance and the two decorators every tool module uses.

read_tool  -> annotations.readOnlyHint = true   (agents may call it freely)
write_tool -> annotations.readOnlyHint = false  (agents should ask the human first; destructive=True for irreversible actions)
"""
from __future__ import annotations

from mcp.server.fastmcp import FastMCP
from mcp.types import ToolAnnotations

from .config import get_settings

_s = get_settings()
mcp = FastMCP(
    "bulwark",
    host=_s.mcp_host,
    port=_s.mcp_port,
    instructions=(
        "Bulwark manages vulnerabilities -> incidents -> solution plans -> approvals -> execution. "
        "Incidents are addressed by code (INC-57), vulnerabilities by CVE id, assets by name, solutions by title (or UUIDs). "
        "Read tools are safe. Write tools change data and run with the caller's own Bulwark roles."
    ),
)


def read_tool(title: str | None = None):
    return mcp.tool(title=title, annotations=ToolAnnotations(readOnlyHint=True, destructiveHint=False, idempotentHint=True, openWorldHint=False))


def write_tool(title: str | None = None, *, destructive: bool = False):
    return mcp.tool(title=title, annotations=ToolAnnotations(readOnlyHint=False, destructiveHint=destructive, openWorldHint=False))

"""username / password sign-in: users login columns + refresh_tokens (same as sql/07_auth.sql)

Revision ID: 0005
Revises: 0004
"""
from pathlib import Path

from alembic import op

from bulwark.core.sqlutil import schema_statements

revision = "0005"
down_revision = "0004"
branch_labels = None
depends_on = None


def upgrade() -> None:
    bind = op.get_bind()
    for stmt in schema_statements(Path(__file__).resolve().parents[2] / "sql" / "07_auth.sql"):
        bind.exec_driver_sql(stmt)
    # then: python scripts/init_auth.py (password hashes are computed in Python)


def downgrade() -> None:
    bind = op.get_bind()
    bind.exec_driver_sql("DROP TABLE IF EXISTS refresh_tokens")
    bind.exec_driver_sql("DROP INDEX IF EXISTS ux_users_username")
    for col in ("password_changed_at", "last_login_at", "locked_until", "failed_logins", "must_change_password",
                "password_hash", "username"):
        bind.exec_driver_sql(f"ALTER TABLE users DROP COLUMN IF EXISTS {col}")

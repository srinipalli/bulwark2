from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import text

import bulwark.models_registry  # noqa: F401
from bulwark.core.config import get_settings
from bulwark.core.db import engine
from bulwark.core.errors import install_error_handlers
from bulwark.core.kafka import publisher
from bulwark.modules.approvals.router import router as approvals_router
from bulwark.modules.assets.router import router as assets_router
from bulwark.modules.auth.router import admin_router as users_admin_router
from bulwark.modules.auth.router import router as auth_router
from bulwark.modules.dashboard.router import router as dashboard_router
from bulwark.modules.execution.router import router as execution_router
from bulwark.modules.incident.router import router as incident_router
from bulwark.modules.insights.router import router as insights_router
from bulwark.modules.reference.router import router as reference_router
from bulwark.modules.scans.router import router as scans_router
from bulwark.modules.solution.router import router as solution_router
from bulwark.modules.vulnerabilities.router import router as vulnerabilities_router


@asynccontextmanager
async def lifespan(_: FastAPI):
    yield
    publisher.close()
    await engine.dispose()


def create_app() -> FastAPI:
    s = get_settings()
    app = FastAPI(title="Bulwark API", version="1.0.0", lifespan=lifespan)
    if s.cors_origins:
        # credentials: the browser sends the refresh cookie to /auth (only for the origins listed here)
        app.add_middleware(CORSMiddleware, allow_origins=s.cors_origins, allow_methods=["*"], allow_headers=["*"],
                           allow_credentials=True)
    install_error_handlers(app)

    @app.get("/health/live", tags=["health"])
    async def live():
        return {"status": "ok"}

    @app.get("/health/ready", tags=["health"])
    async def ready():
        async with engine.connect() as c:
            await c.execute(text("select 1"))
        return {"status": "ready"}

    for r in (auth_router, users_admin_router, dashboard_router, incident_router, approvals_router, vulnerabilities_router, solution_router,
              execution_router, assets_router, reference_router, insights_router, scans_router):
        app.include_router(r, prefix="/api/v1")
    return app


app = create_app()

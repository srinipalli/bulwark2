from pydantic import BaseModel, Field


class Workbook(BaseModel):
    file: str
    size_kb: float


class ScanRequest(BaseModel):
    file_name: str = Field(min_length=5, max_length=200, description="Plain file name of an .xlsx in the scan inbox, no path")


class ScanResult(BaseModel):
    file: str
    mode: str
    exit_code: int
    result: str
    output_tail: list[str]

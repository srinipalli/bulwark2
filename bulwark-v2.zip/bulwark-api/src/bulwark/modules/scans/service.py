"""Drives the existing scan-ingestor CLI for one workbook that sits in the configured inbox folder.
No shell, no user-supplied paths: the file name is checked against the inbox and the command is run with an argument list."""
from __future__ import annotations

import asyncio
import shlex
from pathlib import Path
from uuid import UUID

from bulwark.core.audit import audit
from bulwark.core.errors import AppError, NotFound, Unprocessable
from bulwark.modules.scans.schemas import ScanResult, Workbook
from bulwark.modules.scans.settings import get_scan_settings
from sqlalchemy.ext.asyncio import AsyncSession

EXIT = {0: "ok", 1: "file rejected/failed or Kafka delivery failed", 2: "configuration or Kafka unreachable",
        3: "another ingestor instance is running"}


class IngestorUnavailable(AppError):
    status_code, code = 503, "ingestor_unavailable"


def _inbox() -> Path:
    p = Path(get_scan_settings().scan_inbox).expanduser().resolve()
    if not p.is_dir():
        raise IngestorUnavailable(f"Scan inbox folder does not exist on the API host: {p}. Set SCAN_INBOX.")
    return p


def safe_file(name: str) -> Path:
    """Only plain *.xlsx files directly inside the inbox - no paths, no traversal."""
    if "/" in name or "\\" in name or "\x00" in name or name.startswith(".") or not name.lower().endswith(".xlsx"):
        raise Unprocessable("Give only the file name of an .xlsx workbook that is in the scan inbox.")
    inbox = _inbox()
    f = (inbox / name).resolve()
    if f.parent != inbox or not f.is_file():
        raise NotFound(f"'{name}' is not in the scan inbox.")
    return f


def list_workbooks() -> list[Workbook]:
    return [Workbook(file=p.name, size_kb=round(p.stat().st_size / 1024, 1))
            for p in sorted(_inbox().glob("*.xlsx")) if not p.name.startswith(".") and p.is_file()]


async def run(f: Path, validate_only: bool) -> ScanResult:
    s = get_scan_settings()
    cwd = Path(s.scan_ingestor_dir).expanduser().resolve()
    if not cwd.is_dir():
        raise IngestorUnavailable(f"SCAN_INGESTOR_DIR does not exist on the API host: {cwd}")
    cmd = shlex.split(s.scan_ingestor_cmd) + ["--file", str(f)] + (["--validate-only"] if validate_only else [])
    try:
        proc = await asyncio.create_subprocess_exec(*cmd, cwd=cwd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT)
    except OSError as e:
        raise IngestorUnavailable(f"Could not start the scan ingestor ({cmd[0]}): {e}") from e
    try:
        out, _ = await asyncio.wait_for(proc.communicate(), timeout=s.scan_timeout_seconds)
    except TimeoutError as e:
        proc.kill()
        await proc.wait()
        raise IngestorUnavailable(f"The scan ingestor timed out after {s.scan_timeout_seconds} seconds.") from e
    lines = out.decode(errors="replace").strip().splitlines()
    return ScanResult(file=f.name, mode="validate-only (nothing changed)" if validate_only else "ingested",
                      exit_code=proc.returncode, result=EXIT.get(proc.returncode, "unknown"), output_tail=lines[-30:])


async def validate(file_name: str) -> ScanResult:
    return await run(safe_file(file_name), True)


async def ingest(session: AsyncSession, actor_id: UUID, file_name: str) -> ScanResult:
    res = await run(safe_file(file_name), False)
    audit(session, actor_id, "scan.ingest", "scan_workbook", res.file, None, {"exit_code": res.exit_code, "result": res.result})
    await session.commit()
    return res

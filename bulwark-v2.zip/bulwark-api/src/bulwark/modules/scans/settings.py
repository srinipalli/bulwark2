"""Settings of the scans module, read from bulwark-api/.env (or environment variables) without touching core/config.py."""
from functools import lru_cache
from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict

ROOT = Path(__file__).resolve().parents[4]                  # bulwark-api/


class ScanSettings(BaseSettings):
    model_config = SettingsConfigDict(env_file=ROOT / ".env", extra="ignore")

    scan_inbox: str = "../bulwark-scan-ingestor/inbox"               # folder holding the .xlsx scan workbooks (on the API host)
    scan_ingestor_dir: str = "../bulwark-scan-ingestor"              # working directory of the ingestor CLI
    scan_ingestor_cmd: str = "python -m scan_ingestor"               # command that is run; --file <path> [--validate-only] is appended
    scan_timeout_seconds: int = 600


@lru_cache
def get_scan_settings() -> ScanSettings:
    return ScanSettings()

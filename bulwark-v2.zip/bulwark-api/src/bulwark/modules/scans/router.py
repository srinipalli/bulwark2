"""Scan workbook endpoints (validate / ingest an .xlsx from the inbox with the existing scan-ingestor CLI).
Mount: app.include_router(scans_router, prefix="/api/v1")"""
from bulwark.core.db import get_session
from bulwark.core.security import ANALYST, CurrentUser, get_current_user, require_roles
from bulwark.modules.scans import service
from bulwark.modules.scans.schemas import ScanRequest, ScanResult, Workbook
from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

router = APIRouter(prefix="/scans", tags=["scans"])
analyst = require_roles(ANALYST)


@router.get("/workbooks", response_model=list[Workbook])
async def workbooks(_: CurrentUser = Depends(get_current_user)):
    """The .xlsx workbooks waiting in the scan inbox."""
    return service.list_workbooks()


@router.post("/validate", response_model=ScanResult)
async def validate(data: ScanRequest, _: CurrentUser = Depends(analyst)):
    """Dry run: parses the workbook and reports valid / rejected rows, changes nothing."""
    return await service.validate(data.file_name)


@router.post("/ingest", response_model=ScanResult)
async def ingest(data: ScanRequest, session: AsyncSession = Depends(get_session), user: CurrentUser = Depends(analyst)):
    """Runs the real ingestor: upserts vulnerabilities and assets, creates incidents, publishes events to Kafka."""
    return await service.ingest(session, user.id, data.file_name)

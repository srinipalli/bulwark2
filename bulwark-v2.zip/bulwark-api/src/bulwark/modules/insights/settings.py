"""Settings of the insights module. Read from the same bulwark-api/.env (or environment variables) as the rest of the API,
without touching core/config.py."""
from functools import lru_cache
from pathlib import Path

from pydantic import SecretStr
from pydantic_settings import BaseSettings, SettingsConfigDict

ROOT = Path(__file__).resolve().parents[4]                  # bulwark-api/


class InsightsSettings(BaseSettings):
    model_config = SettingsConfigDict(env_file=ROOT / ".env", extra="ignore")

    gemini_api_key: SecretStr = SecretStr("")               # free key: https://aistudio.google.com/apikey
    gemini_embed_model: str = "gemini-embedding-001"
    embed_dim: int = 768                                    # = incidents.embedding vector(768)


@lru_cache
def get_insights_settings() -> InsightsSettings:
    return InsightsSettings()

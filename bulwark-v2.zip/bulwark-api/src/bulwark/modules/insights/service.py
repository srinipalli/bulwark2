"""Read-only analytics on top of the existing tables, plus semantic search and the one-call incident briefing.
Everything here is SELECT-only; the briefing reuses the incident / execution services in-process."""
from __future__ import annotations

import hashlib
import json
import re
from uuid import UUID

from bulwark.core.errors import NotFound, Unprocessable
from bulwark.core.pagination import PageParams
from bulwark.modules.execution import service as execution_service
from bulwark.modules.incident import service as incident_service
from bulwark.modules.insights.embeddings import Embedder, EmbeddingUnavailable, cosine, vector_literal
from bulwark.modules.insights.schemas import (
    AuditEntry,
    BriefAiPlan,
    BriefAssets,
    BriefExecution,
    BriefFailedAsset,
    BriefIncident,
    Briefing,
    BriefSimilar,
    ExposedAsset,
    FailedJobs,
    IncidentMatch,
    IncidentRef,
    IncidentSearchOut,
    OldestIncident,
    ResolveTime,
    RiskReport,
    SeverityStatusCount,
    SolutionMatch,
)
from bulwark.modules.solution import service as solution_service
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

CLOSED_STATES = "('RESOLVED','CLOSED')"
SEV_ORDER = "array_position(ARRAY['CRITICAL','HIGH','MEDIUM','LOW'], severity)"


# ---- incident lookup -------------------------------------------------------------------------------------------------
_CODE = re.compile(r"(?i)^\s*(?:inc[-\s]?)?(\d+)\s*$")


async def lookup_incident(session: AsyncSession, code: str) -> IncidentRef:
    m = _CODE.match(code)
    if not m:
        raise Unprocessable("Give the incident code like INC-57.")
    row = (await session.execute(text("SELECT id, 'INC-' || incident_no AS code, title, status FROM incidents WHERE incident_no = :n"),
                                 {"n": int(m.group(1))})).mappings().first()
    if not row:
        raise NotFound(f"Incident INC-{int(m.group(1))} not found")
    return IncidentRef(**row)


async def resolve_incident(session: AsyncSession, ref: str) -> UUID:
    try:
        return UUID(ref.strip())
    except ValueError:
        return (await lookup_incident(session, ref)).id


# ---- semantic incident search ----------------------------------------------------------------------------------------
async def _has_embedding_column(session: AsyncSession) -> bool:
    return (await session.execute(text(
        "SELECT 1 FROM information_schema.columns WHERE table_name = 'incidents' AND column_name = 'embedding'"))).first() is not None


async def search_incidents(session: AsyncSession, emb: Embedder, q: str, limit: int, status: str | None, min_similarity: float) -> IncidentSearchOut:
    if not await _has_embedding_column(session):
        raise EmbeddingUnavailable("incidents.embedding does not exist: run sql/02_pgvector_incidents.sql and the embedding backfill first.")
    (vec,) = await emb.embed([q])
    rows = (await session.execute(text("""
        SELECT i.id, 'INC-' || i.incident_no AS code, i.title, i.severity, i.status, v.cve_id,
               round((1 - (i.embedding <=> CAST(:vec AS vector)))::numeric, 4)::float AS similarity
          FROM incidents i JOIN vulnerabilities v ON v.id = i.vulnerability_id
         WHERE i.embedding IS NOT NULL AND i.embedding_model = :model
           AND (CAST(:status AS text) IS NULL OR i.status = CAST(:status AS text))
         ORDER BY i.embedding <=> CAST(:vec AS vector) LIMIT :limit"""),
        {"vec": vector_literal(vec), "model": emb.name, "status": status, "limit": limit})).mappings().all()
    stat = (await session.execute(text("""
        SELECT count(*) AS total, count(*) FILTER (WHERE embedding IS NULL OR embedding_model IS DISTINCT FROM :model) AS not_searchable
          FROM incidents"""), {"model": emb.name})).mappings().one()
    return IncidentSearchOut(
        query=q, embedding_model=emb.name, total_incidents=stat["total"], not_searchable=stat["not_searchable"],
        results=[IncidentMatch(**r) for r in rows if r["similarity"] >= min_similarity],
        note=(f"{stat['not_searchable']} of {stat['total']} incidents have no embedding with this model and cannot be matched "
              "(run the embedding backfill).") if stat["not_searchable"] else None)


# ---- solution search -------------------------------------------------------------------------------------------------
_vec_cache: dict[tuple[str, str, str], list[float]] = {}          # (model, solution id, text hash) -> vector; process-wide


async def search_solutions(session: AsyncSession, emb: Embedder, q: str, limit: int) -> list[SolutionMatch]:
    catalog = []
    for page in range(1, 6):                                       # up to 500 approved solutions
        items, total = await solution_service.list_solutions(session, PageParams(page, 100), None, "APPROVED")
        catalog += [s for s in items if s.has_approved_version and not s.is_retired]
        if page * 100 >= total:
            break
    if not catalog:
        return []
    texts = {str(s.id): f"{s.title}. {s.description or ''} Executor: {s.executor}." for s in catalog}
    key = lambda sid: (emb.name, sid, hashlib.sha256(texts[sid].encode()).hexdigest()[:16])        # noqa: E731
    missing = [sid for sid in texts if key(sid) not in _vec_cache]
    qvec, *dvecs = await emb.embed([q] + [texts[s] for s in missing])
    _vec_cache.update({key(sid): v for sid, v in zip(missing, dvecs)})
    scored = sorted(((cosine(qvec, _vec_cache[key(str(s.id))]), s) for s in catalog), key=lambda t: -t[0])
    return [SolutionMatch(id=s.id, title=s.title, status=s.status, latest_version_no=s.latest_version_no,
                          has_approved_version=s.has_approved_version, executor=s.executor, risk_level=s.risk_level,
                          description=s.description, score=round(sc, 4)) for sc, s in scored[:limit]]


# ---- risk report -----------------------------------------------------------------------------------------------------
async def risk_report(session: AsyncSession, top_n: int) -> RiskReport:
    async def rows(sql: str, **p):
        return (await session.execute(text(sql), p)).mappings().all()

    by_sev = await rows(f"SELECT severity, status, count(*) AS incidents FROM incidents WHERE status NOT IN {CLOSED_STATES} "
                        f"GROUP BY severity, status ORDER BY {SEV_ORDER}, status")
    oldest = await rows(f"""SELECT 'INC-' || i.incident_no AS code, i.title, i.severity, i.status, v.cve_id,
                                   floor(extract(epoch FROM now() - i.created_at) / 86400)::int AS days_open,
                                   (SELECT count(*) FROM incident_assets ia WHERE ia.incident_id = i.id AND ia.status <> 'EXCLUDED')::int AS assets
                              FROM incidents i JOIN vulnerabilities v ON v.id = i.vulnerability_id
                             WHERE i.status NOT IN {CLOSED_STATES} ORDER BY i.created_at LIMIT :n""", n=top_n)
    assets = await rows("""SELECT a.name, a.environment, (count(*) FILTER (WHERE v.severity = 'CRITICAL'))::int AS critical,
                                  (count(*) FILTER (WHERE v.severity = 'HIGH'))::int AS high, count(*)::int AS active_vulnerabilities
                             FROM assets a JOIN vulnerability_assets va ON va.asset_id = a.id
                             JOIN vulnerabilities v ON v.id = va.vulnerability_id AND v.is_active
                            WHERE a.is_active GROUP BY a.id ORDER BY critical DESC, high DESC, active_vulnerabilities DESC LIMIT :n""", n=top_n)
    mttr = await rows(f"""SELECT severity, count(*)::int AS resolved,
                                 round((avg(extract(epoch FROM resolved_at - created_at)) / 86400)::numeric, 1)::float AS mean_days
                            FROM incidents WHERE resolved_at > now() - interval '90 days' GROUP BY severity ORDER BY {SEV_ORDER}""")
    failed = (await rows("""SELECT count(*)::int AS failed_runs_7d, count(DISTINCT incident_id)::int AS incidents_affected
                              FROM job_runs WHERE status = 'FAILED' AND finished_at > now() - interval '7 days'"""))[0]
    return RiskReport(
        open_incidents_by_severity_and_status=[SeverityStatusCount(**r) for r in by_sev],
        oldest_open_incidents=[OldestIncident(**r) for r in oldest], most_exposed_assets=[ExposedAsset(**r) for r in assets],
        mean_time_to_resolve_90d=[ResolveTime(**r) for r in mttr], failed_jobs_last_7_days=FailedJobs(**failed))


# ---- audit trail -----------------------------------------------------------------------------------------------------
def _short(x, n: int = 600) -> str | None:
    if not x:
        return None
    s = json.dumps(x, default=str, ensure_ascii=False)
    return s if len(s) <= n else s[:n] + "...(truncated)"


async def audit_trail(session: AsyncSession, entity_type: str | None, entity_id: str | None, limit: int) -> list[AuditEntry]:
    if entity_id and not entity_type:
        raise Unprocessable("Give entity_type together with entity_id.")
    rows = (await session.execute(text("""
        SELECT a.id, a.created_at, coalesce(u.full_name, 'system') AS actor, a.action, a.entity_type, a.entity_id, a.before, a.after
          FROM audit_logs a LEFT JOIN users u ON u.id = a.actor_id
         WHERE (CAST(:etype AS text) IS NULL OR a.entity_type = CAST(:etype AS text))
           AND (CAST(:eid AS text) IS NULL OR a.entity_id = CAST(:eid AS text))
         ORDER BY a.id DESC LIMIT :limit"""), {"etype": entity_type, "eid": entity_id, "limit": limit})).mappings().all()
    return [AuditEntry(**{**r, "before": _short(r["before"]), "after": _short(r["after"])}) for r in rows]


# ---- incident briefing -----------------------------------------------------------------------------------------------
NEXT = {
    "OPEN": "Build the plan (apply the AI plan, copy the plan of a similar incident, or set it by hand), then submit for approval.",
    "REJECTED": "Read the approver's comment, fix the plan, then submit for approval again.",
    "PENDING_APPROVAL": "Waiting for an approver to approve or reject.",
    "APPROVED": "Ready to execute: run the full plan or a single plan step (role OPERATOR).",
    "IN_PROGRESS": "Watch the execution grid; re-run failed steps; check the run logs for errors.",
    "RESOLVED": "All assets are patched: close the incident once verified.",
    "CLOSED": "Nothing left to do.",
}


async def briefing(session: AsyncSession, iid: UUID) -> Briefing:
    d = await incident_service.get_detail(session, iid)
    similar = await incident_service.similar_incidents(session, iid)
    ai = await incident_service.ai_plan(session, iid)
    grid = await execution_service.get_grid(session, iid) if d.status in ("APPROVED", "IN_PROGRESS", "RESOLVED") else None
    by_status: dict[str, int] = {}
    for a in d.assets:
        by_status[a.status] = by_status.get(a.status, 0) + 1
    nxt = [NEXT.get(d.status, "")]
    if ai and ai.review_status == "NEW" and d.editable:
        nxt.append("An AI plan is waiting for review.")
    execution = None
    if grid:
        cells: dict[str, int] = {}
        for r in grid.rows:
            for c in r.cells:
                cells[c.status] = cells.get(c.status, 0) + 1
        execution = BriefExecution(cells_by_status=cells, can_run=grid.can_run)
    return Briefing(
        incident=BriefIncident(code=d.code, title=d.title, severity=d.severity, status=d.status, cve_id=d.vulnerability.cve_id,
                               assignee=d.assignee.full_name if d.assignee else None,
                               description=(d.description or "")[:600] or None, editable=d.editable),
        assets=BriefAssets(count=len(d.assets), by_status=by_status,
                           failed=[BriefFailedAsset(asset=a.asset.name, error=a.last_error) for a in d.assets if a.status == "FAILED"][:5]),
        plan=[f"{p.step_no}. {p.title} (v{p.version_no}, {p.executor}, risk {p.risk_level}, on failure {p.on_failure})" for p in d.plan],
        approval=d.approval,
        similar_incidents=[BriefSimilar(code=s.code, title=s.title, similarity=round(s.similarity, 3), status=s.status,
                                        plan=[p.title for p in s.plan]) for s in similar[:3]],
        ai_plan=None if not ai else BriefAiPlan(outcome=ai.outcome, confidence=ai.confidence, review_status=ai.review_status,
                                                rationale=(ai.rationale or "")[:500] or None, steps=[f"{s.step_no}. {s.title}" for s in ai.steps],
                                                solution_drafts_needed=[x.title for x in ai.drafts]),
        execution=execution, next_actions=nxt, allowed_status_changes=d.allowed_statuses)

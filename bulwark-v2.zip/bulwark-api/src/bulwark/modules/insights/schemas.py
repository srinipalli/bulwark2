from datetime import datetime
from uuid import UUID

from bulwark.modules.incident.schemas import ApprovalInfo
from pydantic import BaseModel


class IncidentRef(BaseModel):
    id: UUID
    code: str
    title: str
    status: str


# ---- semantic search -------------------------------------------------------------------------------------------------
class IncidentMatch(BaseModel):
    id: UUID
    code: str
    title: str
    severity: str
    status: str
    cve_id: str
    similarity: float                       # cosine similarity 0-1, higher = closer in meaning


class IncidentSearchOut(BaseModel):
    query: str
    embedding_model: str
    results: list[IncidentMatch]
    total_incidents: int
    not_searchable: int                     # incidents without an embedding of this model
    note: str | None = None


class SolutionMatch(BaseModel):
    id: UUID
    title: str
    status: str
    latest_version_no: int
    has_approved_version: bool
    executor: str
    risk_level: str
    description: str | None
    score: float


# ---- risk report -----------------------------------------------------------------------------------------------------
class SeverityStatusCount(BaseModel):
    severity: str
    status: str
    incidents: int


class OldestIncident(BaseModel):
    code: str
    title: str
    severity: str
    status: str
    cve_id: str
    days_open: int
    assets: int


class ExposedAsset(BaseModel):
    name: str
    environment: str
    critical: int
    high: int
    active_vulnerabilities: int


class ResolveTime(BaseModel):
    severity: str
    resolved: int
    mean_days: float | None


class FailedJobs(BaseModel):
    failed_runs_7d: int
    incidents_affected: int


class RiskReport(BaseModel):
    open_incidents_by_severity_and_status: list[SeverityStatusCount]
    oldest_open_incidents: list[OldestIncident]
    most_exposed_assets: list[ExposedAsset]
    mean_time_to_resolve_90d: list[ResolveTime]
    failed_jobs_last_7_days: FailedJobs


# ---- audit -----------------------------------------------------------------------------------------------------------
class AuditEntry(BaseModel):
    id: int
    created_at: datetime
    actor: str
    action: str
    entity_type: str
    entity_id: str
    before: str | None
    after: str | None


# ---- incident briefing -----------------------------------------------------------------------------------------------
class BriefIncident(BaseModel):
    code: str
    title: str
    severity: str
    status: str
    cve_id: str
    assignee: str | None
    description: str | None
    editable: bool


class BriefFailedAsset(BaseModel):
    asset: str
    error: str | None


class BriefAssets(BaseModel):
    count: int
    by_status: dict[str, int]
    failed: list[BriefFailedAsset]


class BriefSimilar(BaseModel):
    code: str
    title: str
    similarity: float
    status: str
    plan: list[str]


class BriefAiPlan(BaseModel):
    outcome: str
    confidence: float | None
    review_status: str
    rationale: str | None
    steps: list[str]
    solution_drafts_needed: list[str]


class BriefExecution(BaseModel):
    cells_by_status: dict[str, int]
    can_run: bool


class Briefing(BaseModel):
    incident: BriefIncident
    assets: BriefAssets
    plan: list[str]
    approval: ApprovalInfo | None
    similar_incidents: list[BriefSimilar]
    ai_plan: BriefAiPlan | None
    execution: BriefExecution | None = None
    next_actions: list[str]
    allowed_status_changes: list[str]

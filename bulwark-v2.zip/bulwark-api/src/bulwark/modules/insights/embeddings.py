"""Gemini embeddings (gemini-embedding-001, truncated to 768 and L2-normalised): the same recipe the scan-ingestor and the recommender use
for incidents.embedding, so a query vector is comparable with the stored ones. Gemini is the only embedding provider.

`get_embedder` is a FastAPI dependency so tests can replace it."""
from __future__ import annotations

import math
from functools import lru_cache
from typing import Protocol

from bulwark.core.errors import AppError
from bulwark.modules.insights.settings import InsightsSettings, get_insights_settings


class EmbeddingUnavailable(AppError):
    status_code, code = 503, "embeddings_unavailable"


class Embedder(Protocol):
    name: str
    dim: int

    async def embed(self, texts: list[str]) -> list[list[float]]: ...


def normalize(v: list[float]) -> list[float]:
    n = math.sqrt(sum(x * x for x in v)) or 1.0
    return [x / n for x in v]


def cosine(a: list[float], b: list[float]) -> float:
    return sum(x * y for x, y in zip(a, b))                  # inputs are normalised


def vector_literal(v: list[float]) -> str:
    return "[" + ",".join(f"{x:.7f}" for x in v) + "]"


class GeminiEmbedder:
    def __init__(self, s: InsightsSettings):
        self.model, self.dim = s.gemini_embed_model, s.embed_dim
        self.name = f"gemini:{self.model}:{self.dim}"        # = incidents.embedding_model
        self._key, self._client, self._types = s.gemini_api_key.get_secret_value(), None, None

    def _init(self):
        if self._client is None:
            if not self._key:
                raise EmbeddingUnavailable("Semantic search needs GEMINI_API_KEY in the API's environment (free key: https://aistudio.google.com/apikey).")
            try:
                from google import genai
                from google.genai import types
            except ImportError as e:
                raise EmbeddingUnavailable("Semantic search needs the 'google-genai' package: pip install google-genai") from e
            self._client, self._types = genai.Client(api_key=self._key), types

    async def embed(self, texts: list[str]) -> list[list[float]]:
        self._init()
        cfg = self._types.EmbedContentConfig(task_type="SEMANTIC_SIMILARITY", output_dimensionality=self.dim)
        out: list[list[float]] = []
        try:
            for i in range(0, len(texts), 100):                # API limit: 100 texts per request
                res = await self._client.aio.models.embed_content(model=self.model, contents=texts[i:i + 100], config=cfg)
                out += [normalize(list(e.values)) for e in res.embeddings]
        except Exception as e:                                 # noqa: BLE001
            raise EmbeddingUnavailable(f"Gemini embedding failed: {str(e)[:200]}") from e
        if len(out) != len(texts) or any(len(v) != self.dim for v in out):
            raise EmbeddingUnavailable("Gemini returned an unexpected embedding shape.")
        return out


@lru_cache
def get_embedder() -> Embedder:
    return GeminiEmbedder(get_insights_settings())

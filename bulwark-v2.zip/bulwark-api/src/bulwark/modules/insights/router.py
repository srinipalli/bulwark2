"""Read-only insight endpoints used by the Bulwark MCP server (and fine for any other client).
Mount: app.include_router(insights_router, prefix="/api/v1")  - the prefix /insights does not clash with /incidents/{id}."""
from typing import Literal

from bulwark.core.db import get_session
from bulwark.core.security import CurrentUser, get_current_user
from bulwark.modules.insights import service
from bulwark.modules.insights.embeddings import Embedder, get_embedder
from bulwark.modules.insights.schemas import AuditEntry, Briefing, IncidentRef, IncidentSearchOut, RiskReport, SolutionMatch
from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession

router = APIRouter(prefix="/insights", tags=["insights"])
STATUS_RE = "^(OPEN|PENDING_APPROVAL|APPROVED|REJECTED|IN_PROGRESS|RESOLVED|CLOSED)$"


@router.get("/incidents/lookup", response_model=IncidentRef)
async def lookup_incident(code: str = Query(..., min_length=1, max_length=40, description="INC-57, inc 57 or 57"),
                          session: AsyncSession = Depends(get_session), _: CurrentUser = Depends(get_current_user)):
    """Incident code -> id (the other endpoints take UUIDs)."""
    return await service.lookup_incident(session, code)


@router.get("/incidents/search", response_model=IncidentSearchOut)
async def search_incidents(q: str = Query(..., min_length=3, max_length=2000), limit: int = Query(5, ge=1, le=20),
                           status: str | None = Query(None, pattern=STATUS_RE), min_similarity: float = Query(0.0, ge=0, le=1),
                           session: AsyncSession = Depends(get_session), emb: Embedder = Depends(get_embedder),
                           _: CurrentUser = Depends(get_current_user)):
    """Find incidents by meaning (Gemini embedding + pgvector cosine over incidents.embedding)."""
    return await service.search_incidents(session, emb, q, limit, status, min_similarity)


@router.get("/incidents/{ref}/briefing", response_model=Briefing)
async def incident_briefing(ref: str, session: AsyncSession = Depends(get_session), _: CurrentUser = Depends(get_current_user)):
    """Everything about one incident in one call. ref = INC-57 or the UUID."""
    return await service.briefing(session, await service.resolve_incident(session, ref))


@router.get("/solutions/search", response_model=list[SolutionMatch])
async def search_solutions(q: str = Query(..., min_length=3, max_length=2000), limit: int = Query(5, ge=1, le=20),
                           session: AsyncSession = Depends(get_session), emb: Embedder = Depends(get_embedder),
                           _: CurrentUser = Depends(get_current_user)):
    """Rank the approved solution catalog against a free-text problem by meaning."""
    return await service.search_solutions(session, emb, q, limit)


@router.get("/risk-report", response_model=RiskReport)
async def risk_report(top_n: int = Query(5, ge=1, le=20), session: AsyncSession = Depends(get_session),
                      _: CurrentUser = Depends(get_current_user)):
    """Management view: open incidents by severity/status, oldest open, most exposed assets, MTTR (90 d), failed jobs (7 d)."""
    return await service.risk_report(session, top_n)


@router.get("/audit", response_model=list[AuditEntry])
async def audit_trail(entity_type: Literal["incident", "vulnerability", "solution", "asset", "approval"] | None = None,
                      entity_id: str | None = Query(None, max_length=100, description="UUID of the record (needs entity_type)"),
                      limit: int = Query(20, ge=1, le=100), session: AsyncSession = Depends(get_session),
                      _: CurrentUser = Depends(get_current_user)):
    """Append-only audit log, newest first."""
    return await service.audit_trail(session, entity_type, entity_id, limit)

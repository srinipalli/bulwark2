from uuid import UUID

from fastapi import APIRouter, Depends, Request, Response
from sqlalchemy.ext.asyncio import AsyncSession

from bulwark.core.config import get_settings
from bulwark.core.db import get_session
from bulwark.core.errors import Forbidden
from bulwark.core.security import ADMIN, CurrentUser, get_signed_in_user, require_roles
from bulwark.modules.auth import service
from bulwark.modules.auth.schemas import (ChangePasswordIn, LoginIn, Me, PasswordReset, TokenOut, UserAdminOut,
                                          UserCreate, UserUpdate)
from bulwark.shared.models import User

router = APIRouter(prefix="/auth", tags=["auth"])
admin_router = APIRouter(prefix="/admin/users", tags=["user administration"])
COOKIE_PATH = "/api/v1/auth"          # the refresh cookie is only ever sent to the auth endpoints
CSRF_HEADER = "x-requested-with"      # cookie-based calls must carry it: other sites cannot add it without CORS approval
admin = require_roles(ADMIN)


def _client(request: Request) -> tuple[str | None, str | None]:
    return request.headers.get("user-agent"), request.client.host if request.client else None


def _set_cookie(response: Response, raw: str) -> None:
    s = get_settings()
    response.set_cookie(s.refresh_cookie_name, raw, max_age=s.refresh_token_hours * 3600, httponly=True,
                        secure=s.refresh_cookie_secure, samesite=s.refresh_cookie_samesite, path=COOKIE_PATH)


def _clear_cookie(response: Response) -> None:
    s = get_settings()
    response.delete_cookie(s.refresh_cookie_name, path=COOKIE_PATH, httponly=True, secure=s.refresh_cookie_secure,
                           samesite=s.refresh_cookie_samesite)


def _cookie(request: Request) -> str | None:
    if not request.headers.get(CSRF_HEADER):
        raise Forbidden(f"Missing {CSRF_HEADER} header", code="csrf")
    return request.cookies.get(get_settings().refresh_cookie_name)


@router.post("/login", response_model=TokenOut)
async def login(data: LoginIn, request: Request, response: Response, session: AsyncSession = Depends(get_session)):
    """Username + password. Returns a short-lived access token and sets the refresh token as an HttpOnly cookie.
    Five wrong passwords in a row lock the account for 15 minutes (configurable)."""
    out, raw = await service.login(session, data.username, data.password, *_client(request))
    _set_cookie(response, raw)
    return out


@router.post("/refresh", response_model=TokenOut)
async def refresh(request: Request, response: Response, session: AsyncSession = Depends(get_session)):
    """New access token from the refresh cookie; the refresh token is rotated (the old one stops working)."""
    out, raw = await service.refresh(session, _cookie(request), *_client(request))
    _set_cookie(response, raw)
    return out


@router.post("/logout", status_code=204)
async def logout(request: Request, response: Response, session: AsyncSession = Depends(get_session)):
    """Ends this session (all refresh tokens of its family) and clears the cookie."""
    await service.logout(session, _cookie(request))
    _clear_cookie(response)


@router.get("/me", response_model=Me)
async def get_me(user: User = Depends(get_signed_in_user)):
    return service.me(user)


@router.post("/change-password", response_model=Me)
async def change_password(data: ChangePasswordIn, request: Request, session: AsyncSession = Depends(get_session),
                          user: User = Depends(get_signed_in_user)):
    """Also allowed while a password change is pending. Other sessions of the user are signed out."""
    family = await service.family_of(session, request.cookies.get(get_settings().refresh_cookie_name))
    return await service.change_password(session, user, data, family)


@admin_router.get("", response_model=list[UserAdminOut])
async def list_users(session: AsyncSession = Depends(get_session), _: CurrentUser = Depends(admin)):
    return await service.list_users(session)


@admin_router.post("", response_model=UserAdminOut, status_code=201)
async def create_user(data: UserCreate, session: AsyncSession = Depends(get_session), user: CurrentUser = Depends(admin)):
    """Without a password the user gets the default password and must change it at first sign-in."""
    return await service.create_user(session, user, data)


@admin_router.patch("/{user_id}", response_model=UserAdminOut)
async def update_user(user_id: UUID, data: UserUpdate, session: AsyncSession = Depends(get_session),
                      user: CurrentUser = Depends(admin)):
    """Name, email, roles, active. Deactivating signs the user out everywhere."""
    return await service.update_user(session, user, user_id, data)


@admin_router.post("/{user_id}/reset-password", response_model=UserAdminOut)
async def reset_password(user_id: UUID, data: PasswordReset | None = None, session: AsyncSession = Depends(get_session),
                         user: CurrentUser = Depends(admin)):
    """Back to the default password (or the one given), to be changed at next sign-in; unlocks; signs out everywhere."""
    return await service.reset_password(session, user, user_id, data or PasswordReset())


@admin_router.post("/{user_id}/unlock", response_model=UserAdminOut)
async def unlock(user_id: UUID, session: AsyncSession = Depends(get_session), user: CurrentUser = Depends(admin)):
    return await service.unlock(session, user, user_id)

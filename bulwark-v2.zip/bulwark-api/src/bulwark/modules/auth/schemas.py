from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, Field


class LoginIn(BaseModel):
    username: str = Field(min_length=1, max_length=200)
    password: str = Field(min_length=1, max_length=200)


class Me(BaseModel):
    id: UUID
    username: str | None
    email: str
    name: str
    roles: list[str]
    must_change_password: bool


class TokenOut(BaseModel):
    """Access token for the Authorization header. The refresh token is only ever sent as an HttpOnly cookie."""
    access_token: str
    token_type: str = "bearer"
    expires_in: int                    # seconds
    user: Me


class ChangePasswordIn(BaseModel):
    current_password: str = Field(min_length=1, max_length=200)
    new_password: str = Field(min_length=1, max_length=200)


class UserAdminOut(BaseModel):
    id: UUID
    username: str | None
    email: str
    full_name: str
    roles: list[str]
    is_active: bool
    must_change_password: bool
    has_password: bool
    locked_until: datetime | None
    last_login_at: datetime | None
    created_at: datetime


class UserCreate(BaseModel):
    username: str = Field(min_length=3, max_length=60, pattern=r"^[A-Za-z0-9._-]+$")
    full_name: str = Field(min_length=1, max_length=200)
    email: str = Field(min_length=3, max_length=200, pattern=r"^[^@\s]+@[^@\s]+$")
    roles: list[str] = Field(min_length=1)
    password: str | None = Field(default=None, max_length=200)    # empty = the default password, to be changed at sign-in


class UserUpdate(BaseModel):
    full_name: str | None = Field(default=None, min_length=1, max_length=200)
    email: str | None = Field(default=None, min_length=3, max_length=200, pattern=r"^[^@\s]+@[^@\s]+$")
    roles: list[str] | None = Field(default=None, min_length=1)
    is_active: bool | None = None


class PasswordReset(BaseModel):
    password: str | None = Field(default=None, max_length=200)    # empty = the default password

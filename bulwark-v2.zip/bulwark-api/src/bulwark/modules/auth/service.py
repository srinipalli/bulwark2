"""Username / password sign-in.

Sign-in returns a short-lived access JWT (kept in the browser's memory) and sets an opaque refresh token in an
HttpOnly cookie. Each refresh rotates the refresh token within its family (= one session); presenting a rotated
token again revokes the whole family (token theft), except within a short grace period so two tabs refreshing at
the same moment do not sign the user out. Only SHA-256 hashes of refresh tokens are stored.
"""
import asyncio
import hashlib
import secrets
import uuid
from datetime import datetime, timedelta, timezone
from uuid import UUID

from sqlalchemy import func, select, update
from sqlalchemy.ext.asyncio import AsyncSession

from bulwark.core.audit import audit
from bulwark.core.config import get_settings
from bulwark.core.errors import Conflict, NotFound, Unprocessable
from bulwark.core.passwords import DUMMY_HASH, hash_password, needs_rehash, verify_password
from bulwark.core.security import ROLES, Unauthorized, create_access_token
from bulwark.modules.auth.schemas import (ChangePasswordIn, Me, PasswordReset, TokenOut, UserAdminOut, UserCreate,
                                          UserUpdate)
from bulwark.shared.models import RefreshToken, User

ROTATION_GRACE = timedelta(seconds=30)
INVALID = "Invalid username or password"


def now() -> datetime:
    return datetime.now(timezone.utc)


def _sha(raw: str) -> str:
    return hashlib.sha256(raw.encode()).hexdigest()


def me(u: User) -> Me:
    return Me(id=u.id, username=u.username, email=u.email, name=u.full_name, roles=sorted(u.roles or []),
              must_change_password=u.must_change_password)


def _token_out(u: User) -> TokenOut:
    token, ttl = create_access_token(u)
    return TokenOut(access_token=token, expires_in=ttl, user=me(u))


async def _issue_refresh(session: AsyncSession, u: User, family: UUID, started: datetime, ua: str | None,
                         ip: str | None) -> tuple[RefreshToken, str]:
    s = get_settings()
    raw = secrets.token_urlsafe(32)
    expires = min(now() + timedelta(hours=s.refresh_token_hours), started + timedelta(hours=s.session_max_hours))
    row = RefreshToken(user_id=u.id, family_id=family, token_hash=_sha(raw), session_started_at=started,
                       expires_at=expires, user_agent=(ua or "")[:300] or None, ip=ip)
    session.add(row)
    await session.flush()
    return row, raw


async def revoke_sessions(session: AsyncSession, user_id: UUID, reason: str, keep_family: UUID | None = None) -> None:
    stmt = update(RefreshToken).where(RefreshToken.user_id == user_id, RefreshToken.revoked_at.is_(None))
    if keep_family:
        stmt = stmt.where(RefreshToken.family_id != keep_family)
    await session.execute(stmt.values(revoked_at=now(), revoked_reason=reason))


async def _revoke_family(session: AsyncSession, family: UUID, reason: str) -> None:
    await session.execute(update(RefreshToken).where(RefreshToken.family_id == family, RefreshToken.revoked_at.is_(None))
                          .values(revoked_at=now(), revoked_reason=reason))


# ------------------------------------------------------------------ sign-in / session
async def login(session: AsyncSession, username: str, password: str, ua: str | None, ip: str | None) -> tuple[TokenOut, str]:
    s = get_settings()
    u = (await session.execute(select(User).where(func.lower(User.username) == username.strip().lower()))).scalar_one_or_none()
    if u and u.locked_until and u.locked_until > now():
        await asyncio.to_thread(verify_password, password, DUMMY_HASH)
        mins = max(1, int((u.locked_until - now()).total_seconds() // 60) + 1)
        raise Unauthorized(f"Too many failed sign-in attempts. Try again in {mins} minute(s).", code="locked")
    ok = await asyncio.to_thread(verify_password, password, u.password_hash if u and u.password_hash else DUMMY_HASH)
    if not (u and u.password_hash and ok and u.is_active):
        if u:
            u.failed_logins = (u.failed_logins or 0) + 1
            if u.failed_logins >= s.login_max_failures:
                u.locked_until, u.failed_logins = now() + timedelta(minutes=s.login_lock_minutes), 0
                audit(session, u.id, "auth.locked", "user", u.id, after={"minutes": s.login_lock_minutes})
            audit(session, u.id, "auth.login_failed", "user", u.id, after={"ip": ip})
            await session.commit()
        raise Unauthorized(INVALID)
    u.failed_logins, u.locked_until, u.last_login_at = 0, None, now()
    if needs_rehash(u.password_hash):
        u.password_hash = await asyncio.to_thread(hash_password, password)
    _, raw = await _issue_refresh(session, u, uuid.uuid4(), now(), ua, ip)
    audit(session, u.id, "auth.login", "user", u.id, after={"ip": ip})
    await session.commit()
    return _token_out(u), raw


async def refresh(session: AsyncSession, raw: str | None, ua: str | None, ip: str | None) -> tuple[TokenOut, str]:
    if not raw:
        raise Unauthorized("Not signed in")
    row = (await session.execute(select(RefreshToken).where(RefreshToken.token_hash == _sha(raw)).with_for_update())).scalar_one_or_none()
    if row is None:
        raise Unauthorized("Session expired. Please sign in again.")
    t = now()
    if row.revoked_at is not None:
        within_grace = row.revoked_reason == "rotated" and row.revoked_at > t - ROTATION_GRACE
        if not within_grace:
            if row.revoked_reason == "rotated":         # an old token came back: assume it was stolen
                await _revoke_family(session, row.family_id, "reuse_detected")
                audit(session, row.user_id, "auth.refresh_reuse_detected", "user", row.user_id, after={"ip": ip})
                await session.commit()
            raise Unauthorized("Session expired. Please sign in again.")
    if row.expires_at <= t:
        raise Unauthorized("Session expired. Please sign in again.")
    u = await session.get(User, row.user_id)
    if u is None or not u.is_active:
        await _revoke_family(session, row.family_id, "deactivated")
        await session.commit()
        raise Unauthorized("Account is disabled")
    new, new_raw = await _issue_refresh(session, u, row.family_id, row.session_started_at, ua, ip)
    if row.revoked_at is None:
        row.revoked_at, row.revoked_reason, row.replaced_by = t, "rotated", new.id
    await session.commit()
    return _token_out(u), new_raw


async def logout(session: AsyncSession, raw: str | None) -> None:
    if not raw:
        return
    row = (await session.execute(select(RefreshToken).where(RefreshToken.token_hash == _sha(raw)))).scalar_one_or_none()
    if row:
        await _revoke_family(session, row.family_id, "logout")
        audit(session, row.user_id, "auth.logout", "user", row.user_id)
        await session.commit()


async def family_of(session: AsyncSession, raw: str | None) -> UUID | None:
    if not raw:
        return None
    return (await session.execute(select(RefreshToken.family_id).where(RefreshToken.token_hash == _sha(raw)))).scalar_one_or_none()


def check_new_password(u: User, new: str) -> None:
    s = get_settings()
    if len(new) < s.password_min_length:
        raise Unprocessable(f"The new password must be at least {s.password_min_length} characters")
    if new == s.default_password:
        raise Unprocessable("The new password cannot be the default password")
    if u.username and u.username.lower() in new.lower():
        raise Unprocessable("The new password cannot contain your username")


async def change_password(session: AsyncSession, u: User, data: ChangePasswordIn, current_family: UUID | None) -> Me:
    if not await asyncio.to_thread(verify_password, data.current_password, u.password_hash):
        raise Unprocessable("The current password is not correct")
    if data.new_password == data.current_password:
        raise Unprocessable("The new password must be different from the current one")
    check_new_password(u, data.new_password)
    u.password_hash = await asyncio.to_thread(hash_password, data.new_password)
    u.must_change_password, u.password_changed_at = False, now()
    await revoke_sessions(session, u.id, "password_changed", keep_family=current_family)   # sign out other devices
    audit(session, u.id, "auth.password_changed", "user", u.id)
    await session.commit()
    return me(u)


# ------------------------------------------------------------------ user administration
def _admin_out(u: User) -> UserAdminOut:
    return UserAdminOut(id=u.id, username=u.username, email=u.email, full_name=u.full_name, roles=sorted(u.roles or []),
                        is_active=u.is_active, must_change_password=u.must_change_password, has_password=bool(u.password_hash),
                        locked_until=u.locked_until if u.locked_until and u.locked_until > now() else None,
                        last_login_at=u.last_login_at, created_at=u.created_at)


def _roles(roles: list[str]) -> list[str]:
    bad = sorted(set(roles) - set(ROLES))
    if bad:
        raise Unprocessable(f"Unknown role(s): {', '.join(bad)}")
    return sorted(set(roles))


async def _password_for(admin_given: str | None, u: User) -> tuple[str, bool]:
    """(hash, must_change). Empty = the default password, which must be changed at sign-in."""
    s = get_settings()
    if not admin_given:
        return await asyncio.to_thread(hash_password, s.default_password), True
    check_new_password(u, admin_given)
    return await asyncio.to_thread(hash_password, admin_given), True


async def list_users(session: AsyncSession) -> list[UserAdminOut]:
    rows = (await session.execute(select(User).order_by(User.is_active.desc(), func.lower(User.full_name)))).scalars().all()
    return [_admin_out(u) for u in rows]


async def _get(session: AsyncSession, uid: UUID) -> User:
    u = await session.get(User, uid)
    if not u:
        raise NotFound("User not found")
    return u


async def _unique(session: AsyncSession, uid: UUID | None, username: str | None, email: str | None) -> None:
    if username and (await session.execute(select(User.id).where(func.lower(User.username) == username.lower(), User.id != uid))).first():
        raise Conflict(f"Username '{username}' is already taken")
    if email and (await session.execute(select(User.id).where(func.lower(User.email) == email.lower(), User.id != uid))).first():
        raise Conflict(f"Email '{email}' is already used")


async def create_user(session: AsyncSession, admin, data: UserCreate) -> UserAdminOut:
    await _unique(session, None, data.username, data.email)
    u = User(id=uuid.uuid4(), username=data.username.lower(), full_name=data.full_name.strip(), email=data.email.strip(),
             roles=_roles(data.roles), is_active=True, failed_logins=0)
    u.password_hash, u.must_change_password = await _password_for(data.password, u)
    session.add(u)
    await session.flush()
    audit(session, admin.id, "user.created", "user", u.id, after={"username": u.username, "roles": u.roles})
    await session.commit()
    await session.refresh(u)
    return _admin_out(u)


async def update_user(session: AsyncSession, admin, uid: UUID, data: UserUpdate) -> UserAdminOut:
    u = await _get(session, uid)
    changes = data.model_dump(exclude_unset=True)
    if u.id == admin.id and (changes.get("is_active") is False or ("roles" in changes and "ADMIN" not in changes["roles"] and "ADMIN" in (u.roles or []))):
        raise Conflict("You cannot deactivate yourself or remove your own ADMIN role")
    await _unique(session, u.id, None, changes.get("email"))
    before = {"roles": u.roles, "is_active": u.is_active}
    if "roles" in changes:
        changes["roles"] = _roles(changes["roles"])
    for k, v in changes.items():
        setattr(u, k, v)
    if changes.get("is_active") is False:
        await revoke_sessions(session, u.id, "deactivated")
    audit(session, admin.id, "user.updated", "user", u.id, before=before, after={k: v for k, v in changes.items()})
    await session.commit()
    await session.refresh(u)
    return _admin_out(u)


async def reset_password(session: AsyncSession, admin, uid: UUID, data: PasswordReset) -> UserAdminOut:
    u = await _get(session, uid)
    u.password_hash, u.must_change_password = await _password_for(data.password, u)
    u.failed_logins, u.locked_until = 0, None
    await revoke_sessions(session, u.id, "password_reset")
    audit(session, admin.id, "user.password_reset", "user", u.id, after={"default": not data.password})
    await session.commit()
    await session.refresh(u)
    return _admin_out(u)


async def unlock(session: AsyncSession, admin, uid: UUID) -> UserAdminOut:
    u = await _get(session, uid)
    u.failed_logins, u.locked_until = 0, None
    audit(session, admin.id, "user.unlocked", "user", u.id)
    await session.commit()
    await session.refresh(u)
    return _admin_out(u)

import uuid
from datetime import datetime, timedelta, timezone
from uuid import UUID

from fastapi import Depends
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from jose import JWTError, jwt
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from bulwark.core.config import get_settings
from bulwark.core.db import get_session
from bulwark.core.errors import AppError, Forbidden
from bulwark.shared.models import User

ADMIN, ANALYST, APPROVER, OPERATOR, VIEWER = "ADMIN", "ANALYST", "APPROVER", "OPERATOR", "VIEWER"
ROLES = (ADMIN, ANALYST, APPROVER, OPERATOR, VIEWER)
# Roles that pass every role check. APPROVER is included for now so approvers can do every operation;
# rules that are not role checks still apply.
FULL_ACCESS = {ADMIN, APPROVER}
bearer = HTTPBearer(auto_error=False)


class CurrentUser(BaseModel):
    id: UUID
    email: str
    name: str
    roles: set[str]
    username: str | None = None

    def has_any(self, *roles: str) -> bool:
        return bool(self.roles & FULL_ACCESS) or bool(self.roles & set(roles))


class Unauthorized(AppError):
    status_code, code = 401, "unauthorized"


def create_access_token(user: User, minutes: int | None = None) -> tuple[str, int]:
    """Short-lived access JWT for a signed-in user. Returns (token, lifetime in seconds)."""
    s = get_settings()
    ttl = (minutes or s.access_token_minutes) * 60
    now = datetime.now(timezone.utc)
    claims = {"sub": str(user.id), "username": user.username, "email": user.email, "name": user.full_name,
              "roles": sorted(user.roles or []), "iss": s.jwt_issuer, "aud": s.jwt_audience, "typ": "access",
              "iat": int(now.timestamp()), "exp": int((now + timedelta(seconds=ttl)).timestamp()), "jti": uuid.uuid4().hex}
    return jwt.encode(claims, s.jwt_secret, algorithm=s.jwt_algorithm), ttl


def decode_token(token: str) -> UUID:
    """Verifies signature, expiry, issuer, audience and type; returns the user id (sub)."""
    s = get_settings()
    try:
        claims = jwt.decode(token, s.jwt_secret, algorithms=[s.jwt_algorithm], audience=s.jwt_audience, issuer=s.jwt_issuer)
        if claims.get("typ") != "access":
            raise Unauthorized("Not an access token")
        return UUID(claims["sub"])
    except (JWTError, KeyError, ValueError) as e:
        raise Unauthorized("Invalid or expired token") from e


async def get_signed_in_user(creds: HTTPAuthorizationCredentials | None = Depends(bearer),
                             session: AsyncSession = Depends(get_session)) -> User:
    """The user behind a valid access token, as stored now: deactivation and role changes apply immediately.
    Used by the sign-in endpoints, which must also work while a password change is pending."""
    if creds is None:
        raise Unauthorized("Missing bearer token")
    user = await session.get(User, decode_token(creds.credentials))
    if user is None or not user.is_active:
        raise Unauthorized("Account is disabled or no longer exists")
    return user


async def get_current_user(user: User = Depends(get_signed_in_user)) -> CurrentUser:
    if user.must_change_password:
        raise Forbidden("Change your password before continuing", code="password_change_required")
    return CurrentUser(id=user.id, email=user.email, name=user.full_name, roles=set(user.roles or []), username=user.username)


def require_roles(*roles: str):
    async def dep(user: CurrentUser = Depends(get_current_user)) -> CurrentUser:
        if not user.has_any(*roles):
            raise Forbidden(f"Requires one of roles: {', '.join(roles)}")
        return user
    return dep

"""Password hashing with scrypt from the standard library (no extra dependency).

Stored format: scrypt$<log2 N>$<r>$<p>$<salt b64>$<hash b64>. The parameters travel with each hash, so they can be
raised later: needs_rehash() tells sign-in to re-hash with the current ones. N=2^15, r=8, p=3 is one of OWASP's
recommended scrypt settings (~32 MiB per hash).
"""
import base64
import hashlib
import hmac
import secrets

LOG_N, R, P, DKLEN = 15, 8, 3, 32
_MAXMEM = 64 * 1024 * 1024


def _b64(b: bytes) -> str:
    return base64.b64encode(b).decode()


def _scrypt(password: str, salt: bytes, log_n: int, r: int, p: int) -> bytes:
    return hashlib.scrypt(password.encode(), salt=salt, n=2 ** log_n, r=r, p=p, dklen=DKLEN, maxmem=_MAXMEM)


def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    return f"scrypt${LOG_N}${R}${P}${_b64(salt)}${_b64(_scrypt(password, salt, LOG_N, R, P))}"


def verify_password(password: str, stored: str | None) -> bool:
    """Constant-time check. False for a missing or malformed hash."""
    try:
        algo, log_n, r, p, salt, digest = (stored or "").split("$")
        if algo != "scrypt":
            return False
        calc = _scrypt(password, base64.b64decode(salt), int(log_n), int(r), int(p))
        return hmac.compare_digest(calc, base64.b64decode(digest))
    except (ValueError, TypeError):
        return False


def needs_rehash(stored: str) -> bool:
    return not stored.startswith(f"scrypt${LOG_N}${R}${P}$")


# verified against when the username does not exist, so a wrong username costs as much time as a wrong password
DUMMY_HASH = hash_password(secrets.token_urlsafe(16))

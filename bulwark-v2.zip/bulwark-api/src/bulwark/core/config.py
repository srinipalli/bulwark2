from functools import lru_cache
from pathlib import Path

from pydantic import SecretStr
from pydantic_settings import BaseSettings, SettingsConfigDict

ROOT = Path(__file__).resolve().parents[3]                  # bulwark-api/
ENV_FILE = ROOT / ".env"                                    # bulwark-api/.env, whatever the working directory


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=ENV_FILE, extra="ignore")

    app_env: str = "local"
    database_url: str = "postgresql+asyncpg://bulwark:bulwark@localhost:5432/bulwark"
    jwt_secret: str = "change-me"
    jwt_algorithm: str = "HS256"
    jwt_issuer: str = "bulwark-api"
    jwt_audience: str = "bulwark"
    cors_origins: list[str] = []

    # Sign-in (POST /api/v1/auth/login). The access JWT lives in the browser's memory; the refresh token in an
    # HttpOnly cookie, rotated on every refresh. A session ends after refresh_token_hours without activity, and at
    # the latest session_max_hours after sign-in.
    access_token_minutes: int = 15
    refresh_token_hours: int = 8
    session_max_hours: int = 24
    refresh_cookie_name: str = "bulwark_refresh"
    refresh_cookie_secure: bool = False           # True whenever the API is served over HTTPS
    refresh_cookie_samesite: str = "lax"          # "none" (with secure) only if UI and API are on different sites
    default_password: str = "admin@123"           # new users and resets; must be changed at first sign-in
    password_min_length: int = 8
    login_max_failures: int = 5                   # consecutive failures before the account locks
    login_lock_minutes: int = 15
    worker_poll_seconds: float = 2.0
    stale_run_grace_seconds: int = 300
    simulate_executors: bool = True

    # Kafka (same settings as bulwark-scan-ingestor). Empty bootstrap servers = events are not published.
    kafka_bootstrap_servers: str = ""
    kafka_security_protocol: str = "PLAINTEXT"      # PLAINTEXT | SSL | SASL_PLAINTEXT | SASL_SSL
    kafka_sasl_mechanism: str = "SCRAM-SHA-256"     # PLAIN | SCRAM-SHA-256 | SCRAM-SHA-512
    kafka_sasl_username: str = ""
    kafka_sasl_password: SecretStr = SecretStr("")
    kafka_ssl_ca_file: str = ""                     # relative paths are resolved against bulwark-api/
    kafka_client_id: str = "bulwark-api"
    kafka_topic_incidents: str = "bulwark.incidents"
    kafka_delivery_timeout_ms: int = 30000
    kafka_socket_timeout_ms: int = 15000


@lru_cache
def get_settings() -> Settings:
    return Settings()

"""Access token for an existing user, for scripts and Swagger "Authorize" (local development only):

  python scripts/dev_token.py <username> [minutes]

Normally clients sign in with POST /api/v1/auth/login. The token is valid for the given minutes (default 60);
the API still checks on every request that the user exists, is active and has no pending password change.
"""
import asyncio
import sys

sys.path.insert(0, "src")
from sqlalchemy import func, select  # noqa: E402

from bulwark.core.db import SessionLocal, engine  # noqa: E402
from bulwark.core.security import create_access_token  # noqa: E402
from bulwark.shared.models import User  # noqa: E402


async def main(username: str, minutes: int) -> None:
    async with SessionLocal() as s:
        u = (await s.execute(select(User).where(func.lower(User.username) == username.lower()))).scalar_one_or_none()
    await engine.dispose()
    if not u:
        sys.exit(f"No user '{username}'")
    print(create_access_token(u, minutes)[0])


if __name__ == "__main__":
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    asyncio.run(main(sys.argv[1], int(sys.argv[2]) if len(sys.argv) > 2 else 60))

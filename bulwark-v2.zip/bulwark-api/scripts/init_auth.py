"""Prepare users for username / password sign-in (after sql/07_auth.sql or alembic upgrade head). Safe to re-run.

  python scripts/init_auth.py

- users without a username get the part of their email before '@'
- users without a password get the default password (DEFAULT_PASSWORD, "admin@123") and must change it at sign-in
- an "admin" user (ADMIN role) is created if there is none
Existing passwords are never touched.
"""
import asyncio
import sys
import uuid

sys.path.insert(0, "src")
from sqlalchemy import func, select  # noqa: E402

from bulwark.core.config import get_settings  # noqa: E402
from bulwark.core.db import SessionLocal, engine  # noqa: E402
from bulwark.core.passwords import hash_password  # noqa: E402
from bulwark.shared.models import User  # noqa: E402


async def main() -> None:
    default = get_settings().default_password
    async with SessionLocal() as s:
        users = (await s.execute(select(User))).scalars().all()
        named = given = 0
        for u in users:
            if not u.username:
                u.username, named = u.email.split("@")[0].lower(), named + 1
            if not u.password_hash:
                u.password_hash, u.must_change_password, given = hash_password(default), True, given + 1
        created = False
        if not (await s.execute(select(User.id).where(func.lower(User.username) == "admin"))).first():
            s.add(User(id=uuid.uuid4(), username="admin", email="admin@example.com", full_name="Administrator",
                       roles=["ADMIN"], is_active=True, password_hash=hash_password(default), must_change_password=True,
                       failed_logins=0))
            created = True
        await s.commit()
    await engine.dispose()
    print(f"{len(users)} existing user(s): {named} username(s) set, {given} given the default password"
          f"{'; created user admin' if created else ''}. Default password users must change it at first sign-in.")


asyncio.run(main())

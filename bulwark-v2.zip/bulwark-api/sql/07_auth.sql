-- Username / password sign-in (POST /api/v1/auth/login -> short-lived access JWT + rotating refresh cookie).
-- Safe to run more than once. Same change as Alembic revision 0005.
-- Afterwards run:  python scripts/init_auth.py   (usernames, default password for users without one, "admin" user)

ALTER TABLE users ADD COLUMN IF NOT EXISTS username             TEXT;
ALTER TABLE users ADD COLUMN IF NOT EXISTS password_hash        TEXT;          -- scrypt$..., never the password itself
ALTER TABLE users ADD COLUMN IF NOT EXISTS must_change_password BOOLEAN NOT NULL DEFAULT TRUE;
ALTER TABLE users ADD COLUMN IF NOT EXISTS failed_logins        INT NOT NULL DEFAULT 0;
ALTER TABLE users ADD COLUMN IF NOT EXISTS locked_until         TIMESTAMPTZ;
ALTER TABLE users ADD COLUMN IF NOT EXISTS last_login_at        TIMESTAMPTZ;
ALTER TABLE users ADD COLUMN IF NOT EXISTS password_changed_at  TIMESTAMPTZ;

UPDATE users SET username = lower(split_part(email, '@', 1)) WHERE username IS NULL;
CREATE UNIQUE INDEX IF NOT EXISTS ux_users_username ON users (lower(username));

-- One row per issued refresh token. Only a SHA-256 of the token is stored. A login starts a family (= session);
-- every refresh revokes the old row and adds a new one in the same family. Reusing a rotated token revokes the family.
CREATE TABLE IF NOT EXISTS refresh_tokens (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id            UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  family_id          UUID NOT NULL,
  token_hash         TEXT NOT NULL UNIQUE,
  session_started_at TIMESTAMPTZ NOT NULL,
  expires_at         TIMESTAMPTZ NOT NULL,
  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  revoked_at         TIMESTAMPTZ,
  revoked_reason     TEXT,              -- rotated | logout | reuse_detected | password_changed | password_reset | deactivated
  replaced_by        UUID,
  user_agent         TEXT,
  ip                 TEXT
);
CREATE INDEX IF NOT EXISTS ix_refresh_tokens_user ON refresh_tokens (user_id);
CREATE INDEX IF NOT EXISTS ix_refresh_tokens_family ON refresh_tokens (family_id);

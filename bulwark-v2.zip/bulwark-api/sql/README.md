# Bulwark database scripts

| File | Purpose |
|---|---|
| `schema.sql` | Full DDL (also applied by Alembic revision `0001`). **Unchanged** - the sample data fits the current schema. |
| `00_truncate_data.sql` | Empties all tables, keeps the schema, restarts identity counters (dev/test only). |
| `00_drop_all.sql` | Drops all tables incl. `alembic_version` (dev/test only). |
| `02_sample_data.sql` | `INSERT` statements for every table, in FK order, in one transaction. |
| `04_allow_solution_self_review.sql` | Drops the solution-review self-approval CHECK on existing databases (same as Alembic `0002`). |
| `05_job_run_chain.sql` | Adds `job_runs.chain` for one-click "Run" on the Execution tab (same as Alembic `0003`). |
| `06_allow_incident_self_approval.sql` | Drops the incident-approval self-approval CHECK on existing databases (same as Alembic `0004`). |
| `07_auth.sql` | Username / password sign-in: login columns on `users` + `refresh_tokens` (same as Alembic `0005`). Then run `python scripts/init_auth.py`. |
| `03_verify.sql` | Row counts, status distribution and 15 integrity checks (each must return 0 rows). |
| `load_sample_data.sh` | Wrapper: optional reset/fresh, load, then run the checks. |
| `../scripts/generate_sample_data.py` | Generator behind `02_sample_data.sql` (deterministic; edit it and re-run to change the data). |

## Load

```bash
# empty database that already has the schema (alembic upgrade head, or psql -f sql/schema.sql)
sql/load_sample_data.sh postgresql://postgres:secret@localhost:5432/bulwark

# wipe existing rows first / rebuild everything
sql/load_sample_data.sh postgresql://postgres:secret@localhost:5432/bulwark --reset
sql/load_sample_data.sh postgresql://postgres:secret@localhost:5432/bulwark --fresh   # not for Alembic-managed DBs

# or just psql
psql "$URL" -f sql/02_sample_data.sql && psql "$URL" -f sql/03_verify.sql
```

## What is in it

| Table | Rows | Notes |
|---|---:|---|
| users | 52 | 3 ADMIN, 12 APPROVER (3 also ANALYST), 16 ANALYST-only (6 also OPERATOR), 14 OPERATOR-only, 7 VIEWER; 2 inactive viewers |
| assets | 76 | web/app/db Linux servers, Windows DCs/Exchange/file servers, FortiGate/F5/Citrix/PAN/Cisco/Pulse appliances, DevOps tools, 15 applications; envs prod/uat/dev/dr |
| vulnerabilities | 60 | real public CVEs (Log4Shell, Spring4Shell, regreSSHion, ProxyShell, MOVEit ...); 3 inactive; 4 have no incident yet |
| vulnerability_assets | 161 | 2-4 matching assets per vulnerability |
| solutions / solution_versions / solution_reviews | 52 / 66 / 66 | 7 REVIEW_PENDING, 3 CHANGES_REQUESTED, 2 REJECTED versions; multi-version solutions; 2 retired |
| incidents | 56 | 12 OPEN, 7 PENDING_APPROVAL, 3 REJECTED, 5 APPROVED, 6 IN_PROGRESS, 18 RESOLVED, 5 CLOSED (one per vulnerability) |
| incident_assets | 149 | PENDING / IN_PROGRESS / PATCHED / FAILED / EXCLUDED with reasons |
| incident_plan_steps | 144 | 1-5 ordered steps per incident, pinned to approved versions (snapshot -> patch -> reboot/restart -> health check/rescan) |
| incident_approvals | 50 | 7 pending (approval queue), approved, rejected-then-resubmitted history, 2 cancelled |
| job_runs | 186 | 171 SUCCEEDED, 13 FAILED (some retried as attempt 2), 2 RUNNING; demonstrates queue, retry and idempotency keys |
| job_run_logs | 902 | Ansible / SSM / shell / HTTP style output, errors on stderr |
| audit_logs | 481 | same action names the API writes (`incident.submitted`, `execution.step_queued`, ...) |

"Now" in the data set is **2026-10-23 06:00 UTC**. Everything is fictional; CVE ids/titles are real but verify CVSS values against NVD before reporting.

## Logging in as a seeded user

Seeded users use the same id/email scheme as `scripts/dev_token.py`, so a token for the same slug **is** that user:

```bash
python scripts/dev_token.py aarav.iyer ADMIN          # admin
python scripts/dev_token.py karthik.bose APPROVER     # approver (pending approvals are waiting)
python scripts/dev_token.py mei.shetty ANALYST OPERATOR
```

Do not mint a token with a *random* id for an existing email: the user upsert would hit the unique email index and the API returns 500.
(`scripts/seed.py` is the tiny alternative seed; do not combine it with this data set.)

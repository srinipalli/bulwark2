-- Removes ALL rows from every Bulwark table but keeps the schema (and alembic_version). Identity counters restart at 1.
-- WARNING: destroys data. Use on dev/test databases only.
TRUNCATE TABLE job_run_logs, job_runs, incident_approvals, incident_plan_steps, incident_assets, incidents,
               solution_reviews, solution_versions, solutions, vulnerability_assets, vulnerabilities, assets,
               audit_logs, refresh_tokens, users
  RESTART IDENTITY CASCADE;

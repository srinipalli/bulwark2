import os
import uuid
from pathlib import Path

import pytest
import pytest_asyncio

TEST_URL = os.environ.get("TEST_DATABASE_URL")
if TEST_URL:
    os.environ["DATABASE_URL"] = TEST_URL
os.environ.setdefault("JWT_SECRET", "test-secret")
os.environ["SIMULATE_EXECUTORS"] = "true"
os.environ["KAFKA_BOOTSTRAP_SERVERS"] = ""          # never publish test incidents to a real topic

pytestmark = pytest.mark.skipif(not TEST_URL, reason="set TEST_DATABASE_URL (postgresql+asyncpg://...) to run")


@pytest_asyncio.fixture(scope="session", autouse=True, loop_scope="session")
async def schema():
    if not TEST_URL:
        pytest.skip("TEST_DATABASE_URL not set")
    from sqlalchemy import text

    from bulwark.core.db import engine
    from bulwark.core.sqlutil import schema_statements

    from bulwark.core.passwords import hash_password
    from bulwark.shared.models import User

    async with engine.begin() as c:
        await c.execute(text("DROP SCHEMA public CASCADE"))
        await c.execute(text("CREATE SCHEMA public"))
        for stmt in schema_statements(Path(__file__).parent.parent / "sql" / "schema.sql"):
            await c.exec_driver_sql(stmt)
    # the API only accepts tokens of users that exist, are active and have no pending password change
    from bulwark.core.db import SessionLocal
    async with SessionLocal() as s:
        pw = hash_password(TEST_PASSWORD)
        s.add_all([User(id=_uid(n), username=n, email=f"{n}@example.com", full_name=n.title(), roles=r, is_active=True,
                        password_hash=pw, must_change_password=False, failed_logins=0) for n, r in USERS.items()])
        await s.commit()


TEST_PASSWORD = "Test-Password-123"
USERS = {"ravi": ["ANALYST", "OPERATOR"], "srini": ["APPROVER"], "meena": ["ANALYST", "APPROVER"], "viewer": ["VIEWER"]}


def _uid(name: str) -> uuid.UUID:
    return uuid.uuid5(uuid.NAMESPACE_DNS, name)


def make_token(name: str) -> dict:
    from bulwark.core.security import create_access_token
    from bulwark.shared.models import User
    tok, _ = create_access_token(User(id=_uid(name), username=name, email=f"{name}@example.com", full_name=name.title(),
                                      roles=USERS[name]))
    return {"Authorization": f"Bearer {tok}"}


@pytest.fixture(scope="session")
def users():
    return {name: make_token(name) for name in USERS}


@pytest_asyncio.fixture(scope="session", loop_scope="session")
async def client():
    import httpx

    from bulwark.main import app
    async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url="http://test") as c:
        yield c

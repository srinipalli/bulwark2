"""Tests for the insights and scans modules. Copy into bulwark-api/tests/ and run with the same TEST_DATABASE_URL as test_flow.py.
Gemini is replaced by an offline embedder; the semantic incident search needs the pgvector extension and is skipped without it."""
import hashlib
import math

import pytest
from bulwark.core.db import SessionLocal
from bulwark.main import app
from bulwark.modules.insights.embeddings import get_embedder
from bulwark.modules.scans.settings import get_scan_settings
from bulwark.shared.models import Asset
from sqlalchemy import text

pytestmark = pytest.mark.asyncio
P = "/api/v1"
MODEL = "gemini:gemini-embedding-001:768"


class FakeEmbedder:
    name, dim = MODEL, 768

    @staticmethod
    def vec(t: str) -> list[float]:
        v = [0.0] * 768
        for w in "".join(c if c.isalnum() else " " for c in t.lower()).split():
            v[int(hashlib.md5(w.encode()).hexdigest(), 16) % 768] += 1.0
        n = math.sqrt(sum(x * x for x in v)) or 1.0
        return [x / n for x in v]

    async def embed(self, texts):
        return [self.vec(t) for t in texts]


@pytest.fixture(autouse=True)
def fake_embedder():
    app.dependency_overrides[get_embedder] = lambda: FakeEmbedder()
    yield
    app.dependency_overrides.pop(get_embedder, None)


async def seed(client, users):
    ravi, srini = users["ravi"], users["srini"]
    async with SessionLocal() as s:
        a = Asset(name="ins-web-01", asset_type="SYSTEM", environment="prod")
        s.add(a)
        await s.commit()
        aid = str(a.id)
    v = (await client.post(f"{P}/vulnerabilities", headers=ravi, json={
        "cve_id": "CVE-2026-7001", "title": "Struts remote code execution", "severity": "CRITICAL", "cvss_score": 9.8,
        "description": "Remote code execution in a java web framework", "asset_ids": [aid]})).json()
    inc = (await client.post(f"{P}/incidents", headers=ravi, json={"vulnerability_id": v["id"]})).json()
    sol = (await client.post(f"{P}/solutions", headers=ravi, json={
        "title": "Upgrade Struts framework", "description": "patch java web framework", "executor": "ANSIBLE", "job_spec": {},
        "risk_level": "LOW"})).json()
    rid = next(x["id"] for x in (await client.get(f"{P}/approvals/solutions", headers=srini)).json()["items"] if x["title"] == sol["title"])
    assert (await client.post(f"{P}/approvals/solutions/{rid}/approve", headers=srini)).status_code == 200
    return inc, sol


async def test_lookup_briefing_risk_audit_solutions(client, users):
    ravi = users["ravi"]
    inc, sol = await seed(client, users)
    assert (await client.get(f"{P}/insights/risk-report")).status_code == 401

    r = await client.get(f"{P}/insights/incidents/lookup", params={"code": inc["code"].lower()}, headers=ravi)
    assert r.status_code == 200 and r.json()["id"] == inc["id"] and r.json()["code"] == inc["code"]
    assert (await client.get(f"{P}/insights/incidents/lookup", params={"code": "INC-999999"}, headers=ravi)).status_code == 404
    assert (await client.get(f"{P}/insights/incidents/lookup", params={"code": "nonsense"}, headers=ravi)).status_code == 422

    for ref in (inc["code"], inc["id"]):                       # code or UUID
        b = (await client.get(f"{P}/insights/incidents/{ref}/briefing", headers=ravi)).json()
        assert b["incident"]["status"] == "OPEN" and b["assets"]["count"] == 1 and b["next_actions"] and b["execution"] is None
    assert (await client.get(f"{P}/insights/incidents/INC-999999/briefing", headers=ravi)).status_code == 404

    rep = (await client.get(f"{P}/insights/risk-report", params={"top_n": 3}, headers=ravi)).json()
    assert any(x["incidents"] >= 1 and x["severity"] == "CRITICAL" for x in rep["open_incidents_by_severity_and_status"])
    assert rep["oldest_open_incidents"][0]["code"].startswith("INC-") and rep["most_exposed_assets"][0]["name"] == "ins-web-01"
    assert rep["failed_jobs_last_7_days"]["failed_runs_7d"] == 0

    au = (await client.get(f"{P}/insights/audit", params={"entity_type": "incident", "entity_id": inc["id"]}, headers=ravi)).json()
    assert au and all(e["entity_id"] == inc["id"] for e in au)
    assert (await client.get(f"{P}/insights/audit", params={"entity_id": inc["id"]}, headers=ravi)).status_code == 422
    assert (await client.get(f"{P}/insights/audit", params={"limit": 5}, headers=ravi)).status_code == 200

    hits = (await client.get(f"{P}/insights/solutions/search", params={"q": "java web framework patch"}, headers=ravi)).json()
    assert hits and hits[0]["id"] == sol["id"] and hits[0]["score"] > 0


async def test_semantic_incident_search(client, users):
    ravi = users["ravi"]
    async with SessionLocal() as s:
        try:
            await s.execute(text("CREATE EXTENSION IF NOT EXISTS vector"))
            await s.commit()
        except Exception:                                      # noqa: BLE001
            pytest.skip("pgvector is not available")
    r = await client.get(f"{P}/insights/incidents/search", params={"q": "java web framework remote code"}, headers=ravi)
    assert r.status_code == 503 and r.json()["error"]["code"] == "embeddings_unavailable"   # test schema has no embedding column
    async with SessionLocal() as s:
        await s.execute(text("ALTER TABLE incidents ADD COLUMN IF NOT EXISTS embedding vector(768), ADD COLUMN IF NOT EXISTS embedding_model text"))
        rows = (await s.execute(text("SELECT i.id, i.title, v.description FROM incidents i JOIN vulnerabilities v ON v.id = i.vulnerability_id"))).all()
        for iid, title, desc in rows:
            vec = "[" + ",".join(f"{x:.7f}" for x in FakeEmbedder.vec(f"{title}. {desc or ''}")) + "]"
            await s.execute(text("UPDATE incidents SET embedding = CAST(:v AS vector), embedding_model = :m WHERE id = :i"), {"v": vec, "m": MODEL, "i": iid})
        await s.commit()
    r = await client.get(f"{P}/insights/incidents/search", params={"q": "remote code execution java web framework"}, headers=ravi)
    body = r.json()
    assert r.status_code == 200 and body["results"] and body["results"][0]["similarity"] > 0.3 and body["embedding_model"] == MODEL
    assert (await client.get(f"{P}/insights/incidents/search", params={"q": "zzzz qqqq", "min_similarity": 0.9}, headers=ravi)).json()["results"] == []


async def test_scans(client, users, tmp_path, monkeypatch):
    ravi, viewer = users["ravi"], users["viewer"]
    ing = tmp_path / "ingestor"
    ing.mkdir()
    inbox = tmp_path / "inbox"
    inbox.mkdir()
    (inbox / "scan1.xlsx").write_bytes(b"x" * 2048)
    (inbox / "notes.txt").write_text("not a workbook")
    (ing / "fake_ingestor.py").write_text(
        "import sys\nprint('args:', ' '.join(sys.argv[1:]))\nsys.exit(0 if '--validate-only' in sys.argv else 3)\n")
    s = get_scan_settings()
    monkeypatch.setattr(s, "scan_inbox", str(inbox))
    monkeypatch.setattr(s, "scan_ingestor_dir", str(ing))
    monkeypatch.setattr(s, "scan_ingestor_cmd", "python fake_ingestor.py")

    assert [w["file"] for w in (await client.get(f"{P}/scans/workbooks", headers=viewer)).json()] == ["scan1.xlsx"]
    v = (await client.post(f"{P}/scans/validate", json={"file_name": "scan1.xlsx"}, headers=ravi)).json()
    assert v["exit_code"] == 0 and "--validate-only" in v["output_tail"][0]
    assert (await client.post(f"{P}/scans/validate", json={"file_name": "scan1.xlsx"}, headers=viewer)).status_code == 403
    i = (await client.post(f"{P}/scans/ingest", json={"file_name": "scan1.xlsx"}, headers=ravi)).json()
    assert i["exit_code"] == 3 and i["result"] == "another ingestor instance is running" and "--validate-only" not in i["output_tail"][0]
    for bad in ("../scan1.xlsx", "/etc/passwd.xlsx", "notes.txt", ".hidden.xlsx"):
        assert (await client.post(f"{P}/scans/ingest", json={"file_name": bad}, headers=ravi)).status_code == 422
    assert (await client.post(f"{P}/scans/ingest", json={"file_name": "missing.xlsx"}, headers=ravi)).status_code == 404
    log = (await client.get(f"{P}/insights/audit", params={"limit": 5}, headers=ravi)).json()
    assert any(e["action"] == "scan.ingest" for e in log)

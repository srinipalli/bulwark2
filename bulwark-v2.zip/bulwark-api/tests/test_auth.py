from conftest import TEST_PASSWORD

P = "/api/v1"
H = {"X-Requested-With": "bulwark"}


async def test_sign_in_session(client):
    # wrong password and unknown user look the same
    bad = await client.post(f"{P}/auth/login", json={"username": "ravi", "password": "nope"})
    unknown = await client.post(f"{P}/auth/login", json={"username": "nobody", "password": "nope"})
    assert bad.status_code == unknown.status_code == 401 and bad.json() == unknown.json()

    r = await client.post(f"{P}/auth/login", json={"username": "RAVI", "password": TEST_PASSWORD})
    assert r.status_code == 200, r.text
    body, cookie = r.json(), client.cookies.get("bulwark_refresh")
    assert body["user"]["roles"] == ["ANALYST", "OPERATOR"] and body["expires_in"] == 900 and cookie
    auth = {"Authorization": f"Bearer {body['access_token']}"}
    assert (await client.get(f"{P}/dashboard/summary", headers=auth)).status_code == 200

    assert (await client.post(f"{P}/auth/refresh")).status_code == 403                    # CSRF header required
    r = await client.post(f"{P}/auth/refresh", headers=H)
    assert r.status_code == 200 and client.cookies.get("bulwark_refresh") != cookie         # rotated

    assert (await client.post(f"{P}/auth/logout", headers=H)).status_code == 204
    client.cookies.clear()
    assert (await client.post(f"{P}/auth/refresh", headers=H, cookies={"bulwark_refresh": cookie})).status_code == 401


async def test_password_change_required_and_admin(client, users):
    # an admin creates a user with the default password; it must be changed before anything else works
    me = (await client.get(f"{P}/auth/me", headers=users["srini"])).json()          # APPROVER has full access for now
    assert me["username"] == "srini"
    r = await client.post(f"{P}/admin/users", headers=users["srini"],
                          json={"username": "new.user", "full_name": "New User", "email": "new.user@example.com", "roles": ["VIEWER"]})
    assert r.status_code == 201 and r.json()["must_change_password"]
    assert (await client.post(f"{P}/admin/users", headers=users["viewer"],
                              json={"username": "x.y", "full_name": "X", "email": "x@example.com", "roles": ["VIEWER"]})).status_code == 403

    r = await client.post(f"{P}/auth/login", json={"username": "new.user", "password": "admin@123"})
    tok = {"Authorization": f"Bearer {r.json()['access_token']}"}
    assert r.json()["user"]["must_change_password"]
    assert (await client.get(f"{P}/vulnerabilities", headers=tok)).json()["error"]["code"] == "password_change_required"
    r = await client.post(f"{P}/auth/change-password", headers=tok, json={"current_password": "admin@123", "new_password": "short"})
    assert r.status_code == 422
    r = await client.post(f"{P}/auth/change-password", headers=tok,
                          json={"current_password": "admin@123", "new_password": "A-much-longer-secret-1"})
    assert r.status_code == 200 and not r.json()["must_change_password"]
    assert (await client.get(f"{P}/vulnerabilities", headers=tok)).status_code == 200


async def test_lockout(client, users):
    for _ in range(5):
        await client.post(f"{P}/auth/login", json={"username": "viewer", "password": "wrong"})
    r = await client.post(f"{P}/auth/login", json={"username": "viewer", "password": TEST_PASSWORD})
    assert r.status_code == 401 and r.json()["error"]["code"] == "locked"
    uid = next(u["id"] for u in (await client.get(f"{P}/admin/users", headers=users["srini"])).json() if u["username"] == "viewer")
    assert (await client.post(f"{P}/admin/users/{uid}/unlock", headers=users["srini"])).status_code == 200
    assert (await client.post(f"{P}/auth/login", json={"username": "viewer", "password": TEST_PASSWORD})).status_code == 200

# Bulwark UI (React)

React 18 + Vite front end for the Bulwark API: Dashboard, Incidents, Approvals (incident / solution tabs),
Vulnerability List, Solution List and Execution. Light-blue Innova theme with a left sidebar, matching the wireframe.

## Run

```bash
npm install
npm run dev        # http://localhost:3000
npm run build      # static files in dist/ (serve with any web server)
```

## Backend URL (configurable)

Highest priority first:

1. **Settings** (gear in the header) – stored in the browser, takes effect immediately.
2. **`public/config.js`** – `window.__BULWARK_CONFIG__ = { apiBaseUrl: "http://localhost:8000" }`.
   Copied as-is into `dist/`, so you can change it after building without rebuilding.
3. **`VITE_API_BASE_URL`** at build time (see `.env.example`).
4. Default `http://localhost:8000`.

## Bulwark Assistant (chat icon)

Every page has a floating chat icon (bottom right, `src/components/ChatIcon.jsx`). It opens the assistant chat from the
sibling project **`../bulwark-agent-ui`** (`src/chat`, imported through the `@bulwark/agent-chat` alias in
`vite.config.js`, so it must be checked out next to this project). It uses the token of the user signed in here,
shows each task the agent runs, asks before any change, and reloads the page data after an approved change.

- Needs `bulwark-chat-server` (bulwark-ai/bulwark-chat-agent) running; its `CORS_ORIGINS` must include this UI's origin.
- URL: Settings → *Assistant URL*, or `agentUrl` in `public/config.js`, or `VITE_AGENT_URL`; default `http://localhost:8800`.

## Backend requirements

- `CORS_ORIGINS` must include the UI origin, e.g. `["http://localhost:3000"]`.
- Start the **worker** (`python -m bulwark.modules.execution.worker`) or runs stay *Queued*.

## Signing in

Username + password (`POST /api/v1/auth/login`). Users start with the default password **`admin@123`** and must choose
their own before anything else works; an administrator can reset it back (Users page). The API returns a 15-minute
access token, kept **in memory only** (`src/api/client.js`) and renewed a minute before it expires; the session itself
is an HttpOnly refresh cookie the browser sends to `/api/v1/auth`, so a page reload stays signed in. A session ends after
8 h without activity, after 24 h at most, on *Sign out*, or when an administrator deactivates the user or resets the
password. Role checks in the UI only enable or disable buttons; the API enforces them.

The API's `CORS_ORIGINS` must list this UI's exact origin (credentials are allowed only for those origins).
If the UI and API end up on different sites (not just different ports), set `REFRESH_COOKIE_SAMESITE=none` and
`REFRESH_COOKIE_SECURE=true` (HTTPS) on the API.

## Tests

`npm test` runs the offline tests; the page tests also run when a signed-in user is given. With the backend and worker
running, as a user whose password is already changed:

```bash
BULWARK_USER=<username> BULWARK_PASSWORD=<password> npm run smoke   # vuln -> solution -> approve -> incident -> approve -> run
BULWARK_USER=<username> BULWARK_PASSWORD=<password> npm test        # also renders each page against the live API
```

import { Route, Routes } from 'react-router-dom';
import { AuthProvider, useAuth } from './auth/AuthContext';
import LoginPage from './auth/LoginPage';
import { ChangePasswordPage } from './auth/ChangePassword';
import Users from './pages/Users';
import Layout from './components/Layout';
import { ToastProvider } from './components/ui';
import Dashboard from './pages/Dashboard';
import Incidents from './pages/Incidents';
import IncidentView from './pages/IncidentView';
import Approvals from './pages/Approvals';
import Vulnerabilities from './pages/Vulnerabilities';
import Solutions from './pages/Solutions';
import Execution from './pages/Execution';
import Assets from './pages/Assets';

function Gate() {
  const { status, user } = useAuth();
  if (status === 'checking') return <div className="login-wrap"><div className="muted">Loading…</div></div>;
  if (!user) return <LoginPage />;
  if (user.must_change_password) return <ChangePasswordPage />;
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<Dashboard />} />            {/* landing page is always the Dashboard */}
        <Route path="incidents" element={<Incidents />} />
        <Route path="incidents/:id" element={<IncidentView />} />
        <Route path="approvals" element={<Approvals />} />
        <Route path="vulnerabilities" element={<Vulnerabilities />} />
        <Route path="solutions" element={<Solutions />} />
        <Route path="execution" element={<Execution />} />
        <Route path="assets" element={<Assets />} />
        <Route path="users" element={<Users />} />
        <Route path="*" element={<Dashboard />} />
      </Route>
    </Routes>
  );
}

export default function App() {
  return <AuthProvider><ToastProvider><Gate /></ToastProvider></AuthProvider>;
}

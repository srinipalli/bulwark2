import { ChatWidget } from '@bulwark/agent-chat';
import { useAuth } from '../auth/AuthContext';
import { getAgentUrl } from '../config';

// Floating Bulwark Assistant (component from bulwark-agent-ui). Uses the token of the user signed in here;
// after an approved change it fires 'bulwark:changed' so the open page and the sidebar counts reload.
export default function ChatIcon() {
  const { user, token, logout } = useAuth();
  if (!user) return null;
  return (
    <ChatWidget agentUrl={getAgentUrl} token={token} userName={user.name} onUnauthorized={logout}
      onDataChanged={() => window.dispatchEvent(new Event('bulwark:changed'))} />
  );
}

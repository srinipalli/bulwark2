import { request } from './client';

const get = (path, params) => request(path, { params });
const post = (path, body) => request(path, { method: 'POST', body });

export const api = {
  dashboard: {
    summary: () => get('/dashboard/summary'),
    attention: (limit = 10) => get('/dashboard/attention', { limit }),
  },
  incidents: {
    list: (params) => get('/incidents', params),
    get: (id) => get(`/incidents/${id}`),
    similar: (id) => get(`/incidents/${id}/similar`),
    aiPlan: (id) => get(`/incidents/${id}/ai-plan`),
    applyAiPlan: (id, plan_id) => post(`/incidents/${id}/ai-plan/apply`, { plan_id }),
    dismissAiPlan: (id, plan_id, comment) => post(`/incidents/${id}/ai-plan/dismiss`, { plan_id, comment }),
    updateAiDraft: (id, draftId, body) => request(`/incidents/${id}/ai-plan/drafts/${draftId}`, { method: 'PATCH', body }),
    create: (body) => post('/incidents', body),
    update: (id, body) => request(`/incidents/${id}`, { method: 'PATCH', body }),
    replaceAssets: (id, asset_ids) => request(`/incidents/${id}/assets`, { method: 'PUT', body: { asset_ids } }),
    excludeAsset: (id, incidentAssetId, reason) => post(`/incidents/${id}/assets/${incidentAssetId}/exclude`, { reason }),
    replacePlan: (id, steps) => request(`/incidents/${id}/plan`, { method: 'PUT', body: { steps } }),
    clearPlan: (id) => request(`/incidents/${id}/plan`, { method: 'DELETE' }),
    copyPlan: (id, source_incident_id) => post(`/incidents/${id}/plan/copy-from`, { source_incident_id }),
    submit: (id) => post(`/incidents/${id}/submit`),
    setStatus: (id, status, comment) => post(`/incidents/${id}/status`, { status, comment }),
    close: (id) => post(`/incidents/${id}/close`),
  },
  approvals: {
    summary: () => get('/approvals/summary'),
    incidents: (params) => get('/approvals/incidents', params),
    approveIncident: (id, comment) => post(`/approvals/incidents/${id}/approve`, { comment }),
    rejectIncident: (id, comment) => post(`/approvals/incidents/${id}/reject`, { comment }),
    solutions: (params) => get('/approvals/solutions', params),
    approveSolution: (id, comment) => post(`/approvals/solutions/${id}/approve`, { comment }),
    rejectSolution: (id, comment) => post(`/approvals/solutions/${id}/reject`, { comment }),
    requestChanges: (id, comment) => post(`/approvals/solutions/${id}/request-changes`, { comment }),
  },
  vulnerabilities: {
    list: (params) => get('/vulnerabilities', params),
    get: (id) => get(`/vulnerabilities/${id}`),
    create: (body) => post('/vulnerabilities', body),
    update: (id, body) => request(`/vulnerabilities/${id}`, { method: 'PATCH', body }),
    activate: (id) => post(`/vulnerabilities/${id}/activate`),
    deactivate: (id) => post(`/vulnerabilities/${id}/deactivate`),
  },
  solutions: {
    list: (params) => get('/solutions', params),
    get: (id) => get(`/solutions/${id}`),
    create: (body) => post('/solutions', body),
    update: (id, body) => request(`/solutions/${id}`, { method: 'PATCH', body }),
    retire: (id) => post(`/solutions/${id}/retire`),
    suggestions: (incident_id, limit = 5) => get('/solutions/suggestions', { incident_id, limit }),
  },
  execution: {
    incidents: () => get('/execution/incidents'),
    grid: (id) => get(`/execution/incidents/${id}/grid`),
    runStep: (id, stepNo, incident_asset_ids) =>
      post(`/execution/incidents/${id}/steps/${stepNo}/run`, incident_asset_ids ? { incident_asset_ids } : {}),
    runPlan: (id, incident_asset_ids) =>
      post(`/execution/incidents/${id}/run`, incident_asset_ids ? { incident_asset_ids } : {}),
    runs: (params) => get('/execution/runs', params),
    run: (id) => get(`/execution/runs/${id}`),
    logs: (id, after_id = 0) => get(`/execution/runs/${id}/logs`, { after_id }),
    cancel: (id) => post(`/execution/runs/${id}/cancel`),
  },
  assets: {
    list: (params) => get('/assets/inventory', params),
    facets: () => get('/assets/facets'),
    get: (id) => get(`/assets/${id}`),
    create: (body) => post('/assets', body),
    update: (id, body) => request(`/assets/${id}`, { method: 'PATCH', body }),
    activate: (id) => post(`/assets/${id}/activate`),
    deactivate: (id) => post(`/assets/${id}/deactivate`),
  },
  users: {                                                // user administration (ADMIN)
    list: () => get('/admin/users'),
    create: (body) => post('/admin/users', body),
    update: (id, body) => request(`/admin/users/${id}`, { method: 'PATCH', body }),
    resetPassword: (id, password) => post(`/admin/users/${id}/reset-password`, password ? { password } : {}),
    unlock: (id) => post(`/admin/users/${id}/unlock`),
  },
  reference: {
    assets: (params) => get('/assets', params),          // active assets for the pickers (unpaged)
    users: () => get('/users'),
  },
};

import { getApiBase } from '../config';

// Session: the access token lives in memory only (never localStorage); the refresh token is an HttpOnly cookie the
// browser sends to /api/v1/auth. The access token is renewed a minute before it expires, and once more on a 401.
let accessToken = '';
let refreshTimer = null;
let refreshing = null;                 // one refresh at a time, shared by every caller
const listeners = new Set();

export const getToken = () => accessToken;
/** Notified with the new session ({ access_token, expires_in, user }) or null when it ends. */
export const onSession = (fn) => { listeners.add(fn); return () => listeners.delete(fn); };

function setSession(data) {
  accessToken = data?.access_token || '';
  clearTimeout(refreshTimer);
  if (data?.expires_in) {
    refreshTimer = setTimeout(() => { refreshSession().catch(() => {}); }, Math.max(10, data.expires_in - 60) * 1000);
  }
  listeners.forEach((fn) => fn(data || null));
}

export class ApiError extends Error {
  constructor(status, code, message) {
    super(message);
    this.status = status;
    this.code = code;
  }
}

function qs(params) {
  if (!params) return '';
  const p = new URLSearchParams();
  Object.entries(params).forEach(([k, v]) => {
    if (v !== undefined && v !== null && v !== '') p.append(k, v);
  });
  const s = p.toString();
  return s ? `?${s}` : '';
}

function toError(status, data) {
  if (data?.error) return new ApiError(status, data.error.code, data.error.message);
  if (Array.isArray(data?.detail)) {            // FastAPI request validation
    const msg = data.detail.map((d) => `${(d.loc || []).slice(1).join('.') || 'request'}: ${d.msg}`).join('; ');
    return new ApiError(status, 'validation_error', msg);
  }
  return new ApiError(status, 'http_error', typeof data?.detail === 'string' ? data.detail : `Request failed (${status})`);
}

async function send(path, { method = 'GET', body, params, auth = false } = {}) {
  let res;
  try {
    res = await fetch(`${getApiBase()}/api/v1${path}${qs(params)}`, {
      method,
      headers: {
        'Content-Type': 'application/json',
        ...(accessToken ? { Authorization: `Bearer ${accessToken}` } : {}),
        ...(auth ? { 'X-Requested-With': 'bulwark' } : {}),     // required by the cookie-based auth endpoints
      },
      body: body !== undefined ? JSON.stringify(body) : undefined,
      credentials: auth ? 'include' : 'same-origin',              // the refresh cookie only goes to /auth
    });
  } catch {
    throw new ApiError(0, 'network', `Cannot reach the API at ${getApiBase()}. Is the backend running (and CORS allowing this origin)?`);
  }
  let data = null;
  try { data = await res.json(); } catch { /* empty body */ }
  if (!res.ok) throw toError(res.status, data);
  return data;
}

function endSession() {
  setSession(null);
  if (typeof window !== 'undefined') window.dispatchEvent(new Event('bulwark:unauthorized'));
}

/** New access token from the refresh cookie (rotates it). Rejects when there is no valid session. */
export function refreshSession() {
  if (!refreshing) {
    refreshing = send('/auth/refresh', { method: 'POST', auth: true })
      .then((data) => { setSession(data); return data; })
      .catch((e) => { if (e.status === 401 || e.status === 403) setSession(null); throw e; })
      .finally(() => { refreshing = null; });
  }
  return refreshing;
}

export async function login(username, password) {
  const data = await send('/auth/login', { method: 'POST', body: { username, password }, auth: true });
  setSession(data);
  return data;
}

export async function logout() {
  try { await send('/auth/logout', { method: 'POST', auth: true }); } catch { /* signed out locally anyway */ }
  setSession(null);
}

export async function request(path, opts = {}) {
  try {
    return await send(path, opts);
  } catch (e) {
    if (e.status !== 401) throw e;
    try { await refreshSession(); } catch { endSession(); throw e; }    // expired access token: renew once, retry
    try { return await send(path, opts); } catch (e2) { if (e2.status === 401) endSession(); throw e2; }
  }
}

/** Health check lives outside /api/v1 */
export async function ping() {
  const res = await fetch(`${getApiBase()}/health/ready`);
  if (!res.ok) throw new ApiError(res.status, 'unhealthy', `Backend answered ${res.status}`);
  return res.json();
}

/** For tests and scripts that obtained a token themselves. */
export const setAccessToken = (token) => setSession(token ? { access_token: token } : null);

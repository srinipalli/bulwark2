const KEY = 'bulwark.apiBaseUrl';
const DEFAULT = 'http://localhost:8000';

const store = () => (typeof localStorage !== 'undefined' ? localStorage : null);

/** Priority: Settings dialog override > public/config.js (runtime) > VITE_API_BASE_URL (build) > localhost:8000 */
export function getApiBase() {
  const runtime = typeof window !== 'undefined' ? window.__BULWARK_CONFIG__?.apiBaseUrl : undefined;
  const v = store()?.getItem(KEY) || runtime || import.meta.env?.VITE_API_BASE_URL || DEFAULT;
  return v.replace(/\/+$/, '');
}

export function setApiBase(value) {
  const s = store();
  if (!s) return;
  if (value && value.trim()) s.setItem(KEY, value.trim());
  else s.removeItem(KEY);
}

// Bulwark Assistant (bulwark-chat-server). Same priority order as the API URL.
const AGENT_KEY = 'bulwark.agentUrl';
const AGENT_DEFAULT = 'http://localhost:8800';

export function getAgentUrl() {
  const runtime = typeof window !== 'undefined' ? window.__BULWARK_CONFIG__?.agentUrl : undefined;
  const v = store()?.getItem(AGENT_KEY) || runtime || import.meta.env?.VITE_AGENT_URL || AGENT_DEFAULT;
  return v.replace(/\/+$/, '');
}

export function setAgentUrl(value) {
  const s = store();
  if (!s) return;
  if (value && value.trim()) s.setItem(AGENT_KEY, value.trim());
  else s.removeItem(AGENT_KEY);
}

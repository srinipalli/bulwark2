import { useState } from 'react';
import { api } from '../api/endpoints';
import { useAuth } from '../auth/AuthContext';
import { Badge, ConfirmModal, Field, Loading, Modal, useAction } from '../components/ui';
import { fmt, useAsync } from '../hooks';

const ROLES = ['ADMIN', 'APPROVER', 'ANALYST', 'OPERATOR', 'VIEWER'];
const ROLE_HINT = { ADMIN: 'everything, incl. users', APPROVER: 'approvals (full access for now)', ANALYST: 'vulnerabilities, solutions, incidents', OPERATOR: 'runs execution', VIEWER: 'read-only' };

function state(u) {
  if (!u.is_active) return ['', 'Inactive'];
  if (u.locked_until) return ['FAILED', 'Locked'];
  if (!u.has_password) return ['', 'No password'];
  if (u.must_change_password) return ['PENDING', 'Must change password'];
  return ['APPROVED', 'Active'];
}

function UserForm({ user, onClose, onSaved }) {
  const act = useAction();
  const editing = !!user;
  const [f, setF] = useState({ username: user?.username || '', full_name: user?.full_name || '', email: user?.email || '',
    roles: user?.roles || ['VIEWER'], is_active: user?.is_active ?? true, password: '' });
  const set = (k) => (e) => setF({ ...f, [k]: e.target.type === 'checkbox' ? e.target.checked : e.target.value });
  const toggle = (r) => setF({ ...f, roles: f.roles.includes(r) ? f.roles.filter((x) => x !== r) : [...f.roles, r] });
  const valid = f.full_name.trim() && /^[^@\s]+@[^@\s]+$/.test(f.email) && f.roles.length && (editing || /^[A-Za-z0-9._-]{3,}$/.test(f.username));
  const save = async () => {
    const r = await act(() => (editing
      ? api.users.update(user.id, { full_name: f.full_name.trim(), email: f.email.trim(), roles: f.roles, is_active: f.is_active })
      : api.users.create({ username: f.username.trim(), full_name: f.full_name.trim(), email: f.email.trim(), roles: f.roles, password: f.password || null })),
    editing ? 'User updated' : `User ${f.username} created`);
    if (r) onSaved();
  };
  return (
    <Modal title={editing ? `Edit ${user.username}` : 'Add user'} onClose={onClose} wide
      footer={<><button className="btn sec" onClick={onClose}>Cancel</button><button className="btn" disabled={!valid} onClick={save}>{editing ? 'Save changes' : 'Create user'}</button></>}>
      <div className="form2">
        <Field label="Username" hint={editing ? 'Cannot be changed' : 'Letters, digits, . _ - (sign-in name)'}>
          <input value={f.username} disabled={editing} onChange={set('username')} autoComplete="off" /></Field>
        <Field label="Full name"><input value={f.full_name} onChange={set('full_name')} /></Field>
        <Field label="Email"><input value={f.email} onChange={set('email')} /></Field>
        {!editing && <Field label="Initial password" hint="Leave empty for the default password. The user must change it at first sign-in.">
          <input type="password" autoComplete="new-password" value={f.password} onChange={set('password')} /></Field>}
      </div>
      <Field label="Roles">
        <div className="checks roles">{ROLES.map((r) => (
          <label key={r}><input type="checkbox" checked={f.roles.includes(r)} onChange={() => toggle(r)} /><b>{r}</b><small className="muted">{ROLE_HINT[r]}</small></label>))}
        </div></Field>
      {editing && <label className="inline"><input type="checkbox" checked={f.is_active} onChange={set('is_active')} /> Active (inactive users cannot sign in; deactivating signs them out)</label>}
    </Modal>
  );
}

export default function Users() {
  const { user: me } = useAuth();
  const act = useAction();
  const list = useAsync(() => api.users.list(), []);
  const [q, setQ] = useState('');
  const [form, setForm] = useState(null);             // null | {} add | user edit
  const [reset, setReset] = useState(null);
  const words = q.trim().toLowerCase().split(/\s+/).filter(Boolean);
  const rows = (list.data || []).filter((u) => words.every((w) => `${u.username} ${u.full_name} ${u.email} ${u.roles.join(' ')}`.toLowerCase().includes(w)));
  const done = () => { setForm(null); list.reload(); };

  return (
    <section>
      <h1>Users</h1>
      <div className="sub">Who can sign in and with which roles. New users and password resets get the default password, which must be changed at first sign-in.</div>
      <div className="toolbar">
        <input placeholder="Search username, name, email, role…" value={q} onChange={(e) => setQ(e.target.value)} />
        {list.data && <span className="muted">{rows.length} of {list.data.length}</span>}
        <button className="btn push" onClick={() => setForm({})}>+ Add user</button>
      </div>
      <div className="card">
        {!list.data ? <Loading error={list.error} onRetry={list.reload} /> : (
          <table><thead><tr><th>User</th><th>Email</th><th>Roles</th><th>Status</th><th>Last sign-in</th><th>Actions</th></tr></thead>
            <tbody>{rows.map((u) => {
              const [tone, label] = state(u);
              return (
                <tr key={u.id} className={u.is_active ? '' : 'inactive'}>
                  <td><b>{u.username || '—'}</b><div className="muted small">{u.full_name}</div></td>
                  <td>{u.email}</td>
                  <td>{u.roles.map((r) => <span key={r} className="chip">{r}</span>)}</td>
                  <td><Badge value={tone} label={label} />{u.locked_until && <div className="muted small">until {fmt(u.locked_until)}</div>}</td>
                  <td>{fmt(u.last_login_at)}</td>
                  <td className="actions">
                    <button className="btn sec sm" onClick={() => setForm(u)}>Edit</button>
                    <button className="btn sec sm" disabled={u.id === me.id} title={u.id === me.id ? 'Use Change password for yourself' : ''} onClick={() => setReset(u)}>Reset password</button>
                    {u.locked_until && <button className="btn sm" onClick={async () => { if (await act(() => api.users.unlock(u.id), `${u.username} unlocked`)) list.reload(); }}>Unlock</button>}
                  </td></tr>);
            })}
              {!rows.length && <tr><td colSpan="6" className="muted">No users match.</td></tr>}</tbody></table>)}
      </div>
      {form && <UserForm user={form.id ? form : null} onClose={() => setForm(null)} onSaved={done} />}
      {reset && <ConfirmModal title={`Reset password of ${reset.username}`} confirmText="Reset password" danger onClose={() => setReset(null)}
        onConfirm={async () => { const ok = await act(() => api.users.resetPassword(reset.id), `${reset.username} reset to the default password`); if (ok) list.reload(); return ok; }}>
        <p>Set <b>{reset.full_name}</b>'s password back to the default password? They are signed out everywhere and must choose a new password at their next sign-in.</p>
      </ConfirmModal>}
    </section>
  );
}

import { createContext, useCallback, useContext, useEffect, useState } from 'react';
import * as client from '../api/client';

const Ctx = createContext(null);
const FULL_ACCESS = ['ADMIN', 'APPROVER'];

/** Session state: 'checking' (restoring from the refresh cookie on page load) | 'in' | 'out'.
    The user (name, roles, must_change_password) comes from the API, which reads it from the database. */
export function AuthProvider({ children }) {
  const [s, setS] = useState({ status: 'checking', user: null, token: client.getToken() });

  useEffect(() => {
    let live = true;
    const off = client.onSession((data) => live && setS((x) => (data
      ? { status: 'in', user: data.user || x.user, token: data.access_token }
      : { status: 'out', user: null, token: '' })));
    // a token already in memory (tests / scripts) is checked with /auth/me; otherwise the refresh cookie is tried
    const restore = client.getToken()
      ? client.request('/auth/me').then((user) => live && setS({ status: 'in', user, token: client.getToken() }))
      : client.refreshSession();
    restore.catch(() => live && setS({ status: 'out', user: null, token: '' }));
    return () => { live = false; off(); };
  }, []);

  const login = useCallback((username, password) => client.login(username, password), []);
  const logout = useCallback(() => client.logout(), []);
  const setUser = useCallback((user) => setS((x) => ({ ...x, user })), []);

  // UI hint only: the backend is the authority and re-checks every role.
  // ADMIN and (for now) APPROVER pass every role check - keep in sync with FULL_ACCESS in the API's core/security.py.
  const user = s.status === 'in' ? s.user : null;
  const has = useCallback((...roles) => !!user && (FULL_ACCESS.some((r) => user.roles.includes(r)) || roles.some((r) => user.roles.includes(r))), [user]);

  return <Ctx.Provider value={{ status: s.status, user, token: s.token, login, logout, setUser, has }}>{children}</Ctx.Provider>;
}

export const useAuth = () => useContext(Ctx);

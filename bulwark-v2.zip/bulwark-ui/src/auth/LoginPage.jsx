import { useState } from 'react';
import { getApiBase, setApiBase } from '../config';
import { ping } from '../api/client';
import { useAuth } from './AuthContext';

export default function LoginPage() {
  const { login } = useAuth();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);
  const [apiUrl, setUrl] = useState(getApiBase());
  const [msg, setMsg] = useState(null);

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true); setError(null);
    try { await login(username.trim(), password); } catch (err) { setError(err.message); setPassword(''); }
    setBusy(false);
  };
  const test = async () => {
    setApiBase(apiUrl);
    try { await ping(); setMsg({ ok: true, t: `Connected to ${getApiBase()}` }); } catch (e) { setMsg({ ok: false, t: e.message }); }
  };

  return (
    <div className="login-wrap">
      <form className="card login" onSubmit={submit}>
        <img src="/innova-logo.png" alt="Innova Solutions" height="60" />
        <h2>Sign in to Bulwark</h2>
        <label htmlFor="username">Username</label>
        <input id="username" autoComplete="username" autoFocus value={username} onChange={(e) => setUsername(e.target.value)} />
        <label htmlFor="password">Password</label>
        <input id="password" type="password" autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} />
        {error && <div className="note err" role="alert">{error}</div>}
        <button className="btn block" type="submit" disabled={busy || !username.trim() || !password}>{busy ? 'Signing in…' : 'Sign in'}</button>
        <small className="muted">Forgot your password? Ask an administrator to reset it.</small>

        <details>
          <summary>Server settings</summary>
          <label htmlFor="api">Backend API URL</label>
          <div className="row">
            <input id="api" value={apiUrl} onChange={(e) => setUrl(e.target.value)} placeholder="http://localhost:8000" />
            <button type="button" className="btn sec" onClick={test}>Test</button>
          </div>
          {msg && <div className={`note ${msg.ok ? '' : 'err'}`}>{msg.t}</div>}
        </details>
      </form>
    </div>
  );
}

import { useState } from 'react';
import { request } from '../api/client';
import { Field, Modal, useToast } from '../components/ui';
import { useAuth } from './AuthContext';

const MIN = 8;       // keep in sync with PASSWORD_MIN_LENGTH in the API (the API is the authority)

/** Change-password form. `forced`: shown instead of the app until the default / reset password is replaced. */
export function ChangePasswordForm({ forced, onDone }) {
  const { user, setUser } = useAuth();
  const toast = useToast();
  const [f, setF] = useState({ current: '', next: '', confirm: '' });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const problem = f.next && f.next.length < MIN ? `At least ${MIN} characters`
    : f.confirm && f.next !== f.confirm ? 'The passwords do not match' : '';

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true); setError(null);
    try {
      const me = await request('/auth/change-password', { method: 'POST', body: { current_password: f.current, new_password: f.next } });
      setUser(me);
      toast('Password changed');
      onDone?.();
    } catch (err) { setError(err.message); }
    setBusy(false);
  };

  return (
    <form onSubmit={submit}>
      {forced && <div className="note">Welcome, <b>{user.name}</b>. You signed in with a temporary password. Choose your own password to continue.</div>}
      <input type="text" autoComplete="username" value={user.username || ''} readOnly hidden />
      <Field label={forced ? 'Temporary password' : 'Current password'}>
        <input type="password" autoComplete="current-password" autoFocus value={f.current} onChange={set('current')} /></Field>
      <Field label="New password" hint={`At least ${MIN} characters; not the default password and not containing your username.`}>
        <input type="password" autoComplete="new-password" value={f.next} onChange={set('next')} /></Field>
      <Field label="Confirm new password"><input type="password" autoComplete="new-password" value={f.confirm} onChange={set('confirm')} /></Field>
      {(error || problem) && <div className="note err" role="alert">{error || problem}</div>}
      <button className="btn block" type="submit" disabled={busy || !f.current || !f.next || !!problem || f.next !== f.confirm}>
        {busy ? 'Saving…' : 'Change password'}</button>
    </form>
  );
}

/** Full page shown after signing in with the default / a reset password. */
export function ChangePasswordPage() {
  const { logout } = useAuth();
  return (
    <div className="login-wrap">
      <div className="card login">
        <img src="/innova-logo.png" alt="Innova Solutions" height="60" />
        <h2>Set your password</h2>
        <ChangePasswordForm forced />
        <button className="linkbtn" onClick={logout}>Sign out</button>
      </div>
    </div>
  );
}

export function ChangePasswordModal({ onClose }) {
  return <Modal title="Change password" onClose={onClose}><ChangePasswordForm onDone={onClose} /></Modal>;
}

import { fileURLToPath } from 'node:url';
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// The assistant chat component is developed in the sibling project bulwark-agent-ui and used from source here.
const agentChat = fileURLToPath(new URL('../bulwark-agent-ui/src/chat', import.meta.url));

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: { '@bulwark/agent-chat': agentChat },
    dedupe: ['react', 'react-dom'],                  // one React instance, even for files outside this project
  },
  server: { port: 3000, fs: { allow: ['.', agentChat] } },
  test: { environment: 'jsdom', include: ['tests/**/*.test.jsx'], testTimeout: 30000 },
});

// End-to-end check of the UI's API layer against a running backend (with the worker running), signed in as a real
// user with ANALYST + OPERATOR + APPROVER rights (e.g. an ADMIN or, for now, an APPROVER) whose password is already changed.
// Usage: BULWARK_USER=... BULWARK_PASSWORD=... [API_BASE=http://localhost:8000] npm run smoke
const mem = {};
globalThis.localStorage = { getItem: (k) => mem[k] ?? null, setItem: (k, v) => { mem[k] = v; }, removeItem: (k) => { delete mem[k]; } };
localStorage.setItem('bulwark.apiBaseUrl', process.env.API_BASE || 'http://localhost:8000');
const { BULWARK_USER: user, BULWARK_PASSWORD: password } = process.env;
if (!user || !password) { console.error('Set BULWARK_USER and BULWARK_PASSWORD'); process.exit(2); }

const { api } = await import('../src/api/endpoints.js');
const { login } = await import('../src/api/client.js');
const ok = (m) => console.log('  ✓', m);
const must = (c, m) => { if (!c) { console.error('  ✗', m); process.exit(1); } };

const session = await login(user, password);
must(!session.user.must_change_password, `${user} must change the password first`); ok(`signed in as ${user} (${session.user.roles.join(', ')})`);
const sum = await api.dashboard.summary(); must('open_incidents' in sum, 'dashboard summary'); ok('dashboard summary');
const assets = await api.reference.assets();
const list = Array.isArray(assets) ? assets : assets.items; must(list.length >= 2, 'seeded assets'); ok(`${list.length} assets`);

const tag = Date.now();
const vuln = await api.vulnerabilities.create({ cve_id: `CVE-SMOKE-${tag}`, title: 'Smoke vuln', description: 'd', severity: 'HIGH', cvss_score: 7.5, source: 'MANUAL', asset_ids: list.slice(0, 2).map((a) => a.id) });
ok('vulnerability created');
const sol = await api.solutions.create({ title: `Smoke patch ${tag}`, description: 'x', executor: 'ANSIBLE', risk_level: 'LOW', applies_to: null, requires_reboot: false, timeout_seconds: 60, max_retries: 0, job_spec: { playbook: 'p.yml' } });
must(sol.status === 'REVIEW_PENDING', 'new solution is Review Pending'); ok('solution starts REVIEW_PENDING');
const sp = (await api.approvals.solutions({ status: 'PENDING', size: 100 })).items.find((x) => x.title === sol.title);
must(sp, 'solution in approval queue'); await api.approvals.approveSolution(sp.id, 'ok'); ok('solution approved (own submission)');

const inc = await api.incidents.create({ title: 'Smoke incident', description: 'd', severity: 'HIGH', assignee_id: null, vulnerability_id: vuln.id, asset_ids: list.slice(0, 2).map((a) => a.id) });
await api.incidents.replacePlan(inc.id, [{ solution_id: sol.id, on_failure: 'STOP_ASSET' }]);
await api.incidents.submit(inc.id); ok('incident planned & submitted');
const iq = (await api.approvals.incidents({ status: 'PENDING', size: 100 })).items.find((x) => x.cve_id === vuln.cve_id);
must(iq, 'incident in approval queue'); await api.approvals.approveIncident(iq.id, 'go'); ok('incident approved');

const g0 = await api.execution.grid(inc.id); must(g0.can_run, 'grid can_run');
const res = await api.execution.runPlan(inc.id); must(res.every((r) => r.outcome === 'QUEUED'), 'queued'); ok('plan queued (one click)');
const again = await api.execution.runPlan(inc.id); must(again.every((r) => r.outcome === 'EXISTS'), 'no duplicate runs'); ok('second click returns the existing runs');
let g; for (let i = 0; i < 40; i++) { g = await api.execution.grid(inc.id); if (g.rows.every((r) => r.cells[0].status === 'SUCCEEDED')) break; await new Promise((r) => setTimeout(r, 1000)); }
must(g.rows.every((r) => r.cells[0].status === 'SUCCEEDED'), 'all cells succeeded (is the worker running?)'); ok('worker executed all assets');
const logs = await api.execution.logs(g.rows[0].cells[0].run_id, 0); must(logs.length > 0, 'logs'); ok(`${logs.length} log lines`);
const done = await api.incidents.get(inc.id); ok(`incident status: ${done.status}`);
console.log('SMOKE OK');

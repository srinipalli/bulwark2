// Renders every page against a running backend, signed in as a real user (one whose password is already changed):
//   BULWARK_USER=... BULWARK_PASSWORD=... [API_BASE=http://localhost:8000] npm test
import { render, screen, cleanup } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { afterEach, beforeAll, describe, expect, it } from 'vitest';
import { login } from '../src/api/client';
import { AuthProvider } from '../src/auth/AuthContext';
import { ToastProvider } from '../src/components/ui';
import Dashboard from '../src/pages/Dashboard';
import Incidents from '../src/pages/Incidents';
import Approvals from '../src/pages/Approvals';
import Vulnerabilities from '../src/pages/Vulnerabilities';
import Solutions from '../src/pages/Solutions';
import Execution from '../src/pages/Execution';
import Assets from '../src/pages/Assets';
import Users from '../src/pages/Users';

const { BULWARK_USER: user, BULWARK_PASSWORD: password } = process.env;
beforeAll(async () => {
  if (!user) return;
  localStorage.setItem('bulwark.apiBaseUrl', process.env.API_BASE || 'http://localhost:8000');
  const s = await login(user, password);
  if (s.user.must_change_password) throw new Error(`${user} must change the password first (sign in once in the UI)`);
});
afterEach(cleanup);

const wrap = (el, url = '/') => render(<MemoryRouter initialEntries={[url]}><AuthProvider><ToastProvider>{el}</ToastProvider></AuthProvider></MemoryRouter>);

describe.skipIf(!user)('pages against live backend', () => {
  it.each([
    ['Dashboard', <Dashboard />, /dashboard/i],
    ['Incidents', <Incidents />, /incidents/i],
    ['Approvals', <Approvals />, /approvals/i],
    ['Vulnerabilities', <Vulnerabilities />, /vulnerability list/i],
    ['Solutions', <Solutions />, /solution list/i],
    ['Execution', <Execution />, /execution/i],
    ['Assets', <Assets />, /asset inventory/i],
    ['Users', <Users />, /users/i],
  ])('%s renders without error', async (_n, el, title) => {
    wrap(el);
    await screen.findAllByText(title);
    await new Promise((r) => setTimeout(r, 800));
    expect(document.querySelector('.note.err')).toBeNull();
  });
});

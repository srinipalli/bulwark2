// Offline: the chat icon (bulwark-agent-ui component) uses the signed-in user's token and the configured agent URL.
import { cleanup, fireEvent, render, screen } from '@testing-library/react';
import { afterEach, expect, it, vi } from 'vitest';
import { setAccessToken } from '../src/api/client';
import { AuthProvider } from '../src/auth/AuthContext';
import ChatIcon from '../src/components/ChatIcon';

const token = 'access-token-for-srini';
const me = { id: 'u1', username: 'srini', email: 'srini@x.io', name: 'Srini', roles: ['ANALYST'], must_change_password: false };
const json = (body, status = 200) => Promise.resolve({ ok: status < 400, status, json: () => Promise.resolve(body) });

afterEach(() => { cleanup(); vi.unstubAllGlobals(); localStorage.clear(); setAccessToken(''); });

it('opens the assistant and sends the signed-in user token to the agent', async () => {
  localStorage.setItem('bulwark.agentUrl', 'http://agent.test:8800');
  const fetch = vi.fn((url) => (String(url).endsWith('/auth/me') ? json(me)
    : json({ thread_id: 't', reply: 'Hi Srini.', pending: null, steps: [] })));
  vi.stubGlobal('fetch', fetch);
  setAccessToken(token);                                                    // signed in (token in memory)

  render(<AuthProvider><ChatIcon /></AuthProvider>);
  fireEvent.click(await screen.findByLabelText('Open Bulwark Assistant'));
  expect(screen.getByText(/Hi Srini\./)).toBeTruthy();                     // greeting uses the signed-in name
  fireEvent.change(screen.getByLabelText('Message'), { target: { value: 'hello' } });
  fireEvent.click(screen.getByText('Send'));

  expect(await screen.findByText('Hi Srini.')).toBeTruthy();
  const chat = fetch.mock.calls.find(([url]) => url === 'http://agent.test:8800/chat');
  expect(chat[1].headers.Authorization).toBe(`Bearer ${token}`);
});

it('renders nothing when nobody is signed in', async () => {
  vi.stubGlobal('fetch', vi.fn(() => json({ error: { code: 'unauthorized', message: 'Not signed in' } }, 401)));   // no refresh cookie
  const { container } = render(<AuthProvider><ChatIcon /></AuthProvider>);
  await new Promise((r) => setTimeout(r, 0));
  expect(container.innerHTML).toBe('');
});

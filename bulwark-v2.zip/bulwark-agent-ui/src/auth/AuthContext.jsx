import { createContext, useCallback, useContext, useMemo, useState } from 'react';

// Same storage key as bulwark-ui, so the token format and handling are identical in both apps.
const TOKEN_KEY = 'bulwark.token';
const ls = () => (typeof localStorage !== 'undefined' ? localStorage : null);
export const getToken = () => ls()?.getItem(TOKEN_KEY) || '';
const setToken = (t) => (t ? ls()?.setItem(TOKEN_KEY, t) : ls()?.removeItem(TOKEN_KEY));

const Ctx = createContext(null);

export function decode(token) {
  try {
    const p = JSON.parse(atob(token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/')));
    if (p.exp && p.exp * 1000 < Date.now()) return null;
    return { id: p.sub, name: p.name || p.email, email: p.email, roles: p.roles || [] };
  } catch {
    return null;
  }
}

export function AuthProvider({ children }) {
  const [token, setTok] = useState(getToken());
  const user = useMemo(() => (token ? decode(token) : null), [token]);
  const login = useCallback((t) => { setToken(t); setTok(t); }, []);
  const logout = useCallback(() => { setToken(''); setTok(''); }, []);
  // UI display only: the Bulwark API verifies the token and enforces every role.
  return <Ctx.Provider value={{ user, token, login, logout }}>{children}</Ctx.Provider>;
}

export const useAuth = () => useContext(Ctx);

import { useState } from 'react';
import { createAgentClient } from '../chat';
import { getAgentUrl, setAgentUrl } from '../config';
import { decode, useAuth } from './AuthContext';
import { mintDevToken } from './devToken';

const ROLES = ['ANALYST', 'OPERATOR', 'APPROVER', 'ADMIN', 'VIEWER'];

export default function LoginPage() {
  const { login } = useAuth();
  const [url, setUrl] = useState(getAgentUrl());
  const [token, setTok] = useState('');
  const [name, setName] = useState('');
  const [secret, setSecret] = useState('');
  const [roles, setRoles] = useState(['ANALYST', 'OPERATOR']);
  const [msg, setMsg] = useState(null);

  const saveUrl = () => setAgentUrl(url);
  const test = async () => {
    saveUrl();
    try { await createAgentClient({ baseUrl: getAgentUrl(), getToken: () => '' }).health(); setMsg({ ok: true, t: `Assistant reachable at ${getAgentUrl()}` }); }
    catch (e) { setMsg({ ok: false, t: e.message }); }
  };
  const useToken = () => {
    const t = token.trim();
    if (!decode(t)) return setMsg({ ok: false, t: 'That is not a valid (or it is an expired) Bulwark JWT.' });
    saveUrl();
    login(t);
  };
  const dev = async () => {
    if (!name.trim()) return setMsg({ ok: false, t: 'Enter a user name' });
    if (!roles.length) return setMsg({ ok: false, t: 'Pick at least one role' });
    if (!secret) return setMsg({ ok: false, t: 'Enter the backend JWT_SECRET' });
    saveUrl();
    login(await mintDevToken({ name: name.trim(), roles, secret }));
  };
  const toggle = (r) => setRoles((x) => (x.includes(r) ? x.filter((y) => y !== r) : [...x, r]));

  return (
    <div className="login-wrap">
      <div className="card login">
        <h2>Bulwark Assistant</h2>
        <p className="muted">Sign in. The assistant acts with your Bulwark roles and asks before it changes anything.</p>
        <label htmlFor="agent-url">Assistant URL (bulwark-chat-server)</label>
        <div className="row">
          <input id="agent-url" value={url} onChange={(e) => setUrl(e.target.value)} placeholder="http://localhost:8800" />
          <button className="btn sec" onClick={test}>Test</button>
        </div>
        {msg && <div className={`note ${msg.ok ? '' : 'err'}`} role="status">{msg.t}</div>}

        <h3>Sign in with a token</h3>
        <textarea rows="3" value={token} onChange={(e) => setTok(e.target.value)} placeholder="Paste a JWT from your identity provider" aria-label="JWT" />
        <button className="btn" disabled={!token.trim()} onClick={useToken}>Sign in</button>

        <details>
          <summary>Local development login (mints a token in the browser)</summary>
          <div className="note">Only for local testing. Needs the same <b>JWT_SECRET</b> the Bulwark API uses.</div>
          <label htmlFor="dev-name">Name</label><input id="dev-name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Any user name" />
          <label>Roles</label>
          <div className="checks">{ROLES.map((r) => (
            <label key={r}><input type="checkbox" checked={roles.includes(r)} onChange={() => toggle(r)} />{r}</label>))}
          </div>
          <label htmlFor="dev-secret">JWT secret</label><input id="dev-secret" type="password" value={secret} onChange={(e) => setSecret(e.target.value)} />
          <button className="btn" onClick={dev}>Dev sign in</button>
        </details>
      </div>
    </div>
  );
}

const KEY = 'bulwark.agentUrl';
const DEFAULT = 'http://localhost:8800';

const store = () => (typeof localStorage !== 'undefined' ? localStorage : null);

/** Priority: Settings dialog override > public/config.js (runtime) > VITE_AGENT_URL (build) > localhost:8800 */
export function getAgentUrl() {
  const runtime = typeof window !== 'undefined' ? window.__BULWARK_CONFIG__?.agentUrl : undefined;
  const v = store()?.getItem(KEY) || runtime || import.meta.env?.VITE_AGENT_URL || DEFAULT;
  return v.replace(/\/+$/, '');
}

export function setAgentUrl(value) {
  const s = store();
  if (!s) return;
  if (value && value.trim()) s.setItem(KEY, value.trim());
  else s.removeItem(KEY);
}

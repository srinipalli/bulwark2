import { AuthProvider, useAuth } from './auth/AuthContext';
import LoginPage from './auth/LoginPage';
import { ChatPanel } from './chat';
import { getAgentUrl } from './config';

function Shell() {
  const { user, token, logout } = useAuth();
  if (!user) return <LoginPage />;
  return (
    <div className="shell">
      <header>
        <span className="brand">Bulwark</span><span className="tag">Assistant</span>
        <div className="me">
          <div className="avatar">{(user.name || '?').slice(0, 2).toUpperCase()}</div>
          <div><b>{user.name}</b><br /><small className="muted">{user.roles.join(' · ') || 'no roles'}</small></div>
          <button className="btn sec sm" onClick={logout}>Sign out</button>
        </div>
      </header>
      <main className="chat-main">
        <ChatPanel agentUrl={getAgentUrl} token={token} userName={user.name} onUnauthorized={logout} docked />
      </main>
    </div>
  );
}

export default function App() {
  return <AuthProvider><Shell /></AuthProvider>;
}

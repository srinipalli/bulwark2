// Minimal, safe Markdown for assistant replies: headings, paragraphs, lists, tables, code, **bold**, `code`, links.
// Builds React elements only (no innerHTML), so model output can never inject markup.

const INLINE = /(`[^`]+`|\*\*[^*]+\*\*|\[[^\]]+\]\(https?:\/\/[^)\s]+\))/g;

function inline(text) {
  return text.split(INLINE).filter(Boolean).map((part, i) => {
    if (part.startsWith('`') && part.endsWith('`') && part.length > 2) return <code key={i}>{part.slice(1, -1)}</code>;
    if (part.startsWith('**') && part.endsWith('**') && part.length > 4) return <b key={i}>{part.slice(2, -2)}</b>;
    const link = part.match(/^\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)$/);
    if (link) return <a key={i} href={link[2]} target="_blank" rel="noreferrer">{link[1]}</a>;
    return part;
  });
}

const cells = (row) => row.trim().replace(/^\|/, '').replace(/\|$/, '').split('|').map((c) => c.trim());
const isRule = (row) => /^\s*\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?\s*$/.test(row);
const LIST = /^\s*([-*•]|\d+[.)])\s+/;

export function parseBlocks(src) {
  const lines = (src || '').replace(/\r\n/g, '\n').split('\n');
  const out = [];
  for (let i = 0; i < lines.length;) {
    const l = lines[i];
    if (!l.trim()) { i++; continue; }
    if (l.trim().startsWith('```')) {
      const body = [];
      for (i++; i < lines.length && !lines[i].trim().startsWith('```'); i++) body.push(lines[i]);
      out.push({ type: 'code', text: body.join('\n') });
      i++;
    } else if (/^#{1,6}\s/.test(l)) {
      out.push({ type: 'h', text: l.replace(/^#+\s*/, '') });
      i++;
    } else if (l.trim().startsWith('|') && i + 1 < lines.length && isRule(lines[i + 1])) {
      const head = cells(l), rows = [];
      for (i += 2; i < lines.length && lines[i].trim().startsWith('|'); i++) rows.push(cells(lines[i]));
      out.push({ type: 'table', head, rows });
    } else if (LIST.test(l)) {
      const ordered = /^\s*\d/.test(l), items = [];
      for (; i < lines.length && LIST.test(lines[i]); i++) items.push(lines[i].replace(LIST, ''));
      out.push({ type: ordered ? 'ol' : 'ul', items });
    } else {
      const para = [];
      for (; i < lines.length && lines[i].trim() && !LIST.test(lines[i]) && !/^#{1,6}\s/.test(lines[i])
        && !lines[i].trim().startsWith('```') && !lines[i].trim().startsWith('|'); i++) para.push(lines[i].trim());
      if (!para.length) { out.push({ type: 'p', text: l.trim() }); i++; } else out.push({ type: 'p', text: para.join(' ') });
    }
  }
  return out;
}

export default function Markdown({ text }) {
  return (
    <div className="bwc-md">
      {parseBlocks(text).map((b, i) => {
        switch (b.type) {
          case 'code': return <pre key={i}><code>{b.text}</code></pre>;
          case 'h': return <h4 key={i}>{inline(b.text)}</h4>;
          case 'ul': return <ul key={i}>{b.items.map((t, j) => <li key={j}>{inline(t)}</li>)}</ul>;
          case 'ol': return <ol key={i}>{b.items.map((t, j) => <li key={j}>{inline(t)}</li>)}</ol>;
          case 'table': return (
            <div key={i} className="bwc-tablewrap"><table>
              <thead><tr>{b.head.map((h, j) => <th key={j}>{inline(h)}</th>)}</tr></thead>
              <tbody>{b.rows.map((r, j) => <tr key={j}>{r.map((c, k) => <td key={k}>{inline(c)}</td>)}</tr>)}</tbody>
            </table></div>);
          default: return <p key={i}>{inline(b.text)}</p>;
        }
      })}
    </div>
  );
}

import { useEffect, useRef, useState } from 'react';
import ChatPanel from './ChatPanel';

/** Floating chat icon (bottom right) that opens the assistant. Takes the same props as ChatPanel.
 *  The panel stays mounted while closed, so the conversation survives closing and reopening. */
export default function ChatWidget({ defaultOpen = false, ...panel }) {
  const [open, setOpen] = useState(defaultOpen);
  const [unread, setUnread] = useState(false);
  const isOpen = useRef(open);
  isOpen.current = open;

  useEffect(() => {
    const esc = (e) => e.key === 'Escape' && setOpen(false);
    window.addEventListener('keydown', esc);
    return () => window.removeEventListener('keydown', esc);
  }, []);

  const toggle = () => { setOpen((o) => !o); setUnread(false); };

  return (
    <div className="bwc-widget">
      <div className="bwc-pop" hidden={!open}>
        <ChatPanel {...panel} onClose={() => setOpen(false)} onReply={() => { if (!isOpen.current) setUnread(true); panel.onReply?.(); }} />
      </div>
      <button className={`bwc-fab ${open ? 'open' : ''}`} onClick={toggle} aria-label={open ? 'Close Bulwark Assistant' : 'Open Bulwark Assistant'}
        aria-expanded={open} title="Bulwark Assistant">
        {open ? <span className="bwc-fab-x">×</span> : (
          <svg viewBox="0 0 24 24" width="26" height="26" aria-hidden="true">
            <path fill="currentColor" d="M4 3h16a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H9l-5 4v-4H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2Zm3 6.5a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3Zm5 0a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3Zm5 0a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3Z" />
          </svg>)}
        {unread && !open && <span className="bwc-unread" aria-label="New reply" />}
      </button>
    </div>
  );
}

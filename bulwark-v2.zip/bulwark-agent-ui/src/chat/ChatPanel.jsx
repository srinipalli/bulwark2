import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { createAgentClient } from './agentClient';
import History, { Icon } from './History';
import Markdown from './Markdown';
import './chat.css';

const SUGGESTIONS = ['What needs my attention?', 'Show the portfolio risk report', 'Explain INC-48', 'Which fix handles an OpenSSL buffer overrun?'];

const STATUS = {
  planned: ['…', 'running', 'Running'],
  awaiting_approval: ['⏸', 'wait', 'Waiting for your approval'],
  done: ['✓', 'ok', 'Done'],
  failed: ['✗', 'bad', 'Failed'],
  declined: ['⊘', 'gray', 'Declined - nothing changed'],
  unknown: ['?', 'wait', 'Approved, but no result came back - check the page'],
};

export const pretty = (tool) => (tool || '').replace(/_/g, ' ').replace(/^\w/, (c) => c.toUpperCase());

export function argSummary(args) {
  const parts = Object.entries(args || {}).filter(([, v]) => v !== null && v !== undefined && v !== '')
    .map(([k, v]) => `${k.replace(/_/g, ' ')}: ${typeof v === 'string' ? v : JSON.stringify(v)}`);
  const s = parts.join(' · ');
  return s.length > 140 ? `${s.slice(0, 137)}…` : s;
}

/** Merge the steps of a later response (same ids, e.g. after an approval) into the steps seen so far, keeping order. */
export function mergeSteps(old, add) {
  const out = old.map((s) => ({ ...s }));
  (add || []).forEach((n) => {
    const i = out.findIndex((s) => s.id === n.id);
    if (i >= 0) out[i] = { ...out[i], ...n, args: n.args ?? out[i].args };
    else out.push(n);
  });
  return out;
}

// The open conversation is remembered per browser tab, so a page refresh reopens it (only for the same user).
const OPEN_KEY = 'bwc.openThread';
const subOf = (token) => {
  try { return JSON.parse(atob(token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/'))).sub || token; } catch { return token; }
};
const remembered = (token) => {
  try { const v = JSON.parse(sessionStorage.getItem(OPEN_KEY) || 'null'); return v && v.user === subOf(token) ? v.id : null; } catch { return null; }
};
const remember = (token, id) => {
  try { if (id) sessionStorage.setItem(OPEN_KEY, JSON.stringify({ user: subOf(token), id })); else sessionStorage.removeItem(OPEN_KEY); } catch { /* storage blocked */ }
};

/** Saved transcript from GET /threads/{id} -> chat messages. A turn that broke off gets the Retry prompt back. */
function fromSaved(t) {
  const msgs = t.messages.map((m, i) => ({ ...m, id: `h${i}`, steps: m.steps || [] }));
  const last = [...msgs].reverse().find((m) => m.role === 'assistant');
  if (t.retryable && last) Object.assign(last, { error: 'This conversation stopped on an error.', retryable: true });
  return msgs;
}

function Steps({ steps }) {
  if (!steps.length) return null;
  return (
    <ol className="bwc-steps" aria-label="Tasks">
      {steps.map((s, i) => {
        const [icon, cls, label] = STATUS[s.status] || STATUS.planned;
        return (
          <li key={s.id || i} className={`bwc-step ${cls}`} title={label}>
            <span className="bwc-no">{i + 1}</span>
            <div className="bwc-grow">
              <b>{pretty(s.tool)}</b>
              {argSummary(s.args) && <small>{argSummary(s.args)}</small>}
              {s.detail && <small className="bwc-err-t">{s.detail}</small>}
            </div>
            <span className={`bwc-st ${cls}`} aria-label={label}>{icon}</span>
          </li>);
      })}
    </ol>
  );
}

function Approval({ actions, onDecide, busy, decision }) {
  return (
    <div className="bwc-approval" role="group" aria-label="Approval needed">
      <div className="bwc-approval-h">The assistant wants to change data:</div>
      <ul>
        {actions.map((a) => (
          <li key={a.id}>
            <b>{a.title || pretty(a.tool)}</b>{a.destructive && <span className="bwc-badge bad">destructive</span>}
            {argSummary(a.args) && <small>{argSummary(a.args)}</small>}
          </li>))}
      </ul>
      {decision ? <div className="bwc-muted">{decision === 'approved' ? 'Approved - running…' : 'Declined.'}</div> : (
        <div className="bwc-row">
          <button className="bwc-btn" disabled={busy} onClick={() => onDecide(true)}>Approve</button>
          <button className="bwc-btn sec" disabled={busy} onClick={() => onDecide(false)}>Decline</button>
        </div>)}
    </div>
  );
}

/**
 * The Bulwark Assistant chat.
 * Props: agentUrl (string | () => string), token (the signed-in user's Bulwark JWT), userName,
 *        onUnauthorized(), onDataChanged() after an approved change ran, onClose() shows a close button, onReply(), title,
 *        docked: show "Recent chats" as a side column (full page) instead of a drawer (widget).
 */
export default function ChatPanel({ agentUrl, token, userName, onUnauthorized, onDataChanged, onClose, onReply, title = 'Bulwark Assistant', docked = false }) {
  const [msgs, setMsgs] = useState([]);
  const [threadId, setThreadId] = useState(null);
  const [text, setText] = useState('');
  const [busy, setBusy] = useState(false);
  const [showHistory, setShowHistory] = useState(docked);
  const [history, setHistory] = useState(null);                  // null = not loaded yet
  const [historyError, setHistoryError] = useState(null);
  const live = useRef({});
  live.current = { agentUrl, token, onUnauthorized, onDataChanged, onReply };
  const client = useMemo(() => createAgentClient({
    baseUrl: () => (typeof live.current.agentUrl === 'function' ? live.current.agentUrl() : live.current.agentUrl),
    getToken: () => live.current.token,
  }), []);
  const scroller = useRef(null);
  const input = useRef(null);

  const select = (id) => { setThreadId(id); remember(live.current.token, id); };

  const refreshHistory = useCallback(async () => {
    try { setHistory(await client.threads()); setHistoryError(null); }
    catch (e) { setHistoryError(e.message); if (e.status === 401) live.current.onUnauthorized?.(); }
  }, [client]);

  const openThread = useCallback(async (id, { quiet = false } = {}) => {
    setBusy(true);
    try {
      const t = await client.thread(id);
      setMsgs(fromSaved(t));
      select(id);
      if (!docked) setShowHistory(false);
    } catch (e) {
      if (quiet) remember(live.current.token, null);                // a remembered chat that is gone: just start fresh
      else setHistoryError(e.status === 404 ? 'That chat no longer exists.' : e.message);
      if (e.status === 404) refreshHistory();
    } finally {
      setBusy(false);
    }
  }, [client, docked, refreshHistory]);

  // Another user signed in: never show the previous chat. Reopen this user's chat from before a page refresh.
  useEffect(() => {
    setMsgs([]); setThreadId(null); setHistory(null);
    if (!token) return;
    const id = remembered(token);
    if (id) openThread(id, { quiet: true });
  }, [token]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => { if (showHistory && token) refreshHistory(); }, [showHistory, token, refreshHistory]);
  useEffect(() => { const el = scroller.current; if (el) el.scrollTop = el.scrollHeight; }, [msgs, busy]);

  const patch = (id, fn) => setMsgs((ms) => ms.map((m) => (m.id === id ? { ...m, ...fn(m) } : m)));
  const waiting = msgs.some((m) => m.pending && !m.decision);

  async function turn(id, call) {
    setBusy(true);
    try {
      const r = await call();
      select(r.thread_id);
      patch(id, (m) => ({ steps: mergeSteps(m.steps, r.steps), text: r.reply ?? m.text, pending: r.pending?.length ? r.pending : null, decision: null }));
      if (r.reply) live.current.onReply?.();
      return r;
    } catch (e) {
      patch(id, (m) => {
        // no step report after an approval: the approved change may or may not have run - do not keep showing "waiting"
        const steps = e.steps ? mergeSteps(m.steps, e.steps)
          : m.steps.map((s) => (s.status === 'awaiting_approval' && m.decision === 'approved' ? { ...s, status: 'unknown' } : s));
        return { error: e.message, retryable: e.retryable, pending: null, steps };
      });
      if (e.status === 401) live.current.onUnauthorized?.();
      if (e.steps?.length) live.current.onDataChanged?.();                    // something may have changed before the error
      return null;
    } finally {
      setBusy(false);
      if (showHistory) refreshHistory();                                     // new chat / new title / moved to the top
      setTimeout(() => input.current?.focus(), 0);
    }
  }

  async function send(raw) {
    const q = (raw ?? text).trim();
    if (!q || busy || waiting) return;
    const id = `${Date.now()}`;
    setText('');
    setMsgs((ms) => [...ms, { id: `${id}u`, role: 'user', text: q }, { id, role: 'assistant', text: null, steps: [], pending: null }]);
    await turn(id, () => client.chat(q, threadId));
  }

  async function decide(id, approve) {
    patch(id, () => ({ decision: approve ? 'approved' : 'declined' }));
    const r = await turn(id, () => client.confirm(threadId, approve));
    if (r && approve) live.current.onDataChanged?.();
  }

  async function retry(id) {
    patch(id, () => ({ error: null, retryable: false }));
    await turn(id, () => client.retry(threadId));
  }

  function newChat() {
    setMsgs([]); select(null); setText('');
    if (!docked) setShowHistory(false);
    setTimeout(() => input.current?.focus(), 0);
  }

  async function removeThread(id) {
    try {
      await client.deleteThread(id);
      if (id === threadId) newChat();
    } catch (e) {
      setHistoryError(e.message);
    }
    refreshHistory();
  }

  const onKey = (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } };

  return (
    <section className={`bwc-panel ${docked ? 'bwc-docked' : ''}`} aria-label={title}>
      <div className="bwc-head">
        <button className={`bwc-icon head ${showHistory ? 'on' : ''}`} onClick={() => setShowHistory((v) => !v)} aria-label="Recent chats"
          aria-expanded={showHistory} title="Recent chats">{Icon.history}</button>
        <div className="bwc-title"><span className="bwc-dot" />{title}</div>
        <button className="bwc-icon head" onClick={newChat} disabled={busy} aria-label="New chat" title="New chat">{Icon.newChat}</button>
        {onClose && <button className="bwc-x" onClick={onClose} aria-label="Close assistant">×</button>}
      </div>

      <div className="bwc-wrap">
        {showHistory && (
          <History items={history} error={historyError} activeId={threadId} busy={busy}
            onOpen={(id) => openThread(id)} onNew={newChat} onDelete={removeThread} />)}

        <div className="bwc-chat">
          <div className="bwc-body" ref={scroller}>
            {!msgs.length && !busy && (
              <div className="bwc-empty">
                <p>Hi{userName ? ` ${userName}` : ''}. Ask about incidents, vulnerabilities, plans, approvals or executions.
                  I work out the tasks, run them in order and ask you before anything changes.</p>
                <div className="bwc-sugg">{SUGGESTIONS.map((s) => <button key={s} onClick={() => send(s)} disabled={busy}>{s}</button>)}</div>
              </div>)}
            {msgs.map((m) => (m.role === 'user'
              ? <div key={m.id} className="bwc-msg user"><div className="bwc-bubble">{m.text}</div></div>
              : (
                <div key={m.id} className="bwc-msg bot">
                  <div className="bwc-bubble">
                    <Steps steps={m.steps} />
                    {m.pending && <Approval actions={m.pending} busy={busy} decision={m.decision} onDecide={(ok) => decide(m.id, ok)} />}
                    {m.text && <Markdown text={m.text} />}
                    {m.error && (
                      <div className="bwc-error" role="alert">
                        {m.error}
                        {m.retryable && <div className="bwc-row bwc-retry">
                          <button className="bwc-btn sm" disabled={busy} onClick={() => retry(m.id)}>Retry</button>
                          <span className="bwc-muted">continues from the last completed step - nothing done so far is repeated</span>
                        </div>}
                      </div>)}
                    {!m.text && !m.error && !m.pending && busy && <div className="bwc-typing" aria-label="Working"><i /><i /><i /></div>}
                  </div>
                </div>)))}
            {!msgs.length && busy && <div className="bwc-typing center" aria-label="Loading chat"><i /><i /><i /></div>}
          </div>

          <div className="bwc-foot">
            <textarea ref={input} rows="2" value={text} onChange={(e) => setText(e.target.value)} onKeyDown={onKey} disabled={busy || waiting}
              placeholder={waiting ? 'Approve or decline the change above first' : 'Ask the assistant… (Enter to send, Shift+Enter for a new line)'} aria-label="Message" />
            <button className="bwc-btn" onClick={() => send()} disabled={busy || waiting || !text.trim()}>Send</button>
          </div>
        </div>
      </div>
    </section>
  );
}

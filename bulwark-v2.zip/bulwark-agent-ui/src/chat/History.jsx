import { useState } from 'react';

export function ago(iso, now = Date.now()) {
  const t = Date.parse(iso);
  if (Number.isNaN(t)) return '';
  const m = Math.max(0, Math.round((now - t) / 60000));
  if (m < 1) return 'just now';
  if (m < 60) return `${m} min ago`;
  if (m < 24 * 60) return `${Math.round(m / 60)} h ago`;
  if (m < 7 * 24 * 60) return `${Math.round(m / 1440)} d ago`;
  return new Date(t).toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' });
}

export const Icon = {
  history: (
    <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path fill="currentColor" d="M13 3a9 9 0 0 0-9 9H1l3.9 3.9L9 12H6a7 7 0 1 1 2.05 4.95l-1.42 1.42A9 9 0 1 0 13 3Zm-1 5v5l4.25 2.52.77-1.28-3.52-2.09V8H12Z" /></svg>),
  newChat: (
    <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path fill="currentColor" d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25ZM20.71 7.04a1 1 0 0 0 0-1.41l-2.34-2.34a1 1 0 0 0-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83Z" /></svg>),
  trash: (
    <svg viewBox="0 0 24 24" width="15" height="15" aria-hidden="true"><path fill="currentColor" d="M9 3h6l1 1h4v2H4V4h4l1-1Zm-3 5h12l-1 13H7L6 8Zm4 2v9h1.5v-9H10Zm3.5 0v9H15v-9h-1.5Z" /></svg>),
};

/** "Recent chats": the signed-in user's saved conversations, newest first. */
export default function History({ items, error, activeId, busy, onOpen, onNew, onDelete }) {
  const [confirming, setConfirming] = useState(null);
  return (
    <aside className="bwc-history" aria-label="Recent chats">
      <div className="bwc-history-h">
        <b>Recent chats</b>
        <button className="bwc-btn sm" onClick={onNew} disabled={busy}>{Icon.newChat} New chat</button>
      </div>
      {error && <div className="bwc-error small">{error}</div>}
      {items === null && !error && <div className="bwc-muted bwc-pad">Loading…</div>}
      {items?.length === 0 && <div className="bwc-muted bwc-pad">No saved chats yet. Your conversations appear here.</div>}
      <ul>
        {(items || []).map((t) => (
          <li key={t.thread_id} className={t.thread_id === activeId ? 'on' : ''}>
            {confirming === t.thread_id ? (
              <div className="bwc-confirm">
                <span>Delete this chat?</span>
                <button className="bwc-btn sm danger" onClick={() => { setConfirming(null); onDelete(t.thread_id); }}>Delete</button>
                <button className="bwc-btn sm sec" onClick={() => setConfirming(null)}>Keep</button>
              </div>
            ) : (
              <>
                <button className="bwc-thread" onClick={() => onOpen(t.thread_id)} disabled={busy} aria-current={t.thread_id === activeId ? 'true' : undefined}>
                  <span className="bwc-thread-t">{t.title}</span>
                  <small>{ago(t.updated_at)}</small>
                </button>
                <button className="bwc-icon del" onClick={() => setConfirming(t.thread_id)} disabled={busy} aria-label={`Delete chat: ${t.title}`} title="Delete">{Icon.trash}</button>
              </>
            )}
          </li>))}
      </ul>
    </aside>
  );
}

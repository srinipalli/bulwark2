// HTTP client for bulwark-chat-server. The caller supplies the user's Bulwark JWT; the agent forwards it to the
// MCP server and on to the Bulwark API, so every task runs with that user's roles.

export class AgentError extends Error {
  constructor(status, message, { retryable = false, steps = null } = {}) {
    super(message);
    this.status = status;
    this.retryable = retryable;          // the turn stopped on an error and POST /chat/retry can continue it
    this.steps = steps;                  // tool calls that ran before the error
  }
}

export function createAgentClient({ baseUrl, getToken }) {
  const base = () => (typeof baseUrl === 'function' ? baseUrl() : baseUrl).replace(/\/+$/, '');

  async function request(method, path, body) {
    const token = getToken();
    if (!token) throw new AgentError(401, 'You are not signed in.');
    let res;
    try {
      res = await fetch(`${base()}${path}`, {
        method,
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: body !== undefined ? JSON.stringify(body) : undefined,
      });
    } catch {
      throw new AgentError(0, `No answer from the assistant at ${base()}. Either bulwark-chat-server is not running / not allowing this origin (CORS), `
        + 'or it failed without a readable answer - see its console. Changes approved before this point may already have been made.');
    }
    let data = null;
    try { data = await res.json(); } catch { /* empty body */ }
    if (!res.ok) {
      const d = data?.detail;
      if (d && typeof d === 'object' && !Array.isArray(d)) throw new AgentError(res.status, d.message || `The assistant answered ${res.status}`, d);
      throw new AgentError(res.status, typeof d === 'string' ? d : `The assistant answered ${res.status}`);
    }
    return data;
  }
  const post = (path, body) => request('POST', path, body);
  const tid = (id) => encodeURIComponent(id);

  return {
    chat: (message, threadId) => post('/chat', { message, thread_id: threadId || null }),
    confirm: (threadId, approve) => post('/chat/confirm', { thread_id: threadId, approve }),
    retry: (threadId) => post('/chat/retry', { thread_id: threadId }),
    threads: () => request('GET', '/threads'),                                   // saved conversations, newest first
    thread: (threadId) => request('GET', `/threads/${tid(threadId)}`),           // {title, messages, pending, retryable}
    deleteThread: (threadId) => request('DELETE', `/threads/${tid(threadId)}`),
    health: async () => {
      let res;
      try { res = await fetch(`${base()}/health`); } catch { throw new AgentError(0, `Cannot reach the assistant at ${base()}`); }
      if (!res.ok) throw new AgentError(res.status, `The assistant answered ${res.status}`);
      return res.json();
    },
  };
}

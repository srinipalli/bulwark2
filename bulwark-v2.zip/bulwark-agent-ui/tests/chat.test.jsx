import { cleanup, fireEvent, render, screen, waitFor, within } from '@testing-library/react';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { ChatPanel, ChatWidget } from '../src/chat';
import { mergeSteps } from '../src/chat/ChatPanel';
import { parseBlocks } from '../src/chat/Markdown';

const ok = (body) => Promise.resolve({ ok: true, status: 200, json: () => Promise.resolve(body) });

function mockAgent(...responses) {
  const fetch = vi.fn(() => {                                               // a function response is created lazily (rejections)
    const r = responses.length ? responses.shift() : ok({});
    return typeof r === 'function' ? r() : r;
  });
  vi.stubGlobal('fetch', fetch);
  return fetch;
}

const ask = (text) => {
  fireEvent.change(screen.getByLabelText('Message'), { target: { value: text } });
  fireEvent.click(screen.getByText('Send'));
};

afterEach(() => { cleanup(); vi.unstubAllGlobals(); sessionStorage.clear(); });

/** fetch mock answering by "METHOD /path"; records the calls. */
function routes(table) {
  const calls = [];
  vi.stubGlobal('fetch', vi.fn((url, init = {}) => {
    const key = `${init.method || 'GET'} ${new URL(url).pathname}`;
    calls.push({ key, body: init.body ? JSON.parse(init.body) : undefined });
    const h = table[key];
    if (!h) return Promise.resolve({ ok: false, status: 404, json: () => Promise.resolve({ detail: 'No such conversation.' }) });
    const body = typeof h === 'function' ? h(calls.at(-1).body) : h;
    return body === 204 ? Promise.resolve({ ok: true, status: 204, json: () => Promise.reject(new Error('empty')) }) : ok(body);
  }));
  return calls;
}

const SAVED = {
  thread_id: 'th1', title: 'explain INC-48', created_at: '2026-10-26T10:00:00+00:00', updated_at: '2026-10-26T10:05:00+00:00',
  pending: false, retryable: false,
  messages: [
    { role: 'user', text: 'explain INC-48' },
    { role: 'assistant', text: 'INC-48 is **open** with 3 assets.', pending: null,
      steps: [{ id: 'c1', tool: 'explain_incident', args: { incident: 'INC-48' }, status: 'done' }] },
  ],
};
const LIST = [{ thread_id: 'th1', title: 'explain INC-48', updated_at: new Date().toISOString() },
  { thread_id: 'th0', title: 'risk report', updated_at: '2026-01-02T10:00:00+00:00' }];

describe('Recent chats', () => {
  it('lists saved chats, opens one with its tasks and reply, and continues it', async () => {
    const calls = routes({ 'GET /threads': LIST, 'GET /threads/th1': SAVED,
      'POST /chat': { thread_id: 'th1', reply: 'It has no plan yet.', pending: null, steps: [] } });
    render(<ChatPanel agentUrl="http://a" token="jwt" />);
    fireEvent.click(screen.getByLabelText('Recent chats'));
    const list = await screen.findByRole('complementary', { name: 'Recent chats' });
    expect(await within(list).findByText('explain INC-48')).toBeTruthy();
    expect(within(list).getByText('just now')).toBeTruthy();

    fireEvent.click(within(list).getByText('explain INC-48'));
    expect(await screen.findByText('open', { selector: 'b' })).toBeTruthy();          // markdown reply restored
    expect(screen.getByText('Explain incident')).toBeTruthy();                          // its task list too
    expect(screen.queryByRole('complementary', { name: 'Recent chats' })).toBeNull();  // drawer closes after picking

    ask('does it have a plan?');
    expect(await screen.findByText('It has no plan yet.')).toBeTruthy();
    expect(calls.find((c) => c.key === 'POST /chat').body).toEqual({ message: 'does it have a plan?', thread_id: 'th1' });
  });

  it('the new chat icon starts a fresh conversation', async () => {
    const calls = routes({ 'GET /threads/th1': SAVED, 'POST /chat': { thread_id: 'th2', reply: 'Hello.', pending: null, steps: [] } });
    sessionStorage.setItem('bwc.openThread', JSON.stringify({ user: 'jwt', id: 'th1' }));    // as left before a page refresh
    render(<ChatPanel agentUrl="http://a" token="jwt" />);
    expect(await screen.findByText('Explain incident')).toBeTruthy();                 // reopened after the refresh
    fireEvent.click(screen.getByLabelText('New chat'));
    expect(screen.queryByText('Explain incident')).toBeNull();
    ask('hi');
    expect(await screen.findByText('Hello.')).toBeTruthy();
    expect(calls.find((c) => c.key === 'POST /chat').body.thread_id).toBeNull();
  });

  it('a reopened chat that waits for approval can still be approved', async () => {
    const pendingChat = { ...SAVED, pending: true, messages: [
      { role: 'user', text: 'approve INC-57' },
      { role: 'assistant', text: null, steps: [{ id: 'c9', tool: 'approve_incident', args: { incident: 'INC-57' }, status: 'awaiting_approval' }],
        pending: [{ id: 'c9', tool: 'approve_incident', title: 'Approve incident', args: { incident: 'INC-57' }, destructive: false }] }] };
    const calls = routes({ 'GET /threads': LIST, 'GET /threads/th1': pendingChat,
      'POST /chat/confirm': { thread_id: 'th1', reply: 'Approved.', pending: null, steps: [{ id: 'c9', tool: 'approve_incident', status: 'done' }] } });
    render(<ChatPanel agentUrl="http://a" token="jwt" docked />);
    fireEvent.click(await screen.findByText('explain INC-48'));
    const card = await screen.findByRole('group', { name: 'Approval needed' });
    expect(screen.getByLabelText('Message').disabled).toBe(true);
    fireEvent.click(within(card).getByText('Approve'));
    expect(await screen.findByText('Approved.')).toBeTruthy();
    expect(calls.find((c) => c.key === 'POST /chat/confirm').body).toEqual({ thread_id: 'th1', approve: true });
    expect(screen.getByRole('complementary', { name: 'Recent chats' })).toBeTruthy();   // docked: the list stays
  });

  it('a reopened chat that broke off offers Retry', async () => {
    routes({ 'GET /threads/th1': { ...SAVED, retryable: true }, 'POST /chat/retry': { thread_id: 'th1', reply: 'Done now.', pending: null, steps: [] } });
    sessionStorage.setItem('bwc.openThread', JSON.stringify({ user: 'jwt', id: 'th1' }));
    render(<ChatPanel agentUrl="http://a" token="jwt" />);
    fireEvent.click(await screen.findByText('Retry'));
    expect(await screen.findByText('Done now.')).toBeTruthy();
  });

  it('deletes a chat after confirming', async () => {
    let list = [...LIST];
    const calls = routes({ 'GET /threads': () => list, 'DELETE /threads/th0': () => { list = list.filter((t) => t.thread_id !== 'th0'); return 204; } });
    render(<ChatPanel agentUrl="http://a" token="jwt" docked />);
    fireEvent.click(await screen.findByLabelText('Delete chat: risk report'));
    fireEvent.click(screen.getByText('Delete'));
    await waitFor(() => expect(screen.queryByText('risk report')).toBeNull());
    expect(calls.map((c) => c.key)).toContain('DELETE /threads/th0');
    expect(screen.getByText('explain INC-48')).toBeTruthy();
  });

  it("does not reopen another user's remembered chat", async () => {
    const calls = routes({});
    sessionStorage.setItem('bwc.openThread', JSON.stringify({ user: 'someone-else', id: 'th1' }));
    render(<ChatPanel agentUrl="http://a" token="jwt" />);
    await new Promise((r) => setTimeout(r, 20));
    expect(calls).toEqual([]);
  });
});

describe('ChatPanel', () => {
  it('sends the prompt with the user token and shows the tasks and the reply', async () => {
    const fetch = mockAgent(ok({
      thread_id: 't1', reply: 'You have **2** critical incidents.', pending: null,
      steps: [{ id: 'a', tool: 'get_dashboard_summary', args: {}, status: 'done' },
        { id: 'b', tool: 'list_incidents', args: { severity: 'CRITICAL' }, status: 'done' }],
    }));
    render(<ChatPanel agentUrl="http://agent:8800/" token="jwt-1" />);
    ask('what needs my attention?');

    expect(await screen.findByText('critical incidents.', { exact: false })).toBeTruthy();
    const [url, init] = fetch.mock.calls[0];
    expect(url).toBe('http://agent:8800/chat');
    expect(init.headers.Authorization).toBe('Bearer jwt-1');
    expect(JSON.parse(init.body)).toEqual({ message: 'what needs my attention?', thread_id: null });
    const tasks = within(screen.getByLabelText('Tasks')).getAllByRole('listitem');
    expect(tasks.map((t) => t.querySelector('b').textContent)).toEqual(['Get dashboard summary', 'List incidents']);
    expect(screen.getByText('severity: CRITICAL')).toBeTruthy();
  });

  it('asks for approval, sends the decision on the same thread and reports the change', async () => {
    const fetch = mockAgent(
      ok({ thread_id: 't9', reply: null, steps: [{ id: 'c1', tool: 'copy_incident_plan', args: { incident: 'INC-55', source_incident: 'INC-48' }, status: 'awaiting_approval' }],
        pending: [{ id: 'c1', tool: 'copy_incident_plan', title: 'Copy incident plan', args: { incident: 'INC-55', source_incident: 'INC-48' }, destructive: false }] }),
      ok({ thread_id: 't9', reply: 'Copied the plan of INC-48 to INC-55.', pending: null, steps: [{ id: 'c1', tool: 'copy_incident_plan', status: 'done' }] }),
    );
    const changed = vi.fn();
    render(<ChatPanel agentUrl="http://agent:8800" token="jwt-1" onDataChanged={changed} />);
    ask('copy the plan of INC-48 to INC-55');

    const card = await screen.findByRole('group', { name: 'Approval needed' });
    expect(within(card).getByText('Copy incident plan')).toBeTruthy();
    expect(screen.getByLabelText('Message').disabled).toBe(true);           // nothing else until the human decides
    fireEvent.click(within(card).getByText('Approve'));

    expect(await screen.findByText('Copied the plan of INC-48 to INC-55.')).toBeTruthy();
    expect(fetch.mock.calls[1][0]).toBe('http://agent:8800/chat/confirm');
    expect(JSON.parse(fetch.mock.calls[1][1].body)).toEqual({ thread_id: 't9', approve: true });
    expect(changed).toHaveBeenCalledTimes(1);
    expect(screen.getByLabelText('Done')).toBeTruthy();
    expect(screen.queryByRole('group', { name: 'Approval needed' })).toBeNull();
  });

  it('a declined change does not notify the host', async () => {
    mockAgent(
      ok({ thread_id: 't2', reply: null, steps: [], pending: [{ id: 'x', tool: 'close_incident', title: 'Close incident', args: {}, destructive: true }] }),
      ok({ thread_id: 't2', reply: 'Left it open.', pending: null, steps: [{ id: 'x', tool: 'close_incident', status: 'declined' }] }),
    );
    const changed = vi.fn();
    render(<ChatPanel agentUrl="http://a" token="jwt" onDataChanged={changed} />);
    ask('close INC-1');
    expect(await screen.findByText('destructive')).toBeTruthy();
    fireEvent.click(screen.getByText('Decline'));
    expect(await screen.findByText('Left it open.')).toBeTruthy();
    expect(changed).not.toHaveBeenCalled();
  });

  it('shows errors and tells the host about a 401', async () => {
    mockAgent(Promise.resolve({ ok: false, status: 401, json: () => Promise.resolve({ detail: "Send 'Authorization: Bearer <Bulwark JWT>'." }) }));
    const unauth = vi.fn();
    render(<ChatPanel agentUrl="http://a" token="jwt" onUnauthorized={unauth} />);
    ask('hi');
    expect((await screen.findByRole('alert')).textContent).toContain('Authorization');
    expect(unauth).toHaveBeenCalled();
  });

  it('shows a model error with the steps that ran and continues on Retry', async () => {
    const fetch = mockAgent(
      ok({ thread_id: 't5', reply: null, steps: [{ id: 'c2', tool: 'approve_incident', args: { incident: 'INC-149' }, status: 'awaiting_approval' }],
        pending: [{ id: 'c2', tool: 'approve_incident', title: 'Approve incident', args: { incident: 'INC-149' }, destructive: false }] }),
      Promise.resolve({ ok: false, status: 502, json: () => Promise.resolve({ detail: {
        message: 'The assistant stopped on an error: RuntimeError: 429 RESOURCE_EXHAUSTED', retryable: true,
        steps: [{ id: 'c2', tool: 'approve_incident', status: 'done' }] } }) }),
      ok({ thread_id: 't5', reply: 'INC-149 is approved.', pending: null, steps: [] }),
    );
    const changed = vi.fn();
    render(<ChatPanel agentUrl="http://a" token="jwt" onDataChanged={changed} />);
    ask('approve INC-149');
    fireEvent.click(within(await screen.findByRole('group', { name: 'Approval needed' })).getByText('Approve'));

    expect((await screen.findByRole('alert')).textContent).toContain('429 RESOURCE_EXHAUSTED');
    expect(screen.getByLabelText('Done')).toBeTruthy();                       // the approval did run
    expect(changed).toHaveBeenCalled();
    fireEvent.click(screen.getByText('Retry'));
    expect(await screen.findByText('INC-149 is approved.')).toBeTruthy();
    expect(fetch.mock.calls[2][0]).toBe('http://a/chat/retry');
    expect(JSON.parse(fetch.mock.calls[2][1].body)).toEqual({ thread_id: 't5' });
    expect(screen.queryByRole('alert')).toBeNull();
  });

  it('after an approval with no answer, the step is shown as unknown, not waiting', async () => {
    mockAgent(
      ok({ thread_id: 't6', reply: null, steps: [{ id: 'c3', tool: 'run_full_plan', args: {}, status: 'awaiting_approval' }],
        pending: [{ id: 'c3', tool: 'run_full_plan', title: 'Run full plan', args: {}, destructive: false }] }),
      () => Promise.reject(new TypeError('Failed to fetch')),
    );
    render(<ChatPanel agentUrl="http://a" token="jwt" />);
    ask('run it');
    fireEvent.click(within(await screen.findByRole('group', { name: 'Approval needed' })).getByText('Approve'));
    expect((await screen.findByRole('alert')).textContent).toContain('may already have been made');
    expect(screen.getByLabelText('Approved, but no result came back - check the page')).toBeTruthy();
  });

  it('explains when the assistant cannot be reached', async () => {
    vi.stubGlobal('fetch', vi.fn(() => Promise.reject(new TypeError('Failed to fetch'))));
    render(<ChatPanel agentUrl="http://down:8800" token="jwt" />);
    ask('hi');
    expect((await screen.findByRole('alert')).textContent).toContain('No answer from the assistant at http://down:8800');
  });
});

describe('ChatWidget', () => {
  it('opens from the chat icon and keeps the conversation when closed', async () => {
    mockAgent(ok({ thread_id: 't', reply: 'Hello.', pending: null, steps: [] }));
    render(<ChatWidget agentUrl="http://a" token="jwt" />);
    fireEvent.click(screen.getByLabelText('Open Bulwark Assistant'));
    ask('hi');
    expect(await screen.findByText('Hello.')).toBeTruthy();
    fireEvent.click(screen.getByLabelText('Close Bulwark Assistant'));
    fireEvent.click(screen.getByLabelText('Open Bulwark Assistant'));
    expect(screen.getByText('Hello.')).toBeTruthy();
  });
});

describe('helpers', () => {
  it('merges later step updates by id', () => {
    const s = mergeSteps([{ id: 'a', tool: 't', args: { x: 1 }, status: 'awaiting_approval' }], [{ id: 'a', tool: 't', status: 'done' }, { id: 'b', tool: 'u', status: 'done' }]);
    expect(s).toEqual([{ id: 'a', tool: 't', args: { x: 1 }, status: 'done' }, { id: 'b', tool: 'u', status: 'done' }]);
  });

  it('parses markdown tables and lists and never produces raw html', () => {
    const b = parseBlocks('Top:\n\n| Code | Sev |\n|---|---|\n| INC-1 | HIGH |\n\n- one\n- two\n\n<script>x</script>');
    expect(b.map((x) => x.type)).toEqual(['p', 'table', 'ul', 'p']);
    expect(b[1].rows).toEqual([['INC-1', 'HIGH']]);
  });
});

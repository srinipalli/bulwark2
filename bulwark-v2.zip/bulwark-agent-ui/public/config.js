// Runtime configuration. Change this file (no rebuild needed) to point the UI at another chat agent.
// A value saved from the in-app Settings dialog overrides this one for that browser.
window.__BULWARK_CONFIG__ = {
  agentUrl: "http://localhost:8800",          // bulwark-chat-server (bulwark-ai/bulwark-chat-agent)
};

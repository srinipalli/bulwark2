# Bulwark Agent UI

Web chat for the **Bulwark Assistant** (React 18 + Vite). You type a request; the agent (`bulwark-chat-server`) works out
which tasks (MCP tools) are needed, runs them in order, and answers. The UI shows every task with its status, and
**asks you to approve or decline** before anything that changes data runs.

```
browser (this UI) ──POST /chat, /chat/confirm + Bearer JWT──► bulwark-chat-server :8800 ──► bulwark-mcp :8765 ──► Bulwark API :8000
```

It is two things:

| | Path | Used by |
|---|---|---|
| Standalone app with its own login | `src/App.jsx`, `src/auth/` | `npm run dev` on http://localhost:3100 |
| **Reusable chat component** | `src/chat/` (`ChatPanel`, `ChatWidget`, `createAgentClient`) | this app, and `bulwark-ui` (floating chat icon) |

## Run
```bash
npm install
npm run dev        # http://localhost:3100
npm run build      # static files in dist/
npm test           # component tests, no backend needed
```
Needs `bulwark-chat-server` running, with this origin in its `CORS_ORIGINS`
(default already allows `http://localhost:3000` and `http://localhost:3100`).

## Signing in
Same as bulwark-ui: paste a Bulwark JWT from your identity provider, or (local development only) mint one in the browser
with the API's `JWT_SECRET`. The token is kept in `localStorage["bulwark.token"]` and sent to the agent on every request;
the agent forwards it, so the assistant can never do more than that user can in the UI. Signing in as someone else
clears the conversation.

## Assistant URL (configurable)
1. Login page field (stored in the browser)
2. `public/config.js` - `window.__BULWARK_CONFIG__ = { agentUrl: "http://localhost:8800" }` (editable after build)
3. `VITE_AGENT_URL` at build time
4. Default `http://localhost:8800`

## The chat component
```jsx
import { ChatWidget, ChatPanel } from '<path>/bulwark-agent-ui/src/chat';

<ChatWidget agentUrl="http://localhost:8800" token={jwt} userName="Srini"
            onUnauthorized={logout} onDataChanged={refreshPage} />   // floating icon + popup
<ChatPanel  agentUrl={() => url} token={jwt} />                        // inline, fills its container
```
| Prop | |
|---|---|
| `agentUrl` | string or function returning the chat server URL |
| `token` | the signed-in user's Bulwark JWT (changing it starts a fresh conversation) |
| `userName` | used in the greeting |
| `onUnauthorized()` | the agent answered 401 |
| `onDataChanged()` | an approved change has run - refresh what is on screen |
| `onClose()` | (ChatPanel) show a close button |
| `docked` | (ChatPanel) show *Recent chats* as a side column instead of a drawer (the standalone app does this) |

### Chat history
The clock icon opens **Recent chats** (the user's saved conversations, newest first, from `GET /threads`); click one to load it
with its tasks and replies and carry on, or delete it (trash icon, then confirm). The pencil icon starts a **new chat**.
A chat that was waiting for approval can still be approved after reopening; one that broke off shows *Retry*.
The open chat is remembered per browser tab, so a page refresh reopens it (only for the same user).
History is stored by bulwark-chat-server, so it is the same in this app and in the bulwark-ui chat icon.

All CSS classes are prefixed `bwc-`; colours are `--bwc-*` variables you can override.

### What the agent returns (and the UI shows)
`POST /chat` → `{thread_id, reply, pending, steps}`. `steps` lists each tool call in order with
`status`: `planned`, `awaiting_approval`, `done`, `failed` (with `detail`) or `declined`. When `pending` is set,
the UI shows the approval card and sends `POST /chat/confirm {thread_id, approve}`.

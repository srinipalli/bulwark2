"""bulwark-scan-ingestor: vulnerability scan workbooks -> Bulwark DB (vulnerabilities + incidents) -> Kafka (incident events)."""
__version__ = "1.0.0"

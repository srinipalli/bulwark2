"""Business rules: scan rows -> vulnerabilities, assets, links and ONE open incident per vulnerability."""

from .repository import A_COMMITTED, EDITABLE, FILE_ENTITY, Repo
from .schemas import ParsedFile, VulnRow


def _f(v) -> float | None:
    return None if v is None else float(v)


def incident_title(r: VulnRow) -> str:
    return f"{r.cve_id}: {r.title.split(' (')[0]}"


def incident_description(r: VulnRow, asset_names: list[str], parsed: ParsedFile) -> str:
    names = ", ".join(asset_names[:3]) + (f" and {len(asset_names) - 3} more" if len(asset_names) > 3 else "")
    parts = [f"Remediate {r.cve_id} ({r.title.split(' (')[0]}) on {len(asset_names)} impacted asset{'s' if len(asset_names) != 1 else ''}"
             + (f": {names}." if asset_names else "."),
             f"CVSS {r.cvss_score}, severity {r.severity}." if r.cvss_score is not None else f"Severity {r.severity}.",
             "Reported as exploited in the wild - treat as urgent." if r.exploited_in_wild else "",
             f"Detected by {parsed.scan.scanner} in {parsed.scan.scan_id}" + (f" (first seen {r.first_detected})." if r.first_detected else "."),
             f"Recommendation: {r.recommendation}" if r.recommendation else ""]
    return " ".join(p for p in parts if p)


def apply(repo: Repo, parsed: ParsedFile, *, sha: str, filename: str, actor, assignee) -> dict:
    """Write everything for one file. Caller owns the transaction (one commit per file)."""
    scan = parsed.scan
    warnings: list[str] = []
    used = sorted({n for r in parsed.rows for n in r.affected_assets})
    assets = repo.assets_by_name(used) if used else {}
    created_assets = []
    for name in used:
        if name not in assets and name in parsed.assets:
            assets[name] = repo.create_asset(parsed.assets[name], {"discovered_by": scan.scanner, "scan_id": scan.scan_id})
            created_assets.append(name)
            repo.audit(actor, "asset.created", "asset", assets[name]["id"], after={"name": name, "via": "scan", "scan_id": scan.scan_id})
    vulns = repo.vulns_by_cve([r.cve_id for r in parsed.rows])
    # CVEs that exist already: look up their open incidents in one query
    open_inc = repo.open_incidents([v["id"] for v in vulns.values()]) if vulns else {}

    actions: dict[str, dict] = {}
    t = {"vulnerabilities_created": 0, "vulnerabilities_updated": 0, "vulnerabilities_unchanged": 0, "incidents_created": 0, "incidents_updated": 0,
         "incidents_unchanged": 0, "incidents_locked": 0, "incidents_skipped_inactive": 0, "incident_assets_added": 0}
    for r in parsed.rows:
        resolved = []
        for n in r.affected_assets:
            if n in assets:
                resolved.append(assets[n])
            else:
                warnings.append(f"{r.cve_id} (row {r.row}): asset '{n}' is not in the database or the Assets sheet; skipped")
        # ---------------- vulnerability
        v = vulns.get(r.cve_id)
        if v is None:
            v = repo.create_vuln(r, actor)
            vulns[r.cve_id] = v
            vact = {"action": "CREATED", "changed": {}, "assets_added": [a["name"] for a in resolved]}
            repo.link_vuln_assets(v["id"], [a["id"] for a in resolved])
            repo.audit(actor, "vulnerability.created", "vulnerability", v["id"], after={"cve_id": r.cve_id, "via": "scan", "scan_id": scan.scan_id})
            t["vulnerabilities_created"] += 1
        else:
            changed: dict[str, dict] = {}
            upd: dict = {}
            if r.cvss_score is not None and v["cvss_score"] != r.cvss_score:
                changed["cvss_score"] = {"from": _f(v["cvss_score"]), "to": _f(r.cvss_score)}
                upd["cvss_score"] = r.cvss_score
                if r.severity != v["severity"]:
                    changed["severity"] = {"from": v["severity"], "to": r.severity}
                    upd["severity"] = r.severity
            if v["published_at"] is None and r.published_at:
                changed["published_at"] = {"from": None, "to": r.published_at.isoformat()}
                upd["published_at"] = r.published_at
            if not (v["description"] or "").strip() and r.description:
                changed["description"] = {"from": None, "to": "(filled from scan)"}
                upd["description"] = r.description
            if upd:
                repo.update_vuln(v["id"], **upd)
                v = {**v, **upd}
                vulns[r.cve_id] = v
            added = repo.link_vuln_assets(v["id"], [a["id"] for a in resolved])
            names_added = [a["name"] for a in resolved if a["id"] in added]
            status = "UPDATED" if (changed or added) else "UNCHANGED"
            vact = {"action": status, "changed": changed, "assets_added": names_added}
            t[f"vulnerabilities_{status.lower()}"] += 1
            if status == "UPDATED":
                repo.audit(actor, "vulnerability.updated", "vulnerability", v["id"], before={k: c["from"] for k, c in changed.items()},
                           after={**{k: c["to"] for k, c in changed.items()}, "assets_added": [str(x) for x in added], "via": "scan", "scan_id": scan.scan_id})

        # ---------------- incident (one open incident per vulnerability)
        inc: dict = {"action": "UNCHANGED", "id": None, "no": None, "reopened": False, "previous_incident": None, "assets_added": [], "changed": {}}
        if not v["is_active"]:
            inc["action"] = "SKIPPED_INACTIVE"
            t["incidents_skipped_inactive"] += 1
            warnings.append(f"{r.cve_id} (row {r.row}): vulnerability is deactivated; no incident created")
        elif v["id"] not in open_inc:
            prev = repo.last_finished_incident(v["id"])
            row = repo.create_incident(v["id"], incident_title(r), incident_description(r, [a["name"] for a in resolved], parsed), v["severity"], assignee, actor)
            repo.add_incident_assets(row["id"], [a["id"] for a in resolved])
            open_inc[v["id"]] = {"id": row["id"], "incident_no": row["incident_no"], "status": "OPEN", "severity": v["severity"]}
            inc.update(action="CREATED", id=str(row["id"]), no=row["incident_no"], reopened=prev is not None,
                       previous_incident=f"INC-{prev['incident_no']}" if prev else None, assets_added=[a["name"] for a in resolved])
            t["incidents_created"] += 1
            t["incident_assets_added"] += len(resolved)
            if not resolved:
                warnings.append(f"{r.cve_id} (row {r.row}): incident INC-{row['incident_no']} created without impacted assets")
            repo.audit(actor, "incident.created", "incident", row["id"], after={"vulnerability": r.cve_id, "via": "scan", "scan_id": scan.scan_id})
        else:
            cur = open_inc[v["id"]]
            inc.update(id=str(cur["id"]), no=cur["incident_no"])
            have = repo.incident_asset_ids(cur["id"])
            new_assets = [a for a in resolved if a["id"] not in have]
            if cur["status"] in EDITABLE:
                added = repo.add_incident_assets(cur["id"], [a["id"] for a in new_assets])
                sev_changed = cur["severity"] != v["severity"]
                if sev_changed:
                    repo.set_incident_severity(cur["id"], v["severity"])
                    inc["changed"]["severity"] = {"from": cur["severity"], "to": v["severity"]}
                if added or sev_changed:
                    if added and not sev_changed:
                        repo.touch_incident(cur["id"])
                    inc.update(action="UPDATED", assets_added=[a["name"] for a in new_assets if a["id"] in added])
                    t["incidents_updated"] += 1
                    t["incident_assets_added"] += len(added)
                    repo.audit(actor, "incident.updated", "incident", cur["id"], before={k: c["from"] for k, c in inc["changed"].items()},
                               after={**{k: c["to"] for k, c in inc["changed"].items()}, "assets_added": [str(x) for x in added], "via": "scan", "scan_id": scan.scan_id})
                else:
                    t["incidents_unchanged"] += 1
            elif new_assets:
                inc["action"] = "LOCKED"
                inc["assets_pending"] = [a["name"] for a in new_assets]
                t["incidents_locked"] += 1
                warnings.append(f"INC-{cur['incident_no']} ({r.cve_id}) is {cur['status']} and cannot take new assets; not added: {', '.join(inc['assets_pending'])}")
            else:
                t["incidents_unchanged"] += 1
        actions[r.cve_id] = {"vulnerability": vact, "incident": inc}

    summary = {**t, "assets_created": len(created_assets), "assets_created_names": created_assets}
    repo.audit(actor, A_COMMITTED, FILE_ENTITY, sha, after={"file": filename, "scan_id": scan.scan_id, "actions": actions, "totals": summary})
    return {"actions": actions, "totals": summary, "warnings": warnings}


def snapshot(repo: Repo, parsed: ParsedFile, actions: dict) -> dict:
    """Post-commit state needed to build the events."""
    inc_ids = [a["incident"]["id"] for a in actions.values() if a["incident"].get("id")]
    return {
        "vulns": repo.vulns_by_cve([r.cve_id for r in parsed.rows]),
        "incidents": repo.incident_details(inc_ids) if inc_ids else {},
        "incident_assets": repo.incident_asset_rows(inc_ids) if inc_ids else {},
    }

"""Orchestration for one file / one folder:  validate -> DB transaction -> Kafka -> markers -> archive.

Delivery model: the DB transaction (vulnerabilities, assets, incidents, marker) commits first. Kafka events are then sent; only when ALL are
acknowledged is the 'published' marker written and the file archived. A Kafka failure leaves the file in place; the next run skips the DB step
(marker) and re-sends the same events with the same event_id (at-least-once; consumers de-duplicate on event_id).
"""
import hashlib
import json
import logging
import shutil
import time
import uuid
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

import psycopg
from psycopg.rows import dict_row

from . import messages, service
from .config import Settings
from .publisher import Publisher
from .reader import WorkbookError, read_workbook
from .repository import A_PUBLISHED, FILE_ENTITY, Repo

log = logging.getLogger("scan_ingestor")
LOCK_KEY = 7_461_002                                # pg_advisory_lock: one ingestor at a time


def _report(**kw) -> dict:
    return {"status": "error", "file": None, "sha256": None, "scan_id": None, "message": None, "counts": {}, "kafka": {}, "errors": [], "warnings": [], **kw}


def connect(settings: Settings, autocommit: bool = False) -> psycopg.Connection:
    return psycopg.connect(settings.dsn, row_factory=dict_row, autocommit=autocommit)


def process_file(path: Path, *, settings: Settings, publisher: Publisher | None, job_run_id: str, force: bool = False, validate_only: bool = False) -> dict:
    t0 = time.monotonic()
    data = path.read_bytes()
    file = {"name": path.name, "sha256": hashlib.sha256(data).hexdigest(), "size": len(data)}
    rep = _report(file=path.name, sha256=file["sha256"])
    try:
        parsed = read_workbook(path, tz=settings.ingest_timezone)
    except WorkbookError as e:
        return {**rep, "status": "rejected", "message": str(e)}
    rep["scan_id"] = parsed.scan.scan_id
    rep["errors"] = [i.model_dump() for i in parsed.errors]
    rep["warnings"] = [i.model_dump() for i in parsed.warnings]
    bad_rows = len({i.row for i in parsed.errors if i.sheet == "Vulnerabilities"})
    pct = 100.0 * bad_rows / parsed.total_rows if parsed.total_rows else 100.0
    rep["counts"] = {"rows_in_file": parsed.total_rows, "valid_rows": len(parsed.rows), "rejected_rows": bad_rows}
    if not parsed.rows or pct > settings.ingest_max_invalid_pct:
        return {**rep, "status": "rejected", "message": f"{bad_rows} of {parsed.total_rows} rows are invalid ({pct:.0f}% > limit {settings.ingest_max_invalid_pct:.0f}%); nothing was written"}
    if validate_only:
        return {**rep, "status": "validated", "message": "validation only; nothing written"}
    assert publisher is not None

    with connect(settings) as conn:
        repo = Repo(conn)
        actor = repo.ensure_user(settings.ingest_actor_email, "Scan Ingestion Job", "ingestion.bot")
        assignee = None
        if settings.ingest_default_assignee_email:
            u = repo.find_user(settings.ingest_default_assignee_email)
            assignee = u["id"] if u else None
            if not u:
                rep["warnings"].append({"level": "warning", "sheet": "-", "message": f"INGEST_DEFAULT_ASSIGNEE_EMAIL {settings.ingest_default_assignee_email} not found; incidents left unassigned"})
        state, prev = repo.file_state(file["sha256"])
        if state == "published" and not force:
            conn.commit()
            return {**rep, "status": "already_published", "message": "this exact file was already processed (use --force to run it again)"}
        if state == "committed" and not force:
            log.info("%s: database step already committed earlier; re-publishing to Kafka only", path.name)
            actions, totals, warns = prev["actions"], prev["totals"], []
            conn.commit()
        else:
            res = service.apply(repo, parsed, sha=file["sha256"], filename=path.name, actor=actor, assignee=assignee)
            conn.commit()
            actions, totals, warns = res["actions"], res["totals"], res["warnings"]
        rep["warnings"] += [{"level": "warning", "sheet": "Vulnerabilities", "message": w} for w in warns]
        rep["counts"].update({k: v for k, v in totals.items() if k != "assets_created_names"})
        rep["counts"]["assets_created_names"] = totals.get("assets_created_names", [])
        snap = service.snapshot(repo, parsed, actions)
        conn.commit()

        produced_at = messages.now_iso()
        sev: Counter = Counter()
        sent = 0
        for r in parsed.rows:
            act = actions.get(r.cve_id)
            if not act or not act["incident"].get("id"):
                continue                                                       # inactive vulnerability: no incident, no event
            if act["incident"]["action"] in ("LOCKED",) or (act["incident"]["action"] == "UNCHANGED" and not settings.kafka_publish_unchanged):
                continue
            iid = act["incident"]["id"]
            inc = snap["incidents"].get(uuid.UUID(iid))
            vuln = snap["vulns"].get(r.cve_id)
            if inc is None or vuln is None:
                rep["errors"].append({"level": "error", "sheet": "Vulnerabilities", "row": r.row, "message": f"{r.cve_id}: incident not found after commit"})
                continue
            msg = messages.incident_event(parsed=parsed, row=r, actions=act, vuln=vuln, incident=inc, assets=snap["incident_assets"].get(inc["id"], []), file=file,
                                          job_run_id=job_run_id, produced_at=produced_at)
            publisher.publish(settings.kafka_topic_incidents, iid, messages.to_bytes(msg),
                              {"event_type": msg["event_type"], "schema_version": messages.SCHEMA_VERSION, "scan_id": parsed.scan.scan_id, "cve_id": r.cve_id})
            sev[inc["severity"]] += 1
            sent += 1
        left = publisher.flush(settings.kafka_delivery_timeout_ms / 1000 + 30)
        if left or publisher.failures:
            rep["kafka"] = {"sent": sent, "delivered": publisher.delivered, "failed": left, "first_error": publisher.failures[0][1] if publisher.failures else "timeout waiting for broker acknowledgements"}
            return {**rep, "status": "db_committed_publish_failed", "message": "database updated, Kafka delivery failed; file left in place and will be re-published on the next run"}
        summary = messages.scan_message(parsed=parsed, file=file, totals=totals, severity=dict(sev), job_run_id=job_run_id, produced_at=produced_at, events_published=sent)
        publisher.publish(settings.kafka_topic_scans, parsed.scan.scan_id, messages.to_bytes(summary),
                          {"event_type": messages.SCAN_DONE, "schema_version": messages.SCHEMA_VERSION, "scan_id": parsed.scan.scan_id})
        left = publisher.flush(settings.kafka_delivery_timeout_ms / 1000 + 30)
        if left or publisher.failures:
            rep["kafka"] = {"sent": sent + 1, "delivered": publisher.delivered, "failed": left, "first_error": publisher.failures[0][1] if publisher.failures else "timeout"}
            return {**rep, "status": "db_committed_publish_failed", "message": "incident events delivered, scan summary failed; file left in place for retry"}
        repo.audit(actor, A_PUBLISHED, FILE_ENTITY, file["sha256"], after={"file": path.name, "scan_id": parsed.scan.scan_id, "messages": sent + 1})
        conn.commit()
    rep["kafka"] = {"incident_events": sent, "scan_summary": 1, "delivered": publisher.delivered, "failed": 0}
    return {**rep, "status": "published", "message": f"ok in {time.monotonic() - t0:.1f}s"}


def discover(folder: Path, min_age: int) -> list[Path]:
    now, out = time.time(), []
    for p in sorted(folder.glob("*.xlsx")):
        if p.name.startswith(("~$", ".")):
            continue
        if now - p.stat().st_mtime < min_age:
            log.info("skipping %s (modified %.0fs ago; still being written?)", p.name, now - p.stat().st_mtime)
            continue
        out.append(p)
    return out


def archive(folder: Path, path: Path, sub: str, rep: dict, run_ts: str) -> None:
    (folder / "reports").mkdir(exist_ok=True)
    (folder / "reports" / f"{path.stem}.{run_ts}.report.json").write_text(json.dumps(rep, indent=2, default=str), encoding="utf-8")
    if sub:
        (folder / sub).mkdir(exist_ok=True)
        shutil.move(str(path), str(folder / sub / f"{path.stem}.{run_ts}{path.suffix}"))


def run_folder(folder: Path, *, settings: Settings, publisher: Publisher | None, force: bool, validate_only: bool, no_move: bool, files: list[Path] | None = None) -> list[dict]:
    job_run_id = str(uuid.uuid4())
    run_ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S")
    todo = files or discover(folder, settings.ingest_min_file_age_seconds)
    log.info("job_run_id=%s: %d file(s) to process in %s", job_run_id, len(todo), folder)
    results: list[dict] = []

    def one(path: Path) -> dict:
        log.info("processing %s", path.name)
        try:
            rep = process_file(path, settings=settings, publisher=publisher, job_run_id=job_run_id, force=force, validate_only=validate_only)
        except Exception as e:                                          # noqa: BLE001 - one bad file must not stop the batch
            log.exception("unexpected failure on %s", path.name)
            rep = _report(file=path.name, status="error", message=f"{type(e).__name__}: {e}")
        c = {k: v for k, v in rep.get("counts", {}).items() if k != "assets_created_names"}
        log.info("%s -> %s  %s  %s", path.name, rep["status"], c, rep.get("message") or "")
        for i in rep["errors"][:15]:
            log.warning("  %s row %s %s: %s", i.get("sheet"), i.get("row"), i.get("field") or "", i["message"])
        for w in rep["warnings"][:5]:
            log.info("  warning: %s", w["message"])
        if not no_move and not validate_only and files is None:
            archive(folder, path, {"published": "processed", "already_published": "processed", "rejected": "failed", "error": "failed"}.get(rep["status"], ""), rep, run_ts)
        return rep

    if validate_only:                                                   # no database involved at all
        return [one(p) for p in todo]
    with connect(settings, autocommit=True) as lock:
        if not lock.execute("SELECT pg_try_advisory_lock(%s) AS ok", (LOCK_KEY,)).fetchone()["ok"]:
            log.warning("another ingestor is running; exiting")
            return [_report(status="locked", message="another instance is running")]
        try:
            for p in todo:
                results.append(one(p))
        finally:
            lock.execute("SELECT pg_advisory_unlock(%s)", (LOCK_KEY,))
    return results

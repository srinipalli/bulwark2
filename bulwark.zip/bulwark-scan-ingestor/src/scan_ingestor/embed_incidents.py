"""Read the incidents table and fill incidents.embedding (pgvector) with Gemini embeddings.

    pip install -r requirements.txt
    python src/scan_ingestor/embed_incidents.py                   # only incidents with no vector / changed text / other model
    python src/scan_ingestor/embed_incidents.py --all --limit 20  # re-embed (at most 20)
    python src/scan_ingestor/embed_incidents.py --dry-run         # print the text of the first incidents, call nothing

All settings (DATABASE_URL, GEMINI_*, EMBED_*) are read from .env in the project folder; see .env.example.
Requires the pgvector columns incidents.embedding vector(EMBED_DIMENSIONS), embedding_model, embedding_text_hash, embedded_at.
"""
import argparse
import hashlib
import math
import os
import sys
import time
from pathlib import Path

if __package__ in (None, ""):                                       # started as a script: import the package from src/, read .env from the project folder
    ROOT = Path(__file__).resolve().parents[2]
    os.chdir(ROOT)
    sys.path[0] = str(ROOT / "src")

import psycopg  # noqa: E402
from psycopg.rows import dict_row  # noqa: E402
from pydantic import ValidationError  # noqa: E402

from scan_ingestor.config import EmbedSettings  # noqa: E402


# ----------------------------------------------------------------------------------------- Gemini embeddings
def normalize(v):
    n = math.sqrt(sum(x * x for x in v)) or 1.0
    return [x / n for x in v]


def make_embedder(s: EmbedSettings):
    from google import genai
    from google.genai import types

    client = genai.Client(api_key=s.gemini_api_key.get_secret_value())
    cfg = types.EmbedContentConfig(task_type=s.gemini_embed_task_type, output_dimensionality=s.embed_dimensions)

    def embed(texts):                                               # <= 100 texts per call
        for attempt in range(s.embed_max_retries):
            try:
                res = client.models.embed_content(model=s.gemini_embed_model, contents=texts, config=cfg)
                time.sleep(s.embed_request_delay_seconds)           # stay under the free-tier requests/minute
                return [normalize(list(e.values)) for e in res.embeddings]
            except Exception as e:                                  # 429 / 503: back off and retry
                if attempt == s.embed_max_retries - 1:
                    raise
                print(f"  Gemini busy ({str(e)[:60]}), retry in {2 ** (attempt + 2)}s")
                time.sleep(2 ** (attempt + 2))
    return f"gemini:{s.gemini_embed_model}:{s.embed_dimensions}", embed


# ----------------------------------------------------------------------------------------- read incidents
QUERY = """
SELECT i.id, i.incident_no, i.title, i.description, i.severity,
       i.embedding IS NULL AS no_vector, i.embedding_model, i.embedding_text_hash,
       v.cve_id, v.title AS vuln_title, v.description AS vuln_description, v.cvss_score,
       COALESCE((SELECT string_agg(DISTINCT concat_ws(' ', a.asset_type, a.os_name, a.os_version, a.environment), '; ')
                   FROM incident_assets ia JOIN assets a ON a.id = ia.asset_id
                  WHERE ia.incident_id = i.id), '') AS platforms
  FROM incidents i
  JOIN vulnerabilities v ON v.id = i.vulnerability_id
 ORDER BY i.incident_no
"""


def build_text(r):
    """The text that is embedded. Keep it stable: changing it re-embeds every incident."""
    parts = [f"Incident: {r['title']}",
             f"Vulnerability {r['cve_id']}: {r['vuln_title']}",
             r["vuln_description"] or "",
             r["description"] or "",
             f"Severity: {r['severity']}" + (f", CVSS {r['cvss_score']}" if r["cvss_score"] is not None else ""),
             f"Affected platforms: {r['platforms']}" if r["platforms"] else ""]
    return "\n".join(p.strip() for p in parts if p and p.strip())


def main():
    ap = argparse.ArgumentParser(description="Fill incidents.embedding with Gemini embeddings")
    ap.add_argument("--all", action="store_true", help="re-embed every incident")
    ap.add_argument("--limit", type=int, help="max incidents this run")
    ap.add_argument("--dry-run", action="store_true", help="print the text of the first incidents, call nothing")
    a = ap.parse_args()

    try:
        s = EmbedSettings()
    except ValidationError as e:
        print("invalid or missing settings in .env / environment:", ", ".join(str(err["loc"][0]).upper() for err in e.errors()), "(see .env.example)")
        return 2

    with psycopg.connect(s.dsn, row_factory=dict_row) as conn:
        rows = conn.execute(QUERY).fetchall()
        model_name, embed = ("dry-run", None) if a.dry_run else make_embedder(s)

        todo = []
        for r in rows:
            r["text"] = build_text(r)
            r["hash"] = hashlib.sha256(r["text"].encode()).hexdigest()
            if a.all or r["no_vector"] or r["hash"] != r["embedding_text_hash"] or r["embedding_model"] != model_name:
                todo.append(r)
        todo = todo[:a.limit] if a.limit else todo
        print(f"{len(rows)} incidents, {len(todo)} to embed with {model_name}")

        if a.dry_run:
            for r in todo[:3]:
                print(f"--- INC-{r['incident_no']}\n{r['text']}\n")
            return 0

        batch = s.embed_batch_size
        for i in range(0, len(todo), batch):
            chunk = todo[i:i + batch]
            vectors = embed([r["text"] for r in chunk])
            with conn.transaction():                                 # one commit per batch
                for r, vec in zip(chunk, vectors):
                    assert len(vec) == s.embed_dimensions
                    conn.execute(
                        "UPDATE incidents SET embedding = %s::vector, embedding_model = %s, embedding_text_hash = %s, embedded_at = now() WHERE id = %s",
                        ("[" + ",".join(f"{x:.7g}" for x in vec) + "]", model_name, r["hash"], r["id"]))
            print(f"  embedded {min(i + batch, len(todo))}/{len(todo)}")
    print("done")
    return 0


if __name__ == "__main__":
    sys.exit(main())

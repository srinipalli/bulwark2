"""Command line.

    scan-ingestor --dir ./data/vulnerabilities                 # process every new *.xlsx once (cron / k8s CronJob)
    scan-ingestor --watch --interval 60
    scan-ingestor --file scan.xlsx --validate-only             # parse + validate, touches nothing
    scan-ingestor --kafka-dry-run                              # real database, Kafka events written to a .jsonl file

Exit codes: 0 ok (or nothing to do) | 1 a file was rejected/failed | 2 configuration or Kafka connectivity problem | 3 another instance is running
"""
import argparse
import logging
import sys
import time
from pathlib import Path

from pydantic import ValidationError

from .config import get_settings
from .pipeline import run_folder
from .publisher import FilePublisher, KafkaPublisher, Publisher, PublisherError

log = logging.getLogger("scan_ingestor")


def build_publisher(args, settings, folder: Path) -> Publisher | None:
    if args.validate_only:
        return None
    if args.kafka_dry_run:
        out = args.kafka_dry_run_out or str(folder / "reports" / "kafka_dry_run.jsonl")
        log.info("Kafka DRY RUN: events are written to %s", out)
        return FilePublisher(out)
    pub = KafkaPublisher(settings)
    pub.preflight()
    log.info("Kafka reachable at %s (topics: %s, %s)", settings.kafka_bootstrap_servers, settings.kafka_topic_incidents, settings.kafka_topic_scans)
    return pub


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="scan-ingestor", description="Import vulnerability scan workbooks, create incidents, publish incident events to Kafka")
    ap.add_argument("--dir", help="folder with *.xlsx files (default: INGEST_DIR)")
    ap.add_argument("--file", action="append", type=Path, help="process only this file (repeatable); files are not moved")
    ap.add_argument("--watch", action="store_true", help="keep running and poll the folder")
    ap.add_argument("--interval", type=int, help="poll interval in seconds for --watch (default: INGEST_WATCH_INTERVAL_SECONDS)")
    ap.add_argument("--validate-only", action="store_true", help="parse and validate only; no database, no Kafka")
    ap.add_argument("--kafka-dry-run", action="store_true", help="write events to a JSON-lines file instead of Kafka")
    ap.add_argument("--kafka-dry-run-out", help="path of the dry-run file")
    ap.add_argument("--force", action="store_true", help="process a file even if its hash was already processed")
    ap.add_argument("--no-move", action="store_true", help="leave files in place after processing")
    ap.add_argument("-v", "--verbose", action="store_true")
    args = ap.parse_args(argv)
    logging.basicConfig(level=logging.DEBUG if args.verbose else logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    try:
        settings = get_settings()
    except ValidationError as e:
        missing = [str(err["loc"][0]).upper() for err in e.errors()]
        log.error("invalid or missing settings in .env / environment: %s (see .env.example)", ", ".join(missing))
        return 2
    interval = args.interval or settings.ingest_watch_interval_seconds
    folder = Path(args.dir or settings.ingest_dir)
    if not args.file and not folder.is_dir():
        log.error("folder %s does not exist", folder)
        return 2
    try:
        publisher = build_publisher(args, settings, folder)
    except PublisherError as e:
        log.error("Kafka configuration/connection problem: %s", e)
        log.error("Fix the KAFKA_* settings, or run with --kafka-dry-run / --validate-only")
        return 2
    worst = 0
    try:
        while True:
            res = run_folder(folder, settings=settings, publisher=publisher, force=args.force, validate_only=args.validate_only, no_move=args.no_move, files=args.file)
            if any(r["status"] == "locked" for r in res):
                worst = max(worst, 3)
            if any(r["status"] in ("rejected", "error", "db_committed_publish_failed") for r in res):
                worst = max(worst, 1)
            if not args.watch:
                return worst
            time.sleep(interval)
    except KeyboardInterrupt:
        return worst


if __name__ == "__main__":
    sys.exit(main())

from functools import lru_cache

from pydantic import SecretStr
from pydantic_settings import BaseSettings, SettingsConfigDict


class _Database(BaseSettings):
    """Every value comes from the environment / .env (see .env.example); nothing is defaulted in code."""
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # ---- database (the Bulwark PostgreSQL database; sql/schema.sql)
    database_url: str                             # a '+asyncpg' suffix from the API's .env is accepted

    @property
    def dsn(self) -> str:
        return self.database_url.replace("postgresql+asyncpg://", "postgresql://").replace("postgresql+psycopg://", "postgresql://")


class Settings(_Database):
    """Scan ingestor (run.py)."""

    # ---- folder job
    ingest_dir: str
    ingest_timezone: str                          # timezone of naive timestamps in the workbook
    ingest_actor_email: str                       # service user that owns created vulnerabilities / incidents
    ingest_default_assignee_email: str            # optional (may be empty): assign new incidents to this user
    ingest_min_file_age_seconds: int              # ignore files still being copied
    ingest_max_invalid_pct: float                 # reject the whole file when more rows than this are invalid
    ingest_watch_interval_seconds: int            # poll interval for --watch

    # ---- Kafka (Aiven: SASL_SSL + SCRAM + project CA certificate)
    kafka_bootstrap_servers: str                  # host:port
    kafka_security_protocol: str                  # PLAINTEXT | SSL | SASL_PLAINTEXT | SASL_SSL
    kafka_sasl_mechanism: str                     # PLAIN | SCRAM-SHA-256 | SCRAM-SHA-512
    kafka_sasl_username: str
    kafka_sasl_password: SecretStr
    kafka_ssl_ca_file: str                        # service CA certificate (ca.pem); empty = system CAs
    kafka_client_id: str
    kafka_topic_incidents: str
    kafka_topic_scans: str
    kafka_publish_unchanged: bool                 # also emit an event for incidents that needed no change
    kafka_delivery_timeout_ms: int
    kafka_socket_timeout_ms: int
    kafka_create_topics: bool
    kafka_topic_partitions: int
    kafka_topic_replication: int


class EmbedSettings(_Database):
    """Incident embeddings with Gemini (embed_incidents.py)."""
    gemini_api_key: SecretStr
    gemini_embed_model: str
    gemini_embed_task_type: str                   # SEMANTIC_SIMILARITY | RETRIEVAL_DOCUMENT | ...
    embed_dimensions: int                         # must match the incidents.embedding vector(N) column
    embed_batch_size: int                         # texts per Gemini call (max 100)
    embed_request_delay_seconds: float            # pause after each call (free-tier requests/minute)
    embed_max_retries: int                        # attempts per batch on 429 / 503


@lru_cache
def get_settings() -> Settings:
    return Settings()

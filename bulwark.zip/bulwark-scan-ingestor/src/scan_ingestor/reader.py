"""Read and validate a scan workbook. Pure function of the file: no database, no Kafka."""
import re
from datetime import date, datetime, time
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo

from openpyxl import load_workbook
from pydantic import ValidationError

from .schemas import AssetRow, Issue, ParsedFile, ScanMeta, VulnRow, severity_from_cvss


class WorkbookError(Exception):
    """The file cannot be processed at all (not an xlsx, required sheet or column missing)."""


def _key(v: Any) -> str:
    return re.sub(r"[^a-z0-9]+", "_", str(v or "").strip().lower()).strip("_")


def _s(v: Any) -> str | None:
    if v is None:
        return None
    s = str(v).strip()
    return s or None


def _dt(v: Any, tz: ZoneInfo) -> datetime | None:
    if v in (None, ""):
        return None
    if isinstance(v, datetime):
        d = v
    elif isinstance(v, date):
        d = datetime.combine(v, time.min)
    else:
        txt = str(v).strip().replace("Z", "+00:00")
        try:
            d = datetime.fromisoformat(txt)
        except ValueError:
            for fmt in ("%d-%m-%Y %H:%M", "%d/%m/%Y %H:%M", "%d-%m-%Y", "%d/%m/%Y", "%m/%d/%Y"):
                try:
                    d = datetime.strptime(txt, fmt)
                    break
                except ValueError:
                    continue
            else:
                raise ValueError(f"'{v}' is not a recognised date")
    return d if d.tzinfo else d.replace(tzinfo=tz)


def _d(v: Any, tz: ZoneInfo) -> date | None:
    d = _dt(v, tz)
    return d.date() if d else None


def _bool(v: Any) -> bool | None:
    if v in (None, ""):
        return None
    t = str(v).strip().lower()
    if t in ("y", "yes", "true", "1", "t"):
        return True
    if t in ("n", "no", "false", "0", "f"):
        return False
    raise ValueError(f"'{v}' is not Y/N")


def _num(v: Any) -> Decimal | None:
    if v in (None, ""):
        return None
    try:
        return Decimal(str(v).strip().replace(",", ".")).quantize(Decimal("0.1"))
    except InvalidOperation:
        raise ValueError(f"'{v}' is not a number") from None


def _sheet(wb, name: str):
    for ws in wb.worksheets:
        if _key(ws.title) == name:
            return ws
    return None


def _table(ws) -> tuple[list[str], list[tuple[int, list[Any]]]]:
    it = ws.iter_rows(values_only=True)
    header = next(it, None)
    if header is None:
        return [], []
    cols = [_key(h) for h in header]
    rows = []
    for n, r in enumerate(it, start=2):
        if r is None or all(c is None or str(c).strip() == "" for c in r):
            continue                                   # blank line
        rows.append((n, list(r)))
    return cols, rows


def read_workbook(path: Path, *, tz: str = "UTC", default_scan_id: str | None = None) -> ParsedFile:
    zone = ZoneInfo(tz)
    try:
        wb = load_workbook(path, read_only=True, data_only=True)
    except Exception as e:                              # not a zip / corrupt / wrong format
        raise WorkbookError(f"cannot open workbook: {e}") from e
    try:
        return _parse(wb, path, zone, default_scan_id)
    finally:
        wb.close()                                      # read-only mode keeps the file open; on Windows it could not be moved afterwards


def _parse(wb, path: Path, zone: ZoneInfo, default_scan_id: str | None) -> ParsedFile:
    issues: list[Issue] = []

    # ---------------- Scan sheet (key/value)
    meta_raw: dict[str, Any] = {}
    ws = _sheet(wb, "scan")
    if ws is not None:
        for r in ws.iter_rows(values_only=True):
            if r and r[0] is not None and _key(r[0]) not in ("field", "key"):
                meta_raw[_key(r[0])] = r[1] if len(r) > 1 else None
    else:
        issues.append(Issue(level="warning", sheet="Scan", message="sheet 'Scan' not found; scan metadata derived from the file name"))
    try:
        scan = ScanMeta(scan_id=_s(meta_raw.get("scan_id")) or default_scan_id or f"SCAN-{path.stem}", scanner=_s(meta_raw.get("scanner")) or "unknown",
                        scanner_version=_s(meta_raw.get("scanner_version")), scan_type=_s(meta_raw.get("scan_type")),
                        started_at=_dt(meta_raw.get("started_at"), zone), finished_at=_dt(meta_raw.get("finished_at"), zone),
                        scope=_s(meta_raw.get("scope")), initiated_by=_s(meta_raw.get("initiated_by")), notes=_s(meta_raw.get("notes")))
    except (ValueError, ValidationError) as e:
        raise WorkbookError(f"invalid 'Scan' sheet: {e}") from e

    # ---------------- Assets sheet (optional)
    assets: dict[str, AssetRow] = {}
    ws = _sheet(wb, "assets")
    if ws is not None:
        cols, rows = _table(ws)
        for n, r in rows:
            rec = dict(zip(cols, r))
            try:
                a = AssetRow(name=_s(rec.get("name")) or "", asset_type=(_s(rec.get("asset_type")) or "SYSTEM").upper(),
                             environment=(_s(rec.get("environment")) or "unknown").lower(), os_name=_s(rec.get("os_name")),
                             os_version=_s(rec.get("os_version")), owner_team=_s(rec.get("owner_team")))
                if not a.name:
                    raise ValueError("name is required")
                assets[a.name] = a
            except (ValueError, ValidationError) as e:
                issues.append(Issue(level="error", sheet="Assets", row=n, message=_msg(e)))

    # ---------------- Vulnerabilities sheet (required)
    ws = _sheet(wb, "vulnerabilities")
    if ws is None:
        raise WorkbookError("required sheet 'Vulnerabilities' not found")
    cols, rows = _table(ws)
    missing = [c for c in ("cve_id", "title") if c not in cols]
    if missing or not ("cvss_score" in cols or "severity" in cols):
        raise WorkbookError(f"'Vulnerabilities' needs columns cve_id, title and cvss_score or severity (missing: {', '.join(missing) or 'cvss_score/severity'})")

    by_cve: dict[str, VulnRow] = {}
    for n, r in rows:
        rec = dict(zip(cols, r))
        try:
            cvss = _num(rec.get("cvss_score"))
            sev = (_s(rec.get("severity")) or "").upper() or severity_from_cvss(cvss)
            if sev is None:
                raise ValueError("either severity or cvss_score is required")
            derived = severity_from_cvss(cvss)
            if cvss is not None and derived != sev:
                issues.append(Issue(level="warning", sheet="Vulnerabilities", row=n, field="severity",
                                    message=f"severity {sev} does not match CVSS {cvss} ({derived}); keeping {sev}"))
            assets_raw = _s(rec.get("affected_assets")) or ""
            v = VulnRow(row=n, cve_id=_s(rec.get("cve_id")) or "", title=_s(rec.get("title")) or "", description=_s(rec.get("description")),
                        severity=sev, cvss_score=cvss, published_at=_dt(rec.get("published_date") or rec.get("published_at"), zone),
                        source=_s(rec.get("source")) or scan.scanner or "SCANNER", exploited_in_wild=_bool(rec.get("exploited_in_wild")),
                        affected_assets=[a.strip() for a in re.split(r"[;,\n]+", assets_raw) if a.strip()], recommendation=_s(rec.get("recommendation")),
                        plugin_id=_s(rec.get("plugin_id")), first_detected=_d(rec.get("first_detected"), zone), last_detected=_d(rec.get("last_detected"), zone))
        except (ValueError, ValidationError) as e:
            issues.append(Issue(level="error", sheet="Vulnerabilities", row=n, field=_field(e), message=_msg(e)))
            continue
        if v.cve_id in by_cve:                           # same CVE twice: merge assets, later non-empty values win
            old = by_cve[v.cve_id]
            merged = old.model_copy(update={**{k: val for k, val in v.model_dump(exclude={"row", "affected_assets"}).items() if val not in (None, "")},
                                            "affected_assets": list(dict.fromkeys(old.affected_assets + v.affected_assets)), "row": old.row})
            by_cve[v.cve_id] = merged
            issues.append(Issue(level="warning", sheet="Vulnerabilities", row=n, field="cve_id", message=f"{v.cve_id} already listed on row {old.row}; merged"))
        else:
            by_cve[v.cve_id] = v
    return ParsedFile(scan=scan, rows=list(by_cve.values()), assets=assets, issues=issues, total_rows=len(rows))


def _msg(e: Exception) -> str:
    if isinstance(e, ValidationError):
        return "; ".join(f"{'.'.join(str(x) for x in err['loc'])}: {err['msg']}" for err in e.errors())
    return str(e)


def _field(e: Exception) -> str | None:
    if isinstance(e, ValidationError) and e.errors():
        return str(e.errors()[0]["loc"][0]) if e.errors()[0]["loc"] else None
    return None

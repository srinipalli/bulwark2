"""Kafka message contracts (docs/kafka/*.schema.json). JSON, UTF-8. Incident events are keyed by incident id (per-incident ordering)."""
import json
import uuid
from datetime import datetime, timezone

from .schemas import ParsedFile, VulnRow

SCHEMA_VERSION = "1.0"
INCIDENT_CREATED = "incident.created"
INCIDENT_UPDATED = "incident.updated"
INCIDENT_UNCHANGED = "incident.unchanged"
SCAN_DONE = "scan.completed"
SYSTEM = "bulwark-scan-ingestor"


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _iso(d) -> str | None:
    return d.isoformat() if d else None


def _f(v) -> float | None:
    return None if v is None else float(v)


def event_id(incident_id: str, event_type: str, scan_id: str) -> str:
    """Deterministic: a retry re-sends the SAME id, consumers de-duplicate on it."""
    return str(uuid.uuid5(uuid.NAMESPACE_URL, f"bulwark/incident-event/{incident_id}/{event_type}/{scan_id}"))


def _scan(p: ParsedFile) -> dict:
    s = p.scan
    return {"scan_id": s.scan_id, "scanner": s.scanner, "scanner_version": s.scanner_version, "scan_type": s.scan_type,
            "started_at": _iso(s.started_at), "finished_at": _iso(s.finished_at), "scope": s.scope}


def event_type_for(action: str) -> str:
    return {"CREATED": INCIDENT_CREATED, "UPDATED": INCIDENT_UPDATED}.get(action, INCIDENT_UNCHANGED)


def incident_event(*, parsed: ParsedFile, row: VulnRow, actions: dict, vuln: dict, incident: dict, assets: list[dict], file: dict, job_run_id: str, produced_at: str) -> dict:
    inc_act, v_act = actions["incident"], actions["vulnerability"]
    et = event_type_for(inc_act["action"])
    known = {a["name"] for a in assets}
    return {
        "schema_version": SCHEMA_VERSION,
        "event_id": event_id(str(incident["id"]), et, parsed.scan.scan_id),
        "event_type": et,
        "occurred_at": _iso(incident["created_at"] if et == INCIDENT_CREATED else incident["updated_at"]),
        "produced_at": produced_at,
        "source": {"system": SYSTEM, "job_run_id": job_run_id, "file": file["name"], "file_sha256": file["sha256"], "row": row.row},
        "scan": _scan(parsed),
        "incident": {
            "id": str(incident["id"]), "incident_no": incident["incident_no"], "code": f"INC-{incident['incident_no']}", "title": incident["title"],
            "description": incident["description"], "severity": incident["severity"], "status": incident["status"],
            "assignee": {"id": str(incident["assignee_id"]), "full_name": incident["assignee_name"]} if incident["assignee_id"] else None,
            "created_by": {"id": str(incident["creator_id"]), "full_name": incident["creator_name"]} if incident["creator_id"] else None,
            "created_at": _iso(incident["created_at"]), "updated_at": _iso(incident["updated_at"]),
        },
        "vulnerability": {"id": str(vuln["id"]), "cve_id": vuln["cve_id"], "title": vuln["title"], "description": vuln["description"], "severity": vuln["severity"],
                          "cvss_score": _f(vuln["cvss_score"]), "published_at": _iso(vuln["published_at"]), "source": vuln["source"], "is_active": vuln["is_active"],
                          "db_action": v_act["action"]},
        "detection": {"exploited_in_wild": row.exploited_in_wild, "plugin_id": row.plugin_id, "first_detected": _iso(row.first_detected),
                      "last_detected": _iso(row.last_detected), "recommendation": row.recommendation},
        "impacted_assets": [{"id": str(a["id"]), "name": a["name"], "asset_type": a["asset_type"], "environment": a["environment"], "hostname": a["hostname"],
                             "os_name": a["os_name"], "os_version": a["os_version"], "owner_team": a["owner_team"], "status": a["incident_asset_status"]} for a in assets],
        "unresolved_assets": [n for n in row.affected_assets if n not in known and n not in inc_act.get("assets_added", [])],
        "change": {"action": inc_act["action"], "reopened": inc_act.get("reopened", False), "previous_incident": inc_act.get("previous_incident"),
                   "assets_added": inc_act.get("assets_added", []), "changed_fields": inc_act.get("changed", {})},
    }


def scan_message(*, parsed: ParsedFile, file: dict, totals: dict, severity: dict, job_run_id: str, produced_at: str, events_published: int) -> dict:
    rejected = len({i.row for i in parsed.errors if i.sheet == "Vulnerabilities"})
    return {
        "schema_version": SCHEMA_VERSION,
        "event_id": str(uuid.uuid5(uuid.NAMESPACE_URL, f"bulwark/scan/{parsed.scan.scan_id}/{file['sha256']}")),
        "event_type": SCAN_DONE,
        "occurred_at": _iso(parsed.scan.finished_at) or produced_at,
        "produced_at": produced_at,
        "source": {"system": SYSTEM, "job_run_id": job_run_id, "file": file["name"], "file_sha256": file["sha256"]},
        "scan": _scan(parsed),
        "file": {"name": file["name"], "sha256": file["sha256"], "size_bytes": file["size"]},
        "totals": {"rows_in_file": parsed.total_rows, "valid_rows": len(parsed.rows), "rejected_rows": rejected, "incident_events_published": events_published,
                   "vulnerabilities_created": totals["vulnerabilities_created"], "vulnerabilities_updated": totals["vulnerabilities_updated"],
                   "vulnerabilities_unchanged": totals["vulnerabilities_unchanged"], "incidents_created": totals["incidents_created"],
                   "incidents_updated": totals["incidents_updated"], "incidents_unchanged": totals["incidents_unchanged"], "incidents_locked": totals["incidents_locked"],
                   "incidents_skipped_inactive": totals["incidents_skipped_inactive"], "assets_created": totals["assets_created"], "warnings": len(parsed.warnings)},
        "severity_breakdown": severity,
    }


def to_bytes(msg: dict) -> bytes:
    return json.dumps(msg, ensure_ascii=False, separators=(",", ":"), default=str).encode("utf-8")

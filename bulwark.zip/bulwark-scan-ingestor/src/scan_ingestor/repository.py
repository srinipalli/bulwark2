"""All SQL for the ingestor (plain psycopg; no dependency on the Bulwark API code). Targets sql/schema.sql."""
import uuid
from typing import Any

from psycopg import Connection
from psycopg.types.json import Jsonb

FILE_ENTITY = "scan_file"
A_COMMITTED = "ingestion.file_db_committed"
A_PUBLISHED = "ingestion.file_published"
OPEN_EXCLUDED = ("RESOLVED", "CLOSED")          # statuses that do not count as an open incident
EDITABLE = ("OPEN", "REJECTED")                  # incident statuses where plan/assets may still change


class Repo:
    def __init__(self, conn: Connection):
        self.c = conn

    def one(self, sql: str, params: Any = None):
        return self.c.execute(sql, params).fetchone()

    def all(self, sql: str, params: Any = None):
        return self.c.execute(sql, params).fetchall()

    # ------------------------------------------------------------ users / audit
    def ensure_user(self, email: str, full_name: str, key: str) -> uuid.UUID:
        self.c.execute("INSERT INTO users (id, email, full_name, roles, is_active) VALUES (%s, %s, %s, %s, TRUE) ON CONFLICT DO NOTHING",
                       (uuid.uuid5(uuid.NAMESPACE_DNS, key), email, full_name, ["ANALYST"]))
        return self.one("SELECT id FROM users WHERE lower(email) = lower(%s)", (email,))["id"]

    def find_user(self, email: str):
        return self.one("SELECT id, full_name FROM users WHERE lower(email) = lower(%s) AND is_active", (email,))

    def audit(self, actor, action: str, etype: str, eid: Any, before: dict | None = None, after: dict | None = None) -> None:
        self.c.execute("INSERT INTO audit_logs (actor_id, action, entity_type, entity_id, before, after) VALUES (%s, %s, %s, %s, %s, %s)",
                       (actor, action, etype, str(eid), Jsonb(before) if before is not None else None, Jsonb(after) if after is not None else None))

    def file_state(self, sha: str) -> tuple[str, dict]:
        rows = self.all("SELECT action, after FROM audit_logs WHERE entity_type = %s AND entity_id = %s ORDER BY id", (FILE_ENTITY, sha))
        if any(r["action"] == A_PUBLISHED for r in rows):
            return "published", {}
        committed = [r for r in rows if r["action"] == A_COMMITTED]
        return ("committed", committed[-1]["after"] or {}) if committed else ("new", {})

    # ------------------------------------------------------------ assets
    def assets_by_name(self, names: list[str]) -> dict[str, dict]:
        return {r["name"]: r for r in self.all("SELECT * FROM assets WHERE name = ANY(%s)", (list(names),))}

    def create_asset(self, a, attrs: dict) -> dict:
        return self.one("INSERT INTO assets (name, asset_type, environment, os_name, os_version, owner_team, attributes) VALUES (%s,%s,%s,%s,%s,%s,%s) RETURNING *",
                        (a.name, a.asset_type, a.environment, a.os_name, a.os_version, a.owner_team, Jsonb(attrs)))

    # ------------------------------------------------------------ vulnerabilities
    def vulns_by_cve(self, cves: list[str]) -> dict[str, dict]:
        return {r["cve_id"]: r for r in self.all("SELECT * FROM vulnerabilities WHERE cve_id = ANY(%s)", (list(cves),))}

    def create_vuln(self, r, actor) -> dict:
        return self.one("INSERT INTO vulnerabilities (cve_id, title, description, severity, cvss_score, source, published_at, is_active, created_by) "
                        "VALUES (%s,%s,%s,%s,%s,%s,%s,TRUE,%s) RETURNING *",
                        (r.cve_id, r.title, r.description, r.severity, r.cvss_score, r.source, r.published_at, actor))

    def update_vuln(self, vid, **cols) -> None:
        sets = ", ".join(f"{k} = %s" for k in cols)
        self.c.execute(f"UPDATE vulnerabilities SET {sets}, updated_at = now() WHERE id = %s", (*cols.values(), vid))   # noqa: S608 - column names are code-controlled

    def link_vuln_assets(self, vid, asset_ids: list) -> list:
        added = []
        for aid in asset_ids:
            if self.one("INSERT INTO vulnerability_assets (vulnerability_id, asset_id) VALUES (%s,%s) ON CONFLICT DO NOTHING RETURNING asset_id", (vid, aid)):
                added.append(aid)
        return added

    # ------------------------------------------------------------ incidents
    def open_incidents(self, vuln_ids: list) -> dict:
        rows = self.all("SELECT id, incident_no, vulnerability_id, status, severity FROM incidents WHERE vulnerability_id = ANY(%s) AND status <> ALL(%s)",
                        (list(vuln_ids), list(OPEN_EXCLUDED)))
        return {r["vulnerability_id"]: r for r in rows}

    def last_finished_incident(self, vid):
        return self.one("SELECT incident_no, status FROM incidents WHERE vulnerability_id = %s AND status = ANY(%s) ORDER BY incident_no DESC LIMIT 1", (vid, list(OPEN_EXCLUDED)))

    def create_incident(self, vid, title, description, severity, assignee, actor) -> dict:
        return self.one("INSERT INTO incidents (vulnerability_id, title, description, severity, status, assignee_id, created_by) VALUES (%s,%s,%s,%s,'OPEN',%s,%s) "
                        "RETURNING id, incident_no, created_at", (vid, title, description, severity, assignee, actor))

    def add_incident_assets(self, iid, asset_ids: list) -> list:
        added = []
        for aid in asset_ids:
            if self.one("INSERT INTO incident_assets (incident_id, asset_id) VALUES (%s,%s) ON CONFLICT DO NOTHING RETURNING asset_id", (iid, aid)):
                added.append(aid)
        return added

    def incident_asset_ids(self, iid) -> set:
        return {r["asset_id"] for r in self.all("SELECT asset_id FROM incident_assets WHERE incident_id = %s", (iid,))}

    def set_incident_severity(self, iid, severity) -> None:
        self.c.execute("UPDATE incidents SET severity = %s, updated_at = now() WHERE id = %s", (severity, iid))

    def touch_incident(self, iid) -> None:
        self.c.execute("UPDATE incidents SET updated_at = now() WHERE id = %s", (iid,))

    def incident_details(self, ids: list) -> dict:
        rows = self.all("SELECT i.id, i.incident_no, i.title, i.description, i.severity, i.status, i.created_at, i.updated_at, "
                        "a.id AS assignee_id, a.full_name AS assignee_name, c.id AS creator_id, c.full_name AS creator_name "
                        "FROM incidents i LEFT JOIN users a ON a.id = i.assignee_id LEFT JOIN users c ON c.id = i.created_by WHERE i.id = ANY(%s)", (list(ids),))
        return {r["id"]: r for r in rows}

    def incident_asset_rows(self, ids: list) -> dict:
        out: dict = {}
        for r in self.all("SELECT ia.incident_id, ia.status AS incident_asset_status, a.* FROM incident_assets ia JOIN assets a ON a.id = ia.asset_id "
                          "WHERE ia.incident_id = ANY(%s) ORDER BY a.name", (list(ids),)):
            out.setdefault(r["incident_id"], []).append(r)
        return out

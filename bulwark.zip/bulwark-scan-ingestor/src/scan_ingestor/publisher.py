"""Message sinks: Kafka (confluent-kafka / librdkafka), a JSON-lines file for dry runs, and an in-memory one for tests."""
import json
import logging
from pathlib import Path
from typing import Protocol

from .config import Settings

log = logging.getLogger("scan_ingestor.kafka")


class PublisherError(Exception):
    pass


class Publisher(Protocol):
    failures: list[tuple[str, str]]

    def preflight(self) -> None: ...
    def publish(self, topic: str, key: str, value: bytes, headers: dict[str, str]) -> None: ...
    def flush(self, timeout: float = 60.0) -> int: ...      # returns messages NOT delivered
    @property
    def delivered(self) -> int: ...


class KafkaPublisher:
    def __init__(self, s: Settings):
        from confluent_kafka import Producer                  # imported lazily so the module works without the package for dry runs

        if not s.kafka_bootstrap_servers:
            raise PublisherError("KAFKA_BOOTSTRAP_SERVERS is not set")
        self.s = s
        cfg = {
            "bootstrap.servers": s.kafka_bootstrap_servers, "client.id": s.kafka_client_id, "security.protocol": s.kafka_security_protocol,
            "enable.idempotence": True, "acks": "all", "compression.type": "lz4", "linger.ms": 20,
            "delivery.timeout.ms": s.kafka_delivery_timeout_ms, "socket.timeout.ms": s.kafka_socket_timeout_ms,
            "error_cb": lambda e: log.error("kafka client error: %s", e),
        }
        if "SASL" in s.kafka_security_protocol:
            pw = s.kafka_sasl_password.get_secret_value()
            if not (s.kafka_sasl_username and pw):
                raise PublisherError("KAFKA_SASL_USERNAME / KAFKA_SASL_PASSWORD are not set")
            cfg.update({"sasl.mechanisms": s.kafka_sasl_mechanism, "sasl.username": s.kafka_sasl_username, "sasl.password": pw})
        if s.kafka_ssl_ca_file:
            if not Path(s.kafka_ssl_ca_file).is_file():
                raise PublisherError(f"KAFKA_SSL_CA_FILE not found: {s.kafka_ssl_ca_file}")
            cfg["ssl.ca.location"] = s.kafka_ssl_ca_file
        self._p = Producer(cfg)
        self.failures: list[tuple[str, str]] = []
        self._ok = 0

    @property
    def delivered(self) -> int:
        return self._ok

    def preflight(self) -> None:
        """Fail fast (clear message) on bad host / credentials / CA before touching the database."""
        from confluent_kafka import KafkaException
        from confluent_kafka.admin import AdminClient, NewTopic

        try:
            md = self._p.list_topics(timeout=15)
        except KafkaException as e:
            raise PublisherError(f"cannot reach Kafka at {self.s.kafka_bootstrap_servers}: {e.args[0] if e.args else e}") from e
        wanted = [self.s.kafka_topic_incidents, self.s.kafka_topic_scans]
        missing = [t for t in wanted if t not in md.topics]
        if missing and self.s.kafka_create_topics:
            adm = AdminClient({k: v for k, v in self._p_conf().items()})
            for t, f in adm.create_topics([NewTopic(t, self.s.kafka_topic_partitions, self.s.kafka_topic_replication) for t in missing]).items():
                try:
                    f.result()
                    log.info("created topic %s", t)
                except Exception as e:                       # noqa: BLE001
                    raise PublisherError(f"cannot create topic {t}: {e}") from e
        elif missing:
            raise PublisherError(f"topics do not exist: {', '.join(missing)} (create them in the Aiven console or set KAFKA_CREATE_TOPICS=true)")

    def _p_conf(self) -> dict:
        s = self.s
        c = {"bootstrap.servers": s.kafka_bootstrap_servers, "security.protocol": s.kafka_security_protocol}
        if "SASL" in s.kafka_security_protocol:
            c.update({"sasl.mechanisms": s.kafka_sasl_mechanism, "sasl.username": s.kafka_sasl_username, "sasl.password": s.kafka_sasl_password.get_secret_value()})
        if s.kafka_ssl_ca_file:
            c["ssl.ca.location"] = s.kafka_ssl_ca_file
        return c

    def _cb(self, err, msg):
        if err is not None:
            self.failures.append((msg.key().decode() if msg.key() else "", str(err)))
        else:
            self._ok += 1

    def publish(self, topic: str, key: str, value: bytes, headers: dict[str, str]) -> None:
        while True:
            try:
                self._p.produce(topic, key=key.encode(), value=value, headers=[(k, v.encode()) for k, v in headers.items()], on_delivery=self._cb)
                break
            except BufferError:                               # local queue full: let deliveries drain, then retry
                self._p.poll(0.5)
        self._p.poll(0)

    def flush(self, timeout: float = 60.0) -> int:
        left = self._p.flush(timeout)
        return left + len(self.failures)


class FilePublisher:
    """--kafka-dry-run: writes what would be sent to a JSON-lines file."""

    def __init__(self, path: str):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.failures: list[tuple[str, str]] = []
        self._n = 0
        self._fh = self.path.open("a", encoding="utf-8")

    @property
    def delivered(self) -> int:
        return self._n

    def preflight(self) -> None:
        pass

    def publish(self, topic, key, value, headers):
        self._fh.write(json.dumps({"topic": topic, "key": key, "headers": headers, "value": json.loads(value)}, ensure_ascii=False) + "\n")
        self._n += 1

    def flush(self, timeout: float = 0) -> int:
        self._fh.flush()
        return 0


class MemoryPublisher:
    def __init__(self, fail_after: int | None = None):
        self.sent: list[tuple[str, str, dict, dict]] = []
        self.failures: list[tuple[str, str]] = []
        self.fail_after = fail_after

    @property
    def delivered(self) -> int:
        return len(self.sent)

    def preflight(self) -> None:
        pass

    def publish(self, topic, key, value, headers):
        if self.fail_after is not None and len(self.sent) >= self.fail_after:
            self.failures.append((key, "simulated broker failure"))
            return
        self.sent.append((topic, key, json.loads(value), headers))

    def flush(self, timeout: float = 0) -> int:
        return len(self.failures)

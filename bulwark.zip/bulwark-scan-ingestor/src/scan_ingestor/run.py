"""Start the Bulwark scan ingestor without installing it.

    python src/scan_ingestor/run.py                    # process every new *.xlsx in INGEST_DIR, publish to Kafka
    python src/scan_ingestor/run.py --validate-only    # parse + validate only; no database, no Kafka
    python src/scan_ingestor/run.py --kafka-dry-run    # real database, Kafka events written to <INGEST_DIR>/reports/kafka_dry_run.jsonl
    python src/scan_ingestor/run.py --watch            # keep polling the folder (INGEST_WATCH_INTERVAL_SECONDS)
    python src/scan_ingestor/run.py --help             # all options

All settings are read from .env in the project folder. Relative paths (--dir, --file, INGEST_DIR, KAFKA_SSL_CA_FILE) are resolved from the
project folder, so the script can be started from anywhere. Dependencies: pip install -r requirements.txt
"""
import os
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent              # src/scan_ingestor
ROOT = HERE.parents[1]                              # project folder (holds .env)
os.chdir(ROOT)                                      # .env and relative paths resolve from the project folder
sys.path[:] = [p for p in sys.path if Path(p or ".").resolve() != HERE]   # run as a script: don't expose package modules as top-level ones
sys.path.insert(0, str(HERE.parent))                # src/, so the package imports as scan_ingestor

from scan_ingestor.cli import main  # noqa: E402 - needs the sys.path entry above

if __name__ == "__main__":
    sys.exit(main())

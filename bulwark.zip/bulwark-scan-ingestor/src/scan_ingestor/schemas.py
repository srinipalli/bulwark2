"""Typed view of the scan workbook (sheets: Scan, Vulnerabilities, Assets)."""
import re
from datetime import date, datetime
from decimal import Decimal
from typing import Literal

from pydantic import BaseModel, Field, field_validator

Severity = Literal["LOW", "MEDIUM", "HIGH", "CRITICAL"]
CVE_RE = re.compile(r"^CVE-\d{4}-\d{4,}$")


def severity_from_cvss(score: Decimal | float | None) -> str | None:
    if score is None:
        return None
    s = float(score)
    return "CRITICAL" if s >= 9 else "HIGH" if s >= 7 else "MEDIUM" if s >= 4 else "LOW"


class ScanMeta(BaseModel):
    scan_id: str
    scanner: str = "unknown"
    scanner_version: str | None = None
    scan_type: str | None = None
    started_at: datetime | None = None
    finished_at: datetime | None = None
    scope: str | None = None
    initiated_by: str | None = None
    notes: str | None = None


class VulnRow(BaseModel):
    row: int                                   # Excel row number, for error reports
    cve_id: str
    title: str = Field(min_length=3)
    description: str | None = None
    severity: Severity
    cvss_score: Decimal | None = Field(default=None, ge=0, le=10)
    published_at: datetime | None = None
    source: str = "SCANNER"
    exploited_in_wild: bool | None = None
    affected_assets: list[str] = []
    recommendation: str | None = None
    plugin_id: str | None = None
    first_detected: date | None = None
    last_detected: date | None = None

    @field_validator("cve_id")
    @classmethod
    def _cve(cls, v: str) -> str:
        v = v.strip().upper()
        if not CVE_RE.match(v):
            raise ValueError(f"'{v}' is not a valid CVE id (expected CVE-YYYY-NNNN)")
        return v


class AssetRow(BaseModel):
    name: str
    asset_type: Literal["SYSTEM", "APPLICATION"] = "SYSTEM"
    environment: str = "unknown"
    os_name: str | None = None
    os_version: str | None = None
    owner_team: str | None = None


class Issue(BaseModel):
    level: Literal["error", "warning"]
    sheet: str
    row: int | None = None
    field: str | None = None
    message: str


class ParsedFile(BaseModel):
    scan: ScanMeta
    rows: list[VulnRow]
    assets: dict[str, AssetRow]
    issues: list[Issue]
    total_rows: int                            # non-empty data rows seen in 'Vulnerabilities'

    @property
    def errors(self) -> list[Issue]:
        return [i for i in self.issues if i.level == "error"]

    @property
    def warnings(self) -> list[Issue]:
        return [i for i in self.issues if i.level == "warning"]

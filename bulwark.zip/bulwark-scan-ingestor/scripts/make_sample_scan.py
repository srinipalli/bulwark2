"""Generate a sample vulnerability-scan workbook for the ingestor.

    python scripts/make_sample_scan.py [output.xlsx]        # default: data/vulnerabilities/vuln_scan_2026-10-25.xlsx

Sheets:  Scan (one row of scan metadata) | Vulnerabilities (100 rows) | Assets (assets the scan found that may not exist yet)
The Assets sheet lists EVERY asset used, so the file works on an empty database.  CVE ids / titles are real public
vulnerabilities; scores, dates, 'exploited_in_wild' flags and the asset mapping are illustrative sample data.
"""
import random
import sys
from datetime import datetime, timedelta
from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

rnd = random.Random(1025)
OUT = Path(sys.argv[1] if len(sys.argv) > 1 else "data/vulnerabilities/vuln_scan_2026-10-25.xlsx")
SCAN_START, SCAN_END = datetime(2026, 10, 25, 1, 0), datetime(2026, 10, 25, 3, 42)


def seq(prefix, a, b):
    return [f"{prefix}-{i:02d}" for i in range(a, b + 1)]


# ---------------- asset classes (names exist in the demo DB unless listed in NEW_ASSETS)
CLASS = {
    "linux": seq("web-prod", 1, 6) + seq("app-prod", 1, 6) + seq("db-prod", 1, 4) + seq("app-uat", 1, 2) + seq("web-uat", 1, 2),
    "java_app": ["payments-api", "claims-service", "policy-engine", "ledger-service", "auth-gateway", "notification-svc", "reporting-svc", "document-service", "partner-api-gateway"],
    "node_app": ["customer-portal", "mobile-bff", "admin-console", "customer-portal-uat"],
    "py_app": ["risk-scoring-svc", "etl-pipeline"],
    "tomcat": seq("app-prod", 1, 6) + seq("app-uat", 1, 2),
    "httpd": ["web-prod-05", "web-prod-06"], "nginx": seq("web-prod", 1, 4),
    "win": seq("file-win", 1, 4) + seq("ad-dc", 1, 3) + seq("exch", 1, 2), "win_dc": seq("ad-dc", 1, 3), "exch": seq("exch", 1, 2),
    "wks": ["wks-corp-fleet-01", "wks-finance-fleet-01"],
    "vmware": ["vcenter-prod-01"] + seq("esxi-prod", 1, 3), "weblogic": seq("weblogic-prod", 1, 2), "redis": seq("redis-prod", 1, 2),
    "mysql": seq("mysql-prod", 1, 2), "postgres": seq("db-prod", 1, 4), "k8s": seq("k8s-prod-node", 1, 3),
    "container": seq("k8s-prod-node", 1, 3) + seq("build-dev", 1, 3), "samba": ["nas-lin-01"], "drupal": ["drupal-site-01"],
    "bigdata": seq("spark-prod", 1, 2) + ["solr-prod-01"], "build": seq("build-dev", 1, 3),
    "fortinet": seq("fw-fortigate", 1, 4), "f5": seq("lb-f5", 1, 3), "citrix": seq("citrix-adc", 1, 2), "pan": seq("pa-fw", 1, 2),
    "cisco_ios": seq("cisco-edge", 1, 2), "cisco_asa": seq("cisco-asa", 1, 2), "ivanti": ["ivanti-epmm-01"], "sophos": ["sophos-fw-01"],
    "veeam": ["veeam-bkp-01"], "papercut": ["papercut-01"], "screenconnect": ["screenconnect-01"], "manageengine": ["manageengine-01"],
    "jenkins": ["jenkins-prod-01", "jenkins-uat-01"], "moveit": ["moveit-prod-01", "moveit-dr-01"],
}
# name, type, env, os_name, os_version, owner_team
NEW_ASSETS = [
    ("vcenter-prod-01", "SYSTEM", "prod", "VMware vCenter Server Appliance", "7.0 U3", "Infrastructure"),
    *[(n, "SYSTEM", "prod", "VMware ESXi", "7.0 U3", "Infrastructure") for n in seq("esxi-prod", 1, 3)],
    *[(n, "SYSTEM", "prod", "Oracle Linux", "8.8 (WebLogic 12.2.1.4)", "Application Support") for n in seq("weblogic-prod", 1, 2)],
    *[(n, "SYSTEM", "prod", "Ubuntu", "20.04.6 LTS (Redis 6.0.16)", "Platform Engineering") for n in seq("redis-prod", 1, 2)],
    *[(n, "SYSTEM", "prod", "Red Hat Enterprise Linux", "8.9 (MySQL 5.7.40)", "Database Operations") for n in seq("mysql-prod", 1, 2)],
    *[(n, "SYSTEM", "prod", "Ubuntu", "22.04.4 LTS (Kubernetes 1.24.9)", "Platform Engineering") for n in seq("k8s-prod-node", 1, 3)],
    *[(n, "SYSTEM", "prod", "Cisco ASA", "9.14(2)", "Network Security") for n in seq("cisco-asa", 1, 2)],
    ("ivanti-epmm-01", "SYSTEM", "prod", "Appliance", "Ivanti EPMM 11.10", "End User Computing"),
    ("sophos-fw-01", "SYSTEM", "prod", "Sophos Firewall OS", "SFOS 18.5", "Network Security"),
    ("veeam-bkp-01", "SYSTEM", "prod", "Windows Server", "2019 Standard (Veeam B&R 11)", "Infrastructure"),
    ("papercut-01", "SYSTEM", "prod", "Windows Server", "2019 Standard (PaperCut NG 22.0)", "End User Computing"),
    ("screenconnect-01", "SYSTEM", "prod", "Windows Server", "2019 Standard (ScreenConnect 23.9)", "IT Service Desk"),
    ("manageengine-01", "SYSTEM", "prod", "Windows Server", "2016 Standard (ServiceDesk Plus)", "IT Service Desk"),
    ("nas-lin-01", "SYSTEM", "prod", "Ubuntu", "18.04.6 LTS (Samba 4.7)", "Infrastructure"),
    *[(n, "SYSTEM", "prod", "Ubuntu", "22.04.4 LTS (Spark 3.2.1)", "Data & Analytics") for n in seq("spark-prod", 1, 2)],
    ("solr-prod-01", "SYSTEM", "prod", "Ubuntu", "20.04.6 LTS (Solr 8.2)", "Data & Analytics"),
    ("risk-scoring-svc", "APPLICATION", "prod", None, None, "Risk Analytics"),
    ("etl-pipeline", "APPLICATION", "prod", None, None, "Data & Analytics"),
    ("wks-corp-fleet-01", "SYSTEM", "prod", "Windows 10 Enterprise", "22H2 (managed fleet)", "End User Computing"),
    ("wks-finance-fleet-01", "SYSTEM", "prod", "Windows 11 Enterprise", "23H2 (managed fleet)", "End User Computing"),
    ("drupal-site-01", "APPLICATION", "prod", None, None, "Digital Channels"),
]
FIX = {  # recommendation text per class
    "linux": "Apply the vendor security update (apt/dnf) and reboot if a kernel or glibc package changed.",
    "java_app": "Upgrade the affected library to the fixed version and redeploy the service.", "node_app": "Update the dependency in package-lock.json and rebuild the image.",
    "py_app": "Bump the dependency in requirements.txt and rebuild the image.", "tomcat": "Upgrade Apache Tomcat to the fixed release and restart.",
    "httpd": "Upgrade Apache HTTP Server to the fixed release.", "nginx": "Upgrade nginx or apply the vendor mitigation.",
    "win": "Install the Microsoft security update via WSUS and reboot.", "win_dc": "Install the Microsoft security update on all domain controllers (rolling).",
    "exch": "Install the latest Exchange Server Security Update.", "wks": "Update via Intune/WSUS; verify with the endpoint compliance report.",
    "vmware": "Apply the VMware Security Advisory patch.", "weblogic": "Apply the Oracle Critical Patch Update.", "redis": "Upgrade Redis to the fixed version.",
    "mysql": "Upgrade MySQL to the fixed release.", "postgres": "Upgrade PostgreSQL to the latest minor release.", "k8s": "Upgrade Kubernetes to a fixed patch release.",
    "container": "Upgrade the container runtime to the fixed version.", "samba": "Upgrade Samba to the fixed release.", "drupal": "Upgrade Drupal core to the fixed release.",
    "bigdata": "Upgrade the platform to the fixed version and restrict network access.", "build": "Downgrade or upgrade the package per vendor guidance.",
    "fortinet": "Upgrade FortiOS to the fixed firmware.", "f5": "Upgrade BIG-IP to a fixed release and restrict management access.", "citrix": "Upgrade NetScaler ADC/Gateway to the fixed build.",
    "pan": "Apply the PAN-OS hotfix.", "cisco_ios": "Upgrade IOS XE and disable the HTTP server.", "cisco_asa": "Upgrade Cisco ASA software to a fixed release.",
    "ivanti": "Apply the Ivanti security patch.", "sophos": "Apply the Sophos hotfix.", "veeam": "Install the Veeam cumulative patch.", "papercut": "Upgrade PaperCut NG to the fixed version.",
    "screenconnect": "Upgrade ScreenConnect to the fixed version.", "manageengine": "Apply the ManageEngine security build.", "jenkins": "Upgrade Jenkins to the fixed LTS.", "moveit": "Apply the MOVEit Transfer patch.",
}
# (cve, title, cvss, published, description, class)
RAW = [
 # ---- already in the demo DB (22): a re-scan -> scores refreshed, assets added
 ("CVE-2021-44228", "Apache Log4j2 JNDI remote code execution (Log4Shell)", 10.0, "2021-12-10", "JNDI lookup in log messages allows remote code execution.", "java_app"),
 ("CVE-2021-45046", "Apache Log4j2 incomplete fix for Log4Shell in non-default configurations", 10.0, "2021-12-14", "Rescored by NVD to critical; RCE possible in some non-default configurations.", "java_app"),
 ("CVE-2022-22965", "Spring Framework RCE via data binding on JDK 9+ (Spring4Shell)", 9.8, "2022-04-01", "Data binding RCE on JDK 9+ when deployed as WAR on Tomcat.", "java_app"),
 ("CVE-2022-42889", "Apache Commons Text variable interpolation RCE (Text4Shell)", 9.8, "2022-10-13", "Interpolation of script/dns/url lookups with untrusted input.", "java_app"),
 ("CVE-2017-5638", "Apache Struts 2 Jakarta Multipart parser RCE", 10.0, "2017-03-11", "OGNL evaluation of Content-Type header.", "tomcat"),
 ("CVE-2024-6387", "OpenSSH sshd signal handler race condition (regreSSHion)", 8.1, "2024-07-01", "Unauthenticated RCE as root on glibc-based Linux.", "linux"),
 ("CVE-2021-3156", "sudo heap-based buffer overflow (Baron Samedit)", 7.8, "2021-01-26", "Local privilege escalation via sudoedit -s.", "linux"),
 ("CVE-2022-0847", "Linux kernel pipe buffer flag overwrite (Dirty Pipe)", 7.8, "2022-03-10", "Overwrite data in read-only files; local privilege escalation.", "linux"),
 ("CVE-2023-38545", "curl SOCKS5 proxy handshake heap buffer overflow", 9.8, "2023-10-18", "Heap overflow with a slow SOCKS5 handshake and long hostname.", "linux"),
 ("CVE-2024-3094", "XZ Utils liblzma supply-chain backdoor", 10.0, "2024-03-29", "Backdoored xz 5.6.0/5.6.1 release tarballs.", "build"),
 ("CVE-2023-44487", "HTTP/2 Rapid Reset denial of service", 7.5, "2023-10-10", "Stream cancellation abuse exhausts server resources.", "nginx"),
 ("CVE-2021-41773", "Apache HTTP Server 2.4.49 path traversal and file disclosure", 7.5, "2021-10-05", "Path normalisation flaw in httpd 2.4.49.", "httpd"),
 ("CVE-2017-0144", "Microsoft SMBv1 remote code execution (EternalBlue)", 8.1, "2017-03-16", "SMBv1 RCE exploited by WannaCry and NotPetya.", "win"),
 ("CVE-2020-1472", "Netlogon elevation of privilege (Zerologon)", 10.0, "2020-08-17", "Netlogon crypto flaw allows domain takeover.", "win_dc"),
 ("CVE-2021-34527", "Windows Print Spooler remote code execution (PrintNightmare)", 8.8, "2021-07-02", "Spooler privileged file operations; RCE as SYSTEM.", "win"),
 ("CVE-2021-26855", "Microsoft Exchange Server SSRF (ProxyLogon)", 9.8, "2021-03-02", "Pre-auth SSRF in Exchange, chained into RCE.", "exch"),
 ("CVE-2024-3400", "Palo Alto PAN-OS GlobalProtect command injection", 10.0, "2024-04-12", "Unauthenticated command injection in GlobalProtect.", "pan"),
 ("CVE-2023-20198", "Cisco IOS XE web UI privilege escalation", 10.0, "2023-10-16", "Unauthenticated creation of privilege-15 accounts.", "cisco_ios"),
 ("CVE-2024-23897", "Jenkins CLI arbitrary file read", 9.8, "2024-01-24", "args4j expands @file arguments, leaking file contents.", "jenkins"),
 ("CVE-2023-34362", "Progress MOVEit Transfer SQL injection", 9.8, "2023-06-02", "Unauthenticated SQLi leading to RCE.", "moveit"),
 ("CVE-2022-1388", "F5 BIG-IP iControl REST authentication bypass", 9.8, "2022-05-05", "Auth bypass to root command execution.", "f5"),
 ("CVE-2023-3519", "Citrix ADC and Gateway unauthenticated remote code execution", 9.8, "2023-07-19", "Unauthenticated RCE on gateway/AAA virtual servers.", "citrix"),
 # ---- new to the DB
 ("CVE-2021-21972", "VMware vCenter Server vSphere Client remote code execution", 9.8, "2021-02-24", "Unauthenticated file upload in the vROps plugin.", "vmware"),
 ("CVE-2021-21985", "VMware vCenter Server Virtual SAN Health Check plugin RCE", 9.8, "2021-05-26", "Missing input validation in the vSAN plugin.", "vmware"),
 ("CVE-2021-22005", "VMware vCenter Server analytics service arbitrary file upload", 9.8, "2021-09-23", "File upload leading to code execution.", "vmware"),
 ("CVE-2023-34048", "VMware vCenter Server DCERPC out-of-bounds write", 9.8, "2023-10-25", "Network-reachable out-of-bounds write.", "vmware"),
 ("CVE-2021-21974", "VMware ESXi OpenSLP heap-overflow", 8.8, "2021-02-24", "Heap overflow in OpenSLP; exploited by ESXiArgs ransomware.", "vmware"),
 ("CVE-2019-2725", "Oracle WebLogic Server deserialization remote code execution", 9.8, "2019-04-26", "Unauthenticated deserialization via _async component.", "weblogic"),
 ("CVE-2020-14882", "Oracle WebLogic Server console remote code execution", 9.8, "2020-10-21", "Unauthenticated RCE through the Console component.", "weblogic"),
 ("CVE-2023-21839", "Oracle WebLogic Server T3/IIOP unauthenticated access", 7.5, "2023-01-17", "Unauthenticated JNDI lookup via T3/IIOP.", "weblogic"),
 ("CVE-2022-0543", "Redis Lua sandbox escape (Debian/Ubuntu packages)", 10.0, "2022-02-18", "Lua library loaded by packaging allows sandbox escape.", "redis"),
 ("CVE-2021-32761", "Redis integer overflow on BITFIELD command", 7.5, "2021-07-21", "Integer overflow on 32-bit builds leading to heap corruption.", "redis"),
 ("CVE-2016-6662", "MySQL configuration file remote code execution", 9.8, "2016-09-20", "Malicious my.cnf lets an attacker load code as root.", "mysql"),
 ("CVE-2023-39417", "PostgreSQL extension script SQL injection", 8.8, "2023-08-11", "@extschema@ substitution in extension scripts allows SQLi.", "postgres"),
 ("CVE-2022-2625", "PostgreSQL extension scripts replace objects not belonging to the extension", 8.0, "2022-08-18", "Extension script may replace objects owned by others.", "postgres"),
 ("CVE-2019-5736", "runc container breakout through /proc/self/exe overwrite", 8.6, "2019-02-11", "Malicious container can overwrite the host runc binary.", "container"),
 ("CVE-2024-21626", "runc working directory file descriptor leak container escape", 8.6, "2024-01-31", "Leaked fd allows access to the host filesystem.", "container"),
 ("CVE-2018-1002105", "Kubernetes API server proxy request privilege escalation", 9.8, "2018-12-05", "Upgrade request handling lets users escalate via the aggregated API.", "k8s"),
 ("CVE-2020-8558", "Kubernetes kube-proxy exposes localhost services to the network", 8.8, "2020-07-27", "Adjacent hosts can reach services bound to 127.0.0.1.", "k8s"),
 ("CVE-2021-25741", "Kubernetes symlink exchange allows access to host filesystem", 8.1, "2021-09-20", "subPath volume symlink exchange escapes the container.", "k8s"),
 ("CVE-2022-23648", "containerd CRI plugin image volume arbitrary host file read", 7.5, "2022-03-03", "Specially crafted image config exposes host files.", "container"),
 ("CVE-2021-22555", "Linux netfilter heap out-of-bounds write", 8.3, "2021-07-07", "x_tables heap OOB write enabling local privilege escalation.", "linux"),
 ("CVE-2022-0185", "Linux kernel fsconfig heap overflow", 8.4, "2022-02-11", "Heap-based buffer overflow in legacy_parse_param.", "linux"),
 ("CVE-2023-0386", "Linux kernel OverlayFS privilege escalation", 7.8, "2023-03-22", "Improper ownership handling in OverlayFS copy-up.", "linux"),
 ("CVE-2023-32233", "Linux kernel nf_tables use-after-free", 7.8, "2023-05-08", "Anonymous sets handling leads to local privilege escalation.", "linux"),
 ("CVE-2021-33909", "Linux kernel filesystem layer size_t-to-int conversion (Sequoia)", 7.8, "2021-07-20", "Local privilege escalation by creating deep directory structures.", "linux"),
 ("CVE-2023-3269", "Linux kernel memory management stack rot", 7.8, "2023-07-05", "Maple tree VMA handling race leading to privilege escalation.", "linux"),
 ("CVE-2019-14287", "sudo Runas user ID -1 policy bypass", 8.8, "2019-10-17", "sudo -u#-1 runs commands as root despite !root rules.", "linux"),
 ("CVE-2023-22809", "sudoedit arbitrary file write via EDITOR extra arguments", 7.8, "2023-01-18", "Environment editor with '--' allows editing arbitrary files.", "linux"),
 ("CVE-2020-15778", "OpenSSH scp command injection via backtick in filename", 7.8, "2020-07-24", "Commands in the remote path are executed by the remote shell.", "linux"),
 ("CVE-2023-51385", "OpenSSH shell metacharacter injection in user/host names", 6.5, "2023-12-18", "Command injection through ProxyCommand with untrusted names.", "linux"),
 ("CVE-2017-7494", "Samba remote code execution from a writable share (SambaCry)", 9.8, "2017-05-30", "Malicious shared library upload loaded by smbd.", "samba"),
 ("CVE-2020-0796", "Microsoft SMBv3 compression remote code execution (SMBGhost)", 10.0, "2020-03-12", "Buffer overflow in SMBv3.1.1 compression handling.", "win"),
 ("CVE-2020-1350", "Windows DNS Server remote code execution (SIGRed)", 10.0, "2020-07-14", "Wormable RCE in the DNS Server role.", "win_dc"),
 ("CVE-2021-40444", "Microsoft MSHTML remote code execution", 8.8, "2021-09-15", "Malicious Office documents load ActiveX controls via MSHTML.", "wks"),
 ("CVE-2022-26923", "Active Directory Certificate Services elevation of privilege (Certifried)", 8.8, "2022-05-10", "Machine account dNSHostName spoofing yields domain admin certificates.", "win_dc"),
 ("CVE-2022-37958", "Windows SPNEGO Extended Negotiation remote code execution", 9.8, "2022-09-13", "Pre-authentication RCE in NEGOEX.", "win"),
 ("CVE-2024-38063", "Windows TCP/IP IPv6 remote code execution", 9.8, "2024-08-13", "Zero-click RCE via specially crafted IPv6 packets.", "win"),
 ("CVE-2023-36025", "Windows SmartScreen security feature bypass", 8.8, "2023-11-14", "Crafted .url files bypass SmartScreen prompts.", "wks"),
 ("CVE-2023-28252", "Windows Common Log File System driver elevation of privilege", 7.8, "2023-04-11", "CLFS driver flaw leading to SYSTEM; used in ransomware attacks.", "win"),
 ("CVE-2020-0688", "Microsoft Exchange validation key remote code execution", 8.8, "2020-02-11", "Static ViewState validation key allows authenticated RCE.", "exch"),
 ("CVE-2022-41040", "Microsoft Exchange Server SSRF (ProxyNotShell)", 8.8, "2022-10-03", "Authenticated SSRF chained with CVE-2022-41082.", "exch"),
 ("CVE-2023-2033", "Google Chrome V8 type confusion", 8.8, "2023-04-14", "Type confusion in V8 exploited in the wild.", "wks"),
 ("CVE-2022-0609", "Google Chrome animation use-after-free", 8.8, "2022-02-14", "Use-after-free in Animation; exploited in the wild.", "wks"),
 ("CVE-2024-4671", "Google Chrome Visuals use-after-free", 9.6, "2024-05-13", "Use-after-free in Visuals; exploited in the wild.", "wks"),
 ("CVE-2022-1292", "OpenSSL c_rehash script command injection", 9.8, "2022-05-03", "Shell metacharacters in file names executed by c_rehash.", "linux"),
 ("CVE-2022-2068", "OpenSSL c_rehash script command injection (incomplete fix)", 9.8, "2022-06-21", "Remaining shell metacharacter injection in c_rehash.", "linux"),
 ("CVE-2024-5535", "OpenSSL SSL_select_next_proto buffer over-read", 9.1, "2024-06-27", "Empty protocol list leads to over-read of application memory.", "linux"),
 ("CVE-2018-7600", "Drupal core remote code execution (Drupalgeddon2)", 9.8, "2018-04-25", "Unauthenticated RCE via Form API render arrays.", "drupal"),
 ("CVE-2019-6340", "Drupal core REST module remote code execution", 8.1, "2019-02-21", "Insecure deserialization when REST/JSON:API is enabled.", "drupal"),
 ("CVE-2019-0211", "Apache HTTP Server local privilege escalation (scoreboard)", 7.8, "2019-04-08", "Child process can gain root via the scoreboard.", "httpd"),
 ("CVE-2022-31813", "Apache HTTP Server mod_proxy X-Forwarded-For hop-by-hop bypass", 9.8, "2022-06-09", "Hop-by-hop header handling drops X-Forwarded-* headers.", "httpd"),
 ("CVE-2023-25690", "Apache HTTP Server mod_proxy HTTP request smuggling", 9.8, "2023-03-07", "RewriteRule/ProxyPassMatch with variables enables smuggling.", "httpd"),
 ("CVE-2020-1938", "Apache Tomcat AJP file read/inclusion (Ghostcat)", 9.8, "2020-02-24", "AJP connector allows reading or including webapp files.", "tomcat"),
 ("CVE-2024-50379", "Apache Tomcat TOCTOU race condition on case-insensitive file systems", 9.8, "2024-12-17", "JSP compilation race can lead to RCE.", "tomcat"),
 ("CVE-2025-24813", "Apache Tomcat partial PUT remote code execution", 9.8, "2025-03-10", "Partial PUT and default servlet write enabled lead to RCE.", "tomcat"),
 ("CVE-2022-1471", "SnakeYAML unsafe deserialization via Constructor", 9.8, "2022-12-01", "Default Constructor allows arbitrary class instantiation.", "java_app"),
 ("CVE-2022-25845", "Alibaba fastjson autoType bypass remote code execution", 9.8, "2022-06-10", "Deserialization of untrusted JSON leads to RCE.", "java_app"),
 ("CVE-2019-17558", "Apache Solr VelocityResponseWriter remote code execution", 9.8, "2019-10-30", "Velocity template injection via params.resource.loader.enabled.", "bigdata"),
 ("CVE-2021-25646", "Apache Druid remote code execution through JavaScript", 8.8, "2021-01-29", "Authenticated users can execute arbitrary code on the server.", "bigdata"),
 ("CVE-2019-10744", "lodash prototype pollution via defaultsDeep", 9.1, "2019-07-26", "defaultsDeep allows modification of Object.prototype.", "node_app"),
 ("CVE-2021-23337", "lodash command injection via template", 7.2, "2021-02-15", "Template function can execute arbitrary code.", "node_app"),
 ("CVE-2022-46175", "json5 prototype pollution via parse", 7.1, "2022-12-24", "JSON5.parse can set __proto__ keys on the result.", "node_app"),
 ("CVE-2022-23529", "jsonwebtoken insecure key retrieval", 7.6, "2022-12-21", "Malicious secretOrPublicKey object can lead to code execution.", "node_app"),
 ("CVE-2023-37920", "Python certifi removal of e-Tugra root certificates", 9.8, "2023-07-25", "Certifi before 2023.07.22 trusts removed e-Tugra roots.", "py_app"),
 ("CVE-2023-43804", "urllib3 Cookie header leaked on cross-origin redirects", 8.1, "2023-10-04", "Cookie request header not stripped on redirect.", "py_app"),
 ("CVE-2020-14343", "PyYAML arbitrary code execution through full_load", 9.8, "2020-07-21", "full_load processes untrusted YAML unsafely.", "py_app"),
 ("CVE-2019-10906", "Jinja2 sandbox escape via str.format", 8.6, "2019-04-10", "str.format_map bypasses the sandbox restrictions.", "py_app"),
 ("CVE-2020-3452", "Cisco ASA and FTD web services read-only path traversal", 7.5, "2020-07-22", "Unauthenticated file read on the web services interface.", "cisco_asa"),
 ("CVE-2018-0101", "Cisco ASA WebVPN double free remote code execution", 10.0, "2018-01-29", "Unauthenticated RCE or reload via crafted XML.", "cisco_asa"),
 ("CVE-2020-5902", "F5 BIG-IP Traffic Management User Interface remote code execution", 9.8, "2020-07-01", "TMUI directory traversal leading to RCE.", "f5"),
 ("CVE-2021-22986", "F5 BIG-IP iControl REST unauthenticated remote command execution", 9.8, "2021-03-31", "SSRF to unauthenticated RCE in iControl REST.", "f5"),
 ("CVE-2022-42475", "Fortinet FortiOS sslvpnd heap-based buffer overflow", 9.8, "2022-12-13", "Pre-auth heap overflow in SSL-VPN; exploited in the wild.", "fortinet"),
 ("CVE-2024-47575", "Fortinet FortiManager missing authentication for critical function", 9.8, "2024-10-23", "fgfmd allows remote unauthenticated command execution.", "fortinet"),
 ("CVE-2020-2021", "Palo Alto PAN-OS SAML authentication bypass", 10.0, "2020-06-29", "Signature verification flaw allows authentication bypass.", "pan"),
 ("CVE-2023-4966", "Citrix NetScaler ADC and Gateway sensitive information disclosure (Citrix Bleed)", 9.4, "2023-10-10", "Buffer over-read leaks session tokens enabling session hijack.", "citrix"),
 ("CVE-2023-35078", "Ivanti Endpoint Manager Mobile authentication bypass", 10.0, "2023-07-25", "Unauthenticated access to API paths exposes PII and allows changes.", "ivanti"),
 ("CVE-2024-1709", "ConnectWise ScreenConnect authentication bypass", 10.0, "2024-02-21", "Alternate path bypass of the setup wizard allows admin creation.", "screenconnect"),
 ("CVE-2023-27350", "PaperCut NG/MF authentication bypass and remote code execution", 9.8, "2023-04-20", "SetupCompleted bypass enables RCE via scripting.", "papercut"),
 ("CVE-2022-26500", "Veeam Backup & Replication unauthenticated remote code execution", 9.8, "2022-03-17", "Improper validation in Veeam Distribution Service.", "veeam"),
 ("CVE-2022-47966", "Zoho ManageEngine pre-auth remote code execution via Apache Santuario", 9.8, "2023-01-18", "Outdated third-party dependency enables unauthenticated RCE.", "manageengine"),
 ("CVE-2022-1040", "Sophos Firewall user portal and Webadmin authentication bypass", 9.8, "2022-03-25", "Auth bypass in the User Portal and Webadmin leading to RCE.", "sophos"),
]
# class of the 22 that exist in DB
EXISTING = {r[0] for r in RAW[:22]}
assert len(RAW) >= 100, len(RAW)
RAW = RAW[:100]
EXPLOITED = {"CVE-2021-44228", "CVE-2022-22965", "CVE-2017-5638", "CVE-2017-0144", "CVE-2020-1472", "CVE-2021-34527", "CVE-2021-26855", "CVE-2024-3400", "CVE-2023-20198",
             "CVE-2023-34362", "CVE-2022-1388", "CVE-2023-3519", "CVE-2021-21972", "CVE-2021-22005", "CVE-2019-2725", "CVE-2020-14882", "CVE-2021-21974", "CVE-2020-5902", "CVE-2021-22986",
             "CVE-2022-42475", "CVE-2023-4966", "CVE-2023-35078", "CVE-2024-1709", "CVE-2023-27350", "CVE-2022-47966", "CVE-2020-0688", "CVE-2022-41040", "CVE-2020-2021",
             "CVE-2018-7600", "CVE-2023-28252", "CVE-2020-3452", "CVE-2018-0101", "CVE-2023-2033", "CVE-2022-0609", "CVE-2024-4671", "CVE-2024-47575", "CVE-2019-5736", "CVE-2022-26500"}


def sev(c):
    return "CRITICAL" if c >= 9 else "HIGH" if c >= 7 else "MEDIUM" if c >= 4 else "LOW"


rows, used_assets = [], set()
for i, (cve, title, cvss, pub, desc, cls) in enumerate(RAW):
    pool = CLASS[cls]
    k = min(len(pool), 1 + (i * 7) % 4)
    start = (i * 5) % len(pool)
    names = [pool[(start + j) % len(pool)] for j in range(k)]
    used_assets.update(names)
    pub_d = datetime.strptime(pub, "%Y-%m-%d")
    first = max(pub_d + timedelta(days=rnd.randint(3, 400)), datetime(2024, 1, 1)) if pub_d < SCAN_START - timedelta(days=30) else SCAN_START - timedelta(days=2)
    first = min(first, SCAN_START - timedelta(days=1))
    rows.append([cve, title, desc, sev(cvss), cvss, pub_d.date(), "Qualys VMDR", "Y" if cve in EXPLOITED else "N", "; ".join(names), FIX[cls],
                 f"{91000 + (i * 37) % 9000}", first.date(), SCAN_START.date()])

wb = Workbook()
hdr_fill, hdr_font = PatternFill("solid", fgColor="0072CE"), Font(bold=True, color="FFFFFF")


def sheet(ws, headers, data, widths):
    ws.append(headers)
    for r in data:
        ws.append(r)
    for c in ws[1]:
        c.fill, c.font, c.alignment = hdr_fill, hdr_font, Alignment(vertical="center")
    for i, w in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(i)].width = w
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions


ws = wb.active
ws.title = "Scan"
sheet(ws, ["field", "value"], [
    ["scan_id", "SCAN-20261025-001"], ["scanner", "Qualys VMDR"], ["scanner_version", "10.28"], ["scan_type", "Authenticated network + agent scan"],
    ["started_at", SCAN_START], ["finished_at", SCAN_END], ["scope", "Prod, UAT and DR networks (10.20.0.0/16, 10.21.0.0/16)"],
    ["initiated_by", "scan-scheduler"], ["notes", "Weekly full scan. Sample data - illustrative."]], [20, 70])
sheet(wb.create_sheet("Vulnerabilities"),
      ["cve_id", "title", "description", "severity", "cvss_score", "published_date", "source", "exploited_in_wild", "affected_assets", "recommendation",
       "plugin_id", "first_detected", "last_detected"], rows, [18, 62, 60, 11, 11, 14, 14, 17, 40, 60, 11, 14, 14])
PREFIX_META = [  # name prefix -> (type, os_name, os_version, owner_team)
    ("web-", "SYSTEM", "Ubuntu", "22.04.4 LTS", "Platform Engineering"), ("app-", "SYSTEM", "Red Hat Enterprise Linux", "8.9", "Application Support"),
    ("db-", "SYSTEM", "Red Hat Enterprise Linux", "9.3", "Database Operations"), ("build-dev", "SYSTEM", "Fedora Linux", "40", "DevOps"),
    ("ad-dc", "SYSTEM", "Windows Server", "2019 Datacenter", "Identity & Access"), ("exch-", "SYSTEM", "Windows Server", "2016 Standard", "Messaging"),
    ("file-win", "SYSTEM", "Windows Server", "2019 Standard", "End User Computing"), ("fw-fortigate", "SYSTEM", "FortiOS", "7.0.12", "Network Security"),
    ("lb-f5", "SYSTEM", "BIG-IP TMOS", "15.1.8", "Network Engineering"), ("citrix-adc", "SYSTEM", "NetScaler ADC", "13.0-91.13", "Network Engineering"),
    ("pa-fw", "SYSTEM", "PAN-OS", "10.2.7", "Network Security"), ("cisco-edge", "SYSTEM", "Cisco IOS XE", "17.6.4", "Network Engineering"),
    ("jenkins-", "SYSTEM", "Ubuntu", "20.04.6 LTS", "DevOps"), ("moveit-", "SYSTEM", "Windows Server", "2019 Standard (MOVEit Transfer 2022.1.5)", "Integration"),
]
APP_TEAM = {"payments-api": "Payments", "claims-service": "Claims", "policy-engine": "Underwriting", "ledger-service": "Finance Systems", "auth-gateway": "Identity & Access",
            "notification-svc": "Platform Engineering", "reporting-svc": "Data & Analytics", "document-service": "Claims", "partner-api-gateway": "Integration",
            "customer-portal": "Digital Channels", "mobile-bff": "Digital Channels", "admin-console": "Digital Channels"}
NEW = {a[0]: a for a in NEW_ASSETS}


def env_of(name):
    return "uat" if ("-uat" in name or name.endswith("-uat")) else "dev" if "-dev" in name else "dr" if (name.endswith("-dr-01") or "-dr-" in name) else "prod"


def asset_row(name):
    if name in NEW:
        a = NEW[name]
        return [a[0], a[1], a[2], a[3], a[4], a[5]]
    for pre, typ, osn, osv, team in PREFIX_META:
        if name.startswith(pre):
            return [name, typ, env_of(name), osn, osv, team]
    base = name[:-4] if name.endswith("-uat") else name
    if base in APP_TEAM:
        return [name, "APPLICATION", env_of(name), None, None, APP_TEAM[base]]
    raise SystemExit(f"no metadata for asset {name}")


new_assets = [asset_row(n) for n in sorted(used_assets)]
sheet(wb.create_sheet("Assets"), ["name", "asset_type", "environment", "os_name", "os_version", "owner_team"], new_assets, [26, 14, 14, 30, 36, 24])
OUT.parent.mkdir(parents=True, exist_ok=True)
wb.save(OUT)
print(f"wrote {OUT}: {len(rows)} vulnerabilities, {len(new_assets)} assets, "
      f"{sum(len(r[8].split('; ')) for r in rows)} vulnerability-asset links")

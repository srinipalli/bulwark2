# Bulwark Scan Ingestor

Standalone job. Reads vulnerability-scan workbooks (`*.xlsx`) from a folder, then:

1. **upserts `vulnerabilities`** (plus missing `assets` and `vulnerability_assets` links),
2. **creates one incident per vulnerability** (`incidents` + `incident_assets`),
3. **publishes the incidents to Kafka** (topic `bulwark.incidents`) – vulnerabilities are *not* sent to Kafka –
   followed by one `scan.completed` summary (topic `bulwark.scans.completed`).

## Quick start
No install needed: `pip install -r requirements.txt`, fill in `.env`, then `python src/scan_ingestor/run.py [options]` (same options as `scan-ingestor` below).
```bash
pip install -e ".[dev]"
psql "$DATABASE_URL" -f sql/schema.sql          # Bulwark schema (skip if you already have it)
cp .env.example .env                            # ALL settings live here (no defaults in code); set DATABASE_URL, Kafka password, CA file
scan-ingestor --validate-only                   # parse the folder, touch nothing
scan-ingestor --kafka-dry-run                   # real DB, Kafka messages go to reports/kafka_dry_run.jsonl
scan-ingestor                                   # real run (default folder ./data/vulnerabilities)
```
Put the Aiven **CA certificate** at `certs/ca.pem`; password goes in `KAFKA_SASL_PASSWORD` (never commit `.env`).
Processed files move to `processed/`, rejected ones to `failed/`, JSON reports to `reports/`.
Options: `--dir`, `--file`, `--watch --interval 60`, `--force`, `--no-move`, `-v`.
Exit codes: 0 ok · 1 file rejected/failed or Kafka delivery failed · 2 config/Kafka unreachable · 3 another instance running.

## Workbook format (see `samples/`)
* `Scan` – key/value rows: scan_id, scanner, scanner_version, scan_type, started_at, finished_at, scope.
* `Vulnerabilities` – cve_id, title, description, severity, cvss_score, published_date, source, exploited_in_wild, affected_assets (`;`-separated asset names), recommendation, plugin_id, first_detected, last_detected. Severity is derived from CVSS if blank.
* `Assets` (optional) – name, asset_type, environment, os_name, os_version, owner_team; used to create assets not yet in the DB.
Invalid rows are skipped and reported; the file is rejected when >20 % of rows are invalid or a sheet/column is missing.

## Incident rules
| Situation | Result | Kafka |
|---|---|---|
| No open incident for the vulnerability | new incident (OPEN, created by the bot user) | `incident.created` |
| Previous incident RESOLVED/CLOSED | new incident, `change.reopened=true`, `previous_incident` set | `incident.created` |
| Open incident in OPEN/REJECTED, new assets or higher/lower severity | assets added, severity updated | `incident.updated` |
| Open incident in another status (e.g. PENDING_APPROVAL) with new assets | not modified, warning in report | none |
| Nothing new | unchanged | none (set `KAFKA_PUBLISH_UNCHANGED=true` to send `incident.unchanged`) |
| Vulnerability deactivated | skipped, warning | none |
Existing vulnerabilities: only CVSS/severity are refreshed; description/published date only if empty; assets are only added.

## Kafka messages
JSON, UTF-8, key = incident id (per-incident ordering). Headers: `event_type`, `schema_version`, `scan_id`, `cve_id`.
Schemas: `docs/kafka/*.schema.json`; examples: `docs/kafka/examples/`. Blocks: `incident`, `vulnerability`, `detection`, `impacted_assets`, `change`, `scan`, `source`.
`scan.completed` is sent only after every incident event was acknowledged.

## Delivery guarantees
DB changes for a file commit in one transaction together with a marker (`audit_logs`, keyed by file SHA-256). Kafka is then written (idempotent producer, `acks=all`). If Kafka fails, the file stays in the folder; the next run skips the DB step and re-sends the same events with the **same `event_id`**. Delivery is therefore at-least-once: consumers must de-duplicate on `event_id`. Only one instance runs at a time (Postgres advisory lock).

## Tests
`TEST_DATABASE_URL=postgresql://user:pw@host/scratch_db pytest -q` (**drops the public schema** of that database).

## Not verified here
The live Aiven connection (sandbox has no route to it) and `docker-compose.yml` were not run. The Kafka code path was exercised through the dry-run and in-memory publishers; connection failure exits with code 2.

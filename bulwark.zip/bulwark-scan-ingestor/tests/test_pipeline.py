import uuid

from conftest import make_xlsx
from scan_ingestor.pipeline import process_file
from scan_ingestor.publisher import MemoryPublisher


def run(path, settings, pub, **kw):
    return process_file(path, settings=settings, publisher=pub, job_run_id="job-1", **kw)


def inc_events(pub):
    return [m for m in pub.sent if m[0] == "bulwark.incidents"]


def test_first_run_creates_vulns_incidents_events(tmp_path, settings, db):
    f = make_xlsx(tmp_path / "a.xlsx", [{"cve_id": "CVE-2024-0001", "affected_assets": "srv-a;srv-b"}, {"cve_id": "CVE-2024-0002", "cvss_score": 9.9, "severity": None}])
    pub = MemoryPublisher()
    rep = run(f, settings, pub)
    assert rep["status"] == "published"
    assert db.execute("select count(*) n from vulnerabilities").fetchone()["n"] == 2
    assert db.execute("select count(*) n from incidents where status='OPEN'").fetchone()["n"] == 2
    assert db.execute("select count(*) n from incident_assets").fetchone()["n"] == 3
    assert [m[0] for m in pub.sent] == ["bulwark.incidents", "bulwark.incidents", "bulwark.scans.completed"]    # summary last
    assert {m[2]["event_type"] for m in inc_events(pub)} == {"incident.created"}
    assert not any(m[2]["event_type"].startswith("vulnerability") for m in pub.sent)
    m = inc_events(pub)[0][2]
    assert m["incident"]["code"].startswith("INC-") and len(m["impacted_assets"]) == 2 and m["vulnerability"]["cve_id"] == "CVE-2024-0001"
    assert pub.sent[-1][2]["totals"]["incidents_created"] == 2
    assert run(f, settings, MemoryPublisher())["status"] == "already_published"


def test_rescan_updates_editable_incident(tmp_path, settings, db):
    run(make_xlsx(tmp_path / "a.xlsx", [{"cve_id": "CVE-2024-0001", "cvss_score": 6.0, "severity": None}], scan_id="S1"), settings, MemoryPublisher())
    pub = MemoryPublisher()
    rep = run(make_xlsx(tmp_path / "b.xlsx", [{"cve_id": "CVE-2024-0001", "cvss_score": 9.5, "severity": None, "affected_assets": "srv-a;srv-b"}], scan_id="S2"), settings, pub)
    assert rep["status"] == "published"
    ev = inc_events(pub)
    assert len(ev) == 1 and ev[0][2]["event_type"] == "incident.updated"
    assert ev[0][2]["change"]["assets_added"] == ["srv-b"] and ev[0][2]["change"]["changed_fields"]["severity"]["to"] == "CRITICAL"
    assert db.execute("select count(*) n from incidents").fetchone()["n"] == 1


def test_locked_incident_no_event(tmp_path, settings, db):
    run(make_xlsx(tmp_path / "a.xlsx", [{"cve_id": "CVE-2024-0001"}], scan_id="S1"), settings, MemoryPublisher())
    db.execute("update incidents set status='PENDING_APPROVAL'")
    pub = MemoryPublisher()
    rep = run(make_xlsx(tmp_path / "b.xlsx", [{"cve_id": "CVE-2024-0001", "affected_assets": "srv-a;srv-c"}], scan_id="S2"), settings, pub)
    assert rep["counts"]["incidents_locked"] == 1 and inc_events(pub) == []
    assert any("PENDING_APPROVAL" in w["message"] for w in rep["warnings"])


def test_resolved_incident_reopens_as_new(tmp_path, settings, db):
    run(make_xlsx(tmp_path / "a.xlsx", [{"cve_id": "CVE-2024-0001"}], scan_id="S1"), settings, MemoryPublisher())
    db.execute("update incidents set status='RESOLVED'")
    pub = MemoryPublisher()
    run(make_xlsx(tmp_path / "b.xlsx", [{"cve_id": "CVE-2024-0001"}], scan_id="S2"), settings, pub)
    m = inc_events(pub)[0][2]
    assert m["event_type"] == "incident.created" and m["change"]["reopened"] is True and m["change"]["previous_incident"] == "INC-1"
    assert db.execute("select count(*) n from incidents").fetchone()["n"] == 2


def test_inactive_vulnerability_skipped(tmp_path, settings, db):
    run(make_xlsx(tmp_path / "a.xlsx", [{"cve_id": "CVE-2024-0001"}], scan_id="S1"), settings, MemoryPublisher())
    db.execute("update incidents set status='CLOSED'; update vulnerabilities set is_active=false")
    pub = MemoryPublisher()
    rep = run(make_xlsx(tmp_path / "b.xlsx", [{"cve_id": "CVE-2024-0001"}], scan_id="S2"), settings, pub)
    assert rep["counts"]["incidents_skipped_inactive"] == 1 and inc_events(pub) == []


def test_kafka_failure_then_resume_same_event_ids(tmp_path, settings, db):
    f = make_xlsx(tmp_path / "a.xlsx", [{"cve_id": "CVE-2024-0001"}, {"cve_id": "CVE-2024-0002"}, {"cve_id": "CVE-2024-0003"}])
    bad = MemoryPublisher(fail_after=1)
    rep = run(f, settings, bad)
    assert rep["status"] == "db_committed_publish_failed"
    assert db.execute("select count(*) n from incidents").fetchone()["n"] == 3          # DB already committed
    good = MemoryPublisher()
    rep2 = run(f, settings, good)
    assert rep2["status"] == "published" and db.execute("select count(*) n from incidents").fetchone()["n"] == 3
    ids = {m[2]["event_id"] for m in inc_events(good)}
    assert len(ids) == 3 and {m[2]["event_type"] for m in inc_events(good)} == {"incident.created"}      # original CREATED action kept
    assert {m[2]["event_id"] for m in bad.sent if m[0] == "bulwark.incidents"} <= ids                  # same ids as the failed attempt
    uuid.UUID(next(iter(ids)))


def test_invalid_rows_and_rejection(tmp_path, settings, db):
    rows = [{"cve_id": f"CVE-2024-{i:04d}"} for i in range(1, 10)] + [{"cve_id": "BAD-ID"}]
    pub = MemoryPublisher()
    rep = run(make_xlsx(tmp_path / "a.xlsx", rows), settings, pub)
    assert rep["status"] == "published" and rep["counts"]["rejected_rows"] == 1 and len(inc_events(pub)) == 9
    rows = [{"cve_id": "BAD"}, {"cve_id": "CVE-2024-9999"}]
    rep = run(make_xlsx(tmp_path / "b.xlsx", rows, scan_id="S9"), settings, MemoryPublisher())
    assert rep["status"] == "rejected"

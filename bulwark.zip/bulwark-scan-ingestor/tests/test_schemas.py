import json
from pathlib import Path

import jsonschema
from conftest import make_xlsx
from scan_ingestor.pipeline import process_file
from scan_ingestor.publisher import MemoryPublisher

K = Path(__file__).resolve().parents[1] / "docs" / "kafka"


def test_messages_match_published_schemas(tmp_path, settings, db):
    pub = MemoryPublisher()
    process_file(make_xlsx(tmp_path / "a.xlsx", [{"cve_id": "CVE-2024-0001", "affected_assets": "srv-a;srv-b"}, {"cve_id": "CVE-2024-0002"}]),
                 settings=settings, publisher=pub, job_run_id="j")
    inc, done = (json.loads((K / n).read_text()) for n in ("incident-event.schema.json", "scan-completed.schema.json"))
    for topic, _, value, _ in pub.sent:
        jsonschema.validate(value, done if topic.endswith("completed") else inc)

from conftest import make_xlsx
from scan_ingestor.reader import read_workbook


def test_duplicates_merge_and_severity_from_cvss(tmp_path):
    p = read_workbook(make_xlsx(tmp_path / "a.xlsx", [
        {"cve_id": "CVE-2024-0001", "affected_assets": "srv-a", "cvss_score": 9.8, "severity": None},
        {"cve_id": "CVE-2024-0001", "affected_assets": "srv-b", "cvss_score": None, "severity": "high"}]), tz="UTC")
    assert len(p.rows) == 1 and set(p.rows[0].affected_assets) == {"srv-a", "srv-b"} and float(p.rows[0].cvss_score) == 9.8

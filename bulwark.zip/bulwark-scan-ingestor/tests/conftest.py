import os
from datetime import datetime
from pathlib import Path

import openpyxl
import psycopg
import pytest
from psycopg.rows import dict_row

from scan_ingestor.config import Settings

ROOT = Path(__file__).resolve().parents[1]
URL = os.environ.get("TEST_DATABASE_URL")


@pytest.fixture()
def settings():
    if not URL:
        pytest.skip("set TEST_DATABASE_URL (a scratch database; its public schema is DROPPED)")
    return Settings(database_url=URL, ingest_min_file_age_seconds=0, kafka_bootstrap_servers="x:1")


@pytest.fixture()
def db(settings):
    with psycopg.connect(URL, autocommit=True, row_factory=dict_row) as c:
        c.execute("DROP SCHEMA public CASCADE; CREATE SCHEMA public;")
        c.execute((ROOT / "sql" / "schema.sql").read_text())
        yield c


def make_xlsx(path: Path, rows: list[dict], assets=(), scan_id="SCAN-T-1"):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Scan"
    ws.append(["field", "value"])
    for k, v in {"scan_id": scan_id, "scanner": "TestScan", "scanner_version": "1", "scan_type": "t", "started_at": datetime(2026, 10, 1, 1),
                 "finished_at": datetime(2026, 10, 1, 2), "scope": "unit"}.items():
        ws.append([k, v])
    cols = ["cve_id", "title", "description", "severity", "cvss_score", "published_date", "source", "exploited_in_wild", "affected_assets",
            "recommendation", "plugin_id", "first_detected", "last_detected"]
    ws = wb.create_sheet("Vulnerabilities")
    ws.append(cols)
    for r in rows:
        d = {"title": "Title " + r["cve_id"], "description": "d", "severity": "HIGH", "cvss_score": 8.0, "published_date": datetime(2024, 1, 1), "source": "TestScan",
             "exploited_in_wild": "N", "affected_assets": "srv-a", "recommendation": "Patch it", "plugin_id": "1", "first_detected": datetime(2026, 9, 1),
             "last_detected": datetime(2026, 10, 1), **r}
        ws.append([d.get(c) for c in cols])
    ws = wb.create_sheet("Assets")
    ws.append(["name", "asset_type", "environment", "os_name", "os_version", "owner_team"])
    for a in assets or ["srv-a", "srv-b", "srv-c"]:
        ws.append([a, "SYSTEM", "prod", "Linux", "1", "Platform"])
    wb.save(path)
    return path

import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: { port: 3000 },
  test: { environment: 'jsdom', include: ['tests/**/*.test.jsx'], testTimeout: 30000 },
});

// Renders every page against a running backend. Run: JWT_SECRET=... npm test
import { createHmac } from 'node:crypto';
import { render, screen, waitFor, cleanup } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { afterEach, beforeAll, describe, expect, it } from 'vitest';
import { AuthProvider } from '../src/auth/AuthContext';
import { ToastProvider } from '../src/components/ui';
import Dashboard from '../src/pages/Dashboard';
import Incidents from '../src/pages/Incidents';
import Approvals from '../src/pages/Approvals';
import Vulnerabilities from '../src/pages/Vulnerabilities';
import Solutions from '../src/pages/Solutions';
import Execution from '../src/pages/Execution';
import Assets from '../src/pages/Assets';

const secret = process.env.JWT_SECRET;
const b64 = (o) => Buffer.from(JSON.stringify(o)).toString('base64url');
beforeAll(() => {
  const h = `${b64({ alg: 'HS256', typ: 'JWT' })}.${b64({ sub: '11111111-1111-5111-a111-111111111111', email: 'ui@x.io', name: 'ui', roles: ['ADMIN'], exp: Math.floor(Date.now() / 1000) + 3600 })}`;
  localStorage.setItem('bulwark.token', `${h}.${createHmac('sha256', secret).update(h).digest('base64url')}`);
  localStorage.setItem('bulwark.apiBaseUrl', process.env.API_BASE || 'http://localhost:8000');
});
afterEach(cleanup);

const wrap = (el, url = '/') => render(<MemoryRouter initialEntries={[url]}><AuthProvider><ToastProvider>{el}</ToastProvider></AuthProvider></MemoryRouter>);

describe.skipIf(!secret)('pages against live backend', () => {
  it.each([
    ['Dashboard', <Dashboard />, /dashboard/i],
    ['Incidents', <Incidents />, /incidents/i],
    ['Approvals', <Approvals />, /approvals/i],
    ['Vulnerabilities', <Vulnerabilities />, /vulnerability list/i],
    ['Solutions', <Solutions />, /solution list/i],
    ['Execution', <Execution />, /execution/i],
    ['Assets', <Assets />, /asset inventory/i],
  ])('%s renders without error', async (_n, el, title) => {
    wrap(el);
    await screen.findAllByText(title);
    await new Promise((r) => setTimeout(r, 800));
    expect(document.querySelector('.note.err')).toBeNull();
  });
});

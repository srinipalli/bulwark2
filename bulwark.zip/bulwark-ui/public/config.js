// Runtime configuration. Change this file (no rebuild needed) to point the UI at another backend.
// A value saved from the in-app Settings dialog overrides this one for that browser.
window.__BULWARK_CONFIG__ = {
  apiBaseUrl: "http://localhost:8000",
};

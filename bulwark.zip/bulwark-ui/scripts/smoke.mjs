// End-to-end check of the UI's API layer against a running backend (with the worker running).
// Usage: JWT_SECRET=... [API_BASE=http://localhost:8000] node scripts/smoke.mjs
import { createHash, createHmac } from 'node:crypto';

const mem = {};
globalThis.localStorage = { getItem: (k) => mem[k] ?? null, setItem: (k, v) => { mem[k] = v; }, removeItem: (k) => { delete mem[k]; } };
const base = process.env.API_BASE || 'http://localhost:8000';
localStorage.setItem('bulwark.apiBaseUrl', base);
const secret = process.env.JWT_SECRET;
if (!secret) { console.error('Set JWT_SECRET to the backend secret'); process.exit(2); }

const b64 = (o) => Buffer.from(JSON.stringify(o)).toString('base64url');
const uid = (n) => { const h = createHash('sha1').update(`bulwark-smoke-${n}`).digest('hex'); return `${h.slice(0, 8)}-${h.slice(8, 12)}-5${h.slice(13, 16)}-a${h.slice(17, 20)}-${h.slice(20, 32)}`; };
const mint = (name, roles) => {
  const h = `${b64({ alg: 'HS256', typ: 'JWT' })}.${b64({ sub: uid(name), email: `${name}@x.io`, name, roles, exp: Math.floor(Date.now() / 1000) + 3600 })}`;
  return `${h}.${createHmac('sha256', secret).update(h).digest('base64url')}`;
};
const { api } = await import('../src/api/endpoints.js');
const { setToken } = await import('../src/api/client.js');
const as = (n, r) => setToken(mint(n, r));
const ok = (m) => console.log('  ✓', m);
const must = (c, m) => { if (!c) { console.error('  ✗', m); process.exit(1); } };

as('analyst', ['ANALYST', 'OPERATOR']);
const sum = await api.dashboard.summary(); must('open_incidents' in sum, 'dashboard summary'); ok('dashboard summary');
const assets = (await api.reference.assets({ size: 100 })).items ?? await api.reference.assets();
const list = Array.isArray(assets) ? assets : assets.items; must(list.length >= 2, 'seeded assets'); ok(`${list.length} assets`);

const tag = Date.now();
const vuln = await api.vulnerabilities.create({ cve_id: `CVE-SMOKE-${tag}`, title: 'Smoke vuln', description: 'd', severity: 'HIGH', cvss_score: 7.5, source: 'MANUAL', asset_ids: list.slice(0, 2).map((a) => a.id) });
ok('vulnerability created');
const sol = await api.solutions.create({ title: `Smoke patch ${tag}`, description: 'x', executor: 'ANSIBLE', risk_level: 'LOW', applies_to: null, requires_reboot: false, timeout_seconds: 60, max_retries: 0, job_spec: { playbook: 'p.yml' } });
must(sol.status === 'REVIEW_PENDING', 'new solution is Review Pending'); ok('solution starts REVIEW_PENDING');

as('approver', ['APPROVER']);
const sp = (await api.approvals.solutions({ status: 'PENDING', size: 100 })).items.find((x) => x.title === sol.title || x.solution_id === sol.id);
must(sp, 'solution in approval queue'); await api.approvals.approveSolution(sp.id, 'ok'); ok('solution approved');

as('analyst', ['ANALYST', 'OPERATOR']);
const inc = await api.incidents.create({ title: 'Smoke incident', description: 'd', severity: 'HIGH', assignee_id: null, vulnerability_id: vuln.id, asset_ids: list.slice(0, 2).map((a) => a.id) });
await api.incidents.replacePlan(inc.id, [{ solution_id: sol.id, on_failure: 'STOP_ASSET' }]);
await api.incidents.submit(inc.id); ok('incident planned & submitted');
as('analyst', ['ANALYST', 'APPROVER']);   // same person who submitted
const mine = (await api.approvals.incidents({ status: 'PENDING', size: 100 })).items.find((x) => x.cve_id === vuln.cve_id);
let denied = false; try { await api.approvals.approveIncident(mine.id, ''); } catch (e) { denied = true; }
must(denied, 'self-approval is rejected'); ok('self-approval blocked');

as('approver', ['APPROVER']);
const iq = (await api.approvals.incidents({ status: 'PENDING', size: 100 })).items.find((x) => x.incident_title === 'Smoke incident' && x.cve_id === vuln.cve_id);
must(iq, 'incident in approval queue'); await api.approvals.approveIncident(iq.id, 'go'); ok('incident approved');

as('analyst', ['ANALYST', 'OPERATOR']);
const g0 = await api.execution.grid(inc.id); must(g0.can_run, 'grid can_run');
const res = await api.execution.runStep(inc.id, 1); must(res.every((r) => r.outcome === 'QUEUED'), 'queued'); ok('step 1 queued');
const again = await api.execution.runStep(inc.id, 1); must(again.every((r) => r.outcome === 'EXISTS' || r.outcome === 'BLOCKED'), 'no duplicate runs'); ok('re-run returns existing run');
let g; for (let i = 0; i < 40; i++) { g = await api.execution.grid(inc.id); if (g.rows.every((r) => r.cells[0].status === 'SUCCEEDED')) break; await new Promise((r) => setTimeout(r, 1000)); }
must(g.rows.every((r) => r.cells[0].status === 'SUCCEEDED'), 'all cells succeeded (is the worker running?)'); ok('worker executed all assets');
const logs = await api.execution.logs(g.rows[0].cells[0].run_id, 0); must(logs.length > 0, 'logs'); ok(`${logs.length} log lines`);
const done = await api.incidents.get(inc.id); ok(`incident status: ${done.status}`);
console.log('SMOKE OK');

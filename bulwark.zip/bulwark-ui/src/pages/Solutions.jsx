import { useEffect, useState } from 'react';
import { api } from '../api/endpoints';
import { useAuth } from '../auth/AuthContext';
import { Badge, ConfirmModal, Field, Loading, Modal, Pager, useAction, useToast } from '../components/ui';
import { notifyChanged } from '../components/Layout';
import { fmt, useAsync } from '../hooks';

const STATUSES = ['REVIEW_PENDING', 'APPROVED', 'REJECTED', 'CHANGES_REQUESTED', 'RETIRED'];

// Job spec templates per executor, following the conventions of the existing solutions. {{...}} are placeholders
// the executor fills per asset/incident. "fail_on" is only read by the simulated executor (dev/demo) to force a failure.
const JOB_SPEC_SAMPLES = {
  ANSIBLE: {
    fields: [['playbook', 'Playbook path in your Ansible repository (required)'], ['inventory', 'Inventory file; the asset is used as the limit'],
      ['extra_vars', 'Variables passed to the playbook']],
    spec: { playbook: 'playbooks/linux/package_security_update.yml', inventory: 'inventory/prod.yml',
      extra_vars: { packages: ['openssl', 'libssl3'], restart_dependent_services: true } },
  },
  AWS_SSM: {
    fields: [['document', 'SSM document name, e.g. AWS-RunShellScript, AWS-RunPatchBaseline (required)'],
      ['parameters', 'Document parameters; every value is a list']],
    spec: { document: 'AWS-RunShellScript', parameters: { commands: ['yum -y update openssl || apt-get -y install --only-upgrade openssl', 'openssl version'] } },
  },
  SHELL: {
    fields: [['command', 'Command run on the asset (required)'], ['shell', 'bash (default) or powershell'], ['become', 'Run with sudo / as administrator']],
    spec: { command: "systemctl restart {{service}} && systemctl is-active {{service}}", shell: 'bash', become: true },
  },
  HTTP: {
    fields: [['method', 'GET, POST, PUT, PATCH or DELETE (required)'], ['url', 'Endpoint to call (required)'], ['body', 'JSON request body (optional)'],
      ['expect_status', 'HTTP status that counts as success'], ['expect_json', 'Fields the JSON response must contain (optional)']],
    spec: { method: 'GET', url: 'https://{{hostname}}/actuator/health', expect_status: 200, expect_json: { status: 'UP' } },
  },
};
const PLACEHOLDERS = '{{hostname}}, {{ip}}, {{incident_code}}, {{service}}';

/** "View sample" panel under the job spec field: the template for the selected executor, with "Use this template". */
function JobSpecSample({ executor, current, onUse }) {
  const s = JOB_SPEC_SAMPLES[executor];
  if (!s) return null;
  const empty = !current.trim() || current.trim() === '{}';
  return (
    <div className="spec-sample">
      <div className="spec-head"><b>{executor} job spec sample</b>
        <button className="btn sm" onClick={() => onUse(JSON.stringify(s.spec, null, 2))}>{empty ? 'Use this template' : 'Replace current spec with this template'}</button></div>
      <table><tbody>{s.fields.map(([k, d]) => <tr key={k}><td className="mono">{k}</td><td>{d}</td></tr>)}</tbody></table>
      <pre className="mono">{JSON.stringify(s.spec, null, 2)}</pre>
      <small className="muted">Placeholders such as {PLACEHOLDERS} are filled per asset. For a dev/demo run, add <span className="mono">"fail_on": ["asset-name"]</span> to make the simulated executor fail on that asset.</small>
    </div>
  );
}

/** Add / edit a solution. `initial` pre-fills a new one (e.g. from an AI draft on the incident page); onSaved gets the saved solution. */
export function SolutionForm({ solution, initial, onClose, onSaved }) {
  const act = useAction();
  const toast = useToast();
  const det = useAsync(() => (solution ? api.solutions.get(solution.id) : Promise.resolve(null)), [solution?.id]);
  const v = det.data?.versions?.[det.data.versions.length - 1];
  const [f, setF] = useState(null);
  const [sample, setSample] = useState(false);           // job spec sample panel open
  useEffect(() => {
    if (solution && !v) return;
    const src = v || initial;
    setF({ title: src?.title || '', description: src?.description || '', executor: src?.executor || 'ANSIBLE', risk_level: src?.risk_level || 'MEDIUM',
      applies_to: src?.applies_to || '', requires_reboot: src?.requires_reboot || false, timeout_seconds: src?.timeout_seconds || 1800,
      max_retries: src?.max_retries || 0, job_spec: JSON.stringify(src?.job_spec || {}, null, 2) });
  }, [v?.id]);                                             // eslint-disable-line react-hooks/exhaustive-deps
  if (!f) return <Modal title="Solution" onClose={onClose}><Loading error={det.error} /></Modal>;
  const set = (k) => (e) => setF({ ...f, [k]: e.target.type === 'checkbox' ? e.target.checked : e.target.value });
  const approvedEdit = det.data?.status === 'APPROVED';
  const locked = det.data?.status === 'REVIEW_PENDING' || det.data?.is_retired;
  const save = async () => {
    let spec;
    try { spec = JSON.parse(f.job_spec || '{}'); } catch { return toast('Job spec must be valid JSON', 'err'); }
    const body = { ...f, job_spec: spec, applies_to: f.applies_to || null, description: f.description || null,
      timeout_seconds: Number(f.timeout_seconds), max_retries: Number(f.max_retries) };
    const r = await act(() => (solution ? api.solutions.update(solution.id, body) : api.solutions.create(body)), 'Submitted – Review Pending');
    if (r) { notifyChanged(); onSaved(r); }
  };
  return (
    <Modal title={solution ? 'Edit solution' : 'Add solution'} onClose={onClose} wide
      footer={<><button className="btn sec" onClick={onClose}>Cancel</button><button className="btn" disabled={locked || f.title.trim().length < 3} onClick={save}>Submit for review</button></>}>
      <div className="note">{approvedEdit ? <>Editing an approved solution creates <b>v{(det.data.latest_version_no) + 1}</b>, which goes back to <b>Review Pending</b>. The current version stays usable until the new one is approved.</>
        : locked ? 'This version is under review (or retired) and cannot be edited right now.'
        : <>Saved as <b>Review Pending</b>. It appears under Approvals → Solution approvals and can't be used on an incident until approved.</>}</div>
      <div className="form2">
        <Field label="Title"><input value={f.title} onChange={set('title')} /></Field>
        <Field label="Executor"><select value={f.executor} onChange={set('executor')}>{['ANSIBLE', 'AWS_SSM', 'SHELL', 'HTTP'].map((x) => <option key={x}>{x}</option>)}</select></Field>
        <Field label="Risk"><select value={f.risk_level} onChange={set('risk_level')}>{['LOW', 'MEDIUM', 'HIGH'].map((x) => <option key={x}>{x}</option>)}</select></Field>
        <Field label="Applies to"><input value={f.applies_to} onChange={set('applies_to')} placeholder="RHEL 8/9 · OpenSSL < 3.2.4" /></Field>
        <Field label="Timeout (seconds)"><input type="number" min="1" value={f.timeout_seconds} onChange={set('timeout_seconds')} /></Field>
        <Field label="Automatic retries (0-5)"><input type="number" min="0" max="5" value={f.max_retries} onChange={set('max_retries')} /></Field>
      </div>
      <Field label="Description"><textarea rows="2" value={f.description} onChange={set('description')} /></Field>
      <div className="field">
        <label>Job spec (JSON: playbook path, SSM document, command…)
          <button className="linkbtn" onClick={() => setSample((x) => !x)} aria-expanded={sample}>{sample ? 'Hide sample' : `View sample for ${f.executor}`}</button></label>
        {sample && <JobSpecSample executor={f.executor} current={f.job_spec} onUse={(spec) => setF({ ...f, job_spec: spec })} />}
        <textarea rows={sample ? 8 : 4} className="mono" value={f.job_spec} onChange={set('job_spec')} />
      </div>
      <label className="inline"><input type="checkbox" checked={f.requires_reboot} onChange={set('requires_reboot')} /> Requires reboot</label>
    </Modal>
  );
}

function SolutionView({ id, onClose }) {
  const d = useAsync(() => api.solutions.get(id), [id]);
  const s = d.data;
  return (
    <Modal title={s ? s.title : 'Solution'} onClose={onClose} wide>
      {!s ? <Loading error={d.error} /> : (<>
        <p><Badge value={s.status} /> &nbsp; Risk {s.risk_level} · {s.executor} · by {s.created_by_name || '—'}</p>
        <div className="note">{s.description || <i>No description</i>}</div>
        <h4>Versions</h4>
        <table><thead><tr><th>Version</th><th>Status</th><th>Executor</th><th>Applies to</th><th>Created</th></tr></thead>
          <tbody>{[...s.versions].reverse().map((v) => (
            <tr key={v.id}><td>v{v.version_no}</td><td><Badge value={v.status} /></td><td>{v.executor}</td><td>{v.applies_to || '—'}</td><td>{fmt(v.created_at)}</td></tr>))}</tbody></table>
      </>)}
    </Modal>
  );
}

export default function Solutions() {
  const { has } = useAuth();
  const act = useAction();
  const [q, setQ] = useState('');
  const [status, setStatus] = useState('');
  const [page, setPage] = useState(1);
  const [form, setForm] = useState(null);
  const [view, setView] = useState(null);
  const size = 15;
  const list = useAsync(() => api.solutions.list({ q, status, page, size }), [q, status, page]);
  useEffect(() => setPage(1), [q, status]);
  const canWrite = has('ANALYST');
  const [retiring, setRetiring] = useState(null);
  const retire = async () => { const ok = await act(() => api.solutions.retire(retiring.id), 'Retired'); if (ok) list.reload(); return ok; };

  return (
    <section>
      <h1>Solution List</h1>
      <div className="sub">Every solution is created as <b>Review Pending</b> and decided under Approvals → Solution approvals. Only <b>Approved</b> solutions can be planned.</div>
      <div className="toolbar">
        <input placeholder="Search solutions…" value={q} onChange={(e) => setQ(e.target.value)} />
        <select value={status} onChange={(e) => setStatus(e.target.value)}><option value="">All statuses</option>{STATUSES.map((s) => <option key={s} value={s}>{s.replace(/_/g, ' ')}</option>)}</select>
        <button className="btn push" disabled={!canWrite} title={canWrite ? '' : 'Requires ANALYST role'} onClick={() => setForm({})}>+ Add solution</button>
      </div>
      <div className="card">
        {list.error ? <Loading error={list.error} onRetry={list.reload} /> : !list.data ? <Loading /> : (<>
          <table><thead><tr><th>Solution</th><th>Version</th><th>Executor</th><th>Risk</th><th>Submitted by</th><th>Status</th><th>Actions</th></tr></thead>
            <tbody>{list.data.items.map((s) => (
              <tr key={s.id}>
                <td><b>{s.title}</b>{s.description && <div className="muted small">{s.description}</div>}</td>
                <td>v{s.latest_version_no}</td><td>{s.executor}</td><td>{s.risk_level}</td><td>{s.created_by_name || '—'}</td>
                <td><Badge value={s.status} />{s.has_approved_version && s.status !== 'APPROVED' && s.status !== 'RETIRED' && <div className="muted small">earlier version approved</div>}</td>
                <td className="actions">
                  <button className="btn sec sm" onClick={() => setView(s.id)}>View</button>
                  <button className="btn sec sm" disabled={!canWrite || s.is_retired} onClick={() => setForm(s)}>Edit</button>
                  {!s.is_retired && s.has_approved_version && <button className="btn sec sm" disabled={!has('APPROVER')} onClick={() => setRetiring(s)}>Retire</button>}
                </td></tr>))}
              {!list.data.items.length && <tr><td colSpan="7" className="muted">No solutions match.</td></tr>}</tbody></table>
          <Pager page={page} size={size} total={list.data.total} onPage={setPage} /></>)}
      </div>
      {form && <SolutionForm solution={form.id ? form : null} onClose={() => setForm(null)} onSaved={() => { setForm(null); list.reload(); }} />}
      {view && <SolutionView id={view} onClose={() => setView(null)} />}
      {retiring && <ConfirmModal title={`Retire ${retiring.title}`} confirmText="Retire" danger onConfirm={retire} onClose={() => setRetiring(null)}>
        <p>Retire <b>{retiring.title}</b>? It can no longer be planned.</p></ConfirmModal>}
    </section>
  );
}

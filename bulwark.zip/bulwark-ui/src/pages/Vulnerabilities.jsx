import { useEffect, useState } from 'react';
import { api } from '../api/endpoints';
import { useAuth } from '../auth/AuthContext';
import { Field, Loading, Modal, Pager, Badge, Sev, AssetPicker, useAction } from '../components/ui';
import { notifyChanged } from '../components/Layout';
import { useAsync } from '../hooks';
import IncidentForm from './IncidentForm';

const SEV = ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW'];

function VulnForm({ vuln, onClose, onSaved }) {
  const act = useAction();
  const assets = useAsync(() => api.reference.assets(), []);
  const [f, setF] = useState({
    cve_id: vuln?.cve_id || '', title: vuln?.title || '', description: vuln?.description || '', severity: vuln?.severity || 'HIGH',
    cvss_score: vuln?.cvss_score ?? '', source: vuln?.source || 'MANUAL', asset_ids: vuln?.assets.map((a) => a.id) || [],
  });
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const valid = f.cve_id.trim().length >= 3 && f.title.trim().length >= 3;
  const save = async () => {
    const body = { ...f, cve_id: f.cve_id.trim(), title: f.title.trim(), description: f.description.trim() || null,
      cvss_score: f.cvss_score === '' ? null : Number(f.cvss_score) };
    const r = await act(() => (vuln ? api.vulnerabilities.update(vuln.id, body) : api.vulnerabilities.create(body)), vuln ? 'Vulnerability updated' : 'Vulnerability added');
    if (r) { notifyChanged(); onSaved(); }
  };
  return (
    <Modal title={vuln ? `Edit ${vuln.cve_id}` : 'Add vulnerability'} onClose={onClose} wide
      footer={<><button className="btn sec" onClick={onClose}>Cancel</button><button className="btn" disabled={!valid} onClick={save}>{vuln ? 'Save changes' : 'Add vulnerability'}</button></>}>
      <div className="form2">
        <Field label="CVE / ID"><input value={f.cve_id} onChange={set('cve_id')} placeholder="CVE-2026-XXXX" /></Field>
        <Field label="Title"><input value={f.title} onChange={set('title')} /></Field>
        <Field label="Severity"><select value={f.severity} onChange={set('severity')}>{SEV.map((s) => <option key={s}>{s}</option>)}</select></Field>
        <Field label="CVSS score (0-10)"><input type="number" step="0.1" min="0" max="10" value={f.cvss_score} onChange={set('cvss_score')} /></Field>
        <Field label="Source"><select value={f.source} onChange={set('source')}>{['MANUAL', 'NVD', 'Scanner', 'Vendor'].map((s) => <option key={s}>{s}</option>)}</select></Field>
      </div>
      <Field label="Description"><textarea rows="3" value={f.description} onChange={set('description')} placeholder="What the vulnerability is, impact, exploit conditions…" /></Field>
      <Field label="Affected assets">{assets.data ? <AssetPicker assets={assets.data} value={f.asset_ids} onChange={(v) => setF({ ...f, asset_ids: v })} /> : <Loading error={assets.error} />}</Field>
    </Modal>
  );
}

export default function Vulnerabilities() {
  const { has } = useAuth();
  const act = useAction();
  const [q, setQ] = useState('');
  const [state, setState] = useState('');
  const [sev, setSev] = useState('');
  const [page, setPage] = useState(1);
  const [form, setForm] = useState(null);          // null | {} (new) | vuln (edit)
  const [incFor, setIncFor] = useState(null);
  const size = 15;
  const list = useAsync(() => api.vulnerabilities.list({ q, severity: sev, is_active: state === '' ? undefined : state === 'active', page, size }), [q, sev, state, page]);
  useEffect(() => setPage(1), [q, sev, state]);
  const canWrite = has('ANALYST');

  const toggle = async (v) => {
    if (await act(() => (v.is_active ? api.vulnerabilities.deactivate(v.id) : api.vulnerabilities.activate(v.id)), v.is_active ? 'Deactivated' : 'Activated')) { notifyChanged(); list.reload(); }
  };

  return (
    <section>
      <h1>Vulnerability List</h1><div className="sub">Master list across all systems and applications. Inactive ones can't be used for new incidents.</div>
      <div className="toolbar">
        <input placeholder="Search CVE / title / description…" value={q} onChange={(e) => setQ(e.target.value)} />
        <select value={state} onChange={(e) => setState(e.target.value)}><option value="">Active + inactive</option><option value="active">Active</option><option value="inactive">Inactive</option></select>
        <select value={sev} onChange={(e) => setSev(e.target.value)}><option value="">All severities</option>{SEV.map((s) => <option key={s}>{s}</option>)}</select>
        <button className="btn push" disabled={!canWrite} title={canWrite ? '' : 'Requires ANALYST role'} onClick={() => setForm({})}>+ Add vulnerability</button>
      </div>
      <div className="card">
        {list.error ? <Loading error={list.error} onRetry={list.reload} /> : !list.data ? <Loading /> : (<>
          <table><thead><tr><th>CVE</th><th>Title / description</th><th>Severity</th><th>CVSS</th><th>Source</th><th>Assets</th><th>Incident</th><th>State</th><th>Actions</th></tr></thead>
            <tbody>{list.data.items.map((v) => (
              <tr key={v.id} className={v.is_active ? '' : 'inactive'}>
                <td><b>{v.cve_id}</b></td>
                <td>{v.title}{v.description && <div className="muted small">{v.description}</div>}</td>
                <td><Sev value={v.severity} /></td><td>{v.cvss_score ?? '—'}</td><td>{v.source}</td><td>{v.assets.length}</td>
                <td>{v.open_incident ? <b>{v.open_incident.code}</b> : '—'}</td>
                <td><Badge value={v.is_active ? 'ACTIVE' : 'INACTIVE'} /></td>
                <td className="actions">
                  <button className="btn sec sm" disabled={!canWrite} onClick={() => setForm(v)}>Edit</button>
                  <button className="btn sec sm" disabled={!canWrite} onClick={() => toggle(v)}>{v.is_active ? 'Deactivate' : 'Activate'}</button>
                  {v.is_active && !v.open_incident && <button className="btn sm" disabled={!has('ANALYST', 'OPERATOR')} onClick={() => setIncFor(v.id)}>Create incident</button>}
                </td></tr>))}
              {!list.data.items.length && <tr><td colSpan="9" className="muted">No vulnerabilities match.</td></tr>}</tbody></table>
          <Pager page={page} size={size} total={list.data.total} onPage={setPage} /></>)}
      </div>
      {form && <VulnForm vuln={form.id ? form : null} onClose={() => setForm(null)} onSaved={() => { setForm(null); list.reload(); }} />}
      {incFor && <IncidentForm vulnerabilityId={incFor} onClose={() => setIncFor(null)} onSaved={() => { setIncFor(null); list.reload(); }} />}
    </section>
  );
}

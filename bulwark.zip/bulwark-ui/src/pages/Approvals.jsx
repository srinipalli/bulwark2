import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { api } from '../api/endpoints';
import { useAuth } from '../auth/AuthContext';
import { Badge, Loading, Pager, PromptModal, Sev, useAction } from '../components/ui';
import { notifyChanged } from '../components/Layout';
import { fmt, pretty, useAsync } from '../hooks';

const STAT = { incidents: ['PENDING', 'APPROVED', 'REJECTED', 'CANCELLED'], solutions: ['PENDING', 'APPROVED', 'REJECTED', 'CHANGES_REQUESTED'] };

export default function Approvals() {
  const [params, setParams] = useSearchParams();
  const tab = params.get('tab') === 'solutions' ? 'solutions' : 'incidents';
  const [status, setStatus] = useState('PENDING');
  const [page, setPage] = useState(1);
  const size = 15;
  const sum = useAsync(() => api.approvals.summary(), [tab, status, page]);
  const list = useAsync(() => (tab === 'incidents' ? api.approvals.incidents({ status, page, size }) : api.approvals.solutions({ status, page, size })), [tab, status, page]);
  useEffect(() => { setPage(1); setStatus('PENDING'); }, [tab]);
  const refresh = () => { list.reload(); sum.reload(); notifyChanged(); };

  return (
    <section>
      <h1>Approvals</h1>
      <div className="sub">Level-1 approval, approvers only (including their own submissions).</div>
      <div className="subtabs">
        <span className={tab === 'incidents' ? 'on' : ''} onClick={() => setParams({ tab: 'incidents' })}>Incident approvals <Badge value="PENDING" label={sum.data?.incident_pending ?? '…'} /></span>
        <span className={tab === 'solutions' ? 'on' : ''} onClick={() => setParams({ tab: 'solutions' })}>Solution approvals <Badge value="PENDING" label={sum.data?.solution_pending ?? '…'} /></span>
      </div>
      <div className="toolbar"><select value={status} onChange={(e) => { setStatus(e.target.value); setPage(1); }}>{STAT[tab].map((s) => <option key={s} value={s}>{pretty(s)}</option>)}</select></div>
      <div className="card">
        {list.error ? <Loading error={list.error} onRetry={list.reload} /> : !list.data ? <Loading /> : (<>
          {tab === 'incidents' ? <IncidentTable rows={list.data.items} onDone={refresh} /> : <SolutionTable rows={list.data.items} onDone={refresh} />}
          <Pager page={page} size={size} total={list.data.total} onPage={setPage} /></>)}
      </div>
    </section>
  );
}

/** Why the current user cannot decide. Approvers may decide their own submissions too. */
function useDecision() {
  const { has } = useAuth();
  return () => (!has('APPROVER') ? 'Approvers only' : '');
}

function IncidentTable({ rows, onDone }) {
  const act = useAction();
  const why = useDecision();
  const [reject, setReject] = useState(null);
  return (<>
    <table><thead><tr><th>Incident</th><th>Vulnerability / description</th><th>Severity</th><th>Assets</th><th>Plan (in order)</th><th>Submitted by</th><th>Decision</th></tr></thead>
      <tbody>{rows.map((r) => {
        const block = r.status === 'PENDING' ? why(r.requested_by_id) : 'Decided';
        return (
          <tr key={r.id}>
            <td><b>{r.incident_code}</b></td>
            <td>{r.cve_id}<div className="muted small">{r.incident_title}</div>{r.incident_description && <div className="muted small italic">{r.incident_description}</div>}</td>
            <td><Sev value={r.severity} /></td><td>{r.assets_count}</td>
            <td>{r.plan.map((p) => <div key={p.step_no} className="small">{p.step_no}. {p.title} <span className="muted">({pretty(p.executor)}, v{p.version_no})</span></div>)}</td>
            <td>{r.requested_by}<div className="muted small">{fmt(r.requested_at)}</div></td>
            <td>{r.status === 'PENDING' ? (<div className="actions">
              <button className="btn sm" disabled={!!block} onClick={async () => { if (await act(() => api.approvals.approveIncident(r.id), `${r.incident_code} approved`)) onDone(); }}>Approve</button>
              <button className="btn danger sm" disabled={!!block} onClick={() => setReject(r)}>Reject</button>
              {block && <small className="muted">{block}</small>}</div>)
              : <><Badge value={r.status} /><div className="muted small">{r.decided_by} · {fmt(r.decided_at)}</div>{r.comment && <div className="small">“{r.comment}”</div>}</>}</td></tr>);
      })}
        {!rows.length && <tr><td colSpan="7" className="muted">Nothing here.</td></tr>}</tbody></table>
    {reject && <PromptModal title={`Reject ${reject.incident_code}`} label="Reason (required)" confirmText="Reject" danger onClose={() => setReject(null)}
      onSubmit={async (c) => { const ok = await act(() => api.approvals.rejectIncident(reject.id, c), 'Rejected – returned for changes'); if (ok) onDone(); return ok; }} />}
  </>);
}

function SolutionTable({ rows, onDone }) {
  const act = useAction();
  const why = useDecision();
  const [dlg, setDlg] = useState(null);       // { row, kind: 'reject' | 'changes' }
  return (<>
    <table><thead><tr><th>Solution</th><th>Version</th><th>Executor</th><th>Risk</th><th>Submitted by</th><th>Decision</th></tr></thead>
      <tbody>{rows.map((r) => {
        const block = r.status === 'PENDING' ? why(r.requested_by_id) : 'Decided';
        return (
          <tr key={r.id}>
            <td><b>{r.title}</b>{r.description && <div className="muted small">{r.description}</div>}</td>
            <td>v{r.version_no}</td><td>{r.executor}</td><td>{pretty(r.risk_level)}</td>
            <td>{r.requested_by}<div className="muted small">{fmt(r.requested_at)}</div></td>
            <td>{r.status === 'PENDING' ? (<div className="actions">
              <button className="btn sm" disabled={!!block} onClick={async () => { if (await act(() => api.approvals.approveSolution(r.id), 'Solution approved')) onDone(); }}>Approve</button>
              <button className="btn danger sm" disabled={!!block} onClick={() => setDlg({ row: r, kind: 'reject' })}>Reject</button>
              <button className="btn sec sm" disabled={!!block} onClick={() => setDlg({ row: r, kind: 'changes' })}>Request changes</button>
              {block && <small className="muted">{block}</small>}</div>)
              : <><Badge value={r.status} /><div className="muted small">{r.reviewer} · {fmt(r.decided_at)}</div>{r.comment && <div className="small">“{r.comment}”</div>}</>}</td></tr>);
      })}
        {!rows.length && <tr><td colSpan="6" className="muted">Nothing here.</td></tr>}</tbody></table>
    {dlg && <PromptModal title={`${dlg.kind === 'reject' ? 'Reject' : 'Request changes for'} ${dlg.row.title}`} label="Comment (required)" confirmText={dlg.kind === 'reject' ? 'Reject' : 'Request changes'} danger={dlg.kind === 'reject'} onClose={() => setDlg(null)}
      onSubmit={async (c) => { const ok = await act(() => (dlg.kind === 'reject' ? api.approvals.rejectSolution(dlg.row.id, c) : api.approvals.requestChanges(dlg.row.id, c)), 'Decision recorded'); if (ok) onDone(); return ok; }} />}
  </>);
}

import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../api/endpoints';
import { useAuth } from '../auth/AuthContext';
import { Badge, ConfirmModal, Field, Loading, Modal, Pager, Sev, useAction } from '../components/ui';
import { notifyChanged } from '../components/Layout';
import { fmt, useAsync } from '../hooks';

const TYPES = ['SYSTEM', 'APPLICATION'];
const ENV_DEFAULTS = ['prod', 'uat', 'stage', 'dev', 'dr'];

function AssetForm({ asset, facets, onClose, onSaved }) {
  const act = useAction();
  const [f, setF] = useState({
    name: asset?.name || '', asset_type: asset?.asset_type || 'SYSTEM', environment: asset?.environment || 'prod',
    hostname: asset?.hostname || '', os_name: asset?.os_name || '', os_version: asset?.os_version || '', owner_team: asset?.owner_team || '',
  });
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const valid = f.name.trim().length >= 2 && f.environment.trim().length >= 2;
  const save = async () => {
    const opt = (v) => v.trim() || null;
    // attributes are not edited here: omitted on create (defaults to {}) and left untouched on edit
    const body = { name: f.name.trim(), asset_type: f.asset_type, environment: f.environment.trim(), hostname: opt(f.hostname),
      os_name: opt(f.os_name), os_version: opt(f.os_version), owner_team: opt(f.owner_team) };
    const r = await act(() => (asset ? api.assets.update(asset.id, body) : api.assets.create(body)), asset ? 'Asset updated' : 'Asset added');
    if (r) { notifyChanged(); onSaved(r); }
  };
  const envs = [...new Set([...ENV_DEFAULTS, ...(facets?.environments || [])])];
  return (
    <Modal title={asset ? `Edit ${asset.name}` : 'Add asset'} onClose={onClose} wide
      footer={<><button className="btn sec" onClick={onClose}>Cancel</button><button className="btn" disabled={!valid} onClick={save}>{asset ? 'Save changes' : 'Add asset'}</button></>}>
      <div className="form2">
        <Field label="Name" hint="Unique, e.g. app-prod-01 or Billing API"><input value={f.name} onChange={set('name')} autoFocus /></Field>
        <Field label="Type"><select value={f.asset_type} onChange={set('asset_type')}>{TYPES.map((t) => <option key={t}>{t}</option>)}</select></Field>
        <Field label="Environment"><input list="asset-envs" value={f.environment} onChange={set('environment')} /></Field>
        <Field label="Hostname"><input value={f.hostname} onChange={set('hostname')} placeholder="app-prod-01.corp.local" /></Field>
        <Field label="OS name"><input list="asset-os" value={f.os_name} onChange={set('os_name')} placeholder="Red Hat Enterprise Linux" /></Field>
        <Field label="OS version"><input value={f.os_version} onChange={set('os_version')} placeholder="9.4" /></Field>
        <Field label="Owner team"><input list="asset-teams" value={f.owner_team} onChange={set('owner_team')} /></Field>
      </div>
      <datalist id="asset-envs">{envs.map((e) => <option key={e} value={e} />)}</datalist>
      <datalist id="asset-os">{(facets?.os_names || []).map((o) => <option key={o} value={o} />)}</datalist>
      <datalist id="asset-teams">{(facets?.owner_teams || []).map((t) => <option key={t} value={t} />)}</datalist>
    </Modal>
  );
}

function AssetView({ id, canWrite, onClose, onEdit, onToggle }) {
  const nav = useNavigate();
  const d = useAsync(() => api.assets.get(id), [id]);
  const a = d.data;
  return (
    <Modal title={a ? a.name : 'Asset'} onClose={onClose} wide footer={a && <>
      <button className="btn sec" onClick={onClose}>Close</button>
      <button className="btn sec" disabled={!canWrite} onClick={() => onToggle(a, d.reload)}>{a.is_active ? 'Deactivate' : 'Activate'}</button>
      <button className="btn" disabled={!canWrite} onClick={() => onEdit(a)}>Edit</button></>}>
      {!a ? <Loading error={d.error} onRetry={d.reload} /> : (<>
        <div className="kv">
          <div><small>Type</small>{a.asset_type}</div><div><small>Environment</small>{a.environment}</div><div><small>State</small><Badge value={a.is_active ? 'ACTIVE' : 'INACTIVE'} /></div>
          <div><small>Hostname</small>{a.hostname || '—'}</div><div><small>OS</small>{[a.os_name, a.os_version].filter(Boolean).join(' ') || '—'}</div><div><small>Owner team</small>{a.owner_team || '—'}</div>
          <div><small>Created</small>{fmt(a.created_at)}</div><div><small>Updated</small>{fmt(a.updated_at)}</div>
        </div>
        {Object.keys(a.attributes || {}).length > 0 && <div>{Object.entries(a.attributes).map(([k, v]) => <span key={k} className="chip">{k}: {typeof v === 'object' ? JSON.stringify(v) : String(v)}</span>)}</div>}
        <h4>Vulnerabilities ({a.vulnerabilities.length})</h4>
        {a.vulnerabilities.length ? (
          <table><thead><tr><th>CVE</th><th>Title</th><th>Severity</th><th>State</th></tr></thead>
            <tbody>{a.vulnerabilities.map((v) => (
              <tr key={v.id} className={v.is_active ? '' : 'inactive'}><td><b>{v.cve_id}</b></td><td>{v.title}</td><td><Sev value={v.severity} /></td><td><Badge value={v.is_active ? 'ACTIVE' : 'INACTIVE'} /></td></tr>))}</tbody></table>
        ) : <div className="muted">No vulnerabilities linked to this asset.</div>}
        <h4>Incidents ({a.incidents.length})</h4>
        {a.incidents.length ? (
          <table><thead><tr><th>Incident</th><th>Severity</th><th>Incident status</th><th>This asset</th><th>Patched</th></tr></thead>
            <tbody>{a.incidents.map((i) => (
              <tr key={i.id} className="click" onClick={() => nav(`/incidents/${i.id}`, { state: { from: '/assets' } })}>
                <td><b>{i.code}</b><div className="muted small">{i.title}</div></td><td><Sev value={i.severity} /></td>
                <td><Badge value={i.status} /></td><td><Badge value={i.asset_status} /></td><td>{fmt(i.patched_at)}</td></tr>))}</tbody></table>
        ) : <div className="muted">This asset has not been part of any incident.</div>}
      </>)}
    </Modal>
  );
}

export default function Assets() {
  const { has } = useAuth();
  const act = useAction();
  const [q, setQ] = useState('');
  const [env, setEnv] = useState('');
  const [type, setType] = useState('');
  const [state, setState] = useState('active');
  const [page, setPage] = useState(1);
  const [form, setForm] = useState(null);           // null | {} (new) | asset (edit)
  const [view, setView] = useState(null);           // asset id
  const [confirm, setConfirm] = useState(null);     // { asset, after }
  const size = 15;
  const facets = useAsync(() => api.assets.facets(), []);
  const list = useAsync(() => api.assets.list({ q, environment: env, asset_type: type, is_active: state === '' ? undefined : state === 'active', page, size }),
    [q, env, type, state, page]);
  useEffect(() => setPage(1), [q, env, type, state]);
  const canWrite = has('ANALYST');

  const toggle = async (a, after) => {
    if (await act(() => (a.is_active ? api.assets.deactivate(a.id) : api.assets.activate(a.id)), a.is_active ? 'Asset deactivated' : 'Asset activated')) {
      notifyChanged(); list.reload(); after?.(); return true;
    }
    return false;
  };
  const askToggle = (a, after) => (a.is_active ? setConfirm({ asset: a, after }) : toggle(a, after));

  return (
    <section>
      <h1>Asset Inventory</h1>
      <div className="sub">Systems and applications that vulnerabilities and incidents point at. Inactive assets are hidden from the pickers.</div>
      <div className="toolbar">
        <input placeholder="Search name / hostname / OS / team…" value={q} onChange={(e) => setQ(e.target.value)} />
        <select value={env} onChange={(e) => setEnv(e.target.value)}><option value="">All environments</option>{(facets.data?.environments || []).map((e) => <option key={e}>{e}</option>)}</select>
        <select value={type} onChange={(e) => setType(e.target.value)}><option value="">All types</option>{TYPES.map((t) => <option key={t}>{t}</option>)}</select>
        <select value={state} onChange={(e) => setState(e.target.value)}><option value="active">Active</option><option value="inactive">Inactive</option><option value="">Active + inactive</option></select>
        <button className="btn push" disabled={!canWrite} title={canWrite ? '' : 'Requires ANALYST role'} onClick={() => setForm({})}>+ Add asset</button>
      </div>
      <div className="card">
        {list.error ? <Loading error={list.error} onRetry={list.reload} /> : !list.data ? <Loading /> : (<>
          <table><thead><tr><th>Asset</th><th>Type</th><th>Environment</th><th>OS</th><th>Owner team</th><th title="Active vulnerabilities affecting the asset">Vulns</th><th title="Open incidents where the asset is impacted">Open incidents</th><th>State</th><th>Actions</th></tr></thead>
            <tbody>{list.data.items.map((a) => (
              <tr key={a.id} className={`click ${a.is_active ? '' : 'inactive'}`} onClick={() => setView(a.id)}>
                <td><b>{a.name}</b>{a.hostname && <div className="muted small">{a.hostname}</div>}</td>
                <td>{a.asset_type === 'APPLICATION' ? 'Application' : 'System'}</td><td>{a.environment}</td>
                <td>{a.os_name || '—'}{a.os_version && <div className="muted small">{a.os_version}</div>}</td><td>{a.owner_team || '—'}</td>
                <td>{a.vulnerabilities_count}</td><td>{a.open_incidents_count ? <b>{a.open_incidents_count}</b> : 0}</td>
                <td><Badge value={a.is_active ? 'ACTIVE' : 'INACTIVE'} /></td>
                <td className="actions" onClick={(e) => e.stopPropagation()}>
                  <button className="btn sec sm" onClick={() => setView(a.id)}>View</button>
                  <button className="btn sec sm" disabled={!canWrite} onClick={() => setForm(a)}>Edit</button>
                  <button className="btn sec sm" disabled={!canWrite} onClick={() => askToggle(a)}>{a.is_active ? 'Deactivate' : 'Activate'}</button>
                </td></tr>))}
              {!list.data.items.length && <tr><td colSpan="9" className="muted">No assets match.</td></tr>}</tbody></table>
          <Pager page={page} size={size} total={list.data.total} onPage={setPage} /></>)}
      </div>
      {form && <AssetForm asset={form.id ? form : null} facets={facets.data} onClose={() => setForm(null)}
        onSaved={(saved) => { setForm(null); list.reload(); facets.reload(); if (!form.id) setView(saved.id); }} />}
      {view && !form && <AssetView id={view} canWrite={canWrite} onClose={() => setView(null)} onEdit={(a) => setForm(a)} onToggle={askToggle} />}
      {confirm && (
        <ConfirmModal title={`Deactivate ${confirm.asset.name}?`} confirmText="Deactivate" danger onClose={() => setConfirm(null)}
          onConfirm={() => toggle(confirm.asset, confirm.after)}>
          <p>The asset will no longer be offered when adding vulnerabilities or incidents. Existing links and history are kept, and you can activate it again at any time.</p>
          {confirm.asset.open_incidents_count > 0 && <div className="note">It is in {confirm.asset.open_incidents_count} open incident(s). Deactivation is refused while it is still pending there.</div>}
        </ConfirmModal>)}
    </section>
  );
}

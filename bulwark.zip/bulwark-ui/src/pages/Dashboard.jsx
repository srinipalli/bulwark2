import { useNavigate } from 'react-router-dom';
import { api } from '../api/endpoints';
import { useAsync } from '../hooks';
import { Badge, Loading, Sev } from '../components/ui';

export default function Dashboard() {
  const nav = useNavigate();
  const s = useAsync(() => api.dashboard.summary(), []);
  const a = useAsync(() => api.dashboard.attention(10), []);
  const ap = useAsync(() => api.approvals.summary(), []);
  const d = s.data;
  const tiles = d && [
    ['Open incidents', d.open_incidents, '/incidents'],
    ['Awaiting approval', d.approvals_waiting, '/approvals'],
    [`Jobs running${d.jobs_queued ? ` (${d.jobs_queued} queued)` : ''}`, d.jobs_running, '/execution'],
    [`Assets patched (${d.assets_patched}/${d.assets_total})`, `${d.assets_patched_pct}%`, '/execution'],
  ];
  return (
    <section>
      <h1>Dashboard</h1><div className="sub">Where things stand across vulnerabilities, incidents and patching</div>
      {s.error ? <Loading error={s.error} onRetry={s.reload} /> : !d ? <Loading /> : (
        <div className="kpis">{tiles.map(([l, n, to]) => (
          <div key={l} className="kpi" onClick={() => nav(to)}><div className="n">{n}</div><div className="l">{l}</div></div>))}
        </div>)}
      {d?.jobs_failed_open > 0 && <div className="note err">{d.jobs_failed_open} asset(s) have a failed job. Open Execution to retry or exclude them.</div>}
      <div className="grid2">
        <div className="card"><b>Incidents needing attention</b><br /><br />
          {a.error ? <Loading error={a.error} /> : !a.data ? <Loading /> : (
            <table><thead><tr><th>Incident</th><th>Vulnerability</th><th>Severity</th><th>Patched</th><th>Status</th></tr></thead>
              <tbody>{a.data.map((i) => (
                <tr key={i.id} className="click" onClick={() => nav(`/incidents/${i.id}`)}>
                  <td><b>{i.code}</b></td><td>{i.cve_id}</td><td><Sev value={i.severity} /></td>
                  <td>{i.patched_count}/{i.assets_count}</td><td><Badge value={i.status} /></td></tr>))}
                {!a.data.length && <tr><td colSpan="5" className="muted">Nothing open.</td></tr>}</tbody></table>)}
        </div>
        <div className="card"><b>Waiting for approval</b><br /><br />
          {ap.data && (<>
            <div className="step"><div className="grow"><b>Incident approvals</b><small>Plans waiting for sign-off</small></div>
              <Badge value="PENDING" label={ap.data.incident_pending} /><button className="btn sm" onClick={() => nav('/approvals?tab=incidents')}>Open</button></div>
            <div className="step"><div className="grow"><b>Solution approvals</b><small>New or changed solutions</small></div>
              <Badge value="PENDING" label={ap.data.solution_pending} /><button className="btn sm" onClick={() => nav('/approvals?tab=solutions')}>Open</button></div></>)}
        </div>
      </div>
    </section>
  );
}

import { useEffect, useState } from 'react';
import { api } from '../api/endpoints';
import { AssetPicker, Field, Loading, Modal, useAction } from '../components/ui';
import { notifyChanged } from '../components/Layout';
import { pretty, useAsync } from '../hooks';

const SEV = ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW'];
const FINISHED = ['RESOLVED', 'CLOSED'];
// What choosing a status does (the API only offers allowed moves: incident.allowed_statuses)
const STATUS_HINT = {
  OPEN: { PENDING_APPROVAL: 'Withdraws the submission so the plan can be changed.', DEFAULT: 'Back to planning. The plan has to be approved again before it can run.' },
  PENDING_APPROVAL: 'Submits the plan for incident approval (every solution in it must be approved).',
  RESOLVED: 'Marks the incident resolved without running the remaining steps.',
  CLOSED: 'Closes the incident. It can be reopened later.',
};

/** Add (incident == null) or edit an incident. `vulnerabilityId` preselects the vulnerability when adding. */
export default function IncidentForm({ incident, vulnerabilityId, onClose, onSaved }) {
  const act = useAction();
  const editing = !!incident;
  const vulns = useAsync(() => (editing ? Promise.resolve(null) : api.vulnerabilities.list({ is_active: true, size: 100 })), []);
  const users = useAsync(() => api.reference.users(), []);
  const assets = useAsync(() => api.reference.assets(), []);
  const [f, setF] = useState({
    vulnerability_id: incident?.vulnerability.id || vulnerabilityId || '', title: incident?.title || '', description: incident?.description || '',
    severity: incident?.severity || 'HIGH', assignee_id: incident?.assignee?.id || '', asset_ids: incident?.assets.filter((a) => a.status !== 'EXCLUDED').map((a) => a.asset.id) || [],
    status: incident?.status || 'OPEN',
  });
  const finished = editing && FINISHED.includes(incident.status);     // only the status (reopen / close) can change
  const statusHint = editing && f.status !== incident.status
    ? (f.status === 'OPEN' ? STATUS_HINT.OPEN[incident.status] || STATUS_HINT.OPEN.DEFAULT : STATUS_HINT[f.status]) : '';
  const free = (vulns.data?.items || []).filter((v) => !v.open_incident);

  // when adding: default to first free vulnerability and prefill from it
  const pick = (v) => v && setF((x) => ({ ...x, vulnerability_id: v.id, title: `${v.title} – remediation`, severity: v.severity, asset_ids: v.assets.map((a) => a.id) }));
  useEffect(() => {
    if (editing || !vulns.data) return;
    pick(free.find((v) => v.id === f.vulnerability_id) || free[0]);
  }, [vulns.data]);                                        // eslint-disable-line react-hooks/exhaustive-deps

  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const canEditAssets = !editing || (incident.editable && f.status === incident.status);
  const valid = f.title.trim().length >= 3 && f.vulnerability_id && f.asset_ids.length > 0;

  const save = async () => {
    const common = { title: f.title.trim(), description: f.description.trim() || null, severity: f.severity, assignee_id: f.assignee_id || null };
    const r = await act(async () => {
      if (editing) {
        if (!finished) {
          await api.incidents.update(incident.id, common);
          const before = incident.assets.filter((a) => a.status !== 'EXCLUDED').map((a) => a.asset.id).sort().join();
          if (canEditAssets && before !== [...f.asset_ids].sort().join()) await api.incidents.replaceAssets(incident.id, f.asset_ids);
        }
        if (f.status !== incident.status) await api.incidents.setStatus(incident.id, f.status);
      } else {
        await api.incidents.create({ ...common, vulnerability_id: f.vulnerability_id, asset_ids: f.asset_ids });
      }
      return true;
    }, editing ? 'Incident updated' : 'Incident created');
    if (r) { notifyChanged(); onSaved(); }
  };

  const loading = users.loading || assets.loading || (!editing && vulns.loading);
  return (
    <Modal title={editing ? `Edit ${incident.code}` : 'Add incident'} onClose={onClose} wide
      footer={<><button className="btn sec" onClick={onClose}>Cancel</button><button className="btn" disabled={!valid || loading} onClick={save}>{editing ? 'Save changes' : 'Create incident'}</button></>}>
      {loading ? <Loading error={users.error || assets.error || vulns.error} /> : (<>
        {!editing && !free.length && <div className="note err">No active vulnerability without an open incident. Add or activate one first.</div>}
        <div className="form2">
          <Field label={`Vulnerability${editing ? ' (fixed)' : ''}`}>
            {editing ? <input disabled value={`${incident.vulnerability.cve_id} – ${incident.vulnerability.title}`} /> : (
              <select value={f.vulnerability_id} onChange={(e) => pick(free.find((v) => v.id === e.target.value))}>
                {free.map((v) => <option key={v.id} value={v.id}>{v.cve_id} – {v.title}</option>)}</select>)}
          </Field>
          <Field label="Title"><input disabled={finished} value={f.title} onChange={set('title')} /></Field>
          <Field label="Severity"><select disabled={finished} value={f.severity} onChange={set('severity')}>{SEV.map((s) => <option key={s} value={s}>{pretty(s)}</option>)}</select></Field>
          <Field label="Assignee"><select disabled={finished} value={f.assignee_id} onChange={set('assignee_id')}><option value="">Unassigned</option>{users.data.map((u) => <option key={u.id} value={u.id}>{u.full_name}</option>)}</select></Field>
          {editing && (
            <Field label="Status" hint={statusHint || (incident.allowed_statuses?.length ? '' : 'No manual status change from here. Approval decisions and execution set it.')}>
              <select value={f.status} onChange={set('status')} disabled={!incident.allowed_statuses?.length}>
                {[incident.status, ...(incident.allowed_statuses || [])].map((s) => <option key={s} value={s}>{pretty(s)}{s === incident.status ? ' (current)' : ''}</option>)}</select>
            </Field>)}
        </div>
        <Field label="Description"><textarea disabled={finished} rows="3" value={f.description} onChange={set('description')} placeholder="Scope, urgency, change window, notes for approvers…" /></Field>
        {finished && <div className="note">This incident is {pretty(incident.status).toLowerCase()}. Only its status can change: reopen it to edit the details.</div>}
        <Field label="Impacted assets" hint={canEditAssets ? '' : editing && incident.editable ? 'Save the status change first, then edit the assets.' : 'Assets are locked while the incident is not Open/Rejected.'}>
          {canEditAssets ? <AssetPicker assets={assets.data} value={f.asset_ids} onChange={(v) => setF({ ...f, asset_ids: v })} />
            : <div>{incident.assets.map((a) => <span key={a.incident_asset_id} className="chip">{a.asset.name}</span>)}</div>}
        </Field>
        <div className="note">One open incident per vulnerability. Impacted assets are pre-filled from the vulnerability.</div>
      </>)}
    </Modal>
  );
}

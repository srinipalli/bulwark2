import { useCallback, useEffect, useRef, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { api } from '../api/endpoints';
import { useAuth } from '../auth/AuthContext';
import { Badge, Combobox, Loading, useAction } from '../components/ui';
import { notifyChanged } from '../components/Layout';
import { fmt, pretty, useAsync } from '../hooks';

const LIVE = ['QUEUED', 'RUNNING'];
// cell status -> [css class, label]
const CELL = { WAITING: ['wait', 'Not run'], QUEUED: ['pend', 'Queued'], RUNNING: ['run', 'Running'], SUCCEEDED: ['ok', 'Succeeded'], FAILED: ['fail', 'Failed'], CANCELLED: ['wait', 'Cancelled'] };
// overall system status -> [badge tone value, label]
const OVERALL = { PATCHED: ['APPROVED', 'Patched'], RUNNING: ['RUNNING', 'Running'], QUEUED: ['QUEUED', 'Queued'], FAILED: ['FAILED', 'Failed'], PAUSED: ['PENDING', 'Paused'], NOT_STARTED: ['', 'Not started'] };

/** One system (asset) of the incident: its overall state, progress and the step to run next. */
function summarize(row, steps) {
  const done = row.cells.filter((c) => c.status === 'SUCCEEDED').length;
  const idx = row.cells.findIndex((c) => c.status !== 'SUCCEEDED');
  const current = idx >= 0 ? { cell: row.cells[idx], step: steps[idx] } : null;
  const live = row.cells.find((c) => LIVE.includes(c.status));
  let overall;
  if (row.status === 'PATCHED' || !current) overall = 'PATCHED';
  else if (row.cells.some((c) => c.status === 'RUNNING')) overall = 'RUNNING';
  else if (live) overall = 'QUEUED';
  else if (row.status === 'FAILED' || current.cell.status === 'FAILED') overall = 'FAILED';
  else if (row.cells.every((c) => c.status === 'WAITING' || c.status === 'CANCELLED')) overall = 'NOT_STARTED';
  else overall = 'PAUSED';
  const last = [...row.cells].reverse().find((c) => c.run_id);
  return { done, current, overall, live, last };
}

const RUN_LABEL = { NOT_STARTED: 'Run', PAUSED: 'Resume', FAILED: 'Retry' };

const duration = (c) => {
  if (!c.started_at) return '';
  const s = Math.max(0, Math.round(((c.finished_at ? new Date(c.finished_at) : new Date()) - new Date(c.started_at)) / 1000));
  return s < 60 ? `${s}s` : `${Math.floor(s / 60)}m ${s % 60}s`;
};

export default function Execution() {
  const { has } = useAuth();
  const act = useAction();
  const [params, setParams] = useSearchParams();
  const incidents = useAsync(() => api.execution.incidents(), []);
  const [sel, setSel] = useState(params.get('incident') || '');
  const [grid, setGrid] = useState(null);
  const [gerr, setGerr] = useState(null);
  const [open, setOpen] = useState(() => new Set());     // expanded systems (incident_asset_id)
  const [busy, setBusy] = useState(false);
  const [run, setRun] = useState(null);                  // { id, title } shown in the run log
  const [logs, setLogs] = useState([]);
  const lastLog = useRef(0);
  const canRun = has('OPERATOR');

  useEffect(() => {                                      // default selection
    if (!sel && incidents.data?.length) setSel(incidents.data[0].id);
  }, [incidents.data, sel]);

  const loadGrid = useCallback(async () => {
    if (!sel) return;
    try { setGrid(await api.execution.grid(sel)); setGerr(null); } catch (e) { setGerr(e); }
  }, [sel]);

  // poll faster while something is queued/running
  const active = grid?.rows.some((r) => r.cells.some((c) => LIVE.includes(c.status)));
  useEffect(() => {
    setGrid(null); setRun(null); setLogs([]); setOpen(new Set()); lastLog.current = 0;
    loadGrid();
  }, [sel]);                                             // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => {
    if (!sel) return undefined;
    const t = setInterval(() => { loadGrid(); if (active) incidents.reload(); notifyChanged(); }, active ? 1500 : 6000);
    return () => clearInterval(t);
  }, [sel, active, loadGrid]);                           // eslint-disable-line react-hooks/exhaustive-deps

  // log tail
  useEffect(() => {
    if (!run) return undefined;
    let live = true;
    const tick = async () => {
      try {
        const rows = await api.execution.logs(run.id, lastLog.current);
        if (live && rows.length) { lastLog.current = rows[rows.length - 1].id; setLogs((l) => [...l, ...rows]); }
      } catch { /* ignore */ }
    };
    tick();
    const t = setInterval(tick, 1500);
    return () => { live = false; clearInterval(t); };
  }, [run]);

  const choose = (id) => { setSel(id); setParams(id ? { incident: id } : {}); };
  const refresh = async () => { await loadGrid(); incidents.reload(); notifyChanged(); };
  const report = (res, what) => {
    const n = (o) => res.filter((r) => r.outcome === o).length;
    const parts = [`${n('QUEUED')} started`, n('EXISTS') && `${n('EXISTS')} already running`, n('DONE') && `${n('DONE')} already done`,
      n('BLOCKED') && `${n('BLOCKED')} blocked (${res.find((r) => r.outcome === 'BLOCKED').reason})`].filter(Boolean);
    act(async () => true, `${what}: ${parts.join(', ')}`);
  };
  /** One click: the rest of the plan on all systems (assetIds omitted) or the given ones; the worker chains the steps. */
  const runPlan = async (assetIds, what) => {
    setBusy(true);
    const res = await act(() => api.execution.runPlan(sel, assetIds));
    setBusy(false);
    if (res) { report(res, what); await refresh(); }
  };
  /** Only this step on one system (e.g. retry a failed step without continuing). */
  const runStep = async (stepNo, assetId, what) => {
    const res = await act(() => api.execution.runStep(sel, stepNo, [assetId]));
    if (res) { report(res, what); await refresh(); }
  };
  const openLogs = (cell, row, step) => {
    if (!cell?.run_id) return;
    lastLog.current = 0; setLogs([]); setRun({ id: cell.run_id, title: `${row.asset_name} · step ${step.step_no} · ${step.title}` });
  };
  const toggle = (id) => setOpen((s) => { const n = new Set(s); if (n.has(id)) n.delete(id); else n.add(id); return n; });

  const inc = incidents.data?.find((i) => i.id === sel) || grid?.incident;
  const systems = grid ? grid.rows.map((r) => ({ row: r, ...summarize(r, grid.steps) })) : [];
  const count = (o) => systems.filter((s) => s.overall === o).length;
  const runnable = systems.filter((s) => RUN_LABEL[s.overall]);
  const whyNot = !canRun ? 'Requires OPERATOR role' : grid && !grid.can_run ? `Incident is ${pretty(grid.incident.status).toLowerCase()}` : '';

  return (
    <section>
      <h1>Execution</h1>
      <div className="sub">Only <b>Approved</b> incidents can run. <b>Run</b> runs the remaining plan steps on a system one after another; a step starts only after the previous one succeeded.</div>
      <div className="toolbar">
        <b>Incident</b>
        <Combobox ariaLabel="Incident" value={sel} onChange={choose} empty="No incident matches"
          placeholder={incidents.data?.length === 0 ? 'No approved incident' : 'Type incident, CVE or title…'}
          options={(incidents.data || []).map((i) => ({ value: i.id, label: `${i.code} · ${i.cve_id}`,
            hint: `${pretty(i.status)} · ${i.patched_count}/${i.assets_count} patched · ${i.title}` }))} />
        {inc && <><Badge value={inc.status} /><span className="badge b-info">{inc.patched_count}/{inc.assets_count} systems patched</span></>}
        {grid && <button className="btn push" disabled={!!whyNot || busy || !runnable.length} title={whyNot || (runnable.length ? '' : 'Nothing left to run')}
          onClick={() => runPlan(undefined, 'Run all systems')}>▶ Run all systems{runnable.length ? ` (${runnable.length})` : ''}</button>}
      </div>
      {incidents.error && <Loading error={incidents.error} onRetry={incidents.reload} />}
      {incidents.data && !incidents.data.length && <div className="note">No incident is approved yet. Build a plan in Incidents, submit it, and have it approved under Approvals.</div>}
      <div className="grid2">
        <div className="card">
          {gerr ? <Loading error={gerr} onRetry={loadGrid} /> : !grid ? (sel ? <Loading /> : null) : (<>
            {!grid.can_run && <div className="note">This incident is {pretty(grid.incident.status).toLowerCase()}; nothing can be started.</div>}
            <div className="sys-sum">
              <b>Systems ({systems.length})</b>
              {Object.keys(OVERALL).filter(count).map((o) => <Badge key={o} value={OVERALL[o][0]} label={`${count(o)} ${OVERALL[o][1].toLowerCase()}`} />)}
              <span className="push">
                <button className="linkbtn" onClick={() => setOpen(new Set(systems.map((s) => s.row.incident_asset_id)))}>Expand all</button>
                <button className="linkbtn" onClick={() => setOpen(new Set())}>Collapse all</button>
              </span>
            </div>
            {systems.map(({ row: r, done, current, overall, last }) => {
              const isOpen = open.has(r.incident_asset_id);
              const label = RUN_LABEL[overall];
              return (
                <div className={`sys ${isOpen ? 'open' : ''}`} key={r.incident_asset_id}>
                  <div className="sys-head">
                    <button className="exp" aria-expanded={isOpen} aria-label={`${isOpen ? 'Collapse' : 'Expand'} ${r.asset_name}`} onClick={() => toggle(r.incident_asset_id)}>{isOpen ? '▾' : '▸'}</button>
                    <div className="sys-name" onClick={() => toggle(r.incident_asset_id)}><b>{r.asset_name}</b><small className="muted">{r.environment}</small></div>
                    <div className="sys-prog">
                      <div className="bar-p"><i style={{ width: `${grid.steps.length ? (done * 100) / grid.steps.length : 0}%` }} /></div>
                      <small>{done}/{grid.steps.length} steps</small>
                    </div>
                    <div className="sys-cur small">{current
                      ? <>Step {current.step.step_no} · {current.step.title}<div className="muted">{CELL[current.cell.status]?.[1] || current.cell.status}{current.cell.attempt > 1 ? ` · attempt ${current.cell.attempt}` : ''}</div></>
                      : <span className="muted">All steps succeeded</span>}</div>
                    <Badge value={OVERALL[overall][0]} label={OVERALL[overall][1]} />
                    <div className="actions">
                      {last && <button className="linkbtn" onClick={() => openLogs(last, r, grid.steps.find((s) => s.step_no === last.step_no))}>logs</button>}
                      <button className="btn sm" disabled={!label || !!whyNot || busy} title={whyNot}
                        onClick={() => runPlan([r.incident_asset_id], `${label} ${r.asset_name}`)}>{label ? `▶ ${label}` : overall === 'PATCHED' ? 'Done' : 'Running…'}</button>
                    </div>
                  </div>
                  {isOpen && (
                    <div className="sys-steps">
                      {r.cells.map((c, i) => {
                        const step = grid.steps[i];
                        const [cls, text] = CELL[c.status] || CELL.WAITING;
                        const prevOk = i === 0 || r.cells[i - 1].status === 'SUCCEEDED' || (r.cells[i - 1].status === 'FAILED' && grid.steps[i - 1].on_failure === 'CONTINUE');
                        const single = (c.status === 'FAILED' || c.status === 'WAITING' || c.status === 'CANCELLED') && prevOk;
                        return (
                          <div className={`tl t-${cls}`} key={step.plan_step_id}>
                            <div className="no">{c.status === 'SUCCEEDED' ? '✓' : c.status === 'FAILED' ? '✕' : step.step_no}</div>
                            <div className="grow">
                              <b>Step {step.step_no} · {step.title}</b> <span className="muted small">v{step.version_no} · {step.executor} · on failure: {pretty(step.on_failure).toLowerCase()}</span>
                              <small>
                                <span className={`cell c-${cls}`}>{text}{c.attempt > 1 ? ` #${c.attempt}` : ''}</span>
                                {c.started_at && <> · started {fmt(c.started_at)}</>}{c.started_at && <> · {duration(c)}</>}
                                {c.chain && LIVE.includes(c.status) && <> · next steps follow automatically</>}
                              </small>
                              {c.error_message && <small className="err-t">{c.error_message}</small>}
                            </div>
                            <div className="actions">
                              {c.run_id && <button className="linkbtn" onClick={() => openLogs(c, r, step)}>logs</button>}
                              {single && <button className="btn sec sm" disabled={!!whyNot} title={whyNot || 'Run only this step on this system'}
                                onClick={() => runStep(step.step_no, r.incident_asset_id, `Step ${step.step_no} on ${r.asset_name}`)}>{c.status === 'FAILED' ? 'Retry step' : 'Run step'}</button>}
                            </div>
                          </div>);
                      })}
                    </div>)}
                </div>);
            })}
            <div className="note flat">Jobs are executed by the backend worker process. If systems stay <b>Queued</b>, start it: <code>python -m bulwark.modules.execution.worker</code></div></>)}
        </div>
        <div className="card"><b>Run log</b>{run && <div className="muted small">{run.title}</div>}<br />
          <div className="log">{run ? (logs.length ? logs.map((l) => <div key={l.id} className={l.stream === 'stderr' ? 'err-t' : ''}>{new Date(l.logged_at).toLocaleTimeString()}  {l.message}</div>) : 'No output yet…') : 'Click “logs” on a system or step to view output.'}</div>
        </div>
      </div>
    </section>
  );
}

import { useState } from 'react';
import { useLocation, useNavigate, useSearchParams } from 'react-router-dom';
import { api } from '../api/endpoints';
import { useAuth } from '../auth/AuthContext';
import { Badge, Loading, Pager, Sev } from '../components/ui';
import { useAsync } from '../hooks';
import IncidentForm from './IncidentForm';

const STATUSES = ['OPEN', 'PENDING_APPROVAL', 'APPROVED', 'REJECTED', 'IN_PROGRESS', 'RESOLVED', 'CLOSED'];

export default function Incidents() {
  const { has } = useAuth();
  const nav = useNavigate();
  const location = useLocation();
  // search / filter / page live in the URL so "Back to incident list" returns to the same view
  const [params, setParams] = useSearchParams();
  const q = params.get('q') || '';
  const status = params.get('status') || '';
  const page = Number(params.get('page')) || 1;
  const setParam = (k, v) => setParams((p) => {
    const n = new URLSearchParams(p);
    if (v && v !== 1) n.set(k, v); else n.delete(k);
    if (k !== 'page') n.delete('page');
    return n;
  }, { replace: true });
  const [form, setForm] = useState(null);                 // null | {} add | incident detail edit
  const size = 15;
  const list = useAsync(() => api.incidents.list({ q, status, page, size }), [q, status, page]);
  const open = (id) => nav(`/incidents/${id}`, { state: { from: `${location.pathname}${location.search}` } });

  return (
    <section>
      <h1>Incidents</h1>
      <div className="sub">One incident per vulnerability · many impacted assets · ordered plan of approved solutions · the plan is approved before execution</div>
      <div className="toolbar">
        <input placeholder="Search incident / CVE / description…" value={q} onChange={(e) => setParam('q', e.target.value)} />
        <select value={status} onChange={(e) => setParam('status', e.target.value)}><option value="">All statuses</option>{STATUSES.map((s) => <option key={s} value={s}>{s.replace(/_/g, ' ')}</option>)}</select>
        <button className="btn push" disabled={!has('ANALYST', 'OPERATOR')} title={has('ANALYST', 'OPERATOR') ? '' : 'Requires ANALYST role'} onClick={() => setForm({})}>+ Add incident</button>
      </div>
      <div className="card">
        {list.error ? <Loading error={list.error} onRetry={list.reload} /> : !list.data ? <Loading /> : (<>
          <table><thead><tr><th>Incident</th><th>Vulnerability</th><th>Severity</th><th>Assignee</th><th>Assets</th><th>Plan steps</th><th>Patched</th><th>Status</th><th>Actions</th></tr></thead>
            <tbody>{list.data.items.map((i) => (
              <tr key={i.id} className="click" onClick={() => open(i.id)}>
                <td><b>{i.code}</b></td>
                <td>{i.vulnerability.cve_id}<div className="muted small">{i.title}</div>{i.description && <div className="muted small italic">{i.description}</div>}</td>
                <td><Sev value={i.severity} /></td><td>{i.assignee?.full_name || '—'}</td><td>{i.assets_count}</td><td>{i.plan_steps}</td>
                <td><div className="bar-p"><i style={{ width: `${i.assets_count ? (i.patched_count * 100) / i.assets_count : 0}%` }} /></div><small>{i.patched_count}/{i.assets_count}</small></td>
                <td><Badge value={i.status} /></td>
                <td className="actions" onClick={(e) => e.stopPropagation()}>
                  <button className="btn sec sm" onClick={() => open(i.id)}>View</button>
                  <button className="btn sec sm" disabled={!has('ANALYST', 'OPERATOR')}
                    onClick={async () => setForm(await api.incidents.get(i.id))}>Edit</button></td></tr>))}
              {!list.data.items.length && <tr><td colSpan="9" className="muted">No incidents.</td></tr>}</tbody></table>
          <Pager page={page} size={size} total={list.data.total} onPage={(p) => setParam('page', p)} /></>)}
      </div>
      {form && <IncidentForm incident={form.id ? form : null} onClose={() => setForm(null)} onSaved={() => { setForm(null); list.reload(); }} />}
    </section>
  );
}

import { useEffect, useMemo, useState } from 'react';
import { useLocation, useNavigate, useParams } from 'react-router-dom';
import { api } from '../api/endpoints';
import { useAuth } from '../auth/AuthContext';
import { Badge, ConfirmModal, Loading, Modal, PromptModal, Sev, useAction } from '../components/ui';
import { notifyChanged } from '../components/Layout';
import { fmt, pretty, useAsync } from '../hooks';
import IncidentForm from './IncidentForm';
import { SolutionForm } from './Solutions';

const toRow = (p) => ({ solution_id: p.solution_id, title: p.title, executor: p.executor, version_no: p.version_no, on_failure: p.on_failure, version_status: p.version_status });

export default function IncidentView() {
  const { id } = useParams();
  const { has } = useAuth();
  const act = useAction();
  const nav = useNavigate();
  const location = useLocation();
  const [inc, setInc] = useState(null);
  const [err, setErr] = useState(null);
  const [plan, setPlan] = useState([]);
  const [approved, setApproved] = useState([]);
  const [sugg, setSugg] = useState([]);
  const [pick, setPick] = useState('');
  const [exclude, setExclude] = useState(null);
  const [editing, setEditing] = useState(false);
  const [closing, setClosing] = useState(false);
  const [clearing, setClearing] = useState(false);

  const load = async () => {
    try {
      const d = await api.incidents.get(id);
      setInc(d); setPlan(d.plan.map(toRow)); setErr(null);
      if (d.editable) {
        const a = await api.solutions.list({ status: 'APPROVED', size: 100 });
        setApproved(a.items);
        // "Nearby solutions" section is hidden for now; restore with it:
        // setSugg(await api.solutions.suggestions(id, 5));
      }
    } catch (e) { setErr(e); }
  };
  useEffect(() => { setInc(null); setErr(null); load(); }, [id]);   // eslint-disable-line react-hooks/exhaustive-deps

  const dirty = useMemo(() => inc && JSON.stringify(plan.map((p) => [p.solution_id, p.on_failure])) !== JSON.stringify(inc.plan.map((p) => [p.solution_id, p.on_failure])), [plan, inc]);
  const available = approved.filter((s) => !plan.some((p) => p.solution_id === s.id));

  const move = (i, d) => setPlan((p) => { const n = [...p]; [n[i], n[i + d]] = [n[i + d], n[i]]; return n; });
  const add = (s) => { setPlan((p) => [...p, { solution_id: s.id ?? s.solution_id, title: s.title, executor: s.executor, version_no: s.latest_version_no ?? '', on_failure: 'STOP_ASSET', version_status: 'APPROVED' }]); setPick(''); };   // only approved solutions can be added

  const savePlan = async () => { if (await act(() => api.incidents.replacePlan(id, plan.map(({ solution_id, on_failure }) => ({ solution_id, on_failure }))), 'Plan saved')) { await load(); notifyChanged(); } };
  const submit = async () => { if (await act(() => api.incidents.submit(id), 'Submitted for approval')) { await load(); notifyChanged(); } };
  const clearPlan = async () => {
    if (!inc.plan.length) { setPlan([]); return true; }          // only unsaved steps: nothing stored to delete
    const ok = await act(() => api.incidents.clearPlan(id), 'Solution plan cleared');
    if (ok) { await load(); notifyChanged(); }
    return ok;
  };
  const close = async () => { const ok = await act(() => api.incidents.close(id), 'Incident closed'); if (ok) { await load(); notifyChanged(); } return ok; };

  // back to the list the user came from (keeps its search / filter / page), else the plain list
  const back = <button className="btn sec sm back" onClick={() => nav(location.state?.from || '/incidents')}>‹ Back to incident list</button>;
  if (!inc) return <section>{back}<div className="card"><Loading error={err} onRetry={load} /></div></section>;
  const canWrite = has('ANALYST', 'OPERATOR');
  const canPlan = inc.editable;                 // any signed-in user may change the solution plan for now (API matches)
  const runnable = ['APPROVED', 'IN_PROGRESS', 'RESOLVED'].includes(inc.status);
  const unapproved = inc.plan.filter((p) => p.version_status !== 'APPROVED');     // e.g. solutions created from AI drafts
  const submitWhy = dirty ? 'Save the plan first' : unapproved.length ? `Waiting for solution approval: ${unapproved.map((p) => p.title).join(', ')}` : '';

  return (
    <section>
      {back}
      <div className="toolbar">
        <h1>{inc.code} · {inc.vulnerability.cve_id}</h1>
        <div className="actions push">
          {canWrite && inc.status !== 'CLOSED' && inc.status !== 'IN_PROGRESS' && <button className="btn sec" onClick={() => setClosing(true)}>Close incident</button>}
          {canWrite && <button className="btn sec" onClick={() => setEditing(true)}>Edit</button>}
          {runnable && <button className="btn sec" onClick={() => nav(`/execution?incident=${inc.id}`)}>Go to Execution →</button>}
          {inc.editable && canWrite && <button className="btn" disabled={!!submitWhy || !plan.length} title={submitWhy} onClick={submit}>Submit for approval</button>}
        </div>
      </div>
      <div className="card">
        <p><Badge value={inc.status} /> &nbsp; <Sev value={inc.severity} /> · Assignee <b>{inc.assignee?.full_name || '—'}</b> · {inc.title}</p>
        <div className="two">
          <div><h4>Incident description</h4><div className="note flat">{inc.description || <i>No description</i>}</div></div>
          <div><h4>Vulnerability description</h4><VulnDesc vid={inc.vulnerability.id} /></div>
        </div>
        {inc.status === 'PENDING_APPROVAL' && <div className="note">Waiting for incident approval{inc.approval ? ` (submitted by ${inc.approval.requested_by})` : ''}. Plan and assets are locked.</div>}
        {inc.status === 'REJECTED' && <div className="note err">Rejected{inc.approval?.comment ? `: ${inc.approval.comment}` : ''}. Adjust the plan and submit again.</div>}
        {inc.status === 'APPROVED' && <div className="note">Approved by {inc.approval?.decided_by} on {fmt(inc.approval?.decided_at)}. Ready to execute.</div>}

        <h4>Impacted assets ({inc.assets.filter((a) => a.status !== 'EXCLUDED').length})</h4>
        <table><thead><tr><th>Asset</th><th>Environment</th><th>Status</th><th></th></tr></thead>
          <tbody>{inc.assets.map((a) => (
            <tr key={a.incident_asset_id} className={a.status === 'EXCLUDED' ? 'inactive' : ''}>
              <td>{a.asset.name}</td><td>{a.asset.environment}</td>
              <td><Badge value={a.status} />{a.last_error && <div className="small err-t">{a.last_error}</div>}{a.exclude_reason && <div className="small muted">{a.exclude_reason}</div>}</td>
              <td>{canWrite && !['EXCLUDED', 'PATCHED'].includes(a.status) && ['APPROVED', 'IN_PROGRESS'].includes(inc.status) &&
                <button className="btn sec sm" onClick={() => setExclude(a)}>Exclude</button>}</td></tr>))}</tbody></table>

        <h4>Solution plan (runs in this order)
          {canPlan && plan.length > 0 && <button className="linkbtn" onClick={() => setClearing(true)}>Clear solution plan</button>}</h4>
        {!plan.length && <div className="note">No solutions in the plan yet.</div>}
        {plan.map((p, i) => (
          <div className="step" key={p.solution_id}>
            <div className="no">{i + 1}</div>
            <div className="grow"><b>{p.title}</b><small>{p.executor}{p.version_no ? ` · v${p.version_no}` : ''}</small></div>
            {p.version_status && <Badge value={p.version_status} />}
            <select disabled={!inc.editable} value={p.on_failure} onChange={(e) => setPlan((x) => x.map((r, j) => (j === i ? { ...r, on_failure: e.target.value } : r)))}>
              {['STOP_ASSET', 'CONTINUE', 'STOP_ALL'].map((o) => <option key={o} value={o}>On failure: {pretty(o).toLowerCase()}</option>)}</select>
            <button className="btn sec sm" disabled={!inc.editable || i === 0} onClick={() => move(i, -1)}>▲</button>
            <button className="btn sec sm" disabled={!inc.editable || i === plan.length - 1} onClick={() => move(i, 1)}>▼</button>
            <button className="btn sec sm" disabled={!inc.editable} onClick={() => setPlan((x) => x.filter((_, j) => j !== i))}>Remove</button>
          </div>))}

        {canPlan && (<>
          <div className="row">
            <select value={pick} onChange={(e) => setPick(e.target.value)}>
              <option value="">{available.length ? 'Add an approved solution…' : 'No approved solutions available'}</option>
              {available.map((s) => <option key={s.id} value={s.id}>{s.title} (v{s.latest_version_no})</option>)}</select>
            <button className="btn" disabled={!pick} onClick={() => add(available.find((s) => s.id === pick))}>+ Add step</button>
            <button className="btn" disabled={!dirty} onClick={savePlan}>Save plan</button>
          </div>
          {dirty && <small className="muted">Unsaved plan changes. Save before submitting for approval.</small>}
          {unapproved.length > 0 && <div className="note">{unapproved.length} solution{unapproved.length === 1 ? ' is' : 's are'} waiting for approval under Approvals → Solution approvals. The incident can be submitted once {unapproved.length === 1 ? 'it is' : 'they are'} approved.</div>}
          {/* Hidden for now: keyword-overlap suggestions (GET /solutions/suggestions) were mostly noise.
              Re-enable together with the api.solutions.suggestions call in load().
          {sugg.filter((s) => !plan.some((p) => p.solution_id === s.solution_id)).length > 0 && (<>
            <h4>Nearby solutions (suggested)</h4>
            {sugg.filter((s) => !plan.some((p) => p.solution_id === s.solution_id)).map((s) => (
              <div className="step" key={s.solution_id}>
                <div className="grow"><b>{s.title}</b><small>{s.rationale} · match {(s.score * 100).toFixed(0)}% · {s.source}</small></div>
                <button className="btn sm" onClick={() => add(s)}>Add to plan</button></div>))}</>)}
          */}
        </>)}
      </div>
      <OtherSolutions incident={inc} canMap={canPlan} dirty={dirty} onMapped={async () => { await load(); notifyChanged(); }} />
      {exclude &&<PromptModal title={`Exclude ${exclude.asset.name}`} label="Reason" confirmText="Exclude" onClose={() => setExclude(null)}
        onSubmit={async (reason) => { const r = await act(() => api.incidents.excludeAsset(id, exclude.incident_asset_id, reason), 'Asset excluded'); if (r) { await load(); notifyChanged(); } return r; }} />}
      {clearing && <ConfirmModal title={`Clear solution plan of ${inc.code}`} confirmText="Clear solution plan" danger onConfirm={clearPlan} onClose={() => setClearing(false)}>
        <p>Remove all <b>{plan.length}</b> step{plan.length === 1 ? '' : 's'} from the solution plan{dirty ? ', including unsaved changes' : ''}?</p></ConfirmModal>}
      {closing && <ConfirmModal title={`Close ${inc.code}`} confirmText="Close incident" danger onConfirm={close} onClose={() => setClosing(false)}>
        <p>Close this incident? It can no longer be planned or executed.</p></ConfirmModal>}
      {editing && <IncidentForm incident={inc} onClose={() => setEditing(false)} onSaved={() => { setEditing(false); load(); }} />}
    </section>
  );
}

function OtherSolutions({ incident, ...props }) {
  const [tab, setTab] = useState('similar');
  return (
    <div className="card section">
      <h4 className="flush">Other suggested solutions</h4>
      <div className="subtabs">
        <span className={tab === 'similar' ? 'on' : ''} onClick={() => setTab('similar')}>Similar incident solutions</span>
        <span className={tab === 'ai' ? 'on' : ''} onClick={() => setTab('ai')}>AI Suggested</span>
      </div>
      {tab === 'similar' ? <SimilarIncidents incident={incident} {...props} /> : <AiSuggested incident={incident} {...props} />}
    </div>
  );
}

/** Matches written by the solution recommender (incident_similar_matches); the plan comes from the similar incident. */
function SimilarIncidents({ incident, canMap, dirty, onMapped }) {
  const nav = useNavigate();
  const act = useAction();
  const list = useAsync(() => api.incidents.similar(incident.id), [incident.id]);
  const [plan, setPlan] = useState(null);           // the similar incident whose plan is shown in the popup
  const [chosen, setChosen] = useState('');         // similar incident whose plan will be mapped
  const [confirm, setConfirm] = useState(false);
  if (!list.data) return <Loading error={list.error} onRetry={list.reload} />;

  const source = list.data.find((s) => s.incident_id === chosen);
  const map = async () => {
    const ok = await act(() => api.incidents.copyPlan(incident.id, source.incident_id), `Solution plan of ${source.code} mapped`);
    if (ok) { setChosen(''); await onMapped(); }
    return ok;
  };
  const why = canMap ? '' : 'The plan can only change while the incident is Open or Rejected';

  return (<>
    <table><thead><tr><th></th><th>Similar incident</th><th>Vulnerability</th><th>Similarity</th><th>Solution steps</th><th>Status</th></tr></thead>
      <tbody>{list.data.map((s) => (
        <tr key={`${s.engine}-${s.incident_id}`} className={chosen === s.incident_id ? 'sel' : ''}>
          <td className="pick"><input type="radio" name="similar-plan" aria-label={`Select ${s.code}`} disabled={!canMap || !s.plan.length}
            checked={chosen === s.incident_id} onChange={() => setChosen(s.incident_id)} /></td>
          <td><button className="linkbtn big" onClick={() => nav(`/incidents/${s.incident_id}`)}>{s.code}</button><div className="muted small">{s.title}</div></td>
          <td>{s.cve_id}</td>
          <td>{(s.similarity * 100).toFixed(0)}%</td>
          <td><button className="btn sec sm" onClick={() => setPlan(s)}>{s.plan.length} step{s.plan.length === 1 ? '' : 's'}</button></td>
          <td><Badge value={s.status} /></td></tr>))}
        {!list.data.length && <tr><td colSpan="6" className="muted">No similar incidents found yet.</td></tr>}</tbody></table>
    {list.data.length > 0 && (
      <div className="row end">
        {why && <small className="muted">{why}</small>}
        <button className="btn" disabled={!source} title={source ? '' : 'Select a similar incident first'} onClick={() => setConfirm(true)}>Map Solution Plan</button>
      </div>)}
    {plan && (
      <Modal title={`${plan.code} · solution plan`} onClose={() => setPlan(null)} wide>
        <p className="muted">{plan.title} · {plan.cve_id}</p>
        <PlanSteps steps={plan.plan} />
      </Modal>)}
    {confirm && source && (
      <ConfirmModal title="Map solution plan" confirmText="Map Solution Plan" wide onConfirm={map} onClose={() => setConfirm(false)}>
        <p>Map the <b>{source.plan.length}-step</b> solution plan of <b>{source.code}</b> to <b>{incident.code}</b>?</p>
        <PlanSteps steps={source.plan} />
        {(incident.plan.length > 0 || dirty) && <div className="note err">The current plan ({incident.plan.length} step{incident.plan.length === 1 ? '' : 's'}{dirty ? ', plus unsaved changes' : ''}) will be replaced.</div>}
        <small className="muted">Each solution is mapped to its latest approved version.</small>
      </ConfirmModal>)}
  </>);
}

const OUTCOME = { FULL_PLAN: 'Full plan', PARTIAL_PLAN: 'Partial plan · solutions to develop', NO_MATCH: 'No approved solution fits', FAILED: 'Failed' };
const DRAFT = { OPEN: 'To develop', IN_DEVELOPMENT: 'In development', CREATED: 'Solution created', REJECTED: 'Rejected' };
const live = (d) => ['OPEN', 'IN_DEVELOPMENT'].includes(d.status);

// Once a solution exists for a draft, show that solution's live status rather than the draft's "Solution created".
const SOLUTION_NOTE = {
  REVIEW_PENDING: 'waiting for approval under Approvals → Solution approvals',
  APPROVED: 'approved, can be planned',
  CHANGES_REQUESTED: 'the reviewer requested changes',
  REJECTED: 'rejected by the reviewer',
  RETIRED: 'retired, can no longer be planned',
};
const draftBadge = (d) => (d.created_solution_status
  ? <Badge value={d.created_solution_status} label={`Solution ${pretty(d.created_solution_status).toLowerCase()}`} />
  : <Badge value={d.status === 'OPEN' ? 'PENDING' : d.status} label={DRAFT[d.status]} />);

/** Steps and drafts in run order: drafts sit after the step given by position_after_step (0 = before step 1). */
const sequence = (p) => [
  ...p.drafts.filter((d) => d.position_after_step === 0).map((d) => ({ draft: d })),
  ...p.steps.flatMap((s) => [{ step: s }, ...p.drafts.filter((d) => d.position_after_step === s.step_no).map((d) => ({ draft: d }))]),
  ...p.drafts.filter((d) => d.position_after_step > p.steps.length).map((d) => ({ draft: d })),
];

const draftToSolution = (d, incident) => ({
  title: d.title, executor: d.executor, risk_level: d.risk_level, applies_to: d.applies_to || '', requires_reboot: d.requires_reboot,
  description: `${d.problem}\n\nProposed procedure (AI draft from ${incident.code}):\n${d.proposed_procedure.map((s, i) => `${i + 1}. ${s}`).join('\n')}`,
});

/** Written by the solution recommender's ai-planner engine (Gemini Flash): approved solutions in run order + solutions still to build. */
function AiSuggested({ incident, canMap, dirty, onMapped }) {
  const act = useAction();
  const { has } = useAuth();
  const ai = useAsync(() => api.incidents.aiPlan(incident.id), [incident.id]);
  const [confirm, setConfirm] = useState(false);
  const [dismissing, setDismissing] = useState(false);
  const [building, setBuilding] = useState(null);             // draft opened in the solution form
  if (ai.error) return <Loading error={ai.error} onRetry={ai.reload} />;
  if (ai.loading && !ai.data) return <Loading />;
  const p = ai.data;
  if (!p) return <div className="note">No AI suggestion yet. The solution recommender creates one when the incident is created or updated.</div>;

  const canDev = has('ANALYST');
  const blocked = p.steps.filter((s) => !s.plannable);
  const included = p.drafts.filter((d) => d.status !== 'REJECTED');          // become plan steps on Apply
  const toCreate = included.filter((d) => !d.created_solution_id);           // ...after a solution is created for them
  const awaiting = included.filter((d) => !d.created_solution_has_approved); // not plannable for submit until approved
  const applySeq = sequence(p).filter(({ draft: d }) => !d || d.status !== 'REJECTED');
  const why = !canMap ? 'The plan can only change while the incident is Open or Rejected'
    : blocked.length ? 'Some suggested solutions are no longer approved' : '';
  const apply = async () => {
    const ok = await act(() => api.incidents.applyAiPlan(incident.id, p.plan_id),
      `AI suggested plan applied${toCreate.length ? ` · ${toCreate.length} solution(s) created for approval` : ''}`);
    if (ok) { await onMapped(); ai.reload(); }
    return ok;
  };
  const dismiss = async (comment) => {
    const ok = await act(() => api.incidents.dismissAiPlan(incident.id, p.plan_id, comment || null), 'AI suggestion dismissed');
    if (ok) ai.reload();
    return ok;
  };
  const setDraft = async (d, body, msg) => { if (await act(() => api.incidents.updateAiDraft(incident.id, d.id, body), msg)) ai.reload(); };

  return (<>
    <p>
      <Badge value={p.outcome} label={OUTCOME[p.outcome]} /> &nbsp;
      {p.confidence != null && <>Confidence <b>{Math.round(p.confidence * 100)}%</b> · </>}
      <span className="muted small">{p.llm_model} · {p.catalog_size} approved solution{p.catalog_size === 1 ? '' : 's'} considered · {fmt(p.generated_at)}{p.reused ? ' · unchanged since the last suggestion' : ''}</span>
      {p.review_status !== 'NEW' && <> &nbsp;<Badge value={p.review_status} /> <span className="muted small">by {p.reviewed_by || '—'} · {fmt(p.reviewed_at)}</span></>}
    </p>
    {p.outcome === 'FAILED' && <div className="note err">The AI could not produce a valid plan: {p.error}</div>}
    {p.rationale && <div className="note flat">{p.rationale}</div>}
    {p.review_comment && <small className="muted">Dismiss reason: {p.review_comment}</small>}

    {sequence(p).map(({ step: s, draft: d }) => (s ? (
      <div className="step" key={`s${s.step_no}`}>
        <div className="no">{s.step_no}</div>
        <div className="grow"><b>{s.title}</b>
          <small>{s.executor} · v{s.version_no} · risk {pretty(s.risk_level).toLowerCase()}{s.requires_reboot ? ' · reboot' : ''} · on failure: {pretty(s.on_failure).toLowerCase()}</small>
          {s.reason && <small className="reason">{s.reason}</small>}</div>
        {s.plannable ? <Badge value="APPROVED" /> : <Badge value="REJECTED" label="No longer approved" />}
      </div>) : (
      <div className="step draft" key={d.id}>
        <div className="no">+</div>
        <div className="grow"><b>{d.title}</b> &nbsp;{draftBadge(d)}
          <small>New solution needed · {d.executor}{d.applies_to ? ` · ${d.applies_to}` : ''} · risk {pretty(d.risk_level).toLowerCase()}{d.requires_reboot ? ' · reboot' : ''}</small>
          <small className="reason">{d.problem}</small>
          {d.proposed_procedure.length > 0 && <ol>{d.proposed_procedure.map((x, i) => <li key={i}>{x}</li>)}</ol>}
          {d.created_solution_title && <small>Solution: <b>{d.created_solution_title}</b>{d.created_solution_version_no ? ` v${d.created_solution_version_no}` : ''} · {SOLUTION_NOTE[d.created_solution_status] || pretty(d.created_solution_status || '')}
            {d.created_solution_status !== 'APPROVED' && d.created_solution_status !== 'RETIRED' && d.created_solution_has_approved ? ' · an earlier version is approved and can be planned' : ''}</small>}</div>
        {canDev && (
          <div className="actions">
            {live(d) && <button className="btn sm" onClick={() => setBuilding(d)}>Create solution</button>}
            {d.status === 'OPEN' && <button className="btn sec sm" onClick={() => setDraft(d, { status: 'IN_DEVELOPMENT' }, 'Marked as in development')}>In development</button>}
            {live(d) && <button className="btn sec sm" onClick={() => setDraft(d, { status: 'REJECTED' }, 'Draft rejected')}>Reject</button>}
            {d.status === 'REJECTED' && <button className="btn sec sm" onClick={() => setDraft(d, { status: 'OPEN' }, 'Draft reopened')}>Reopen</button>}
          </div>)}
      </div>)))}

    {p.outcome !== 'FAILED' && (
      <div className="row end">
        {applySeq.length > 0 && why && <small className="muted">{why}</small>}
        {p.review_status === 'NEW' && <button className="btn sec" onClick={() => setDismissing(true)}>Dismiss</button>}
        {applySeq.length > 0 && <button className="btn" disabled={!!why} title={why} onClick={() => setConfirm(true)}>Apply AI Plan</button>}
      </div>)}
    {toCreate.length > 0 && <small className="muted">Apply AI Plan creates the solution{toCreate.length === 1 ? '' : 's'} still to develop (Review Pending) and puts {toCreate.length === 1 ? 'it' : 'them'} in the plan in the suggested order.</small>}

    {confirm && (
      <ConfirmModal title="Apply AI suggested plan" confirmText="Apply AI Plan" wide onConfirm={apply} onClose={() => setConfirm(false)}>
        <p>Apply the <b>{applySeq.length}-step</b> AI suggested plan to <b>{incident.code}</b>?</p>
        {applySeq.map(({ step: s, draft: d }, n) => (s ? (
          <div className="step" key={`s${s.step_no}`}><div className="no">{n + 1}</div>
            <div className="grow"><b>{s.title}</b><small>{s.executor} · on failure: {pretty(s.on_failure).toLowerCase()}</small></div>
            <Badge value="APPROVED" /></div>) : (
          <div className="step draft" key={d.id}><div className="no">{n + 1}</div>
            <div className="grow"><b>{d.created_solution_title || d.title}</b>
              <small>{d.executor} · on failure: stop asset · {d.created_solution_id ? 'solution already created from this draft' : 'new solution will be created'}</small></div>
            <Badge value={d.created_solution_has_approved ? 'APPROVED' : d.created_solution_status || 'REVIEW_PENDING'} /></div>)))}
        {(incident.plan.length > 0 || dirty) && <div className="note err">The current plan ({incident.plan.length} step{incident.plan.length === 1 ? '' : 's'}{dirty ? ', plus unsaved changes' : ''}) will be replaced.</div>}
        {awaiting.length > 0 && <div className="note">
          {toCreate.length > 0 && <>{toCreate.length} new solution{toCreate.length === 1 ? '' : 's'} will be created with status <b>Review Pending</b> and sent to Approvals → Solution approvals. </>}
          The incident can be submitted for approval once {awaiting.length === 1 ? 'this solution is' : `these ${awaiting.length} solutions are`} approved.</div>}
        <small className="muted">Approved solutions are mapped to their latest approved version.</small>
      </ConfirmModal>)}
    {dismissing && <PromptModal title="Dismiss AI suggestion" label="Reason (optional, helps improve the suggestions)" required={false}
      confirmText="Dismiss" onSubmit={dismiss} onClose={() => setDismissing(false)} />}
    {building && <SolutionForm initial={draftToSolution(building, incident)} onClose={() => setBuilding(null)}
      onSaved={async (sol) => { const d = building; setBuilding(null); await setDraft(d, { status: 'CREATED', created_solution_id: sol.id }, 'Draft linked to the new solution'); }} />}
  </>);
}

function PlanSteps({ steps }) {
  return steps.map((p) => (
    <div className="step" key={p.plan_step_id}>
      <div className="no">{p.step_no}</div>
      <div className="grow"><b>{p.title}</b><small>{p.executor} · v{p.version_no} · risk {pretty(p.risk_level).toLowerCase()} · on failure: {pretty(p.on_failure).toLowerCase()}</small></div>
      <Badge value={p.version_status} />
    </div>));
}

function VulnDesc({ vid }) {
  const [v, setV] = useState(null);
  useEffect(() => { api.vulnerabilities.get(vid).then(setV).catch(() => setV({ description: null })); }, [vid]);
  return <div className="note flat">{v ? (v.description || <i>No description</i>) : 'Loading…'}</div>;
}

import { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react';
import { pretty } from '../hooks';

/* ---------- Combobox (type-ahead dropdown) ---------- */
/** Type to filter (every word must match label or hint), ↑/↓ + Enter to pick, Esc to close.
    options: [{ value, label, hint? }] */
export function Combobox({ options, value, onChange, placeholder = 'Type to search…', empty = 'No matches', ariaLabel }) {
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState('');
  const [hi, setHi] = useState(0);
  const listRef = useRef(null);
  const sel = options.find((o) => o.value === value);
  const words = q.trim().toLowerCase().split(/\s+/).filter(Boolean);
  const list = words.length ? options.filter((o) => words.every((w) => `${o.label} ${o.hint || ''}`.toLowerCase().includes(w))) : options;
  useEffect(() => setHi(0), [q]);
  useEffect(() => { listRef.current?.children[hi]?.scrollIntoView({ block: 'nearest' }); }, [hi, open]);
  const close = () => { setOpen(false); setQ(''); };
  const pick = (o) => { onChange(o.value); close(); };
  const onKey = (e) => {
    if (e.key === 'ArrowDown') { e.preventDefault(); setOpen(true); setHi((i) => Math.min(i + 1, list.length - 1)); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); setHi((i) => Math.max(i - 1, 0)); }
    else if (e.key === 'Enter' && open && list[hi]) { e.preventDefault(); pick(list[hi]); }
    else if (e.key === 'Escape' && open) { e.stopPropagation(); close(); }
  };
  return (
    <div className="combo">
      <input role="combobox" aria-expanded={open} aria-label={ariaLabel} aria-autocomplete="list"
        value={open ? q : sel?.label || ''} placeholder={sel?.label || placeholder}
        onFocus={() => setOpen(true)} onClick={() => setOpen(true)} onBlur={close}
        onChange={(e) => { setQ(e.target.value); setOpen(true); }} onKeyDown={onKey} />
      <span className="caret" aria-hidden="true">▾</span>
      {open && (
        <ul role="listbox" ref={listRef}>
          {list.length ? list.map((o, i) => (
            <li key={o.value} role="option" aria-selected={o.value === value} className={`${i === hi ? 'hi' : ''} ${o.value === value ? 'cur' : ''}`}
              onMouseDown={(e) => { e.preventDefault(); pick(o); }} onMouseEnter={() => setHi(i)}>
              <span>{o.label}</span>{o.hint && <small>{o.hint}</small>}</li>))
            : <li className="none">{empty}</li>}
        </ul>)}
    </div>
  );
}

/* ---------- Badge ---------- */
const TONE = {
  APPROVED: 'ok', RESOLVED: 'ok', SUCCEEDED: 'ok', PATCHED: 'ok', ACTIVE: 'ok', FULL_PLAN: 'ok', APPLIED: 'ok', CREATED: 'ok',
  REVIEW_PENDING: 'pend', PENDING_APPROVAL: 'pend', QUEUED: 'pend', PENDING: 'pend', PARTIAL_PLAN: 'pend',
  REJECTED: 'bad', FAILED: 'bad',
  IN_PROGRESS: 'info', RUNNING: 'info', IN_DEVELOPMENT: 'info', NEW: 'info',
};
export function Badge({ value, label }) {
  return <span className={`badge b-${TONE[value] || 'gray'}`}>{label || pretty(value)}</span>;
}
export const Sev = ({ value }) => <span className={`sev-${value}`}>{pretty(value)}</span>;

/* ---------- Modal ---------- */
export function Modal({ title, onClose, children, footer, wide }) {
  useEffect(() => {
    const h = (e) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, [onClose]);
  return (
    <div className="overlay" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className={`modal ${wide ? 'wide' : ''}`} role="dialog" aria-label={title}>
        <div className="mh"><span>{title}</span><button className="x" onClick={onClose} aria-label="Close">✕</button></div>
        <div className="mb">{children}</div>
        {footer && <div className="mf">{footer}</div>}
      </div>
    </div>
  );
}

/* ---------- Toasts ---------- */
const ToastCtx = createContext(null);
export function ToastProvider({ children }) {
  const [items, setItems] = useState([]);
  const push = useCallback((text, kind = 'ok') => {
    const id = Math.random();
    setItems((x) => [...x, { id, text, kind }]);
    setTimeout(() => setItems((x) => x.filter((i) => i.id !== id)), kind === 'err' ? 6000 : 3000);
  }, []);
  return (
    <ToastCtx.Provider value={push}>
      {children}
      <div className="toasts">{items.map((i) => <div key={i.id} className={`toast ${i.kind}`}>{i.text}</div>)}</div>
    </ToastCtx.Provider>
  );
}
export const useToast = () => useContext(ToastCtx);

/** Run an API action, toast success / error, return true on success. */
export function useAction() {
  const toast = useToast();
  return useCallback(async (fn, okText) => {
    try { const r = await fn(); if (okText) toast(okText); return r ?? true; }
    catch (e) { toast(e.message, 'err'); return false; }
  }, [toast]);
}

/* ---------- Misc ---------- */
export const Loading = ({ error, onRetry }) => error
  ? <div className="note err">{error.message} {onRetry && <button className="btn sm sec" onClick={onRetry}>Retry</button>}</div>
  : <div className="muted pad">Loading…</div>;

export function Pager({ page, size, total, onPage }) {
  const pages = Math.max(1, Math.ceil(total / size));
  return (
    <div className="pager">
      <span className="muted">{total} total</span>
      <button className="btn sm sec" disabled={page <= 1} onClick={() => onPage(page - 1)}>‹ Prev</button>
      <span>Page {page} / {pages}</span>
      <button className="btn sm sec" disabled={page >= pages} onClick={() => onPage(page + 1)}>Next ›</button>
    </div>
  );
}

export function Field({ label, children, hint }) {
  return <div className="field"><label>{label}</label>{children}{hint && <small className="muted">{hint}</small>}</div>;
}

export function AssetPicker({ assets, value, onChange }) {
  const toggle = (id) => onChange(value.includes(id) ? value.filter((x) => x !== id) : [...value, id]);
  if (!assets.length) return <div className="muted">No assets found. Seed assets first (backend: python scripts/seed.py).</div>;
  return (
    <div className="checks">
      {assets.map((a) => (
        <label key={a.id}><input type="checkbox" checked={value.includes(a.id)} onChange={() => toggle(a.id)} />
          {a.name} <small className="muted">{a.environment}</small></label>))}
    </div>
  );
}

/** In-app replacement for window.confirm. `onConfirm` returns truthy to close the dialog. */
export function ConfirmModal({ title, children, confirmText = 'Confirm', danger, wide, onConfirm, onClose }) {
  const [busy, setBusy] = useState(false);
  return (
    <Modal title={title} onClose={onClose} wide={wide} footer={<>
      <button className="btn sec" onClick={onClose}>Cancel</button>
      <button className={`btn ${danger ? 'danger' : ''}`} disabled={busy} autoFocus
        onClick={async () => { setBusy(true); const r = await onConfirm(); setBusy(false); if (r) onClose(); }}>{confirmText}</button></>}>
      {children}
    </Modal>
  );
}

export function PromptModal({ title, label, required = true, confirmText = 'Confirm', danger, onSubmit, onClose }) {
  const [text, setText] = useState('');
  const [busy, setBusy] = useState(false);
  const ok = !required || text.trim().length >= 3;
  return (
    <Modal title={title} onClose={onClose} footer={<>
      <button className="btn sec" onClick={onClose}>Cancel</button>
      <button className={`btn ${danger ? 'danger' : ''}`} disabled={!ok || busy}
        onClick={async () => { setBusy(true); const r = await onSubmit(text.trim()); setBusy(false); if (r) onClose(); }}>{confirmText}</button></>}>
      <Field label={label}><textarea rows="3" value={text} onChange={(e) => setText(e.target.value)} autoFocus /></Field>
    </Modal>
  );
}

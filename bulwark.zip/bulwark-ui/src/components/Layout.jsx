import { useEffect, useState } from 'react';
import { NavLink, Outlet } from 'react-router-dom';
import { api } from '../api/endpoints';
import { getApiBase, setApiBase } from '../config';
import { ping, getToken } from '../api/client';
import { useAuth } from '../auth/AuthContext';
import { Field, Modal } from './ui';

function SettingsModal({ onClose }) {
  const { login, logout } = useAuth();
  const [url, setUrl] = useState(getApiBase());
  const [token, setToken] = useState(getToken());
  const [msg, setMsg] = useState(null);
  const test = async () => {
    setApiBase(url);
    try { await ping(); setMsg({ ok: true, t: `Connected to ${getApiBase()}` }); } catch (e) { setMsg({ ok: false, t: e.message }); }
  };
  const save = () => { setApiBase(url); if (token !== getToken()) login(token.trim()); onClose(); window.location.reload(); };
  return (
    <Modal title="Settings" onClose={onClose} footer={<>
      <button className="btn sec" onClick={logout}>Sign out</button>
      <button className="btn sec" onClick={test}>Test connection</button>
      <button className="btn" onClick={save}>Save & reload</button></>}>
      <Field label="Backend API URL" hint="Overrides public/config.js for this browser. Leave empty to use the default."><input value={url} onChange={(e) => setUrl(e.target.value)} /></Field>
      <Field label="Access token (JWT)"><textarea rows="3" value={token} onChange={(e) => setToken(e.target.value)} /></Field>
      {msg && <div className={`note ${msg.ok ? '' : 'err'}`}>{msg.t}</div>}
    </Modal>
  );
}

// [group heading, [[path, label, summary count shown as the badge, what the badge counts (tooltip)]]]
const NAV = [
  ['Operations', [
    ['/', 'Dashboard', null],
    ['/incidents', 'Incidents', 'open_incidents', (c) => `${c.open_incidents} open (not resolved or closed) of ${c.incidents_total} incidents`],
    ['/approvals', 'Approvals', 'approvals_waiting', (c) => `${c.incidents_pending_approval} incident approval(s) + ${c.solutions_pending_review} solution review(s) pending`],
    ['/execution', 'Execution', 'incidents_in_execution',
      (c) => `${c.incidents_in_execution} incident(s) approved or in progress · jobs: ${c.jobs_running} running, ${c.jobs_queued} queued`],
  ]],
  ['Source', [
    ['/vulnerabilities', 'Vulnerabilities', 'active_vulnerabilities', (c) => `${c.active_vulnerabilities} active of ${c.vulnerabilities_total} vulnerabilities`],
    ['/solutions', 'Solutions', null],
    ['/assets', 'Assets', 'inventory_assets_active', (c) => `${c.inventory_assets_active} active of ${c.inventory_assets_total} assets`],
  ]],
];

export default function Layout() {
  const { user } = useAuth();
  const [counts, setCounts] = useState({});
  const [settings, setSettings] = useState(false);

  useEffect(() => {
    let live = true;
    const load = () => api.dashboard.summary().then((s) => live && setCounts(s)).catch(() => {});
    load();
    const t = setInterval(load, 10000);
    window.addEventListener('bulwark:changed', load);
    return () => { live = false; clearInterval(t); window.removeEventListener('bulwark:changed', load); };
  }, []);

  return (
    <>
      <header>
        <img className="logo" src="/innova-logo.png" alt="Innova Solutions" />
        <span className="tag">Bulwark</span>
        <div className="me">
          <div className="avatar">{(user.name || '?').slice(0, 2).toUpperCase()}</div>
          <div><b>{user.name}</b><br /><small className="muted">{user.roles.join(' · ') || 'no roles'}</small></div>
          <button className="btn sec sm" onClick={() => setSettings(true)} title="API URL and token">⚙ Settings</button>
        </div>
      </header>
      <div className="layout">
        <aside>
          {NAV.map(([group, items]) => (
            <nav key={group} aria-label={group}>
              <div className="grp">{group}</div>
              {items.map(([to, label, key, tip]) => (
                <NavLink key={to} to={to} end={to === '/'} className={({ isActive }) => `nv ${isActive ? 'on' : ''} ${key === 'approvals_waiting' && counts[key] ? 'pend' : ''}`}>
                  <span>{label}</span>{key && counts[key] !== undefined && <span className="cnt" title={tip(counts)}>{counts[key]}</span>}
                </NavLink>))}
            </nav>))}
        </aside>
        <main><Outlet /></main>
      </div>
      {settings && <SettingsModal onClose={() => setSettings(false)} />}
    </>
  );
}

export const notifyChanged = () => window.dispatchEvent(new Event('bulwark:changed'));

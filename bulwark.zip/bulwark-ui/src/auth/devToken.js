// LOCAL DEVELOPMENT ONLY: mints an HS256 JWT in the browser from a shared secret.
// In real deployments tokens come from your identity provider and this form should be removed.
const b64url = (buf) => btoa(String.fromCharCode(...new Uint8Array(buf))).replace(/=+$/, '').replace(/\+/g, '-').replace(/\//g, '_');
const enc = (obj) => b64url(new TextEncoder().encode(JSON.stringify(obj)));

async function uuidFromName(name) {            // stable UUID per user name (sha-1, v5-style)
  const h = new Uint8Array(await crypto.subtle.digest('SHA-1', new TextEncoder().encode(`bulwark:${name}`))).slice(0, 16);
  h[6] = (h[6] & 0x0f) | 0x50;
  h[8] = (h[8] & 0x3f) | 0x80;
  const x = [...h].map((b) => b.toString(16).padStart(2, '0')).join('');
  return `${x.slice(0, 8)}-${x.slice(8, 12)}-${x.slice(12, 16)}-${x.slice(16, 20)}-${x.slice(20)}`;
}

export async function mintDevToken({ name, roles, secret }) {
  const header = enc({ alg: 'HS256', typ: 'JWT' });
  const payload = enc({
    sub: await uuidFromName(name.toLowerCase()),
    email: `${name.toLowerCase().replace(/\s+/g, '.')}@example.com`,
    name,
    roles,
    exp: Math.floor(Date.now() / 1000) + 8 * 3600,
  });
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  const sig = await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(`${header}.${payload}`));
  return `${header}.${payload}.${b64url(sig)}`;
}

import { useState } from 'react';
import { getApiBase, setApiBase } from '../config';
import { ping } from '../api/client';
import { mintDevToken } from './devToken';
import { useAuth } from './AuthContext';

const ROLES = ['ANALYST', 'OPERATOR', 'APPROVER', 'ADMIN', 'VIEWER'];

export default function LoginPage() {
  const { login } = useAuth();
  const [apiUrl, setUrl] = useState(getApiBase());
  const [token, setTok] = useState('');
  const [name, setName] = useState('Srini');
  const [secret, setSecret] = useState('');
  const [roles, setRoles] = useState(['ANALYST', 'OPERATOR']);
  const [msg, setMsg] = useState(null);

  const saveUrl = () => setApiBase(apiUrl);
  const test = async () => {
    saveUrl();
    try { await ping(); setMsg({ ok: true, t: `Connected to ${getApiBase()}` }); }
    catch (e) { setMsg({ ok: false, t: e.message }); }
  };
  const useToken = () => { saveUrl(); if (token.trim()) login(token.trim()); };
  const dev = async () => {
    saveUrl();
    if (!secret) return setMsg({ ok: false, t: 'Enter the backend JWT_SECRET' });
    login(await mintDevToken({ name, roles, secret }));
  };
  const toggle = (r) => setRoles((x) => (x.includes(r) ? x.filter((y) => y !== r) : [...x, r]));

  return (
    <div className="login-wrap">
      <div className="card login">
        <img src="/innova-logo.png" alt="Innova Solutions" height="60" />
        <h2>Bulwark</h2>
        <label>Backend API URL</label>
        <div className="row">
          <input value={apiUrl} onChange={(e) => setUrl(e.target.value)} placeholder="http://localhost:8000" />
          <button className="btn sec" onClick={test}>Test</button>
        </div>
        {msg && <div className={`note ${msg.ok ? '' : 'err'}`}>{msg.t}</div>}

        <h3>Sign in with a token</h3>
        <textarea rows="3" value={token} onChange={(e) => setTok(e.target.value)} placeholder="Paste a JWT from your identity provider" />
        <button className="btn" disabled={!token.trim()} onClick={useToken}>Sign in</button>

        <details>
          <summary>Local development login (mints a token in the browser)</summary>
          <div className="note">Only for local testing. Needs the same <b>JWT_SECRET</b> the backend uses.</div>
          <label>Name</label><input value={name} onChange={(e) => setName(e.target.value)} />
          <label>Roles</label>
          <div className="checks">{ROLES.map((r) => (
            <label key={r}><input type="checkbox" checked={roles.includes(r)} onChange={() => toggle(r)} />{r}</label>))}
          </div>
          <label>JWT secret</label><input type="password" value={secret} onChange={(e) => setSecret(e.target.value)} />
          <br /><br /><button className="btn" onClick={dev}>Dev sign in</button>
        </details>
      </div>
    </div>
  );
}

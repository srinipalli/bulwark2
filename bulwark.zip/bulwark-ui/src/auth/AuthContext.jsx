import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { getToken, setToken } from '../api/client';

const Ctx = createContext(null);
const FULL_ACCESS = ['ADMIN', 'APPROVER'];

function decode(token) {
  try {
    const p = JSON.parse(atob(token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/')));
    if (p.exp && p.exp * 1000 < Date.now()) return null;
    return { id: p.sub, name: p.name || p.email, email: p.email, roles: p.roles || [] };
  } catch {
    return null;
  }
}

export function AuthProvider({ children }) {
  const [token, setTok] = useState(getToken());
  const user = useMemo(() => (token ? decode(token) : null), [token]);

  const login = useCallback((t) => { setToken(t); setTok(t); }, []);
  const logout = useCallback(() => { setToken(''); setTok(''); }, []);

  useEffect(() => {
    window.addEventListener('bulwark:unauthorized', logout);
    return () => window.removeEventListener('bulwark:unauthorized', logout);
  }, [logout]);

  // UI hint only: the backend is the authority and re-checks every role.
  // ADMIN and (for now) APPROVER pass every role check - keep in sync with FULL_ACCESS in the API's core/security.py.
  const has = useCallback((...roles) => !!user && (FULL_ACCESS.some((r) => user.roles.includes(r)) || roles.some((r) => user.roles.includes(r))), [user]);

  return <Ctx.Provider value={{ user, token, login, logout, has }}>{children}</Ctx.Provider>;
}

export const useAuth = () => useContext(Ctx);

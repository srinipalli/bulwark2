import { getApiBase } from '../config';

const TOKEN_KEY = 'bulwark.token';
const ls = () => (typeof localStorage !== 'undefined' ? localStorage : null);

export const getToken = () => ls()?.getItem(TOKEN_KEY) || '';
export const setToken = (t) => (t ? ls()?.setItem(TOKEN_KEY, t) : ls()?.removeItem(TOKEN_KEY));

export class ApiError extends Error {
  constructor(status, code, message) {
    super(message);
    this.status = status;
    this.code = code;
  }
}

function qs(params) {
  if (!params) return '';
  const p = new URLSearchParams();
  Object.entries(params).forEach(([k, v]) => {
    if (v !== undefined && v !== null && v !== '') p.append(k, v);
  });
  const s = p.toString();
  return s ? `?${s}` : '';
}

function toError(status, data) {
  if (data?.error) return new ApiError(status, data.error.code, data.error.message);
  if (Array.isArray(data?.detail)) {            // FastAPI request validation
    const msg = data.detail.map((d) => `${(d.loc || []).slice(1).join('.') || 'request'}: ${d.msg}`).join('; ');
    return new ApiError(status, 'validation_error', msg);
  }
  return new ApiError(status, 'http_error', typeof data?.detail === 'string' ? data.detail : `Request failed (${status})`);
}

export async function request(path, { method = 'GET', body, params } = {}) {
  const token = getToken();
  let res;
  try {
    res = await fetch(`${getApiBase()}/api/v1${path}${qs(params)}`, {
      method,
      headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });
  } catch {
    throw new ApiError(0, 'network', `Cannot reach the API at ${getApiBase()}. Is the backend running (and CORS allowing this origin)?`);
  }
  let data = null;
  try { data = await res.json(); } catch { /* empty body */ }
  if (!res.ok) {
    if (res.status === 401 && typeof window !== 'undefined') window.dispatchEvent(new Event('bulwark:unauthorized'));
    throw toError(res.status, data);
  }
  return data;
}

/** Health check lives outside /api/v1 */
export async function ping() {
  const res = await fetch(`${getApiBase()}/health/ready`);
  if (!res.ok) throw new ApiError(res.status, 'unhealthy', `Backend answered ${res.status}`);
  return res.json();
}

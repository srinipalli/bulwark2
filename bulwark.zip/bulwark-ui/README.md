# Bulwark UI (React)

React 18 + Vite front end for the Bulwark API: Dashboard, Incidents, Approvals (incident / solution tabs),
Vulnerability List, Solution List and Execution. Light-blue Innova theme with a left sidebar, matching the wireframe.

## Run

```bash
npm install
npm run dev        # http://localhost:3000
npm run build      # static files in dist/ (serve with any web server)
```

## Backend URL (configurable)

Highest priority first:

1. **Settings** (gear in the header) – stored in the browser, takes effect immediately.
2. **`public/config.js`** – `window.__BULWARK_CONFIG__ = { apiBaseUrl: "http://localhost:8000" }`.
   Copied as-is into `dist/`, so you can change it after building without rebuilding.
3. **`VITE_API_BASE_URL`** at build time (see `.env.example`).
4. Default `http://localhost:8000`.

## Backend requirements

- `CORS_ORIGINS` must include the UI origin, e.g. `["http://localhost:3000"]`.
- Start the **worker** (`python -m bulwark.modules.execution.worker`) or runs stay *Queued*.

## Signing in

The API expects a JWT (`sub`, `email`, `name`, `roles`). The login page accepts a pasted token
(`python scripts/dev_token.py ravi ANALYST OPERATOR` in the backend repo). For local development only, it can also
mint a token in the browser using the backend's `JWT_SECRET`. Do not use that in production: sign in through your identity provider and put the token in
`localStorage["bulwark.token"]`. Role checks in the UI only enable or disable buttons; the API enforces them.

## Tests

With the backend and worker running:

```bash
JWT_SECRET=<backend secret> npm run smoke   # full flow: vuln -> solution -> approve -> incident -> approve -> run
JWT_SECRET=<backend secret> npm test        # renders each page against the live API
```

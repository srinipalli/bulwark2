"""Parsing of incident events (contract: scan-ingestor docs/kafka/incident-event.schema.json, schema_version 1.x)."""
import json
import uuid
from dataclasses import dataclass

from .sources import Msg


class BadMessage(ValueError):
    """Permanent problem with a message: it goes to the dead-letter table, not into a retry loop."""


class NotAnIncidentEvent(Exception):
    """A valid message that is simply not for us (e.g. scan.completed)."""


@dataclass
class IncidentEvent:
    event_id: str
    event_type: str
    incident_id: uuid.UUID
    incident_no: int | None
    scan_id: str | None
    msg: Msg


def parse(msg: Msg) -> IncidentEvent:
    try:
        d = json.loads(msg.value.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as e:
        raise BadMessage(f"not valid JSON: {e}") from e
    if not isinstance(d, dict):
        raise BadMessage("JSON value is not an object")
    if not str(d.get("schema_version", "")).startswith("1."):
        raise BadMessage(f"unsupported schema_version {d.get('schema_version')!r} (this consumer reads 1.x)")
    eid, et = d.get("event_id"), d.get("event_type")
    if not eid or not isinstance(eid, str) or not et or not isinstance(et, str):
        raise BadMessage("event_id / event_type missing")
    inc = d.get("incident")
    if not isinstance(inc, dict) or not inc.get("id"):
        # scan.completed and other non-incident messages have no incident block
        if et.startswith("incident."):
            raise BadMessage("no incident.id in message")
        raise NotAnIncidentEvent(et)
    try:
        iid = uuid.UUID(str(inc["id"]))
    except ValueError as e:
        raise BadMessage(f"incident.id is not a UUID: {inc['id']!r}") from e
    scan = d.get("scan") if isinstance(d.get("scan"), dict) else {}
    return IncidentEvent(eid, et, iid, inc.get("incident_no"), scan.get("scan_id"), msg)

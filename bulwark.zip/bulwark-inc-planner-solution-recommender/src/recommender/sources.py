"""Where messages come from: Kafka, or a JSON-lines file (replay / tests).

A batch is committed only after it was fully handled (at-least-once). On a transient failure the source is rewound and the batch re-read.
"""
import json
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Protocol

log = logging.getLogger("recommender.source")


class SourceError(RuntimeError):
    pass


@dataclass
class Msg:
    topic: str
    partition: int
    offset: int
    key: str | None
    value: bytes
    headers: dict = field(default_factory=dict)


class Source(Protocol):
    def poll_batch(self, n: int, timeout: float) -> list[Msg]: ...
    def commit(self, batch: list[Msg]) -> None: ...
    def rewind(self, batch: list[Msg]) -> None: ...
    def close(self) -> None: ...


class ListSource:
    """In-memory / file source. `finite` -> the run ends when everything was consumed."""
    finite = True

    def __init__(self, msgs: list[Msg]):
        self._q, self.committed = list(msgs), 0

    def poll_batch(self, n, timeout):
        out, self._q = self._q[:n], self._q[n:]
        return out

    def commit(self, batch):
        self.committed += len(batch)

    def rewind(self, batch):
        self._q = list(batch) + self._q

    def close(self):
        pass


def file_source(path: str | Path, topic: str) -> ListSource:
    """Reads the file written by `scan-ingestor --kafka-dry-run` ({"topic","key","headers","value"} per line)."""
    msgs = []
    for n, line in enumerate(Path(path).read_text(encoding="utf-8").splitlines()):
        if not line.strip():
            continue
        d = json.loads(line)
        if d.get("topic", topic) != topic:
            continue
        msgs.append(Msg(topic, 0, n, d.get("key"), json.dumps(d["value"]).encode(), d.get("headers") or {}))
    return ListSource(msgs)


class KafkaSource:
    finite = False

    def __init__(self, s):
        try:
            from confluent_kafka import Consumer
        except ImportError as e:
            raise SourceError("pip install confluent-kafka") from e
        if not s.kafka_bootstrap_servers:
            raise SourceError("KAFKA_BOOTSTRAP_SERVERS is empty")
        conf = {"bootstrap.servers": s.kafka_bootstrap_servers, "group.id": s.kafka_group_id, "client.id": s.kafka_client_id,
                "auto.offset.reset": s.kafka_auto_offset_reset, "enable.auto.commit": False, "security.protocol": s.kafka_security_protocol,
                "session.timeout.ms": 45000, "max.poll.interval.ms": 600000}
        if "SASL" in s.kafka_security_protocol:
            conf.update({"sasl.mechanisms": s.kafka_sasl_mechanism, "sasl.username": s.kafka_sasl_username,
                         "sasl.password": s.kafka_sasl_password.get_secret_value()})
        if s.kafka_ssl_ca_file:
            conf["ssl.ca.location"] = s.kafka_ssl_ca_file
        self.topic = s.kafka_topic_incidents
        self._c = Consumer(conf)
        try:
            md = self._c.list_topics(timeout=15)                                   # fail fast on wrong host / credentials / CA
        except Exception as e:                                                     # noqa: BLE001
            raise SourceError(f"cannot reach Kafka at {s.kafka_bootstrap_servers}: {e}") from e
        if self.topic not in md.topics or md.topics[self.topic].error is not None:
            raise SourceError(f"topic '{self.topic}' does not exist (or is not readable) on {s.kafka_bootstrap_servers}")
        self._c.subscribe([self.topic])

    def poll_batch(self, n, timeout):
        out = []
        for m in self._c.consume(num_messages=n, timeout=timeout):
            if m.error():
                raise SourceError(f"Kafka error: {m.error()}")
            out.append(Msg(m.topic(), m.partition(), m.offset(), m.key().decode("utf-8", "replace") if m.key() else None, m.value() or b"",
                           {k: (v.decode("utf-8", "replace") if isinstance(v, bytes) else v) for k, v in (m.headers() or [])}))
        return out

    def commit(self, batch):
        from confluent_kafka import TopicPartition
        last: dict = {}
        for m in batch:
            last[(m.topic, m.partition)] = max(last.get((m.topic, m.partition), -1), m.offset)
        if last:
            self._c.commit(offsets=[TopicPartition(t, p, o + 1) for (t, p), o in last.items()], asynchronous=False)

    def rewind(self, batch):
        from confluent_kafka import TopicPartition
        first: dict = {}
        for m in batch:
            first[(m.topic, m.partition)] = min(first.get((m.topic, m.partition), m.offset), m.offset)
        for (t, p), o in first.items():
            self._c.seek(TopicPartition(t, p, o))

    def close(self):
        self._c.close()

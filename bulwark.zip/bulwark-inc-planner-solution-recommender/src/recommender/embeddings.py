"""Embeddings: Google Gemini only (gemini-embedding-001, free tier with an AI Studio key), truncated to `dim` (768) and L2-normalised.

`name` (gemini:gemini-embedding-001:768) is stored in incidents.embedding_model; only vectors with the same name are ever compared.
It is the same name the scan-ingestor project's scripts/embed_incidents.py writes, so both projects share the column.
"""
import logging
import math
import time
from typing import Protocol

from .config import Settings

log = logging.getLogger("recommender.embed")


class EmbedError(RuntimeError):
    """Transient failure (rate limit, network ...): the caller retries later."""


class ConfigError(RuntimeError):
    """Missing key / library / wrong dimension: retrying will not help."""


class Embedder(Protocol):
    name: str
    dim: int

    def embed_documents(self, texts: list[str]) -> list[list[float]]: ...


def normalize(v: list[float]) -> list[float]:
    n = math.sqrt(sum(x * x for x in v)) or 1.0
    return [x / n for x in v]


class GeminiEmbedder:
    def __init__(self, s: Settings):
        key = s.gemini_api_key.get_secret_value()
        if not key:
            raise ConfigError("GEMINI_API_KEY is empty (free key: https://aistudio.google.com/apikey)")
        try:
            from google import genai
            from google.genai import types
        except ImportError as e:
            raise ConfigError("pip install google-genai") from e
        self._types, self._client = types, genai.Client(api_key=key)
        self.model, self.dim = s.gemini_embed_model, s.embed_dim
        self.name = f"gemini:{self.model}:{self.dim}"
        self._gap, self._last = 60.0 / max(s.embed_requests_per_minute, 1), 0.0

    def _call(self, texts: list[str]) -> list[list[float]]:
        cfg = self._types.EmbedContentConfig(task_type="SEMANTIC_SIMILARITY", output_dimensionality=self.dim)
        for attempt in range(5):
            wait = self._gap - (time.monotonic() - self._last)
            if wait > 0:
                time.sleep(wait)
            self._last = time.monotonic()
            try:
                res = self._client.models.embed_content(model=self.model, contents=texts, config=cfg)
                out = [normalize(list(e.values)) for e in res.embeddings]
                if len(out) != len(texts) or any(len(v) != self.dim for v in out):
                    raise ConfigError(f"Gemini returned an unexpected shape (wanted {len(texts)}x{self.dim})")
                return out
            except ConfigError:
                raise
            except Exception as e:                                         # noqa: BLE001
                msg = str(e)
                if any(c in msg for c in ("API_KEY_INVALID", "PERMISSION_DENIED", "401", "403")):
                    raise ConfigError(f"Gemini rejected the key: {msg[:200]}") from e
                if attempt == 4:
                    raise EmbedError(f"Gemini embedding failed: {msg[:300]}") from e
                delay = 2 ** (attempt + 2)
                log.warning("Gemini busy / rate limited (%s); retry in %ss", msg[:80], delay)
                time.sleep(delay)
        raise EmbedError("unreachable")

    def embed_documents(self, texts):
        out: list[list[float]] = []
        for i in range(0, len(texts), 100):                                # API limit: 100 texts per request
            out += self._call(texts[i:i + 100])
        return out


def get_embedder(s: Settings) -> Embedder:
    return GeminiEmbedder(s)

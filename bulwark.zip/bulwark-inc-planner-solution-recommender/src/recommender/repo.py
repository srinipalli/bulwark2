"""All SQL of the recommender. Plain psycopg3, no ORM."""
import hashlib
import uuid

from psycopg.types.json import Jsonb

LOAD_INCIDENTS = """
SELECT i.id, i.incident_no, i.title, i.description, i.severity, i.status,
       i.embedding IS NULL AS no_vector, i.embedding_model, i.embedding_text_hash,
       v.cve_id, v.title AS vuln_title, v.description AS vuln_description, v.cvss_score,
       COALESCE((SELECT string_agg(DISTINCT concat_ws(' ', a.asset_type, a.os_name, a.os_version, a.environment), '; ')
                   FROM incident_assets ia JOIN assets a ON a.id = ia.asset_id
                  WHERE ia.incident_id = i.id), '') AS platforms
  FROM incidents i JOIN vulnerabilities v ON v.id = i.vulnerability_id
 WHERE i.id = ANY(%s)"""


def incident_text(r: dict) -> str:
    """Text that is embedded. IDENTICAL to scripts/embed_incidents.py of the scan-ingestor project - do not change one without the other."""
    parts = [f"Incident: {r['title']}",
             f"Vulnerability {r['cve_id']}: {r['vuln_title']}",
             r["vuln_description"] or "",
             r["description"] or "",
             f"Severity: {r['severity']}" + (f", CVSS {r['cvss_score']}" if r["cvss_score"] is not None else ""),
             f"Affected platforms: {r['platforms']}" if r["platforms"] else ""]
    return "\n".join(p.strip() for p in parts if p and p.strip())


def text_hash(text: str) -> str:
    return hashlib.sha256(text.encode()).hexdigest()


def vec_literal(v: list[float]) -> str:
    return "[" + ",".join(f"{x:.7g}" for x in v) + "]"


def load_incidents(conn, ids: list[uuid.UUID]) -> dict:
    rows = conn.execute(LOAD_INCIDENTS, (list(ids),)).fetchall()
    for r in rows:
        r["text"] = incident_text(r)
        r["hash"] = text_hash(r["text"])
    return {r["id"]: r for r in rows}


def set_embedding(conn, incident_id, vec: list[float], model: str, h: str) -> None:
    conn.execute("UPDATE incidents SET embedding=%s::vector, embedding_model=%s, embedding_text_hash=%s, embedded_at=now() WHERE id=%s",
                 (vec_literal(vec), model, h, incident_id))


def needs_embedding(r: dict, model: str) -> bool:
    return r["no_vector"] or r["embedding_model"] != model or r["embedding_text_hash"] != r["hash"]


def schema_problems(conn, engines: list[str] = ()) -> list[str]:
    out = []
    if not conn.execute("SELECT 1 FROM information_schema.columns WHERE table_name='incidents' AND column_name='embedding'").fetchone():
        out.append("incidents.embedding is missing - run sql/02_pgvector_incidents.sql")
    need = [(t, "sql/10_recommender.sql") for t in ("incident_suggestion_runs", "incident_similar_matches", "recommender_dead_letters")]
    if "ai-planner" in engines:
        need += [(t, "sql/11_ai_planner.sql") for t in ("incident_ai_plans", "incident_ai_plan_steps", "ai_solution_drafts")]
    for t, script in need:
        if not conn.execute("SELECT 1 FROM information_schema.tables WHERE table_name=%s", (t,)).fetchone():
            out.append(f"table {t} is missing - run {script}")
    return out


def existing_runs(conn, event_ids: list[str]) -> set[tuple[str, str]]:
    if not event_ids:
        return set()
    return {(r["trigger_event_id"], r["engine"]) for r in conn.execute(
        "SELECT trigger_event_id, engine FROM incident_suggestion_runs WHERE trigger_event_id = ANY(%s)", (event_ids,)).fetchall()}


SIMILAR = """
WITH q AS (SELECT id, embedding FROM incidents WHERE id = %(id)s)
SELECT i.id, i.incident_no, i.title, i.status, v.cve_id, 1 - (i.embedding <=> q.embedding) AS similarity
  FROM q, incidents i JOIN vulnerabilities v ON v.id = i.vulnerability_id
 WHERE i.id <> q.id AND q.embedding IS NOT NULL
   AND i.embedding IS NOT NULL AND i.embedding_model = %(model)s
   AND i.status = ANY(%(statuses)s::text[])
   AND EXISTS (SELECT 1 FROM incident_plan_steps ps WHERE ps.incident_id = i.id)
 ORDER BY i.embedding <=> q.embedding
 LIMIT %(k)s"""


def similar_incidents(conn, incident_id, model: str, statuses: list[str], k: int) -> list[dict]:
    conn.execute("SET LOCAL hnsw.ef_search = 200")          # the filters above are applied after the index scan; widen it so top-k is not starved
    return conn.execute(SIMILAR, {"id": incident_id, "model": model, "statuses": statuses, "k": k}).fetchall()


def insert_run(conn, *, incident_id, event, engine: str, status: str, model: str | None, params: dict, similar_found: int) -> uuid.UUID | None:
    m = event.msg
    row = conn.execute(
        """INSERT INTO incident_suggestion_runs (incident_id, trigger_event_id, trigger_event_type, scan_id, kafka_topic, kafka_partition, kafka_offset,
                                                  engine, embedding_model, params, status, similar_found, is_current)
           VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,FALSE)
           ON CONFLICT (trigger_event_id, engine) DO NOTHING RETURNING id""",
        (incident_id, event.event_id, event.event_type, event.scan_id, m.topic, m.partition, m.offset, engine, model, Jsonb(params), status,
         similar_found)).fetchone()
    return row["id"] if row else None


def make_current(conn, run_id, incident_id, engine: str) -> None:
    conn.execute("UPDATE incident_suggestion_runs SET is_current=FALSE WHERE incident_id=%s AND engine=%s AND is_current", (incident_id, engine))
    conn.execute("UPDATE incident_suggestion_runs SET is_current=TRUE WHERE id=%s", (run_id,))


def insert_matches(conn, run_id, incident_id, matches: list[dict]) -> None:
    with conn.cursor() as cur:
        cur.executemany("INSERT INTO incident_similar_matches (run_id, incident_id, similar_incident_id, similarity, rank) VALUES (%s,%s,%s,%s,%s)",
                        [(run_id, incident_id, m["id"], m["score"], m["rank"]) for m in matches])


def dead_letter(conn, msg, reason: str) -> None:
    conn.execute('INSERT INTO recommender_dead_letters (topic, partition, "offset", msg_key, reason, payload) VALUES (%s,%s,%s,%s,%s,%s) ON CONFLICT (topic, partition, "offset") DO NOTHING',
                 (msg.topic, msg.partition, msg.offset, msg.key, reason[:500], msg.value.decode("utf-8", "replace")[:20000]))


def candidates_not_embedded(conn, model: str, statuses: list[str]) -> int:
    """Earlier incidents with a plan that the similarity search cannot see because they have no vector from the current model."""
    return conn.execute(
        """SELECT count(*) AS n FROM incidents i
            WHERE i.status = ANY(%s::text[]) AND EXISTS (SELECT 1 FROM incident_plan_steps ps WHERE ps.incident_id = i.id)
              AND (i.embedding IS NULL OR i.embedding_model IS DISTINCT FROM %s)""", (statuses, model)).fetchone()["n"]


def all_incident_ids(conn) -> list:
    return [r["id"] for r in conn.execute("SELECT id FROM incidents ORDER BY incident_no").fetchall()]

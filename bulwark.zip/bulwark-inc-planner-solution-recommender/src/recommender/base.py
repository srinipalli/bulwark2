"""Engine contract shared by every engine (vector similarity, AI planner, ...)."""
from dataclasses import dataclass, field
from typing import Callable, Protocol

from .config import Settings


@dataclass
class EngineResult:
    model: str | None
    params: dict
    matches: list[dict] = field(default_factory=list)          # {id, incident_no, title, status, cve_id, score, rank}
    status: str | None = None                                   # run status; default COMPLETED if matches else NO_MATCH
    save: Callable | None = None                                # save(conn, run_id, incident_id): engine-specific rows, same transaction
    note: str = ""                                              # one-line summary for the log


class Engine(Protocol):
    name: str
    needs_embedding: bool

    def suggest(self, conn, incident: dict, s: Settings, model: str | None) -> EngineResult: ...

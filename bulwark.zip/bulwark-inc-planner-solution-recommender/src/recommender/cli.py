"""Command line.

    python -m recommender                          # consume bulwark.incidents from Kafka until stopped (Ctrl+C / SIGTERM)
    python -m recommender --once                   # stop after the topic was idle for --idle-seconds (cron / scheduled job)
    python -m recommender --from-file events.jsonl # replay the file written by `scan-ingestor --kafka-dry-run` (no Kafka needed)
    python -m recommender --incident 57            # find similar incidents for INC-57 now (no Kafka needed)
    python -m recommender --backfill-embeddings    # make sure EVERY incident has a vector from the current model, then exit

Exit codes: 0 ok | 1 gave up after repeated transient failures | 2 configuration / Kafka / database schema problem
"""
import argparse
import json
import logging
import signal
import sys
import uuid

import psycopg
from psycopg.rows import dict_row

from . import repo
from .config import get_settings
from .embeddings import ConfigError, get_embedder
from .engines import build_engines
from .processor import GaveUp, Processor, backfill_embeddings, consume_loop
from .sources import KafkaSource, ListSource, Msg, SourceError, file_source

log = logging.getLogger("recommender")


def incident_no(value: str) -> int:
    """57 or INC-57 (as shown in the UI) -> 57"""
    v = value.strip().upper().removeprefix("INC-")
    if not v.isdigit():
        raise argparse.ArgumentTypeError(f"'{value}' is not an incident number (use 57 or INC-57)")
    return int(v)


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="python -m recommender", description="Suggest solutions for incidents announced on Kafka")
    ap.add_argument("--from-file", help="JSON-lines file with Kafka messages instead of a live consumer")
    ap.add_argument("--incident", type=incident_no, action="append", help="incident to process now, 57 or INC-57 (repeatable); no Kafka")
    ap.add_argument("--once", action="store_true", help="exit when the topic has been idle for --idle-seconds")
    ap.add_argument("--idle-seconds", type=float, default=15)
    ap.add_argument("--max-messages", type=int)
    ap.add_argument("--batch-size", type=int)
    ap.add_argument("--backfill-embeddings", action="store_true")
    ap.add_argument("-v", "--verbose", action="store_true")
    a = ap.parse_args(argv)
    logging.basicConfig(level=logging.DEBUG if a.verbose else logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    s = get_settings()
    if a.batch_size:
        s.batch_size = a.batch_size

    def connect():
        return psycopg.connect(s.dsn, row_factory=dict_row, autocommit=True)

    try:
        engines = build_engines(s)
        with connect() as c:
            problems = repo.schema_problems(c, [e.name for e in engines])
        if problems:
            for p in problems:
                log.error(p)
            return 2
        embedder = get_embedder(s) if any(e.needs_embedding for e in engines) else None
    except (ConfigError, ValueError) as e:
        log.error("%s", e)
        return 2
    except psycopg.OperationalError as e:
        log.error("cannot connect to the database: %s", e)
        return 2

    proc = Processor(connect, s, embedder, engines)
    try:
        if a.backfill_embeddings:
            n = backfill_embeddings(proc.conn(), embedder)
            log.info("done: %d incident(s) (re)embedded with %s", n, embedder.name)
            return 0
        if embedder is not None:
            miss = repo.candidates_not_embedded(proc.conn(), embedder.name, s.status_list)
            if miss:
                log.warning("%d earlier incident(s) with a plan have no %s vector and cannot be found by the search - run with --backfill-embeddings", miss, embedder.name)
        if a.incident:
            source = manual_source(proc.conn(), a.incident, s.kafka_topic_incidents)
        elif a.from_file:
            source = file_source(a.from_file, s.kafka_topic_incidents)
        else:
            source = KafkaSource(s)
            log.info("consuming %s from %s as group %s", s.kafka_topic_incidents, s.kafka_bootstrap_servers, s.kafka_group_id)
    except SourceError as e:
        log.error("%s", e)
        return 2
    except LookupError as e:
        log.error("%s", e)
        return 1

    stopping = {"flag": False}
    for sig in (signal.SIGINT, signal.SIGTERM):
        signal.signal(sig, lambda *_: stopping.update(flag=True))
    try:
        total = consume_loop(source, proc, s, idle_seconds=a.idle_seconds if a.once else None, max_messages=a.max_messages, stop=lambda: stopping["flag"])
    except GaveUp as e:
        log.error("%s - nothing was committed for the failing batch; fix the cause and start again", e)
        return 1
    except ConfigError as e:
        log.error("%s", e)
        return 2
    finally:
        source.close()
        proc.close()
    log.info("finished: %s", total)
    return 0


def manual_source(conn, numbers: list[int], topic: str) -> ListSource:
    msgs = []
    for n, no in enumerate(numbers):
        row = conn.execute("SELECT id FROM incidents WHERE incident_no=%s", (no,)).fetchone()
        if not row:
            raise LookupError(f"INC-{no} not found")
        body = {"schema_version": "1.0", "event_id": f"manual-{uuid.uuid4()}", "event_type": "incident.updated",
                "incident": {"id": str(row["id"]), "incident_no": no}, "scan": {}}
        msgs.append(Msg(topic, 0, n, str(row["id"]), json.dumps(body).encode(), {}))
    return ListSource(msgs)


if __name__ == "__main__":
    sys.exit(main())

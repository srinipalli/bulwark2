from functools import lru_cache

from pydantic import SecretStr
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # ---- database: the Bulwark database (sql/schema.sql + 02_pgvector + 10_recommender)
    database_url: str = "postgresql://bulwark:bulwark@localhost:5432/bulwark"

    # ---- Kafka (consumer)
    kafka_bootstrap_servers: str = ""
    kafka_security_protocol: str = "SASL_SSL"          # PLAINTEXT | SSL | SASL_PLAINTEXT | SASL_SSL
    kafka_sasl_mechanism: str = "SCRAM-SHA-256"        # PLAIN | SCRAM-SHA-256 | SCRAM-SHA-512
    kafka_sasl_username: str = ""
    kafka_sasl_password: SecretStr = SecretStr("")
    kafka_ssl_ca_file: str = ""
    kafka_client_id: str = "bulwark-solution-recommender"
    kafka_group_id: str = "bulwark-solution-recommender"
    kafka_topic_incidents: str = "bulwark.incidents"
    kafka_auto_offset_reset: str = "earliest"          # where a NEW consumer group starts: earliest | latest
    batch_size: int = 20                               # messages handled (and embedded) together
    poll_timeout_seconds: float = 2.0
    max_attempts: int = 5                              # retries for transient failures (DB / embedding API) before giving up
    event_types: str = "incident.created,incident.updated"

    # ---- engines
    engines: str = "vector-similarity"                 # comma separated; see recommender/engines.py
    top_k: int = 10                                    # similar incidents considered
    min_similarity: float = 0.50                       # cosine similarity floor (0-1)
    candidate_statuses: str = "APPROVED,IN_PROGRESS,RESOLVED,CLOSED"   # only incidents whose plan was approved can teach us

    # ---- embeddings: Gemini only (N must match the vector(N) of incidents.embedding)
    embed_dim: int = 768
    gemini_api_key: SecretStr = SecretStr("")          # free key: https://aistudio.google.com/apikey
    gemini_embed_model: str = "gemini-embedding-001"
    embed_requests_per_minute: int = 60

    # ---- ai-planner engine (ENGINES=vector-similarity,ai-planner): Gemini Flash, same GEMINI_API_KEY
    gemini_plan_model: str = "gemini-2.5-flash"
    plan_requests_per_minute: int = 10                 # Flash free tier is ~10 RPM; raise on a paid key
    plan_temperature: float = 0.2
    plan_max_catalog: int = 200                        # approved solutions sent as context (solutions of similar incidents first)
    plan_similar_incidents: int = 5                    # plans of the best vector matches sent as worked examples

    @property
    def dsn(self) -> str:
        return self.database_url.replace("postgresql+asyncpg://", "postgresql://").replace("postgresql+psycopg://", "postgresql://")

    @property
    def event_type_set(self) -> set[str]:
        return {x.strip() for x in self.event_types.split(",") if x.strip()}

    @property
    def status_list(self) -> list[str]:
        return [x.strip().upper() for x in self.candidate_statuses.split(",") if x.strip()]

    @property
    def engine_names(self) -> list[str]:
        return [x.strip() for x in self.engines.split(",") if x.strip()]


@lru_cache
def get_settings() -> Settings:
    return Settings()

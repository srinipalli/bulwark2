"""Batch processing + the consume loop.

Guarantees
* at-least-once: offsets are committed only after the whole batch was handled;
* idempotent: a redelivered event finds its run rows (unique trigger_event_id + engine) and is skipped;
* transient failures (database down, embedding API limits) are retried with back-off, the batch is NOT committed meanwhile;
* permanent problems (bad JSON, unknown incident, a bug on one event) go to recommender_dead_letters and the stream moves on;
* several events for the same incident inside one batch: only the newest is computed, the older ones are recorded as SUPERSEDED.
"""
import logging
import time
from dataclasses import dataclass, fields

import psycopg

from . import repo
from .config import Settings
from .embeddings import ConfigError, Embedder, EmbedError
from .engines import Engine
from .events import BadMessage, IncidentEvent, NotAnIncidentEvent, parse
from .sources import Msg, Source

log = logging.getLogger("recommender")


class Transient(Exception):
    """Retryable infrastructure problem."""


class GaveUp(Exception):
    pass


@dataclass
class Stats:
    messages: int = 0
    ignored: int = 0
    dead_letters: int = 0
    duplicates: int = 0
    superseded: int = 0
    runs: int = 0
    with_matches: int = 0
    no_match: int = 0
    failed: int = 0
    embedded: int = 0

    def add(self, o: "Stats") -> None:
        for f in fields(self):
            setattr(self, f.name, getattr(self, f.name) + getattr(o, f.name))

    def __str__(self) -> str:
        return ", ".join(f"{f.name}={getattr(self, f.name)}" for f in fields(self))


def ensure_embeddings(conn, embedder: Embedder, incidents: dict) -> int:
    todo = [r for r in incidents.values() if repo.needs_embedding(r, embedder.name)]
    if not todo:
        return 0
    vecs = embedder.embed_documents([r["text"] for r in todo])
    with conn.transaction():
        for r, v in zip(todo, vecs):
            repo.set_embedding(conn, r["id"], v, embedder.name, r["hash"])
    for r in todo:
        r.update(no_vector=False, embedding_model=embedder.name, embedding_text_hash=r["hash"])
    return len(todo)


def backfill_embeddings(conn, embedder: Embedder, chunk: int = 50) -> int:
    ids, n = repo.all_incident_ids(conn), 0
    for i in range(0, len(ids), chunk):
        n += ensure_embeddings(conn, embedder, repo.load_incidents(conn, ids[i:i + chunk]))
        log.info("embeddings: %d/%d incidents checked, %d (re)embedded", min(i + chunk, len(ids)), len(ids), n)
    return n


class Processor:
    def __init__(self, connect, s: Settings, embedder: Embedder | None, engines: list[Engine]):
        self._connect, self.s, self.embedder, self.engines = connect, s, embedder, engines
        self._conn = None

    def conn(self):
        if self._conn is None or self._conn.closed:
            self._conn = self._connect()
        return self._conn

    def close(self):
        if self._conn is not None and not self._conn.closed:
            self._conn.close()

    def process_batch(self, msgs: list[Msg]) -> Stats:
        try:
            return self._process(msgs)
        except (psycopg.OperationalError, psycopg.InterfaceError) as e:
            self.close()
            raise Transient(f"database: {e}") from e
        except EmbedError as e:                                                    # includes ai_planner.LlmError
            raise Transient(str(e)) from e

    # ------------------------------------------------------------------------------------------------------
    def _dead(self, conn, st: Stats, msg: Msg, reason: str) -> None:
        log.warning("dead letter %s[%s]@%s: %s", msg.topic, msg.partition, msg.offset, reason)
        with conn.transaction():
            repo.dead_letter(conn, msg, reason)
        st.dead_letters += 1

    def _process(self, msgs: list[Msg]) -> Stats:
        conn, s, st = self.conn(), self.s, Stats(messages=len(msgs))
        events: list[IncidentEvent] = []
        for m in msgs:
            try:
                ev = parse(m)
            except NotAnIncidentEvent:
                st.ignored += 1
                continue
            except BadMessage as e:
                self._dead(conn, st, m, str(e))
                continue
            if ev.event_type not in s.event_type_set:
                st.ignored += 1
                continue
            events.append(ev)
        if not events:
            return st

        done = repo.existing_runs(conn, [e.event_id for e in events])
        latest: dict = {}
        for e in events:
            latest[e.incident_id] = e                                              # events are in log order: the last one wins
        incidents = repo.load_incidents(conn, list(latest))
        if self.embedder is not None and any(g.needs_embedding for g in self.engines):
            st.embedded += ensure_embeddings(conn, self.embedder, incidents)
        model = self.embedder.name if self.embedder else None

        for ev in events:
            inc = incidents.get(ev.incident_id)
            if inc is None:
                self._dead(conn, st, ev.msg, f"incident {ev.incident_id} not found in the database (event {ev.event_id})")
                continue
            is_latest = latest[ev.incident_id] is ev
            for eng in self.engines:
                if (ev.event_id, eng.name) in done:
                    st.duplicates += 1
                    continue
                try:
                    with conn.transaction():
                        if not is_latest:
                            run = repo.insert_run(conn, incident_id=inc["id"], event=ev, engine=eng.name, status="SUPERSEDED", model=model, params={},
                                                  similar_found=0)
                            st.superseded += run is not None
                            continue
                        res = eng.suggest(conn, inc, s, model)
                        status = res.status or ("COMPLETED" if res.matches else "NO_MATCH")
                        run = repo.insert_run(conn, incident_id=inc["id"], event=ev, engine=eng.name, status=status,
                                              model=res.model, params=res.params, similar_found=len(res.matches))
                        if run is None:
                            st.duplicates += 1                                      # another consumer won the race
                            continue
                        repo.insert_matches(conn, run, inc["id"], res.matches)
                        if res.save:
                            res.save(conn, run, inc["id"])
                        repo.make_current(conn, run, inc["id"], eng.name)
                    st.runs += 1
                    st.with_matches += bool(res.matches)
                    st.no_match += status == "NO_MATCH"
                    st.failed += status == "FAILED"
                    log.info("INC-%s via %s: %s", inc["incident_no"], eng.name, res.note or (
                        f"{len(res.matches)} similar incident(s) with a plan"
                        + (f" (best INC-{res.matches[0]['incident_no']} {res.matches[0]['score']:.2f})" if res.matches else "")))
                except (psycopg.OperationalError, psycopg.InterfaceError, EmbedError, ConfigError):
                    raise
                except Exception as e:                                              # noqa: BLE001 - one poison event must not block the stream
                    log.exception("engine %s failed on event %s", eng.name, ev.event_id)
                    self._dead(conn, st, ev.msg, f"{eng.name}: {type(e).__name__}: {e}")
        return st


def consume_loop(source: Source, proc: Processor, s: Settings, *, idle_seconds: float | None = None, max_messages: int | None = None,
                 stop=lambda: False, sleep=time.sleep) -> Stats:
    total, idle_since = Stats(), time.monotonic()
    while not stop():
        batch = source.poll_batch(s.batch_size, s.poll_timeout_seconds)
        if not batch:
            if getattr(source, "finite", False):
                break
            if idle_seconds is not None and time.monotonic() - idle_since >= idle_seconds:
                break
            continue
        idle_since = time.monotonic()
        attempt = 0
        while True:
            try:
                st = proc.process_batch(batch)
                break
            except Transient as e:
                attempt += 1
                if attempt >= s.max_attempts:
                    raise GaveUp(f"giving up after {attempt} attempts: {e}") from e
                delay = min(60, 2 ** attempt)
                log.warning("transient failure (%s); attempt %d/%d, retry in %ss - batch not committed", e, attempt, s.max_attempts, delay)
                sleep(delay)
        source.commit(batch)
        total.add(st)
        log.info("batch of %d committed: %s", len(batch), st)
        if max_messages and total.messages >= max_messages:
            break
    return total

"""Suggestion engines.

* vector-similarity: ranked list of similar earlier incidents that have a plan. Only the reference (similar incident id + score)
  is stored; the plan itself is read from incident_plan_steps of the similar incident.
* ai-planner (ai_planner.py): Gemini Flash builds an ordered plan from the APPROVED solution catalog, plus drafts for missing solutions.

To add another engine:
  1. write a class with `name`, `needs_embedding` and `suggest(conn, incident, settings, model) -> EngineResult`
     (it can read earlier engines' current runs from the DB; `EngineResult.save` writes its own rows),
  2. register it in ENGINES,
  3. enable it with ENGINES=vector-similarity,your-engine (engines run in that order).
Every engine writes its own run rows (incident_suggestion_runs.engine) so results can be compared side by side.
"""
import logging
from typing import Callable

from . import repo
from .ai_planner import AiPlannerEngine
from .base import Engine, EngineResult  # noqa: F401 - re-exported
from .config import Settings

log = logging.getLogger("recommender")


def _score(x: float) -> float:
    return round(max(-1.0, min(1.0, float(x))), 5)             # float noise can give 1.0000001


class VectorSimilarityEngine:
    """Nearest earlier incidents (cosine, pgvector) that already have an approved plan, ranked by similarity."""
    name = "vector-similarity"
    needs_embedding = True

    def suggest(self, conn, incident, s, model):
        params = {"top_k": s.top_k, "min_similarity": s.min_similarity, "candidate_statuses": s.status_list}
        rows = [r for r in repo.similar_incidents(conn, incident["id"], model, s.status_list, s.top_k) if float(r["similarity"]) >= s.min_similarity]
        return EngineResult(model, params, [{**r, "score": _score(r["similarity"]), "rank": n} for n, r in enumerate(rows, 1)])


ENGINES: dict[str, Callable[[Settings], Engine]] = {
    VectorSimilarityEngine.name: lambda s: VectorSimilarityEngine(),
    AiPlannerEngine.name: lambda s: AiPlannerEngine(s),
}


def build_engines(s: Settings) -> list[Engine]:
    names = s.engine_names
    for n in names:
        if n not in ENGINES:
            raise ValueError(f"unknown engine '{n}' (known: {', '.join(ENGINES)})")
    if AiPlannerEngine.name in names and (VectorSimilarityEngine.name not in names
                                          or names.index(VectorSimilarityEngine.name) > names.index(AiPlannerEngine.name)):
        log.warning("ai-planner runs without fresh vector matches - list vector-similarity before it in ENGINES")
    return [ENGINES[n](s) for n in names]

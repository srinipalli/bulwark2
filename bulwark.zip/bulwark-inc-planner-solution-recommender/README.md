# Bulwark Solution Recommender

Reads **incident events** from Kafka, finds **similar earlier incidents that already have an approved plan**, and stores a **reference to each one with its similarity score**. The plan is not copied: the planner reads it from `incident_plan_steps` of the similar incident. Built so an AI step (LLM re-ranking) can be added later as another *engine* without touching the rest.

```
scan-ingestor ──► Kafka  bulwark.incidents ──► recommender ──► incident_suggestion_runs   (one row per event: status, parameters)
 (creates incidents)     incident.created/updated               incident_similar_matches   (incident_id, similar_incident_id, similarity, rank)
                                       ▲
                              pgvector search on incidents.embedding (Postgres)
```

## What happens per event
1. Parse and validate the message (`schema_version` 1.x). Bad messages go to `recommender_dead_letters`; other event types are ignored.
2. Load the incident from Postgres and make sure it has an up-to-date embedding (Gemini `gemini-embedding-001`, 768 dimensions), stored in `incidents.embedding`.
3. **Similarity search**: nearest incidents by cosine distance that (a) have a plan (`incident_plan_steps`), (b) are in `CANDIDATE_STATUSES` (default APPROVED, IN_PROGRESS, RESOLVED, CLOSED - plans that were never approved teach nothing), (c) were embedded with the same model, and (d) score ≥ `MIN_SIMILARITY`.
4. Each match is stored as (incident, similar incident, similarity, rank) in `incident_similar_matches`. The plan of the similar incident is looked up from `incident_plan_steps` when needed.
5. Everything for the event is written in one transaction; then the Kafka offset is committed.

## Setup
```bash
pip install -e ".[dev]"
psql "$DATABASE_URL" -f sql/02_pgvector_incidents.sql   # once - skip if the scan-ingestor project already did it
psql "$DATABASE_URL" -f sql/10_recommender.sql          # the new tables and views
psql "$DATABASE_URL" -f sql/11_ai_planner.sql           # AI planner tables (needed when ENGINES contains ai-planner)
cp .env.example .env                           # DATABASE_URL, Kafka password, CA file (certs/ca.pem), GEMINI_API_KEY
python -m recommender --backfill-embeddings    # embed ALL existing incidents once (needed so history is searchable)
python -m recommender                          # consume bulwark.incidents until Ctrl+C
```
Other modes:
```bash
python -m recommender --once                   # exit after 15 s without messages (cron / scheduled job)
python -m recommender --incident 57            # find similar incidents for INC-57 now, no Kafka
python -m recommender --from-file events.jsonl # replay the file written by `python -m scan_ingestor --kafka-dry-run`
python scripts/seed_demo_solutions.py          # DEMO databases only: gives some incidents an approved plan
```
Exit codes: 0 ok · 1 gave up after repeated transient failures (nothing committed for that batch) · 2 configuration, Kafka or schema problem.

## Reading the results
```sql
-- similar incidents (with a plan) for one incident, current run, best first
SELECT similar_incident, similar_incident_id, rank, similarity, similar_title, similar_status
FROM v_incident_similar_matches WHERE incident = 'INC-57' ORDER BY rank;

-- the plan of the best match, read from the existing planner tables
SELECT ps.step_no, s.title AS solution, sv.version_no, ps.on_failure
  FROM v_incident_similar_matches m
  JOIN incident_plan_steps ps ON ps.incident_id = m.similar_incident_id
  JOIN solution_versions sv ON sv.id = ps.solution_version_id
  JOIN solutions s ON s.id = sv.solution_id
 WHERE m.incident = 'INC-57' AND m.rank = 1
 ORDER BY ps.step_no;

-- full history of runs (every Kafka event, every engine)
SELECT created_at, engine, trigger_event_type, status, similar_found, is_current FROM incident_suggestion_runs
WHERE incident_id = (SELECT id FROM incidents WHERE incident_no = 57) ORDER BY created_at;
```
Tables: `incident_suggestion_runs` (one row per event and engine; `is_current` marks the latest), `incident_similar_matches` (the output), `recommender_dead_letters`.
Databases set up with the earlier version still contain `incident_solution_suggestions`; it is no longer written - see the end of `sql/10_recommender.sql` for the cleanup statements.

## Delivery guarantees
* **At-least-once**: offsets are committed after the batch was stored. A redelivered event finds its run (`UNIQUE (trigger_event_id, engine)`) and is skipped.
* **Transient failures** (database down, Gemini rate limit / outage): retried with back-off up to `MAX_ATTEMPTS`; the batch is not committed meanwhile. After that the process exits with code 1 and a restart resumes from the last committed offset.
* **Permanent problems** on one message (bad JSON, unknown incident, an engine bug) go to the dead-letter table and the stream continues.
* Several events for one incident in the same batch: only the newest is computed, the older ones are stored as `SUPERSEDED`.
* Partitions are keyed by incident id (set by the ingestor), so one incident's events stay in order.

## Things to know
* **Embedding model consistency**: only vectors with the same `embedding_model` are compared. Both projects use Gemini `gemini-embedding-001` at 768 dims with the same text recipe and the same model name, so they share the column. If you ever change the model, run `--backfill-embeddings`. At start-up the consumer warns when earlier incidents with a plan are not embedded with the current model.
* **Calibrate `MIN_SIMILARITY`**: cosine scores depend on the model (unrelated texts often score 0.4-0.6 with some models). Look at `v_incident_similar_matches.similarity` for known-similar and known-different pairs, then set the floor.
* **No history, no matches**: only incidents that already have a plan (and an approved status) can be matched. Fresh databases return `NO_MATCH` runs - that is normal.
* If `CANDIDATE_STATUSES` plus the plan filter leave very few rows, pgvector's HNSW index may return fewer than `TOP_K`; the query raises `hnsw.ef_search` to 200 to limit this.

## AI planner (engine `ai-planner`, Gemini Flash)
Enable with `ENGINES=vector-similarity,ai-planner` (in that order - it uses the vector engine's matches). Per incident it asks Gemini Flash
(`GEMINI_PLAN_MODEL`, default `gemini-2.5-flash`, same `GEMINI_API_KEY`) for an **ordered plan of APPROVED solutions** and, where the catalog
has nothing that fits, **drafts of solutions a developer should build**.

* Context: the incident (CVE, descriptions, impacted assets), the approved catalog (latest APPROVED version of every non-retired solution,
  max `PLAN_MAX_CATALOG`; `job_spec` is never sent) and the plans of the `PLAN_SIMILAR_INCIDENTS` best vector matches as examples.
* The answer is structured JSON. Every step must reference a catalog entry; invented / duplicate references are rejected, the model gets
  one retry with the errors, after that the run is stored as `FAILED`. The outcome (`FULL_PLAN`, `PARTIAL_PLAN`, `NO_MATCH`) is derived from the content.
* Same input as last time (incident, assets, catalog, similar plans, prompt, model) → the earlier answer is copied, no LLM call.
* Output: `incident_ai_plans`, `incident_ai_plan_steps` (references to solution versions), `ai_solution_drafts`. Nothing is written to
  `incident_plan_steps`: planners apply the suggestion in the UI (incident → *AI Suggested* tab → API `POST /incidents/{id}/ai-plan/apply`),
  and it still goes through incident approval. Drafts are tracked there too (*Create solution* → normal solution review).
* `python -m recommender --incident 57` runs both engines for one incident - the quickest way to try it.

## Adding an AI engine later
Implement the `Engine` protocol in `src/recommender/engines.py` (`name`, `needs_embedding`, `suggest(conn, incident, settings, model) -> EngineResult`), register it in `ENGINES`, and enable it with `ENGINES=vector-similarity,my-engine`. It gets its own run rows (`engine` column) and its own `is_current` run per incident, so results sit side by side with the vector engine's. It can read the vector engine's matches from the database, call an LLM, and store its own ranking of similar incidents. `tests/test_recommender.py::test_second_engine_writes_next_to_the_first` shows the pattern.

## Tests
`TEST_DATABASE_URL=postgresql://user:pw@host/scratch_db pytest -q` - **drops the public schema** of that database; needs pgvector. The live Gemini API and the live Kafka consumer are not covered (no network access when this was built); everything else runs against a real Postgres with an offline test embedder (word overlap, tests only).

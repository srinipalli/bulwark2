-- =====================================================================
-- Bulwark: vector column on incidents for similarity search
-- Needs the pgvector extension (>= 0.5 for HNSW). Run once, as a user allowed to CREATE EXTENSION.
-- Dimension 768 is deliberate: it fits both  Gemini  gemini-embedding-001 (output_dimensionality=768)
-- and HuggingFace  BAAI/bge-base-en-v1.5 (native 768).  Changing the model to another size means
-- changing the column type (see the bottom of this file).
-- =====================================================================
CREATE EXTENSION IF NOT EXISTS vector;

ALTER TABLE incidents
  ADD COLUMN IF NOT EXISTS embedding           vector(768),
  ADD COLUMN IF NOT EXISTS embedding_model     TEXT,          -- e.g. gemini:gemini-embedding-001:768 - only compare vectors with the same value
  ADD COLUMN IF NOT EXISTS embedding_text_hash TEXT,          -- sha256 of the text that was embedded; re-embed when it changes
  ADD COLUMN IF NOT EXISTS embedded_at         TIMESTAMPTZ;

-- Cosine distance, approximate nearest neighbour. Partial: rows without a vector are not indexed.
CREATE INDEX IF NOT EXISTS ix_incidents_embedding_hnsw
  ON incidents USING hnsw (embedding vector_cosine_ops)
  WHERE embedding IS NOT NULL;

-- Rows still to embed (used by incident-embed)
CREATE INDEX IF NOT EXISTS ix_incidents_not_embedded ON incidents (created_at) WHERE embedding IS NULL;

-- ---- optional: switch to another dimension (e.g. 384 for all-MiniLM-L6-v2 / bge-small) -------------
-- DROP INDEX ix_incidents_embedding_hnsw;
-- UPDATE incidents SET embedding = NULL, embedding_model = NULL, embedding_text_hash = NULL, embedded_at = NULL;
-- ALTER TABLE incidents ALTER COLUMN embedding TYPE vector(384);
-- CREATE INDEX ix_incidents_embedding_hnsw ON incidents USING hnsw (embedding vector_cosine_ops) WHERE embedding IS NOT NULL;

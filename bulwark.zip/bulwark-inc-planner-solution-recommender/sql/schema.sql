-- Bulwark schema (PostgreSQL 14+). Applied by Alembic revision 0001.
-- Conventions: UUID PKs, TIMESTAMPTZ, TEXT + CHECK instead of native enums (easy to evolve).

CREATE TABLE users (
  id          UUID PRIMARY KEY,
  email       TEXT NOT NULL,
  full_name   TEXT NOT NULL,
  roles       TEXT[] NOT NULL DEFAULT '{}',
  is_active   BOOLEAN NOT NULL DEFAULT TRUE,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX ux_users_email ON users (lower(email));

CREATE TABLE assets (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name         TEXT NOT NULL UNIQUE,
  asset_type   TEXT NOT NULL CHECK (asset_type IN ('SYSTEM','APPLICATION')),
  environment  TEXT NOT NULL,
  hostname     TEXT,
  os_name      TEXT,
  os_version   TEXT,
  owner_team   TEXT,
  attributes   JSONB NOT NULL DEFAULT '{}',
  is_active    BOOLEAN NOT NULL DEFAULT TRUE,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ix_assets_env ON assets (environment);

-- ---------------------------------------------------------------- vulnerabilities
CREATE TABLE vulnerabilities (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  cve_id       TEXT NOT NULL UNIQUE,
  title        TEXT NOT NULL,
  description  TEXT,                                   -- NEW: free-text description
  severity     TEXT NOT NULL CHECK (severity IN ('LOW','MEDIUM','HIGH','CRITICAL')),
  cvss_score   NUMERIC(3,1) CHECK (cvss_score BETWEEN 0 AND 10),
  source       TEXT NOT NULL DEFAULT 'MANUAL',
  published_at TIMESTAMPTZ,
  is_active    BOOLEAN NOT NULL DEFAULT TRUE,          -- activate / deactivate
  created_by   UUID REFERENCES users(id),
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ix_vuln_severity ON vulnerabilities (severity);
CREATE INDEX ix_vuln_active ON vulnerabilities (is_active);

CREATE TABLE vulnerability_assets (
  vulnerability_id UUID NOT NULL REFERENCES vulnerabilities(id) ON DELETE CASCADE,
  asset_id         UUID NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
  PRIMARY KEY (vulnerability_id, asset_id)
);

-- ---------------------------------------------------------------- solutions
CREATE TABLE solutions (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title              TEXT NOT NULL,
  description        TEXT,
  is_retired         BOOLEAN NOT NULL DEFAULT FALSE,
  current_version_id UUID,                              -- latest version (any status)
  created_by         UUID REFERENCES users(id),
  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at         TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Immutable content of a solution. Approval applies to a version, never to "the solution".
CREATE TABLE solution_versions (
  id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  solution_id      UUID NOT NULL REFERENCES solutions(id) ON DELETE CASCADE,
  version_no       INT  NOT NULL,
  title            TEXT NOT NULL,
  description      TEXT,
  executor         TEXT NOT NULL CHECK (executor IN ('ANSIBLE','AWS_SSM','SHELL','HTTP')),
  job_spec         JSONB NOT NULL DEFAULT '{}',        -- playbook path, SSM document, command...
  applies_to       TEXT,
  risk_level       TEXT NOT NULL DEFAULT 'MEDIUM' CHECK (risk_level IN ('LOW','MEDIUM','HIGH')),
  requires_reboot  BOOLEAN NOT NULL DEFAULT FALSE,
  timeout_seconds  INT NOT NULL DEFAULT 1800 CHECK (timeout_seconds > 0),
  max_retries      SMALLINT NOT NULL DEFAULT 0 CHECK (max_retries BETWEEN 0 AND 5),
  status           TEXT NOT NULL DEFAULT 'REVIEW_PENDING'
                   CHECK (status IN ('REVIEW_PENDING','APPROVED','REJECTED','CHANGES_REQUESTED')),
  created_by       UUID REFERENCES users(id),
  created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (solution_id, version_no)
);
ALTER TABLE solutions
  ADD CONSTRAINT fk_solutions_current_version
  FOREIGN KEY (current_version_id) REFERENCES solution_versions(id);

-- Level-1 review of a solution version (Approvals -> Solution approvals tab)
CREATE TABLE solution_reviews (
  id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  solution_version_id UUID NOT NULL REFERENCES solution_versions(id) ON DELETE CASCADE,
  level               SMALLINT NOT NULL DEFAULT 1,
  status              TEXT NOT NULL DEFAULT 'PENDING'
                      CHECK (status IN ('PENDING','APPROVED','REJECTED','CHANGES_REQUESTED')),
  requested_by        UUID NOT NULL REFERENCES users(id),
  reviewer_id         UUID REFERENCES users(id),
  comment             TEXT,
  requested_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  decided_at          TIMESTAMPTZ,
  CHECK (reviewer_id IS NULL OR reviewer_id <> requested_by)          -- no self approval
);
CREATE UNIQUE INDEX ux_solution_review_pending
  ON solution_reviews (solution_version_id, level) WHERE status = 'PENDING';

-- ---------------------------------------------------------------- incidents
CREATE TABLE incidents (
  id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  incident_no    BIGINT GENERATED ALWAYS AS IDENTITY UNIQUE,         -- shown as INC-<no>
  vulnerability_id UUID NOT NULL REFERENCES vulnerabilities(id),     -- one incident per vulnerability
  title          TEXT NOT NULL,
  description    TEXT,                                                -- NEW: free-text description
  severity       TEXT NOT NULL CHECK (severity IN ('LOW','MEDIUM','HIGH','CRITICAL')),
  status         TEXT NOT NULL DEFAULT 'OPEN' CHECK (status IN
                 ('OPEN','PENDING_APPROVAL','APPROVED','REJECTED','IN_PROGRESS','RESOLVED','CLOSED')),
  assignee_id    UUID REFERENCES users(id),
  created_by     UUID REFERENCES users(id),
  submitted_by   UUID REFERENCES users(id),
  submitted_at   TIMESTAMPTZ,
  closed_at      TIMESTAMPTZ,
  resolved_at    TIMESTAMPTZ,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ix_incidents_status ON incidents (status);
CREATE INDEX ix_incidents_vuln ON incidents (vulnerability_id);
-- Only one non-finished incident per vulnerability
CREATE UNIQUE INDEX ux_incident_open_per_vuln
  ON incidents (vulnerability_id) WHERE status NOT IN ('RESOLVED','CLOSED');

-- Impacted assets of an incident
CREATE TABLE incident_assets (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  incident_id  UUID NOT NULL REFERENCES incidents(id) ON DELETE CASCADE,
  asset_id     UUID NOT NULL REFERENCES assets(id),
  status       TEXT NOT NULL DEFAULT 'PENDING'
               CHECK (status IN ('PENDING','IN_PROGRESS','PATCHED','FAILED','EXCLUDED')),
  exclude_reason TEXT,
  last_error   TEXT,
  patched_at   TIMESTAMPTZ,
  UNIQUE (incident_id, asset_id)
);

-- Ordered solutions to apply for the incident (each pinned to an approved version)
CREATE TABLE incident_plan_steps (
  id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  incident_id         UUID NOT NULL REFERENCES incidents(id) ON DELETE CASCADE,
  step_no             SMALLINT NOT NULL CHECK (step_no > 0),
  solution_version_id UUID NOT NULL REFERENCES solution_versions(id),
  on_failure          TEXT NOT NULL DEFAULT 'STOP_ASSET' CHECK (on_failure IN ('STOP_ASSET','CONTINUE','STOP_ALL')),
  UNIQUE (incident_id, step_no),
  UNIQUE (incident_id, solution_version_id)
);

-- Level-1 approval of an incident plan (Approvals -> Incident approvals tab)
CREATE TABLE incident_approvals (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  incident_id   UUID NOT NULL REFERENCES incidents(id) ON DELETE CASCADE,
  level         SMALLINT NOT NULL DEFAULT 1,
  status        TEXT NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING','APPROVED','REJECTED','CANCELLED')),
  requested_by  UUID NOT NULL REFERENCES users(id),
  decided_by    UUID REFERENCES users(id),
  comment       TEXT,
  plan_snapshot JSONB NOT NULL DEFAULT '[]',          -- plan as submitted, for audit
  requested_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  decided_at    TIMESTAMPTZ,
  CHECK (decided_by IS NULL OR decided_by <> requested_by)
);
CREATE UNIQUE INDEX ux_incident_approval_pending
  ON incident_approvals (incident_id, level) WHERE status = 'PENDING';

-- ---------------------------------------------------------------- execution
CREATE TABLE job_runs (
  id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  incident_id      UUID NOT NULL REFERENCES incidents(id),
  plan_step_id     UUID NOT NULL REFERENCES incident_plan_steps(id),
  incident_asset_id UUID NOT NULL REFERENCES incident_assets(id),
  attempt          SMALLINT NOT NULL DEFAULT 1,
  status           TEXT NOT NULL DEFAULT 'QUEUED'
                   CHECK (status IN ('QUEUED','RUNNING','SUCCEEDED','FAILED','CANCELLED')),
  idempotency_key  TEXT NOT NULL UNIQUE,
  exit_code        INT,
  result           JSONB,
  error_message    TEXT,
  triggered_by     UUID REFERENCES users(id),
  locked_by        TEXT,
  queued_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  started_at       TIMESTAMPTZ,
  finished_at      TIMESTAMPTZ
);
CREATE INDEX ix_job_runs_queue ON job_runs (status, queued_at);
CREATE INDEX ix_job_runs_incident ON job_runs (incident_id);
-- never two live runs for the same step + asset ...
CREATE UNIQUE INDEX ux_job_runs_active
  ON job_runs (plan_step_id, incident_asset_id) WHERE status IN ('QUEUED','RUNNING');
-- ... and a succeeded step is never run again
CREATE UNIQUE INDEX ux_job_runs_succeeded
  ON job_runs (plan_step_id, incident_asset_id) WHERE status = 'SUCCEEDED';

CREATE TABLE job_run_logs (
  id         BIGSERIAL PRIMARY KEY,
  job_run_id UUID NOT NULL REFERENCES job_runs(id) ON DELETE CASCADE,
  stream     TEXT NOT NULL DEFAULT 'stdout',
  message    TEXT NOT NULL,
  logged_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ix_job_run_logs_run ON job_run_logs (job_run_id, id);

-- ---------------------------------------------------------------- audit
CREATE TABLE audit_logs (
  id          BIGSERIAL PRIMARY KEY,
  actor_id    UUID REFERENCES users(id),
  action      TEXT NOT NULL,
  entity_type TEXT NOT NULL,
  entity_id   TEXT NOT NULL,
  before      JSONB,
  after       JSONB,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ix_audit_entity ON audit_logs (entity_type, entity_id);

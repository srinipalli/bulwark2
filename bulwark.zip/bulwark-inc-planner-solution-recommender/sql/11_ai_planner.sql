-- =====================================================================
-- Bulwark Solution Recommender - AI planner (engine 'ai-planner', Gemini Flash)
-- Needs: sql/schema.sql + sql/02_pgvector_incidents.sql + sql/10_recommender.sql
-- Safe to run more than once.
--
--   incident_ai_plans        one row per ai-planner run: outcome, confidence, rationale, model, review state
--   incident_ai_plan_steps   the suggested sequence - references to APPROVED solution versions only (no copied content)
--   ai_solution_drafts       solutions the AI says are missing - work items for developers (never executable)
-- The AI only suggests. Planners apply a plan through the API (it goes into incident_plan_steps and the normal approval).
-- =====================================================================

-- ai-planner runs that could not produce a valid plan are stored as FAILED
ALTER TABLE incident_suggestion_runs DROP CONSTRAINT IF EXISTS incident_suggestion_runs_status_check;
ALTER TABLE incident_suggestion_runs ADD CONSTRAINT incident_suggestion_runs_status_check
  CHECK (status IN ('COMPLETED','NO_MATCH','SUPERSEDED','FAILED'));

CREATE TABLE IF NOT EXISTS incident_ai_plans (
  id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  run_id              UUID NOT NULL UNIQUE REFERENCES incident_suggestion_runs(id) ON DELETE CASCADE,
  incident_id         UUID NOT NULL REFERENCES incidents(id) ON DELETE CASCADE,
  outcome             TEXT NOT NULL CHECK (outcome IN ('FULL_PLAN','PARTIAL_PLAN','NO_MATCH','FAILED')),
  confidence          NUMERIC(4,3) CHECK (confidence BETWEEN 0 AND 1),
  rationale           TEXT,
  error               TEXT,                                   -- why the run FAILED (validation errors, ...)
  llm_model           TEXT NOT NULL,
  prompt_version      TEXT NOT NULL,
  input_hash          TEXT NOT NULL,                          -- same input -> the previous answer is reused, no LLM call
  catalog_size        INT NOT NULL DEFAULT 0,
  tokens_in           INT,
  tokens_out          INT,
  reused_from_plan_id UUID REFERENCES incident_ai_plans(id) ON DELETE SET NULL,
  review_status       TEXT NOT NULL DEFAULT 'NEW' CHECK (review_status IN ('NEW','APPLIED','DISMISSED')),
  reviewed_by         UUID REFERENCES users(id),
  review_comment      TEXT,
  reviewed_at         TIMESTAMPTZ,
  created_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_ai_plans_incident ON incident_ai_plans (incident_id, created_at DESC);
CREATE INDEX IF NOT EXISTS ix_ai_plans_hash ON incident_ai_plans (incident_id, input_hash);

CREATE TABLE IF NOT EXISTS incident_ai_plan_steps (
  id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  plan_id             UUID NOT NULL REFERENCES incident_ai_plans(id) ON DELETE CASCADE,
  step_no             SMALLINT NOT NULL CHECK (step_no > 0),
  solution_id         UUID NOT NULL REFERENCES solutions(id) ON DELETE CASCADE,
  solution_version_id UUID NOT NULL REFERENCES solution_versions(id) ON DELETE CASCADE,   -- APPROVED when suggested
  on_failure          TEXT NOT NULL DEFAULT 'STOP_ASSET' CHECK (on_failure IN ('STOP_ASSET','CONTINUE','STOP_ALL')),
  reason              TEXT,
  UNIQUE (plan_id, step_no),
  UNIQUE (plan_id, solution_id)
);

CREATE TABLE IF NOT EXISTS ai_solution_drafts (
  id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  plan_id             UUID NOT NULL REFERENCES incident_ai_plans(id) ON DELETE CASCADE,
  incident_id         UUID NOT NULL REFERENCES incidents(id) ON DELETE CASCADE,
  position_after_step SMALLINT NOT NULL DEFAULT 0 CHECK (position_after_step >= 0),     -- 0 = before step 1
  title               TEXT NOT NULL,
  problem             TEXT NOT NULL,                          -- what the approved catalog does not cover
  executor            TEXT NOT NULL CHECK (executor IN ('ANSIBLE','AWS_SSM','SHELL','HTTP')),
  applies_to          TEXT,
  proposed_procedure  JSONB NOT NULL DEFAULT '[]',            -- ["step 1 in plain words", ...] - never a job_spec
  risk_level          TEXT NOT NULL DEFAULT 'MEDIUM' CHECK (risk_level IN ('LOW','MEDIUM','HIGH')),
  requires_reboot     BOOLEAN NOT NULL DEFAULT FALSE,
  status              TEXT NOT NULL DEFAULT 'OPEN' CHECK (status IN ('OPEN','IN_DEVELOPMENT','CREATED','REJECTED')),
  created_solution_id UUID REFERENCES solutions(id) ON DELETE SET NULL,
  updated_by          UUID REFERENCES users(id),
  updated_at          TIMESTAMPTZ,
  created_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_ai_drafts_plan ON ai_solution_drafts (plan_id);
CREATE INDEX IF NOT EXISTS ix_ai_drafts_open ON ai_solution_drafts (status) WHERE status IN ('OPEN','IN_DEVELOPMENT');

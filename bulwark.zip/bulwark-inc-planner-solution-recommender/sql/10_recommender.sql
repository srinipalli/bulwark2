-- =====================================================================
-- Bulwark Solution Recommender - result tables
-- Needs: Bulwark schema (sql/schema.sql) + incidents.embedding (sql/02_pgvector_incidents.sql)
-- Safe to run more than once.
--
--   incident_suggestion_runs        one row per (Kafka event, engine): provenance, parameters, outcome
--   incident_similar_matches        THE OUTPUT: incident -> similar earlier incident that has a plan, with the similarity score.
--                                   The plan itself is NOT copied: read it from incident_plan_steps of similar_incident_id.
--   recommender_dead_letters        messages that could not be processed (bad JSON, unknown incident ...)
-- "engine" lets other engines (LLM re-ranking, rules ...) write next to the vector engine later.
-- =====================================================================
CREATE TABLE IF NOT EXISTS incident_suggestion_runs (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  incident_id       UUID NOT NULL REFERENCES incidents(id) ON DELETE CASCADE,
  trigger_event_id  TEXT NOT NULL,                       -- event_id of the Kafka message; redelivery cannot create a second run
  trigger_event_type TEXT NOT NULL,                      -- incident.created | incident.updated
  scan_id           TEXT,
  kafka_topic       TEXT,
  kafka_partition   INT,
  kafka_offset      BIGINT,
  engine            TEXT NOT NULL,                       -- 'vector-similarity' today
  embedding_model   TEXT,                                -- model that produced the vectors compared in this run
  params            JSONB NOT NULL DEFAULT '{}',         -- top_k, min_similarity, candidate statuses ...
  status            TEXT NOT NULL CHECK (status IN ('COMPLETED','NO_MATCH','SUPERSEDED','FAILED')),   -- FAILED: ai-planner (11_ai_planner.sql)
  similar_found     INT NOT NULL DEFAULT 0,
  is_current        BOOLEAN NOT NULL DEFAULT FALSE,      -- the latest usable run of this engine for the incident
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (trigger_event_id, engine)
);
CREATE INDEX IF NOT EXISTS ix_suggestion_runs_incident ON incident_suggestion_runs (incident_id, created_at DESC);
CREATE UNIQUE INDEX IF NOT EXISTS ux_suggestion_run_current ON incident_suggestion_runs (incident_id, engine) WHERE is_current;

CREATE TABLE IF NOT EXISTS incident_similar_matches (
  id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  run_id              UUID NOT NULL REFERENCES incident_suggestion_runs(id) ON DELETE CASCADE,
  incident_id         UUID NOT NULL REFERENCES incidents(id) ON DELETE CASCADE,        -- the incident from the Kafka event
  similar_incident_id UUID NOT NULL REFERENCES incidents(id) ON DELETE CASCADE,        -- an earlier incident that has a plan (incident_plan_steps)
  similarity          NUMERIC(6,5) NOT NULL CHECK (similarity BETWEEN -1 AND 1),       -- cosine similarity, 1 = identical
  rank                SMALLINT NOT NULL,
  created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (run_id, similar_incident_id)
);
CREATE INDEX IF NOT EXISTS ix_similar_matches_incident ON incident_similar_matches (incident_id);
CREATE INDEX IF NOT EXISTS ix_similar_matches_similar ON incident_similar_matches (similar_incident_id);

CREATE TABLE IF NOT EXISTS recommender_dead_letters (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  topic      TEXT,
  partition  INT,
  "offset"   BIGINT,
  msg_key    TEXT,
  reason     TEXT NOT NULL,
  payload    TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS ux_dead_letter_msg ON recommender_dead_letters (topic, partition, "offset");

-- Convenience view (current run only) ----------------------------------------------------------
CREATE OR REPLACE VIEW v_incident_similar_matches AS
SELECT 'INC-' || i.incident_no AS incident, 'INC-' || si.incident_no AS similar_incident, m.rank, m.similarity,
       si.title AS similar_title, si.status AS similar_status, m.run_id, r.engine, r.created_at AS matched_at,
       m.incident_id, m.similar_incident_id
  FROM incident_suggestion_runs r
  JOIN incident_similar_matches m ON m.run_id = r.id
  JOIN incidents i ON i.id = m.incident_id
  JOIN incidents si ON si.id = m.similar_incident_id
 WHERE r.is_current;

-- Databases created with an earlier version of this file still have the per-solution output; it is no longer written.
-- Remove it when nothing reads it any more:
--   DROP VIEW IF EXISTS v_incident_solution_suggestions; DROP TABLE IF EXISTS incident_solution_suggestions;
--   ALTER TABLE incident_suggestion_runs DROP COLUMN IF EXISTS suggestions_count;

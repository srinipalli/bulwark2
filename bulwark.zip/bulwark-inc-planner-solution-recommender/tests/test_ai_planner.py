import json

from conftest import OPENSSL, OPENSSL2, add_incident, add_plan, add_solution, event_body, msgs
from recommender.ai_planner import AiPlannerEngine, LlmPlan, validate
from recommender.engines import VectorSimilarityEngine
from recommender.processor import backfill_embeddings


class FakeLlm:
    """Offline stand-in for Gemini Flash: returns the queued answers in order and records the prompts."""
    name = "fake:flash"

    def __init__(self, *answers):
        self.answers, self.prompts = list(answers), []

    def generate(self, system, prompt):
        self.prompts.append(prompt)
        a = self.answers.pop(0)
        return (a if isinstance(a, str) else json.dumps(a)), 100, 20


def ref_of(prompt: str, title: str) -> str:
    cat = json.loads(prompt.split("\n", 2)[1])
    return next(c["ref"] for c in cat if c["title"].startswith(title))


def setup(db):
    a = add_incident(db, "CVE-2024-0001", *OPENSSL, status="RESOLVED")
    backup, (vb,) = add_solution(db, "Backup and snapshot")
    upgrade, (vu,) = add_solution(db, "Upgrade OpenSSL")
    add_plan(db, a["id"], vb, 1)
    add_plan(db, a["id"], vu, 2)
    add_solution(db, "Never approved", versions=("REVIEW_PENDING",))
    add_solution(db, "Retired fix", retired=True)
    new = add_incident(db, "CVE-2024-0003", *OPENSSL2)
    return a, new, (backup, vb), (upgrade, vu)


def plan_answer(*steps, drafts=()):
    return {"outcome": "FULL_PLAN", "confidence": 0.8, "rationale": "Same fix as INC-1.",
            "steps": [{"ref": r, "on_failure": f, "reason": "because"} for r, f in steps], "new_solution_drafts": list(drafts)}


DRAFT = {"position_after_step": 2, "title": "Verify OpenSSL version", "problem": "No verification step in the catalog",
         "executor": "SHELL", "applies_to": "Linux", "proposed_procedure": ["openssl version", "compare with 3.0.13"],
         "risk_level": "LOW", "requires_reboot": False}


class LazyLlm(FakeLlm):
    """Builds its answer from the prompt (refs are only known once the catalog was rendered)."""

    def __init__(self, make):
        super().__init__()
        self.make = make

    def generate(self, system, prompt):
        self.prompts.append(prompt)
        return json.dumps(self.make(prompt)), 100, 20


def test_ai_plan_uses_only_approved_catalog_and_stores_drafts(db, make_proc):
    llm = LazyLlm(lambda p: plan_answer((ref_of(p, "Backup"), "STOP_ALL"), (ref_of(p, "Upgrade"), "STOP_ASSET"), drafts=[DRAFT]))
    p = make_proc(engines=[VectorSimilarityEngine(), AiPlannerEngine(llm=llm)])
    a, new, (backup, vb), (upgrade, vu) = setup(db)
    backfill_embeddings(p.conn(), p.embedder)
    st = p.process_batch(msgs(event_body(new["id"])))
    assert st.runs == 2 and st.failed == 0

    prompt = llm.prompts[0]
    assert "Never approved" not in prompt and "Retired fix" not in prompt and "job_spec" not in prompt
    assert f"INC-{a['no']}" in prompt                                           # similar incident's plan is an example
    plan = db.execute("select * from incident_ai_plans").fetchone()
    assert plan["outcome"] == "PARTIAL_PLAN" and float(plan["confidence"]) == 0.8 and plan["review_status"] == "NEW"
    steps = db.execute("select * from incident_ai_plan_steps order by step_no").fetchall()
    assert [(s["solution_id"], s["solution_version_id"], s["on_failure"]) for s in steps] == [(backup, vb, "STOP_ALL"), (upgrade, vu, "STOP_ASSET")]
    d = db.execute("select * from ai_solution_drafts").fetchone()
    assert d["title"] == "Verify OpenSSL version" and d["status"] == "OPEN" and d["proposed_procedure"] == ["openssl version", "compare with 3.0.13"]
    run = db.execute("select * from incident_suggestion_runs where engine='ai-planner'").fetchone()
    assert run["status"] == "COMPLETED" and run["is_current"]


def test_invented_ref_is_retried_then_fails(db, make_proc):
    llm = FakeLlm(plan_answer(("S99", "STOP_ASSET")), "not json at all")
    p = make_proc(engines=[AiPlannerEngine(llm=llm)])
    new = add_incident(db, "CVE-2024-0003", *OPENSSL2)
    add_solution(db, "Upgrade OpenSSL")
    p.process_batch(msgs(event_body(new["id"])))
    assert len(llm.prompts) == 2 and "S99" in llm.prompts[1] and "rejected" in llm.prompts[1]
    plan = db.execute("select * from incident_ai_plans").fetchone()
    assert plan["outcome"] == "FAILED" and "schema" in plan["error"]
    assert db.execute("select status from incident_suggestion_runs").fetchone()["status"] == "FAILED"


def test_same_input_reuses_previous_plan_without_llm_call(db, make_proc):
    llm = LazyLlm(lambda p: plan_answer((ref_of(p, "Upgrade"), "STOP_ASSET")))
    p = make_proc(engines=[AiPlannerEngine(llm=llm)])
    new = add_incident(db, "CVE-2024-0003", *OPENSSL2)
    add_solution(db, "Upgrade OpenSSL")
    p.process_batch(msgs(event_body(new["id"], event_id="e-1")))
    db.execute("update incident_ai_plans set review_status='DISMISSED'")
    p.process_batch(msgs(event_body(new["id"], event_id="e-2"), start=5))
    assert len(llm.prompts) == 1                                                # second event: nothing changed -> no LLM call
    plans = db.execute("select * from incident_ai_plans order by created_at").fetchall()
    assert len(plans) == 2 and plans[1]["reused_from_plan_id"] == plans[0]["id"] and plans[1]["review_status"] == "DISMISSED"
    assert db.execute("select count(*) n from incident_ai_plan_steps").fetchone()["n"] == 2
    add_solution(db, "New approved fix")                                        # catalog changed -> new LLM call
    p.process_batch(msgs(event_body(new["id"], event_id="e-3"), start=9))
    assert len(llm.prompts) == 2


def test_validate_derives_outcome_and_rejects_duplicates():
    refs = {"S1": {"solution_id": "a", "version_id": "va"}, "S2": {"solution_id": "b", "version_id": "vb"}}
    errors, r = validate(LlmPlan(**plan_answer(("S1", "STOP_ASSET"), ("S1", "CONTINUE"))), refs)
    assert errors and "more than once" in errors[0]
    errors, r = validate(LlmPlan(outcome="FULL_PLAN", confidence=3, rationale="x", steps=[], new_solution_drafts=[DRAFT | {"position_after_step": 0}]), refs)
    assert not errors and r["outcome"] == "NO_MATCH" and r["confidence"] == 1.0          # label comes from the content, confidence clamped
    errors, _ = validate(LlmPlan(outcome="NO_MATCH", steps=[], new_solution_drafts=[]), refs)
    assert errors

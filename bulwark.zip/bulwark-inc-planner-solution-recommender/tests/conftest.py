import hashlib
import json
import os
import re
import uuid
from pathlib import Path

import psycopg
import pytest
from psycopg.rows import dict_row

from recommender.config import Settings
from recommender.embeddings import normalize
from recommender.engines import VectorSimilarityEngine
from recommender.processor import Processor
from recommender.sources import Msg

ROOT = Path(__file__).resolve().parents[1]
URL = os.environ.get("TEST_DATABASE_URL")


@pytest.fixture()
def settings():
    if not URL:
        pytest.skip("set TEST_DATABASE_URL (scratch database - its public schema is DROPPED)")
    return Settings(database_url=URL, embed_provider="hash", min_similarity=0.5, batch_size=10, max_attempts=2)


@pytest.fixture()
def db(settings):
    with psycopg.connect(URL, autocommit=True, row_factory=dict_row) as c:
        c.execute("DROP SCHEMA public CASCADE; CREATE SCHEMA public;")
        c.execute((ROOT / "sql" / "schema.sql").read_text())
        try:
            c.execute((ROOT / "sql" / "02_pgvector_incidents.sql").read_text())
        except Exception as e:                                                # noqa: BLE001
            pytest.skip(f"pgvector not available: {e}")
        c.execute((ROOT / "sql" / "10_recommender.sql").read_text())
        c.execute((ROOT / "sql" / "11_ai_planner.sql").read_text())
        yield c


class HashEmbedder:
    """OFFLINE TEST DOUBLE (word overlap, no semantics). Production uses Gemini only."""
    name, dim = "hash:bow:768", 768

    def embed_documents(self, texts):
        out = []
        for t in texts:
            v = [0.0] * self.dim
            toks = re.findall(r"[a-z0-9]+", t.lower())
            for tok in toks + [a + "_" + b for a, b in zip(toks, toks[1:])]:
                v[int(hashlib.md5(tok.encode()).hexdigest(), 16) % self.dim] += 1.0
            out.append(normalize(v))
        return out


@pytest.fixture()
def embedder():
    return HashEmbedder()


@pytest.fixture()
def make_proc(settings, embedder):
    procs = []

    def f(engines=None, emb=None):
        p = Processor(lambda: psycopg.connect(URL, autocommit=True, row_factory=dict_row), settings, emb or embedder, engines or [VectorSimilarityEngine()])
        procs.append(p)
        return p
    yield f
    for p in procs:
        p.close()


# ---------------------------------------------------------------- data helpers
def add_incident(db, cve: str, title: str, desc: str = "", status: str = "OPEN") -> dict:
    v = db.execute("INSERT INTO vulnerabilities (cve_id, title, description, severity, cvss_score) VALUES (%s,%s,%s,'HIGH',8.1) RETURNING id", (cve, title, desc)).fetchone()
    i = db.execute("INSERT INTO incidents (vulnerability_id, title, severity, status) VALUES (%s,%s,'HIGH',%s) RETURNING id, incident_no", (v["id"], f"{cve}: {title}", status)).fetchone()
    return {"id": i["id"], "no": i["incident_no"]}


def add_solution(db, title: str, versions=("APPROVED",), retired: bool = False) -> tuple:
    sid = db.execute("INSERT INTO solutions (title, is_retired) VALUES (%s,%s) RETURNING id", (title, retired)).fetchone()["id"]
    vids = [db.execute("INSERT INTO solution_versions (solution_id, version_no, title, executor, status) VALUES (%s,%s,%s,'ANSIBLE',%s) RETURNING id",
                       (sid, n, f"{title} v{n}", st)).fetchone()["id"] for n, st in enumerate(versions, 1)]
    return sid, vids


def add_plan(db, incident_id, version_id, step: int = 1):
    db.execute("INSERT INTO incident_plan_steps (incident_id, step_no, solution_version_id) VALUES (%s,%s,%s)", (incident_id, step, version_id))


def event_body(incident_id, event_id=None, event_type="incident.created", **over) -> dict:
    d = {"schema_version": "1.0", "event_id": event_id or str(uuid.uuid4()), "event_type": event_type,
         "incident": {"id": str(incident_id), "incident_no": 1}, "scan": {"scan_id": "SCAN-T"}}
    d.update(over)
    return d


def msgs(*bodies, start=0, raw=None) -> list[Msg]:
    out = [Msg("bulwark.incidents", 0, start + n, str(b.get("incident", {}).get("id")), json.dumps(b).encode()) for n, b in enumerate(bodies)]
    for r in raw or []:
        out.append(Msg("bulwark.incidents", 0, start + len(out), None, r))
    return out


OPENSSL = ("OpenSSL buffer overflow remote code execution", "A heap buffer overflow in OpenSSL allows remote code execution on Linux servers.")
OPENSSL2 = ("OpenSSL heap buffer overflow remote code execution", "Heap buffer overflow in OpenSSL TLS handling allows remote code execution on Linux servers.")
SPOOLER = ("Windows print spooler privilege escalation", "The Windows Print Spooler service lets a local user elevate privileges to SYSTEM.")

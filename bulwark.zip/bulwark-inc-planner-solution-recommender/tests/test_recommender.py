import json
import uuid

import pytest
from conftest import OPENSSL, OPENSSL2, SPOOLER, add_incident, add_plan, add_solution, event_body, msgs
from recommender import cli
from recommender.config import get_settings
from recommender.embeddings import EmbedError
from recommender.engines import EngineResult, VectorSimilarityEngine
from recommender.events import BadMessage, NotAnIncidentEvent, parse
from recommender.processor import GaveUp, Transient, backfill_embeddings, consume_loop
from recommender.sources import ListSource, Msg, file_source


def history(db, embedder):
    """Two finished incidents with plans (OpenSSL -> sol_a, spooler -> sol_b) and one new OPEN OpenSSL incident."""
    a = add_incident(db, "CVE-2024-0001", *OPENSSL, status="RESOLVED")
    b = add_incident(db, "CVE-2024-0002", *SPOOLER, status="RESOLVED")
    sa, (va1,) = add_solution(db, "Upgrade OpenSSL via Ansible")
    sb, (vb1,) = add_solution(db, "Disable Print Spooler via GPO")
    add_plan(db, a["id"], va1)
    add_plan(db, b["id"], vb1)
    new = add_incident(db, "CVE-2024-0003", *OPENSSL2)
    return a, b, new, sa, sb


def run(proc, *bodies, raw=None, start=0):
    return proc.process_batch(msgs(*bodies, raw=raw, start=start))


def embed_history(db, proc):
    backfill_embeddings(proc.conn(), proc.embedder)


def test_finds_similar_incident_with_plan(db, make_proc):
    p = make_proc()
    a, b, new, sa, sb = history(db, p.embedder)
    st = run(p, event_body(new["id"]))
    assert st.runs == 1 and st.embedded == 1                       # history is embedded below only for the new one -> see next test for backfill
    # the history was never embedded: the search cannot see it yet
    assert db.execute("select status from incident_suggestion_runs").fetchone()["status"] == "NO_MATCH"
    embed_history(db, p)
    run(p, event_body(new["id"]))
    runs = db.execute("select * from incident_suggestion_runs where is_current").fetchall()
    assert len(runs) == 1 and runs[0]["status"] == "COMPLETED" and runs[0]["engine"] == "vector-similarity" and runs[0]["embedding_model"] == "hash:bow:768"
    m = db.execute("select * from incident_similar_matches where run_id=%s", (runs[0]["id"],)).fetchall()
    assert [x["similar_incident_id"] for x in m] == [a["id"]] and m[0]["incident_id"] == new["id"] and float(m[0]["similarity"]) > 0.5 and m[0]["rank"] == 1
    v = db.execute("select * from v_incident_similar_matches").fetchall()
    assert len(v) == 1 and v[0]["incident"] == f"INC-{new['no']}" and v[0]["similar_incident"] == f"INC-{a['no']}" and v[0]["similar_incident_id"] == a["id"]
    plan = db.execute("select ps.solution_version_id from v_incident_similar_matches m join incident_plan_steps ps on ps.incident_id = m.similar_incident_id").fetchall()
    assert len(plan) == 1                                         # the plan is read from the similar incident, not copied


def test_exclusions(db, make_proc):
    p = make_proc()
    new = add_incident(db, "CVE-2024-0003", *OPENSSL2)
    for n, status in enumerate(["OPEN", "PENDING_APPROVAL", "REJECTED"], 10):          # plans that were never approved teach nothing
        i = add_incident(db, f"CVE-2024-00{n}", *OPENSSL, status=status)
        add_plan(db, i["id"], add_solution(db, f"Sol {status}")[1][0], 1)
    noplan = add_incident(db, "CVE-2024-0022", *OPENSSL, status="RESOLVED")           # finished but without a plan
    assert noplan
    embed_history(db, p)
    run(p, event_body(new["id"]))
    r = db.execute("select * from incident_suggestion_runs where is_current").fetchone()
    assert r["status"] == "NO_MATCH" and r["similar_found"] == 0
    assert db.execute("select count(*) n from incident_similar_matches").fetchone()["n"] == 0


def test_several_similar_incidents_are_ranked(db, make_proc):
    p = make_proc()
    sa, (va,) = add_solution(db, "Upgrade OpenSSL")
    for n, t in enumerate([OPENSSL, OPENSSL2], 1):
        i = add_incident(db, f"CVE-2024-010{n}", *t, status="CLOSED")
        add_plan(db, i["id"], va)
    new = add_incident(db, "CVE-2024-0003", "OpenSSL buffer overflow remote code execution on Linux", OPENSSL[1])
    embed_history(db, p)
    run(p, event_body(new["id"]))
    m = db.execute("select rank, similarity from incident_similar_matches order by rank").fetchall()
    assert [x["rank"] for x in m] == [1, 2] and m[0]["similarity"] >= m[1]["similarity"]


def test_redelivery_is_idempotent(db, make_proc):
    p = make_proc()
    a, b, new, *_ = history(db, p.embedder)
    embed_history(db, p)
    ev = event_body(new["id"], event_id="e-1")
    run(p, ev)
    st = run(p, ev, start=10)
    assert st.duplicates == 1 and st.runs == 0
    assert db.execute("select count(*) n from incident_suggestion_runs").fetchone()["n"] == 1


def test_newer_run_replaces_current_and_keeps_history(db, make_proc):
    p = make_proc()
    a, b, new, *_ = history(db, p.embedder)
    embed_history(db, p)
    run(p, event_body(new["id"], event_id="e-1"))
    run(p, event_body(new["id"], event_id="e-2", event_type="incident.updated"), start=5)
    rows = db.execute("select trigger_event_id, is_current from incident_suggestion_runs order by created_at").fetchall()
    assert [(r["trigger_event_id"], r["is_current"]) for r in rows] == [("e-1", False), ("e-2", True)]
    assert db.execute("select count(*) n from incident_similar_matches").fetchone()["n"] == 2      # old matches stay for audit
    assert db.execute("select count(*) n from v_incident_similar_matches").fetchone()["n"] == 1    # views show current only


def test_same_incident_twice_in_a_batch_is_collapsed(db, make_proc):
    p = make_proc()
    a, b, new, *_ = history(db, p.embedder)
    embed_history(db, p)
    st = run(p, event_body(new["id"], event_id="e-1"), event_body(new["id"], event_id="e-2", event_type="incident.updated"))
    assert st.runs == 1 and st.superseded == 1
    assert {(r["trigger_event_id"], r["status"]) for r in db.execute("select * from incident_suggestion_runs").fetchall()} == {("e-1", "SUPERSEDED"), ("e-2", "COMPLETED")}


def test_bad_messages_go_to_dead_letters(db, make_proc):
    p = make_proc()
    a, b, new, *_ = history(db, p.embedder)
    bodies = [event_body(uuid.uuid4(), event_id="e-ghost"),                                   # unknown incident
              event_body(new["id"], schema_version="2.0"),
              {"schema_version": "1.0", "event_type": "incident.created", "incident": {"id": str(new["id"])}},   # no event_id
              event_body(new["id"], event_id="e-nouuid", incident={"id": "not-a-uuid"})]
    ignored = [{"schema_version": "1.0", "event_id": "s1", "event_type": "scan.completed", "scan": {"scan_id": "x"}},
               event_body(new["id"], event_id="u1", event_type="incident.unchanged")]
    st = run(p, *bodies, *ignored, raw=[b"{not json", b"\xff\xfe"])
    assert st.dead_letters == 6 and st.ignored == 2 and st.runs == 0
    reasons = [r["reason"] for r in db.execute("select reason from recommender_dead_letters order by \"offset\"").fetchall()]
    assert any("not found" in r for r in reasons) and any("schema_version" in r for r in reasons) and any("JSON" in r for r in reasons)
    run(p, *bodies, *ignored, raw=[b"{not json", b"\xff\xfe"])                                  # replay: dead letters are not duplicated
    assert db.execute("select count(*) n from recommender_dead_letters").fetchone()["n"] == 6


def test_embeds_the_new_incident_on_demand(db, make_proc):
    p = make_proc()
    new = add_incident(db, "CVE-2024-0003", *OPENSSL2)
    st = run(p, event_body(new["id"]))
    r = db.execute("select embedding is not null as has, embedding_model, embedding_text_hash, embedded_at from incidents").fetchone()
    assert st.embedded == 1 and r["has"] and r["embedding_model"] == "hash:bow:768" and r["embedding_text_hash"] and r["embedded_at"]
    assert run(p, event_body(new["id"]), start=3).embedded == 0                               # unchanged text: not embedded again


class FlakyEmbedder:
    name, dim = "hash:bow:768", 768

    def __init__(self, inner, fail_times):
        self.inner, self.left = inner, fail_times

    def embed_documents(self, texts):
        if self.left > 0:
            self.left -= 1
            raise EmbedError("429 rate limited")
        return self.inner.embed_documents(texts)


def test_transient_failure_retries_and_does_not_commit_early(db, make_proc, embedder, settings):
    new = add_incident(db, "CVE-2024-0003", *OPENSSL2)
    src = ListSource(msgs(event_body(new["id"])))
    ok = consume_loop(src, make_proc(emb=FlakyEmbedder(embedder, 1)), settings, sleep=lambda s: None)
    assert ok.runs == 1 and src.committed == 1
    db.execute("delete from incident_suggestion_runs")
    db.execute("update incidents set embedding = null")                       # force an embedding call again
    src = ListSource(msgs(event_body(new["id"], event_id="again")))
    with pytest.raises(GaveUp):
        consume_loop(src, make_proc(emb=FlakyEmbedder(embedder, 99)), settings, sleep=lambda s: None)
    assert src.committed == 0 and db.execute("select count(*) n from incident_suggestion_runs").fetchone()["n"] == 0
    with pytest.raises(Transient):
        make_proc(emb=FlakyEmbedder(embedder, 99)).process_batch(msgs(event_body(new["id"], event_id="x")))


class BoomEngine:
    name, needs_embedding = "boom", False

    def suggest(self, conn, incident, s, model):
        raise ValueError("bug in engine")


class RerankEngine:
    """Stand-in for a later AI engine: re-ranks the vector engine's matches and writes its own run next to it."""
    name, needs_embedding = "ai-rerank", False

    def suggest(self, conn, incident, s, model):
        rows = conn.execute("select similar_incident_id as id, similarity from incident_similar_matches where incident_id=%s order by created_at limit 1",
                            (incident["id"],)).fetchall()
        return EngineResult("test-llm", {"prompt": "v1"}, [{"id": r["id"], "score": 0.99, "rank": 1} for r in rows])


def test_one_failing_engine_is_isolated(db, make_proc):
    p = make_proc(engines=[BoomEngine(), VectorSimilarityEngine()])
    a, b, new, *_ = history(db, p.embedder)
    embed_history(db, p)
    st = run(p, event_body(new["id"]))
    assert st.dead_letters == 1 and st.runs == 1
    assert "bug in engine" in db.execute("select reason from recommender_dead_letters").fetchone()["reason"]


def test_second_engine_writes_next_to_the_first(db, make_proc):
    p = make_proc(engines=[VectorSimilarityEngine(), RerankEngine()])
    a, b, new, *_ = history(db, p.embedder)
    embed_history(db, p)
    run(p, event_body(new["id"]))
    rows = db.execute("select engine, is_current from incident_suggestion_runs order by engine").fetchall()
    assert [(r["engine"], r["is_current"]) for r in rows] == [("ai-rerank", True), ("vector-similarity", True)]
    assert db.execute("select count(*) n from v_incident_similar_matches where engine='ai-rerank' and similar_incident_id=%s", (a["id"],)).fetchone()["n"] == 1


def test_file_source_reads_ingestor_dry_run_format(tmp_path, db):
    new = add_incident(db, "CVE-2024-0003", *OPENSSL2)
    f = tmp_path / "k.jsonl"
    f.write_text("\n".join(json.dumps(x) for x in [
        {"topic": "bulwark.incidents", "key": "k1", "headers": {"event_type": "incident.created"}, "value": event_body(new["id"], event_id="f-1")},
        {"topic": "bulwark.scans.completed", "key": "s", "headers": {}, "value": {"event_type": "scan.completed"}}]) + "\n")
    src = file_source(f, "bulwark.incidents")
    batch = src.poll_batch(10, 0)
    assert len(batch) == 1 and parse(batch[0]).event_id == "f-1"


def test_parse_unit():
    ok = Msg("t", 0, 0, None, json.dumps(event_body(uuid.uuid4())).encode())
    assert parse(ok).event_type == "incident.created"
    with pytest.raises(NotAnIncidentEvent):
        parse(Msg("t", 0, 0, None, json.dumps({"schema_version": "1.0", "event_id": "x", "event_type": "scan.completed"}).encode()))
    with pytest.raises(BadMessage):
        parse(Msg("t", 0, 0, None, b"[]"))


def test_cli_manual_incident_and_backfill(db, settings, embedder, monkeypatch):
    monkeypatch.setenv("DATABASE_URL", settings.database_url)
    monkeypatch.setattr(cli, "get_embedder", lambda s: embedder)
    monkeypatch.setenv("MIN_SIMILARITY", "0.5")
    get_settings.cache_clear()
    from conftest import add_incident as ai
    a = ai(db, "CVE-2024-0001", *OPENSSL, status="RESOLVED")
    add_plan(db, a["id"], add_solution(db, "Upgrade OpenSSL")[1][0])
    new = ai(db, "CVE-2024-0003", *OPENSSL2)
    assert cli.main(["--backfill-embeddings"]) == 0
    assert db.execute("select count(*) n from incidents where embedding is not null").fetchone()["n"] == 2
    assert cli.main(["--incident", str(new["no"])]) == 0
    assert db.execute("select count(*) n from v_incident_similar_matches").fetchone()["n"] == 1
    assert cli.main(["--incident", "9999"]) == 1
    db.execute("drop table recommender_dead_letters")
    assert cli.main(["--incident", str(new["no"])]) == 2                                      # schema check
    get_settings.cache_clear()

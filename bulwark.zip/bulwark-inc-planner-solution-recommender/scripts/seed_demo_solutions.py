"""DEMO ONLY: gives a few finished incidents an approved plan so the recommender has something to learn from.

For each product keyword below it creates a solution (+ APPROVED version 1), takes the OLDEST incident whose vulnerability title contains the keyword,
sets it to RESOLVED and attaches the solution as plan step 1. Run it on a scratch / demo database, never on production data.

    python scripts/seed_demo_solutions.py            # uses DATABASE_URL from the environment or .env
"""
import os
import sys

import psycopg
from psycopg.rows import dict_row

PRODUCTS = {
    "Apache HTTP Server": ("Patch Apache HTTP Server and restart httpd", "ANSIBLE", "MEDIUM", False),
    "Apache Tomcat": ("Upgrade Apache Tomcat to the fixed release", "ANSIBLE", "MEDIUM", False),
    "Oracle WebLogic": ("Apply Oracle WebLogic critical patch update", "SHELL", "HIGH", True),
    "VMware vCenter": ("Apply VMware vCenter security patch", "HTTP", "HIGH", True),
    "PostgreSQL": ("Upgrade PostgreSQL minor version", "ANSIBLE", "MEDIUM", True),
    "Linux kernel": ("Update Linux kernel and reboot", "AWS_SSM", "HIGH", True),
    "Windows": ("Install Windows cumulative update via SSM", "AWS_SSM", "MEDIUM", True),
    "Redis": ("Upgrade Redis to the patched version", "ANSIBLE", "LOW", False),
    "Drupal": ("Update Drupal core with composer", "SHELL", "LOW", False),
    "F5 BIG-IP": ("Apply F5 BIG-IP hotfix", "HTTP", "HIGH", True),
}


def load_dotenv(path=".env"):
    if os.path.exists(path):
        for line in open(path, encoding="utf-8"):
            line = line.split("  #")[0].strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))


def main():
    load_dotenv()
    url = os.environ.get("DATABASE_URL", "postgresql://bulwark:bulwark@localhost:5432/bulwark").replace("postgresql+asyncpg://", "postgresql://")
    n = 0
    with psycopg.connect(url, row_factory=dict_row) as conn:
        for kw, (title, executor, risk, reboot) in PRODUCTS.items():
            inc = conn.execute("""SELECT i.id, i.incident_no FROM incidents i JOIN vulnerabilities v ON v.id = i.vulnerability_id
                                   WHERE v.title ILIKE %s AND NOT EXISTS (SELECT 1 FROM incident_plan_steps ps WHERE ps.incident_id = i.id)
                                   ORDER BY i.incident_no LIMIT 1""", (f"%{kw}%",)).fetchone()
            if not inc:
                continue
            sid = conn.execute("INSERT INTO solutions (title, description) VALUES (%s, %s) RETURNING id", (title, f"Demo solution for {kw}")).fetchone()["id"]
            vid = conn.execute("""INSERT INTO solution_versions (solution_id, version_no, title, executor, risk_level, requires_reboot, status)
                                  VALUES (%s, 1, %s, %s, %s, %s, 'APPROVED') RETURNING id""", (sid, title, executor, risk, reboot)).fetchone()["id"]
            conn.execute("UPDATE solutions SET current_version_id = %s WHERE id = %s", (vid, sid))
            conn.execute("INSERT INTO incident_plan_steps (incident_id, step_no, solution_version_id) VALUES (%s, 1, %s)", (inc["id"], vid))
            conn.execute("UPDATE incidents SET status = 'RESOLVED', resolved_at = now() WHERE id = %s", (inc["id"],))
            print(f"INC-{inc['incident_no']} resolved with '{title}'")
            n += 1
    print(f"{n} demo solution(s) created")


if __name__ == "__main__":
    sys.exit(main())

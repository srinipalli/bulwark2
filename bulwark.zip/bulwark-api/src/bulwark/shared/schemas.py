from uuid import UUID

from pydantic import BaseModel, ConfigDict

SEVERITIES = ("LOW", "MEDIUM", "HIGH", "CRITICAL")


class ORM(BaseModel):
    model_config = ConfigDict(from_attributes=True)


class AssetRef(ORM):
    id: UUID
    name: str
    asset_type: str
    environment: str


class UserRef(ORM):
    id: UUID
    full_name: str

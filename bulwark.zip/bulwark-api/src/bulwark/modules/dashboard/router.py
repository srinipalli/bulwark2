from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession

from bulwark.core.db import get_session
from bulwark.core.security import CurrentUser, get_current_user
from bulwark.modules.dashboard import service
from bulwark.modules.dashboard.schemas import AttentionIncident, Summary

router = APIRouter(prefix="/dashboard", tags=["dashboard"])


@router.get("/summary", response_model=Summary)
async def summary(session: AsyncSession = Depends(get_session), _: CurrentUser = Depends(get_current_user)):
    """Numbers for the dashboard tiles."""
    return await service.summary(session)


@router.get("/attention", response_model=list[AttentionIncident])
async def attention(limit: int = Query(10, ge=1, le=50), session: AsyncSession = Depends(get_session),
                    _: CurrentUser = Depends(get_current_user)):
    """Open incidents, most severe first."""
    return await service.attention(session, limit)

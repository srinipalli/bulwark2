from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from bulwark.modules.approvals.models import IncidentApproval, SolutionReview
from bulwark.modules.dashboard.schemas import AttentionIncident, Summary
from bulwark.modules.execution.models import JobRun
from bulwark.modules.incident.models import FINISHED, RUNNABLE, Incident, IncidentAsset
from bulwark.modules.vulnerabilities.models import Vulnerability
from bulwark.shared.models import Asset


async def _count(session: AsyncSession, stmt) -> int:
    return (await session.execute(select(func.count()).select_from(stmt.subquery()))).scalar_one()


async def summary(session: AsyncSession) -> Summary:
    open_inc = await _count(session, select(Incident.id).where(Incident.status.notin_(FINISHED)))
    all_inc = await _count(session, select(Incident.id))
    in_exec = await _count(session, select(Incident.id).where(Incident.status.in_(RUNNABLE)))
    p_inc = await _count(session, select(IncidentApproval.id).where(IncidentApproval.status == "PENDING"))
    p_sol = await _count(session, select(SolutionReview.id).where(SolutionReview.status == "PENDING"))
    running = await _count(session, select(JobRun.id).where(JobRun.status == "RUNNING"))
    queued = await _count(session, select(JobRun.id).where(JobRun.status == "QUEUED"))
    failed = await _count(session, select(IncidentAsset.id).join(Incident, Incident.id == IncidentAsset.incident_id)
                          .where(IncidentAsset.status == "FAILED", Incident.status.notin_(FINISHED)))
    active_v = await _count(session, select(Vulnerability.id).where(Vulnerability.is_active.is_(True)))
    all_v = await _count(session, select(Vulnerability.id))
    total = await _count(session, select(IncidentAsset.id).where(IncidentAsset.status != "EXCLUDED"))
    patched = await _count(session, select(IncidentAsset.id).where(IncidentAsset.status == "PATCHED"))
    inv_active = await _count(session, select(Asset.id).where(Asset.is_active.is_(True)))
    inv_total = await _count(session, select(Asset.id))
    return Summary(open_incidents=open_inc, incidents_total=all_inc, incidents_in_execution=in_exec,
                   incidents_pending_approval=p_inc, solutions_pending_review=p_sol,
                   approvals_waiting=p_inc + p_sol, jobs_running=running, jobs_queued=queued, jobs_failed_open=failed,
                   active_vulnerabilities=active_v, vulnerabilities_total=all_v, assets_patched=patched, assets_total=total,
                   assets_patched_pct=round(patched * 100 / total) if total else 0,
                   inventory_assets_active=inv_active, inventory_assets_total=inv_total)


async def attention(session: AsyncSession, limit: int = 10) -> list[AttentionIncident]:
    sev_rank = func.array_position(["CRITICAL", "HIGH", "MEDIUM", "LOW"], Incident.severity)
    rows = (await session.execute(
        select(Incident, Vulnerability.cve_id).join(Vulnerability, Vulnerability.id == Incident.vulnerability_id)
        .where(Incident.status.notin_(FINISHED)).order_by(sev_rank, Incident.incident_no.desc()).limit(limit))).all()
    out = []
    for i, cve in rows:
        act = [a for a in i.assets if a.status != "EXCLUDED"]
        out.append(AttentionIncident(id=i.id, code=i.code, cve_id=cve, severity=i.severity, status=i.status,
                                     assets_count=len(act), patched_count=sum(1 for a in act if a.status == "PATCHED")))
    return out

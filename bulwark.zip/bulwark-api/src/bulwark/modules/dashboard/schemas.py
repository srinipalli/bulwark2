from uuid import UUID

from pydantic import BaseModel


class Summary(BaseModel):
    open_incidents: int                # not RESOLVED / CLOSED
    incidents_total: int
    incidents_in_execution: int        # APPROVED or IN_PROGRESS: what the Execution tab can run
    incidents_pending_approval: int
    solutions_pending_review: int
    approvals_waiting: int
    jobs_running: int
    jobs_queued: int
    jobs_failed_open: int
    active_vulnerabilities: int
    vulnerabilities_total: int
    assets_patched: int                # incident assets (impacted asset rows), not the inventory
    assets_total: int
    assets_patched_pct: int
    inventory_assets_active: int       # asset inventory (Assets tab)
    inventory_assets_total: int


class AttentionIncident(BaseModel):
    id: UUID
    code: str
    cve_id: str
    severity: str
    status: str
    assets_count: int
    patched_count: int

from uuid import UUID

from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from bulwark.core.audit import audit
from bulwark.core.errors import Conflict, NotFound, Unprocessable
from bulwark.core.pagination import PageParams, count_rows
from bulwark.core.security import CurrentUser
from bulwark.modules.incident.models import FINISHED, Incident
from bulwark.modules.vulnerabilities.models import Vulnerability
from bulwark.modules.vulnerabilities.schemas import (OpenIncidentRef, VulnerabilityCreate, VulnerabilityOut,
                                                      VulnerabilityUpdate)
from bulwark.shared.models import Asset


async def _open_incidents(session: AsyncSession, ids: list[UUID]) -> dict[UUID, Incident]:
    if not ids:
        return {}
    rows = (await session.execute(select(Incident).where(Incident.vulnerability_id.in_(ids),
                                                          Incident.status.notin_(FINISHED)))).scalars()
    return {i.vulnerability_id: i for i in rows}


async def _out(session: AsyncSession, vulns: list[Vulnerability]) -> list[VulnerabilityOut]:
    open_map = await _open_incidents(session, [v.id for v in vulns])
    out = []
    for v in vulns:
        o = VulnerabilityOut.model_validate(v)
        i = open_map.get(v.id)
        o.open_incident = OpenIncidentRef(id=i.id, code=i.code, status=i.status) if i else None
        out.append(o)
    return out


async def _assets(session: AsyncSession, ids: list[UUID]) -> list[Asset]:
    if not ids:
        return []
    found = (await session.execute(select(Asset).where(Asset.id.in_(set(ids))))).scalars().all()
    if len(found) != len(set(ids)):
        raise Unprocessable("One or more asset_ids do not exist")
    return list(found)


async def list_vulnerabilities(session: AsyncSession, params: PageParams, q: str | None,
                               severity: str | None, is_active: bool | None):
    stmt = select(Vulnerability)
    if q:
        like = f"%{q}%"
        stmt = stmt.where(Vulnerability.cve_id.ilike(like) | Vulnerability.title.ilike(like)
                          | Vulnerability.description.ilike(like))
    if severity:
        stmt = stmt.where(Vulnerability.severity == severity)
    if is_active is not None:
        stmt = stmt.where(Vulnerability.is_active == is_active)
    total = await count_rows(session, stmt)
    rows = (await session.execute(stmt.order_by(Vulnerability.created_at.desc()).offset(params.offset)
                                  .limit(params.size))).scalars().all()
    return await _out(session, list(rows)), total


async def get_model(session: AsyncSession, vid: UUID) -> Vulnerability:
    v = await session.get(Vulnerability, vid)
    if not v:
        raise NotFound("Vulnerability not found")
    return v


async def get_vulnerability(session: AsyncSession, vid: UUID) -> VulnerabilityOut:
    return (await _out(session, [await get_model(session, vid)]))[0]


async def create_vulnerability(session: AsyncSession, user: CurrentUser, data: VulnerabilityCreate) -> VulnerabilityOut:
    if (await session.execute(select(Vulnerability.id).where(Vulnerability.cve_id == data.cve_id))).first():
        raise Conflict(f"{data.cve_id} already exists")
    v = Vulnerability(**data.model_dump(exclude={"asset_ids"}), created_by=user.id)
    v.assets = await _assets(session, data.asset_ids)
    session.add(v)
    await session.flush()
    audit(session, user.id, "vulnerability.created", "vulnerability", v.id, after={"cve_id": v.cve_id})
    await session.commit()
    await session.refresh(v)
    return (await _out(session, [v]))[0]


async def update_vulnerability(session: AsyncSession, user: CurrentUser, vid: UUID,
                               data: VulnerabilityUpdate) -> VulnerabilityOut:
    v = await get_model(session, vid)
    changes = data.model_dump(exclude_unset=True)
    asset_ids = changes.pop("asset_ids", None)
    if "cve_id" in changes and changes["cve_id"] != v.cve_id:
        if (await session.execute(select(Vulnerability.id).where(Vulnerability.cve_id == changes["cve_id"]))).first():
            raise Conflict(f"{changes['cve_id']} already exists")
    for k, val in changes.items():
        setattr(v, k, val)
    if asset_ids is not None:
        v.assets = await _assets(session, asset_ids)
    audit(session, user.id, "vulnerability.updated", "vulnerability", v.id, after=changes | ({"asset_ids": [str(a) for a in asset_ids]} if asset_ids is not None else {}))
    try:
        await session.commit()
    except IntegrityError as e:
        await session.rollback()
        raise Conflict("Could not update vulnerability") from e
    await session.refresh(v)
    return (await _out(session, [v]))[0]


async def set_active(session: AsyncSession, user: CurrentUser, vid: UUID, active: bool) -> VulnerabilityOut:
    v = await get_model(session, vid)
    if v.is_active == active:
        return (await _out(session, [v]))[0]
    if not active:
        oi = (await _open_incidents(session, [v.id])).get(v.id)
        if oi:
            raise Conflict(f"Cannot deactivate: open incident {oi.code} exists. Resolve or close it first.")
    v.is_active = active
    audit(session, user.id, "vulnerability.activated" if active else "vulnerability.deactivated", "vulnerability", v.id)
    await session.commit()
    await session.refresh(v)
    return (await _out(session, [v]))[0]

from datetime import datetime
from decimal import Decimal
from typing import Literal
from uuid import UUID

from pydantic import BaseModel, Field

from bulwark.shared.schemas import ORM, AssetRef

Severity = Literal["LOW", "MEDIUM", "HIGH", "CRITICAL"]


class VulnerabilityCreate(BaseModel):
    cve_id: str = Field(min_length=3, max_length=64)
    title: str = Field(min_length=3, max_length=300)
    description: str | None = Field(default=None, max_length=10_000)
    severity: Severity
    cvss_score: Decimal | None = Field(default=None, ge=0, le=10)
    source: str = "MANUAL"
    published_at: datetime | None = None
    asset_ids: list[UUID] = []


class VulnerabilityUpdate(BaseModel):
    cve_id: str | None = Field(default=None, min_length=3, max_length=64)
    title: str | None = Field(default=None, min_length=3, max_length=300)
    description: str | None = Field(default=None, max_length=10_000)
    severity: Severity | None = None
    cvss_score: Decimal | None = Field(default=None, ge=0, le=10)
    source: str | None = None
    published_at: datetime | None = None
    asset_ids: list[UUID] | None = None


class OpenIncidentRef(BaseModel):
    id: UUID
    code: str
    status: str


class VulnerabilityOut(ORM):
    id: UUID
    cve_id: str
    title: str
    description: str | None
    severity: str
    cvss_score: Decimal | None
    source: str
    published_at: datetime | None
    is_active: bool
    created_at: datetime
    updated_at: datetime
    assets: list[AssetRef]
    open_incident: OpenIncidentRef | None = None

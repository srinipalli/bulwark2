from uuid import UUID

from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession

from bulwark.core.db import get_session
from bulwark.core.pagination import Page, PageParams
from bulwark.core.security import ANALYST, CurrentUser, get_current_user, require_roles
from bulwark.modules.vulnerabilities import service
from bulwark.modules.vulnerabilities.schemas import (Severity, VulnerabilityCreate, VulnerabilityOut,
                                                      VulnerabilityUpdate)

router = APIRouter(prefix="/vulnerabilities", tags=["vulnerabilities"])


@router.get("", response_model=Page[VulnerabilityOut])
async def list_vulnerabilities(q: str | None = None, severity: Severity | None = None,
                               is_active: bool | None = Query(None), params: PageParams = Depends(),
                               session: AsyncSession = Depends(get_session), _: CurrentUser = Depends(get_current_user)):
    items, total = await service.list_vulnerabilities(session, params, q, severity, is_active)
    return Page(items=items, total=total, page=params.page, size=params.size)


@router.post("", response_model=VulnerabilityOut, status_code=201)
async def create_vulnerability(data: VulnerabilityCreate, session: AsyncSession = Depends(get_session),
                               user: CurrentUser = Depends(require_roles(ANALYST))):
    return await service.create_vulnerability(session, user, data)


@router.get("/{vulnerability_id}", response_model=VulnerabilityOut)
async def get_vulnerability(vulnerability_id: UUID, session: AsyncSession = Depends(get_session),
                            _: CurrentUser = Depends(get_current_user)):
    return await service.get_vulnerability(session, vulnerability_id)


@router.patch("/{vulnerability_id}", response_model=VulnerabilityOut)
async def update_vulnerability(vulnerability_id: UUID, data: VulnerabilityUpdate,
                               session: AsyncSession = Depends(get_session),
                               user: CurrentUser = Depends(require_roles(ANALYST))):
    return await service.update_vulnerability(session, user, vulnerability_id, data)


@router.post("/{vulnerability_id}/activate", response_model=VulnerabilityOut)
async def activate(vulnerability_id: UUID, session: AsyncSession = Depends(get_session),
                   user: CurrentUser = Depends(require_roles(ANALYST))):
    return await service.set_active(session, user, vulnerability_id, True)


@router.post("/{vulnerability_id}/deactivate", response_model=VulnerabilityOut)
async def deactivate(vulnerability_id: UUID, session: AsyncSession = Depends(get_session),
                     user: CurrentUser = Depends(require_roles(ANALYST))):
    return await service.set_active(session, user, vulnerability_id, False)

import uuid
from datetime import datetime
from decimal import Decimal

from sqlalchemy import Boolean, Column, DateTime, ForeignKey, Numeric, String, Table, Text, func
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from bulwark.core.db import Base
from bulwark.shared.models import UUID_PK, Asset

vulnerability_assets = Table(
    "vulnerability_assets", Base.metadata,
    Column("vulnerability_id", UUID(as_uuid=True), ForeignKey("vulnerabilities.id", ondelete="CASCADE"), primary_key=True),
    Column("asset_id", UUID(as_uuid=True), ForeignKey("assets.id", ondelete="CASCADE"), primary_key=True),
)


class Vulnerability(Base):
    __tablename__ = "vulnerabilities"
    __mapper_args__ = {"eager_defaults": True}
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), **UUID_PK)
    cve_id: Mapped[str] = mapped_column(String, unique=True)
    title: Mapped[str] = mapped_column(String)
    description: Mapped[str | None] = mapped_column(Text)
    severity: Mapped[str] = mapped_column(String)
    cvss_score: Mapped[Decimal | None] = mapped_column(Numeric(3, 1))
    source: Mapped[str] = mapped_column(String, default="MANUAL")
    published_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_by: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    assets: Mapped[list[Asset]] = relationship(secondary=vulnerability_assets, lazy="selectin", order_by=Asset.name)

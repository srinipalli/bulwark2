from uuid import UUID

from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession

from bulwark.core.db import get_session
from bulwark.core.pagination import Page, PageParams
from bulwark.core.security import APPROVER, CurrentUser, get_current_user, require_roles
from bulwark.modules.approvals import service
from bulwark.modules.approvals.schemas import (ApprovalSummary, CommentRequired, DecisionIn, IncidentApprovalOut,
                                               SolutionReviewOut)

router = APIRouter(prefix="/approvals", tags=["approvals"])
approver = require_roles(APPROVER)


@router.get("/summary", response_model=ApprovalSummary)
async def summary(session: AsyncSession = Depends(get_session), _: CurrentUser = Depends(get_current_user)):
    return await service.summary(session)


# ---- Incident approvals tab
@router.get("/incidents", response_model=Page[IncidentApprovalOut])
async def list_incident_approvals(status: str | None = Query("PENDING", pattern="^(PENDING|APPROVED|REJECTED|CANCELLED)$"),
                                  params: PageParams = Depends(), session: AsyncSession = Depends(get_session),
                                  _: CurrentUser = Depends(get_current_user)):
    items, total = await service.list_incident_approvals(session, params, status)
    return Page(items=items, total=total, page=params.page, size=params.size)


@router.post("/incidents/{approval_id}/approve", response_model=IncidentApprovalOut)
async def approve_incident(approval_id: UUID, body: DecisionIn | None = None, session: AsyncSession = Depends(get_session),
                           user: CurrentUser = Depends(approver)):
    return await service.decide_incident(session, user, approval_id, True, body.comment if body else None)


@router.post("/incidents/{approval_id}/reject", response_model=IncidentApprovalOut)
async def reject_incident(approval_id: UUID, body: CommentRequired, session: AsyncSession = Depends(get_session),
                          user: CurrentUser = Depends(approver)):
    return await service.decide_incident(session, user, approval_id, False, body.comment)


# ---- Solution approvals tab
@router.get("/solutions", response_model=Page[SolutionReviewOut])
async def list_solution_reviews(status: str | None = Query("PENDING", pattern="^(PENDING|APPROVED|REJECTED|CHANGES_REQUESTED)$"),
                                params: PageParams = Depends(), session: AsyncSession = Depends(get_session),
                                _: CurrentUser = Depends(get_current_user)):
    items, total = await service.list_solution_reviews(session, params, status)
    return Page(items=items, total=total, page=params.page, size=params.size)


@router.post("/solutions/{review_id}/approve", response_model=SolutionReviewOut)
async def approve_solution(review_id: UUID, body: DecisionIn | None = None, session: AsyncSession = Depends(get_session),
                           user: CurrentUser = Depends(approver)):
    return await service.decide_solution(session, user, review_id, "APPROVED", body.comment if body else None)


@router.post("/solutions/{review_id}/reject", response_model=SolutionReviewOut)
async def reject_solution(review_id: UUID, body: CommentRequired, session: AsyncSession = Depends(get_session),
                          user: CurrentUser = Depends(approver)):
    return await service.decide_solution(session, user, review_id, "REJECTED", body.comment)


@router.post("/solutions/{review_id}/request-changes", response_model=SolutionReviewOut)
async def request_changes(review_id: UUID, body: CommentRequired, session: AsyncSession = Depends(get_session),
                          user: CurrentUser = Depends(approver)):
    return await service.decide_solution(session, user, review_id, "CHANGES_REQUESTED", body.comment)

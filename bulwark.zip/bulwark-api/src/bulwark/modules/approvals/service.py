from datetime import datetime, timezone
from uuid import UUID

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from bulwark.core.audit import audit
from bulwark.core.errors import Conflict, NotFound, Unprocessable
from bulwark.core.pagination import PageParams, count_rows
from bulwark.core.security import CurrentUser
from bulwark.modules.approvals.models import IncidentApproval, SolutionReview
from bulwark.modules.approvals.schemas import ApprovalSummary, IncidentApprovalOut, SolutionReviewOut
from bulwark.modules.incident.models import Incident
from bulwark.modules.solution.models import SolutionVersion
from bulwark.modules.vulnerabilities.models import Vulnerability
from bulwark.shared.models import User


def _now() -> datetime:
    return datetime.now(timezone.utc)


async def _names(session: AsyncSession, ids: set) -> dict:
    ids = {i for i in ids if i}
    if not ids:
        return {}
    return {u.id: u.full_name for u in (await session.execute(select(User).where(User.id.in_(ids)))).scalars()}


async def summary(session: AsyncSession) -> ApprovalSummary:
    inc = (await session.execute(select(func.count()).select_from(IncidentApproval).where(IncidentApproval.status == "PENDING"))).scalar_one()
    sol = (await session.execute(select(func.count()).select_from(SolutionReview).where(SolutionReview.status == "PENDING"))).scalar_one()
    return ApprovalSummary(incident_pending=inc, solution_pending=sol)


# ------------------------------------------------------------------ incident approvals
async def _inc_out(session: AsyncSession, rows: list[IncidentApproval]) -> list[IncidentApprovalOut]:
    if not rows:
        return []
    incs = {i.id: i for i in (await session.execute(select(Incident).where(Incident.id.in_({r.incident_id for r in rows})))).scalars()}
    vul = {v.id: v for v in (await session.execute(select(Vulnerability).where(Vulnerability.id.in_({i.vulnerability_id for i in incs.values()})))).scalars()}
    names = await _names(session, {r.requested_by for r in rows} | {r.decided_by for r in rows})
    out = []
    for r in rows:
        i = incs[r.incident_id]
        out.append(IncidentApprovalOut(
            id=r.id, status=r.status, incident_id=i.id, incident_code=i.code, incident_title=i.title,
            incident_description=i.description, severity=i.severity, cve_id=vul[i.vulnerability_id].cve_id,
            assets_count=sum(1 for a in i.assets if a.status != "EXCLUDED"), plan=r.plan_snapshot,
            requested_by=names.get(r.requested_by), requested_by_id=r.requested_by, decided_by=names.get(r.decided_by),
            comment=r.comment, requested_at=r.requested_at, decided_at=r.decided_at))
    return out


async def list_incident_approvals(session: AsyncSession, params: PageParams, status: str | None):
    stmt = select(IncidentApproval)
    if status:
        stmt = stmt.where(IncidentApproval.status == status)
    total = await count_rows(session, stmt)
    rows = (await session.execute(stmt.order_by(IncidentApproval.requested_at.desc()).offset(params.offset).limit(params.size))).scalars().all()
    return await _inc_out(session, list(rows)), total


async def decide_incident(session: AsyncSession, user: CurrentUser, approval_id: UUID, approve: bool,
                          comment: str | None) -> IncidentApprovalOut:
    a = (await session.execute(select(IncidentApproval).where(IncidentApproval.id == approval_id).with_for_update())).scalar_one_or_none()
    if not a:
        raise NotFound("Approval not found")
    if a.status != "PENDING":
        raise Conflict(f"Approval is already {a.status}")
    # Approvers may decide their own submissions too (the route already requires APPROVER); the audit marks it.
    inc = await session.get(Incident, a.incident_id)
    if inc.status != "PENDING_APPROVAL":
        raise Conflict(f"Incident is {inc.status}, not pending approval")
    if approve:
        if not inc.plan or any(p.solution_version.status != "APPROVED" for p in inc.plan):
            raise Unprocessable("A solution in the plan is no longer approved. Reject so the plan can be corrected.")
    elif not comment or len(comment.strip()) < 3:
        raise Unprocessable("A comment is required when rejecting")
    a.status, a.decided_by, a.comment, a.decided_at = ("APPROVED" if approve else "REJECTED"), user.id, comment, _now()
    inc.status = "APPROVED" if approve else "REJECTED"
    audit(session, user.id, "incident.approved" if approve else "incident.rejected", "incident", inc.id,
          after={"comment": comment, "own_submission": a.requested_by == user.id})
    await session.commit()
    return (await _inc_out(session, [a]))[0]


# ------------------------------------------------------------------ solution reviews
async def _sol_out(session: AsyncSession, rows: list[SolutionReview]) -> list[SolutionReviewOut]:
    if not rows:
        return []
    vers = {v.id: v for v in (await session.execute(select(SolutionVersion).where(SolutionVersion.id.in_({r.solution_version_id for r in rows})))).scalars()}
    names = await _names(session, {r.requested_by for r in rows} | {r.reviewer_id for r in rows})
    out = []
    for r in rows:
        v = vers[r.solution_version_id]
        out.append(SolutionReviewOut(
            id=r.id, status=r.status, solution_id=v.solution_id, solution_version_id=v.id, title=v.title,
            description=v.description, version_no=v.version_no, executor=v.executor, risk_level=v.risk_level,
            requested_by=names.get(r.requested_by), requested_by_id=r.requested_by, reviewer=names.get(r.reviewer_id),
            comment=r.comment, requested_at=r.requested_at, decided_at=r.decided_at))
    return out


async def list_solution_reviews(session: AsyncSession, params: PageParams, status: str | None):
    stmt = select(SolutionReview)
    if status:
        stmt = stmt.where(SolutionReview.status == status)
    total = await count_rows(session, stmt)
    rows = (await session.execute(stmt.order_by(SolutionReview.requested_at.desc()).offset(params.offset).limit(params.size))).scalars().all()
    return await _sol_out(session, list(rows)), total


async def decide_solution(session: AsyncSession, user: CurrentUser, review_id: UUID, decision: str,
                          comment: str | None) -> SolutionReviewOut:
    """decision: APPROVED | REJECTED | CHANGES_REQUESTED"""
    r = (await session.execute(select(SolutionReview).where(SolutionReview.id == review_id).with_for_update())).scalar_one_or_none()
    if not r:
        raise NotFound("Review not found")
    if r.status != "PENDING":
        raise Conflict(f"Review is already {r.status}")
    # Approvers may decide their own solution submissions (e.g. solutions they created by applying an AI plan).
    # The route already requires APPROVER; the audit marks it.
    if decision != "APPROVED" and (not comment or len(comment.strip()) < 3):
        raise Unprocessable("A comment is required to reject or request changes")
    v = await session.get(SolutionVersion, r.solution_version_id)
    r.status, r.reviewer_id, r.comment, r.decided_at = decision, user.id, comment, _now()
    v.status = decision
    audit(session, user.id, f"solution.{decision.lower()}", "solution_version", v.id,
          after={"comment": comment, "own_submission": r.requested_by == user.id})
    await session.commit()
    return (await _sol_out(session, [r]))[0]

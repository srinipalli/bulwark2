from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, Field


class DecisionIn(BaseModel):
    comment: str | None = Field(default=None, max_length=2000)


class CommentRequired(BaseModel):
    comment: str = Field(min_length=3, max_length=2000)


class IncidentApprovalOut(BaseModel):
    id: UUID
    status: str
    incident_id: UUID
    incident_code: str
    incident_title: str
    incident_description: str | None
    severity: str
    cve_id: str
    assets_count: int
    plan: list[dict]
    requested_by: str | None
    requested_by_id: UUID
    decided_by: str | None
    comment: str | None
    requested_at: datetime
    decided_at: datetime | None


class SolutionReviewOut(BaseModel):
    id: UUID
    status: str
    solution_id: UUID
    solution_version_id: UUID
    title: str
    description: str | None
    version_no: int
    executor: str
    risk_level: str
    requested_by: str | None
    requested_by_id: UUID
    reviewer: str | None
    comment: str | None
    requested_at: datetime
    decided_at: datetime | None


class ApprovalSummary(BaseModel):
    incident_pending: int
    solution_pending: int

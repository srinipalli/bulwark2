from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from bulwark.core.db import get_session
from bulwark.core.security import CurrentUser, get_current_user
from bulwark.shared.models import User
from bulwark.shared.schemas import UserRef

router = APIRouter(tags=["reference"])
# the asset picker (GET /assets) lives in modules/assets with the rest of the asset endpoints


@router.get("/users", response_model=list[UserRef])
async def list_users(session: AsyncSession = Depends(get_session), _: CurrentUser = Depends(get_current_user)):
    """Users for the assignee dropdown."""
    return (await session.execute(select(User).where(User.is_active.is_(True)).order_by(User.full_name))).scalars().all()

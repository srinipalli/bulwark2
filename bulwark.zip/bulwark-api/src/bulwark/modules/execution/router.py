from uuid import UUID

from fastapi import APIRouter, Depends, Query
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from bulwark.core.db import get_session
from bulwark.core.pagination import Page, PageParams
from bulwark.core.security import OPERATOR, CurrentUser, get_current_user, require_roles
from bulwark.modules.execution import service
from bulwark.modules.execution.schemas import ExecIncident, Grid, LogOut, QueueResult, RunDetail, RunOut

router = APIRouter(prefix="/execution", tags=["execution"])
operator = require_roles(OPERATOR)


class RunStepBody(BaseModel):
    incident_asset_ids: list[UUID] | None = None    # omit = all impacted assets


@router.get("/incidents", response_model=list[ExecIncident])
async def executable_incidents(session: AsyncSession = Depends(get_session), _: CurrentUser = Depends(get_current_user)):
    """Approved / in-progress / resolved incidents (the Execution tab's incident picker)."""
    return await service.list_executable_incidents(session)


@router.get("/incidents/{incident_id}/grid", response_model=Grid)
async def grid(incident_id: UUID, session: AsyncSession = Depends(get_session), _: CurrentUser = Depends(get_current_user)):
    """Assets x plan-steps matrix with the latest run status per cell."""
    return await service.get_grid(session, incident_id)


@router.post("/incidents/{incident_id}/steps/{step_no}/run", response_model=list[QueueResult])
async def run_step(incident_id: UUID, step_no: int, body: RunStepBody | None = None,
                   session: AsyncSession = Depends(get_session), user: CurrentUser = Depends(operator)):
    """Queue a step for all (or selected) assets. Idempotent: an existing live/succeeded run is returned, not duplicated.
    Re-calling after a FAILED run queues a retry (next attempt)."""
    return await service.queue_step(session, user, incident_id, step_no, body.incident_asset_ids if body else None)


@router.post("/incidents/{incident_id}/run", response_model=list[QueueResult])
async def run_plan(incident_id: UUID, body: RunStepBody | None = None,
                   session: AsyncSession = Depends(get_session), user: CurrentUser = Depends(operator)):
    """One click: run the rest of the plan on all (or selected) assets. Each asset starts at its first unfinished step
    and the worker continues with the next step after each success (or failure on a CONTINUE step)."""
    return await service.queue_plan(session, user, incident_id, body.incident_asset_ids if body else None)


@router.get("/runs", response_model=Page[RunOut])
async def list_runs(incident_id: UUID | None = None,
                    status: str | None = Query(None, pattern="^(QUEUED|RUNNING|SUCCEEDED|FAILED|CANCELLED)$"),
                    params: PageParams = Depends(), session: AsyncSession = Depends(get_session),
                    _: CurrentUser = Depends(get_current_user)):
    items, total = await service.list_runs(session, params, incident_id, status)
    return Page(items=items, total=total, page=params.page, size=params.size)


@router.get("/runs/{run_id}", response_model=RunDetail)
async def get_run(run_id: UUID, session: AsyncSession = Depends(get_session), _: CurrentUser = Depends(get_current_user)):
    return await service.get_run(session, run_id)


@router.get("/runs/{run_id}/logs", response_model=list[LogOut])
async def get_logs(run_id: UUID, after_id: int = Query(0, ge=0), limit: int = Query(500, ge=1, le=2000),
                   session: AsyncSession = Depends(get_session), _: CurrentUser = Depends(get_current_user)):
    """Poll with after_id=<last id seen> to stream logs."""
    return await service.get_logs(session, run_id, after_id, limit)


@router.post("/runs/{run_id}/cancel", response_model=RunOut)
async def cancel_run(run_id: UUID, session: AsyncSession = Depends(get_session), user: CurrentUser = Depends(operator)):
    return await service.cancel_run(session, user, run_id)

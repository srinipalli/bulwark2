from bulwark.core.config import get_settings
from bulwark.modules.execution.executors.base import Executor
from bulwark.modules.execution.executors.real import NotConfiguredExecutor
from bulwark.modules.execution.executors.simulated import SimulatedExecutor

_REAL: dict[str, Executor] = {}     # register real implementations here, e.g. _REAL["AWS_SSM"] = AwsSsmExecutor()


def get_executor(kind: str) -> Executor:
    if get_settings().simulate_executors:
        return SimulatedExecutor()
    return _REAL.get(kind) or NotConfiguredExecutor(kind)

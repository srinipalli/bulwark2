import asyncio
import random

from bulwark.modules.execution.executors.base import ExecContext, ExecResult, LogFn


class SimulatedExecutor:
    """Dev/demo executor. job_spec may contain {"fail_on": ["asset-name"]} to force failures."""

    async def run(self, ctx: ExecContext, log: LogFn) -> ExecResult:
        await log("stdout", f"[simulated {ctx.executor}] starting on {ctx.asset_name} ({ctx.environment})")
        for msg in ("connecting", "applying change", "verifying"):
            await asyncio.sleep(random.uniform(0.2, 0.6))
            await log("stdout", msg)
        if ctx.asset_name in ctx.job_spec.get("fail_on", []):
            await log("stderr", "simulated failure")
            return ExecResult(success=False, exit_code=1, error="simulated failure")
        await log("stdout", "done")
        return ExecResult(success=True, exit_code=0, result={"simulated": True})

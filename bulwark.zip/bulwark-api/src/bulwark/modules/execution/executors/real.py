"""Real executors: integration points. Each must (1) run the approved job_spec against ctx.asset_name,
(2) stream output through `log`, (3) return ExecResult. They are intentionally NOT implemented here:
wire them to your Ansible runner / AWS SSM client and keep credentials in your secret manager."""
from bulwark.modules.execution.executors.base import ExecContext, ExecResult, LogFn


class NotConfiguredExecutor:
    def __init__(self, name: str):
        self.name = name

    async def run(self, ctx: ExecContext, log: LogFn) -> ExecResult:
        msg = f"Executor {self.name} is not configured in this deployment"
        await log("stderr", msg)
        return ExecResult(success=False, exit_code=127, error=msg)


# TODO: class AnsibleExecutor / AwsSsmExecutor implementing Executor.run(); register them in registry.py

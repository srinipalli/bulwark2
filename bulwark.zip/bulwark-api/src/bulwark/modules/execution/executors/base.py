from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from typing import Protocol

LogFn = Callable[[str, str], Awaitable[None]]      # (stream, message)


@dataclass
class ExecContext:
    run_id: str
    asset_name: str
    environment: str
    executor: str
    job_spec: dict
    timeout_seconds: int


@dataclass
class ExecResult:
    success: bool
    exit_code: int = 0
    result: dict = field(default_factory=dict)
    error: str | None = None


class Executor(Protocol):
    async def run(self, ctx: ExecContext, log: LogFn) -> ExecResult: ...

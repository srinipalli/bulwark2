"""Job worker. Run as its own process:  python -m bulwark.modules.execution.worker

Postgres is the queue: runs are claimed with SELECT ... FOR UPDATE SKIP LOCKED, so any number of workers can run
side by side. Nothing is executed inside the API process.
"""
import asyncio
import logging
import os
import signal
import socket
from datetime import datetime, timedelta, timezone

from sqlalchemy import select

from bulwark.core.config import get_settings
from bulwark.core.db import SessionLocal
from bulwark.modules.execution.executors.base import ExecContext, ExecResult
from bulwark.modules.execution.executors.registry import get_executor
from bulwark.modules.execution.models import JobRun, JobRunLog
from bulwark.modules.incident.models import RUNNABLE, Incident, IncidentAsset, IncidentPlanStep
from bulwark.modules.incident.service import maybe_resolve
from bulwark.modules.solution.models import SolutionVersion
from bulwark.shared.models import Asset

log = logging.getLogger("bulwark.worker")
WORKER_ID = f"{socket.gethostname()}:{os.getpid()}"


def _now() -> datetime:
    return datetime.now(timezone.utc)


async def claim_next() -> JobRun | None:
    async with SessionLocal() as s:
        run = (await s.execute(select(JobRun).where(JobRun.status == "QUEUED").order_by(JobRun.queued_at)
                               .limit(1).with_for_update(skip_locked=True))).scalar_one_or_none()
        if not run:
            return None
        run.status, run.started_at, run.locked_by = "RUNNING", _now(), WORKER_ID
        await s.commit()
        return run


async def _write_log(run_id, stream: str, message: str) -> None:
    async with SessionLocal() as s:
        s.add(JobRunLog(job_run_id=run_id, stream=stream, message=message))
        await s.commit()


async def _finish(run_id, res: ExecResult) -> None:
    """Persist the outcome and update asset + incident roll-ups (one transaction)."""
    async with SessionLocal() as s:
        run = (await s.execute(select(JobRun).where(JobRun.id == run_id).with_for_update())).scalar_one()
        if run.status != "RUNNING":
            return
        run.status = "SUCCEEDED" if res.success else "FAILED"
        run.exit_code, run.result, run.error_message, run.finished_at = res.exit_code, res.result, res.error, _now()
        inc = await s.get(Incident, run.incident_id)
        await s.refresh(inc)
        ia = next(a for a in inc.assets if a.id == run.incident_asset_id)
        step = next(p for p in inc.plan if p.id == run.plan_step_id)
        retrying = False
        if res.success:
            done = {r for r in (await s.execute(select(JobRun.plan_step_id).where(
                JobRun.incident_asset_id == ia.id, JobRun.status == "SUCCEEDED"))).scalars()}
            if all(p.id in done for p in inc.plan):
                ia.status, ia.patched_at, ia.last_error = "PATCHED", _now(), None
            else:
                ia.status = "IN_PROGRESS"
            maybe_resolve(inc)
        else:
            ia.status, ia.last_error = "FAILED", res.error
            if run.attempt <= step.solution_version.max_retries:          # automatic retry
                retrying = True
                s.add(JobRun(incident_id=run.incident_id, plan_step_id=run.plan_step_id, incident_asset_id=ia.id,
                             attempt=run.attempt + 1, status="QUEUED", triggered_by=run.triggered_by, chain=run.chain,
                             idempotency_key=f"{ia.id}:{step.id}:{run.attempt + 1}"))
                ia.status = "IN_PROGRESS"
            elif step.on_failure == "STOP_ALL":
                queued = (await s.execute(select(JobRun).where(JobRun.incident_id == inc.id, JobRun.status == "QUEUED"))).scalars().all()
                for q in queued:
                    q.status, q.finished_at = "CANCELLED", _now()
                    other = next(a for a in inc.assets if a.id == q.incident_asset_id)
                    if other.status == "IN_PROGRESS":
                        other.status = "PENDING"
        if run.chain and inc.status in RUNNABLE and (res.success or (step.on_failure == "CONTINUE" and not retrying)):
            await _queue_next(s, run, inc, ia, step)
        await s.commit()


async def _queue_next(s, run: JobRun, inc: Incident, ia: IncidentAsset, step: IncidentPlanStep, resuming: bool = False) -> bool:
    """One-click "Run": queue the asset's next plan step, unless it already ran or is queued/running.
    resuming: only when the next step has not been queued at all since `run` was (repairs a broken chain without
    re-running a step that later failed and stopped the asset)."""
    nxt = next((p for p in inc.plan if p.step_no == step.step_no + 1), None)
    if nxt is None:
        return False
    last = (await s.execute(select(JobRun).where(JobRun.plan_step_id == nxt.id, JobRun.incident_asset_id == ia.id)
                            .order_by(JobRun.attempt.desc()).limit(1))).scalar_one_or_none()
    if last and (last.status in ("QUEUED", "RUNNING", "SUCCEEDED") or (resuming and last.queued_at >= run.queued_at)):
        return False
    attempt = (last.attempt + 1) if last else 1
    s.add(JobRun(incident_id=inc.id, plan_step_id=nxt.id, incident_asset_id=ia.id, attempt=attempt, status="QUEUED",
                 triggered_by=run.triggered_by, chain=True, idempotency_key=f"{ia.id}:{nxt.id}:{attempt}"))
    ia.status = "IN_PROGRESS"
    return True


async def resume_chains() -> int:
    """Chained runs that finished without their next step being queued - e.g. run by a worker that predates chaining,
    or a worker that died in between - get their next step queued now."""
    n = 0
    async with SessionLocal() as s:
        runs = (await s.execute(select(JobRun).join(Incident, Incident.id == JobRun.incident_id)
                                .where(JobRun.chain.is_(True), JobRun.status.in_(("SUCCEEDED", "FAILED")),
                                       Incident.status.in_(RUNNABLE)))).scalars().all()
        incs = {}
        for run in runs:
            inc = incs.get(run.incident_id)
            if inc is None:
                inc = incs[run.incident_id] = await s.get(Incident, run.incident_id)
                await s.refresh(inc)
            step = next((p for p in inc.plan if p.id == run.plan_step_id), None)
            ia = next((a for a in inc.assets if a.id == run.incident_asset_id), None)
            if not step or not ia or ia.status == "EXCLUDED":
                continue
            ok = run.status == "SUCCEEDED" or (step.on_failure == "CONTINUE" and run.attempt > step.solution_version.max_retries)
            if ok and await _queue_next(s, run, inc, ia, step, resuming=True):
                n += 1
        await s.commit()
    if n:
        log.info("resumed %d chained run(s)", n)
    return n


async def execute(run: JobRun) -> None:
    async with SessionLocal() as s:
        step = await s.get(IncidentPlanStep, run.plan_step_id)
        ver = await s.get(SolutionVersion, step.solution_version_id)
        ia = await s.get(IncidentAsset, run.incident_asset_id)
        asset = await s.get(Asset, ia.asset_id)
        ctx = ExecContext(run_id=str(run.id), asset_name=asset.name, environment=asset.environment,
                          executor=ver.executor, job_spec=dict(ver.job_spec), timeout_seconds=ver.timeout_seconds)

    async def emit(stream: str, message: str) -> None:
        await _write_log(run.id, stream, message)

    try:
        res = await asyncio.wait_for(get_executor(ctx.executor).run(ctx, emit), timeout=ctx.timeout_seconds)
    except asyncio.TimeoutError:
        await emit("stderr", f"timed out after {ctx.timeout_seconds}s")
        res = ExecResult(success=False, exit_code=124, error=f"Timed out after {ctx.timeout_seconds}s")
    except Exception as e:      # an executor bug must never kill the worker
        log.exception("executor crashed")
        await emit("stderr", f"executor error: {e}")
        res = ExecResult(success=False, exit_code=1, error=f"Executor error: {e}")
    await _finish(run.id, res)


async def process_next() -> bool:
    run = await claim_next()
    if not run:
        return False
    await execute(run)
    return True


async def process_all() -> int:
    """Drain the queue (used by tests and one-off runs)."""
    n = 0
    while await process_next():
        n += 1
    return n


async def reap_stale() -> int:
    """Fail runs whose worker disappeared (RUNNING far beyond their timeout)."""
    grace = get_settings().stale_run_grace_seconds
    n = 0
    async with SessionLocal() as s:
        rows = (await s.execute(
            select(JobRun, SolutionVersion.timeout_seconds)
            .join(IncidentPlanStep, IncidentPlanStep.id == JobRun.plan_step_id)
            .join(SolutionVersion, SolutionVersion.id == IncidentPlanStep.solution_version_id)
            .where(JobRun.status == "RUNNING"))).all()
    for run, timeout in rows:
        if run.started_at and run.started_at < _now() - timedelta(seconds=timeout + grace):
            await _finish(run.id, ExecResult(success=False, exit_code=137, error="Worker lost; run marked failed"))
            n += 1
    return n


async def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    stop = asyncio.Event()
    loop = asyncio.get_running_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, stop.set)
        except NotImplementedError:     # Windows event loops have no add_signal_handler
            signal.signal(sig, lambda *_: loop.call_soon_threadsafe(stop.set))
    poll = get_settings().worker_poll_seconds
    log.info("worker %s started", WORKER_ID)
    ticks = 0
    while not stop.is_set():
        try:
            if ticks % 30 == 0:
                await reap_stale()
                await resume_chains()
            ticks += 1
            if not await process_next():
                try:
                    await asyncio.wait_for(stop.wait(), timeout=poll)
                except asyncio.TimeoutError:
                    pass
        except Exception:
            log.exception("worker loop error")
            await asyncio.sleep(poll)
    log.info("worker stopped")


if __name__ == "__main__":
    asyncio.run(main())

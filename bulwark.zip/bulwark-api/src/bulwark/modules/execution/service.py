from datetime import datetime, timezone
from uuid import UUID

from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from bulwark.core.audit import audit
from bulwark.core.errors import Conflict, NotFound, Unprocessable
from bulwark.core.pagination import PageParams, count_rows
from bulwark.core.security import CurrentUser
from bulwark.modules.execution.models import JobRun, JobRunLog
from bulwark.modules.execution.schemas import (Cell, ExecIncident, Grid, GridRow, LogOut, QueueResult, RunDetail,
                                               RunOut, StepHeader)
from bulwark.modules.incident.models import RUNNABLE, Incident, IncidentAsset, IncidentPlanStep
from bulwark.modules.vulnerabilities.models import Vulnerability

LIVE = ("QUEUED", "RUNNING")


async def _incident(session: AsyncSession, iid: UUID) -> Incident:
    i = await session.get(Incident, iid)
    if not i:
        raise NotFound("Incident not found")
    await session.refresh(i)
    return i


def _exec_incident(i: Incident, cve: str) -> ExecIncident:
    act = [a for a in i.assets if a.status != "EXCLUDED"]
    return ExecIncident(id=i.id, code=i.code, title=i.title, status=i.status, cve_id=cve, assets_count=len(act),
                        patched_count=sum(1 for a in act if a.status == "PATCHED"), plan_steps=len(i.plan))


async def list_executable_incidents(session: AsyncSession) -> list[ExecIncident]:
    rows = (await session.execute(
        select(Incident, Vulnerability.cve_id).join(Vulnerability, Vulnerability.id == Incident.vulnerability_id)
        .where(Incident.status.in_(("APPROVED", "IN_PROGRESS", "RESOLVED"))).order_by(Incident.incident_no.desc()))).all()
    return [_exec_incident(i, cve) for i, cve in rows]


async def _latest_runs(session: AsyncSession, iid: UUID) -> dict[tuple[UUID, UUID], JobRun]:
    runs = (await session.execute(select(JobRun).where(JobRun.incident_id == iid)
                                  .order_by(JobRun.queued_at, JobRun.attempt))).scalars().all()
    return {(r.plan_step_id, r.incident_asset_id): r for r in runs}   # later rows overwrite earlier ones


async def get_grid(session: AsyncSession, iid: UUID) -> Grid:
    i = await _incident(session, iid)
    cve = (await session.get(Vulnerability, i.vulnerability_id)).cve_id
    latest = await _latest_runs(session, iid)
    steps = [StepHeader(plan_step_id=p.id, step_no=p.step_no, title=p.solution_version.title,
                        version_no=p.solution_version.version_no, executor=p.solution_version.executor,
                        on_failure=p.on_failure) for p in i.plan]
    rows = []
    for a in i.assets:
        if a.status == "EXCLUDED":
            continue
        cells = []
        for p in i.plan:
            r = latest.get((p.id, a.id))
            cells.append(Cell(step_no=p.step_no, status=r.status if r else "WAITING", run_id=r.id if r else None,
                              attempt=r.attempt if r else None, error_message=r.error_message if r else None,
                              started_at=r.started_at if r else None, finished_at=r.finished_at if r else None,
                              chain=bool(r and r.chain)))
        rows.append(GridRow(incident_asset_id=a.id, asset_name=a.asset.name, environment=a.asset.environment,
                            status=a.status, cells=cells))
    return Grid(incident=_exec_incident(i, cve), can_run=i.status in RUNNABLE, steps=steps, rows=rows)


def _prev_ok(prev_step: IncidentPlanStep, last: JobRun | None) -> bool:
    if last is None:
        return False
    if last.status == "SUCCEEDED":
        return True
    return last.status == "FAILED" and prev_step.on_failure == "CONTINUE"


async def _runnable(session: AsyncSession, iid: UUID) -> Incident:
    i = await _incident(session, iid)
    if i.status not in RUNNABLE:
        raise Conflict(f"Incident is {i.status}. Only approved incidents can be executed.")
    return i


def _targets(i: Incident, incident_asset_ids: list[UUID] | None) -> list[IncidentAsset]:
    targets = [a for a in i.assets if a.status != "EXCLUDED" and (incident_asset_ids is None or a.id in incident_asset_ids)]
    if incident_asset_ids is not None and len(targets) != len(set(incident_asset_ids)):
        raise Unprocessable("Unknown or excluded incident_asset_id")
    return targets


async def _enqueue(session: AsyncSession, user: CurrentUser, i: Incident, step: IncidentPlanStep, a: IncidentAsset,
                   last: JobRun | None, chain: bool) -> QueueResult:
    """Queue one run of `step` on `a` (attempt+1 after a failure)."""
    attempt = (last.attempt + 1) if last else 1
    run = JobRun(incident_id=i.id, plan_step_id=step.id, incident_asset_id=a.id, attempt=attempt, status="QUEUED",
                 idempotency_key=f"{a.id}:{step.id}:{attempt}", triggered_by=user.id, chain=chain)
    try:
        async with session.begin_nested():
            session.add(run)
            await session.flush()
    except IntegrityError:      # lost a race with another request: report the winner
        existing = (await _latest_runs(session, i.id)).get((step.id, a.id))
        return QueueResult(incident_asset_id=a.id, asset_name=a.asset.name, outcome="EXISTS", step_no=step.step_no,
                           run=RunOut.model_validate(existing) if existing else None)
    a.status, a.last_error = "IN_PROGRESS", None
    return QueueResult(incident_asset_id=a.id, asset_name=a.asset.name, outcome="QUEUED", step_no=step.step_no,
                       run=RunOut.model_validate(run))


async def _started(session: AsyncSession, user: CurrentUser, i: Incident, results: list[QueueResult], action: str, **info) -> None:
    queued = [r for r in results if r.outcome == "QUEUED"]
    if queued:
        if i.status == "APPROVED":
            i.status = "IN_PROGRESS"
        audit(session, user.id, action, "incident", i.id, after={**info, "assets": len(queued)})
    await session.commit()


async def queue_step(session: AsyncSession, user: CurrentUser, iid: UUID, step_no: int,
                     incident_asset_ids: list[UUID] | None) -> list[QueueResult]:
    """Idempotent. For each target asset: returns the existing run if one is live/succeeded, BLOCKED if the previous
    step has not succeeded on that asset, otherwise queues a new run (attempt+1 after a failure)."""
    i = await _runnable(session, iid)
    step = next((p for p in i.plan if p.step_no == step_no), None)
    if not step:
        raise NotFound(f"Step {step_no} is not part of this plan")
    prev = next((p for p in i.plan if p.step_no == step_no - 1), None)
    targets = _targets(i, incident_asset_ids)
    latest = await _latest_runs(session, iid)
    results: list[QueueResult] = []
    for a in targets:
        last = latest.get((step.id, a.id))
        name = a.asset.name
        if last and (last.status in LIVE or last.status == "SUCCEEDED"):
            results.append(QueueResult(incident_asset_id=a.id, asset_name=name, outcome="EXISTS", step_no=step_no,
                                       reason=f"Existing run is {last.status}", run=RunOut.model_validate(last)))
            continue
        if prev and not _prev_ok(prev, latest.get((prev.id, a.id))):
            results.append(QueueResult(incident_asset_id=a.id, asset_name=name, outcome="BLOCKED", step_no=step_no,
                                       reason=f"Step {prev.step_no} has not succeeded on this asset"))
            continue
        results.append(await _enqueue(session, user, i, step, a, last, chain=False))
    await _started(session, user, i, results, "execution.step_queued", step_no=step_no)
    return results


async def queue_plan(session: AsyncSession, user: CurrentUser, iid: UUID,
                     incident_asset_ids: list[UUID] | None) -> list[QueueResult]:
    """One-click run of the rest of the plan. For each target asset the first step that has not finished (succeeded,
    or failed on a CONTINUE step) is queued as a chained run; the worker then queues the following steps one by one.
    A run already queued/running on the asset is chained instead of duplicated. Idempotent."""
    i = await _runnable(session, iid)
    if not i.plan:
        raise Unprocessable("This incident has no plan steps")
    targets = _targets(i, incident_asset_ids)
    latest = await _latest_runs(session, iid)
    results: list[QueueResult] = []
    for a in targets:
        step = next((p for p in i.plan if not _prev_ok(p, latest.get((p.id, a.id)))), None)
        if step is None:
            results.append(QueueResult(incident_asset_id=a.id, asset_name=a.asset.name, outcome="DONE",
                                       reason="Every step has already run on this asset"))
            continue
        last = latest.get((step.id, a.id))
        if last and last.status in LIVE:
            last.chain = True
            results.append(QueueResult(incident_asset_id=a.id, asset_name=a.asset.name, outcome="EXISTS", step_no=step.step_no,
                                       reason=f"Step {step.step_no} is already {last.status.lower()}; the next steps follow it",
                                       run=RunOut.model_validate(last)))
            continue
        results.append(await _enqueue(session, user, i, step, a, last, chain=True))
    await _started(session, user, i, results, "execution.plan_queued", scope="all" if incident_asset_ids is None else "selected")
    return results


async def list_runs(session: AsyncSession, params: PageParams, incident_id: UUID | None, status: str | None):
    stmt = select(JobRun)
    if incident_id:
        stmt = stmt.where(JobRun.incident_id == incident_id)
    if status:
        stmt = stmt.where(JobRun.status == status)
    total = await count_rows(session, stmt)
    rows = (await session.execute(stmt.order_by(JobRun.queued_at.desc()).offset(params.offset).limit(params.size))).scalars().all()
    return [RunOut.model_validate(r) for r in rows], total


async def get_run(session: AsyncSession, rid: UUID) -> RunDetail:
    r = await session.get(JobRun, rid)
    if not r:
        raise NotFound("Run not found")
    i = await _incident(session, r.incident_id)
    step = next(p for p in i.plan if p.id == r.plan_step_id)
    ia = next(a for a in i.assets if a.id == r.incident_asset_id)
    return RunDetail(**RunOut.model_validate(r).model_dump(), step_no=step.step_no,
                     solution_title=step.solution_version.title, asset_name=ia.asset.name, incident_code=i.code)


async def get_logs(session: AsyncSession, rid: UUID, after_id: int = 0, limit: int = 500) -> list[LogOut]:
    if not await session.get(JobRun, rid):
        raise NotFound("Run not found")
    rows = (await session.execute(select(JobRunLog).where(JobRunLog.job_run_id == rid, JobRunLog.id > after_id)
                                  .order_by(JobRunLog.id).limit(limit))).scalars().all()
    return [LogOut.model_validate(x) for x in rows]


async def cancel_run(session: AsyncSession, user: CurrentUser, rid: UUID) -> RunOut:
    r = (await session.execute(select(JobRun).where(JobRun.id == rid).with_for_update())).scalar_one_or_none()
    if not r:
        raise NotFound("Run not found")
    if r.status != "QUEUED":
        raise Conflict(f"Only QUEUED runs can be cancelled (this one is {r.status})")
    r.status, r.finished_at = "CANCELLED", datetime.now(timezone.utc)
    ia = await session.get(IncidentAsset, r.incident_asset_id)
    if ia.status == "IN_PROGRESS":
        ia.status = "PENDING"
    audit(session, user.id, "execution.run_cancelled", "job_run", r.id)
    await session.commit()
    return RunOut.model_validate(r)

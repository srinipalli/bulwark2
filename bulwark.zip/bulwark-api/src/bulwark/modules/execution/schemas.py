from datetime import datetime
from uuid import UUID

from pydantic import BaseModel

from bulwark.shared.schemas import ORM


class RunOut(ORM):
    id: UUID
    incident_id: UUID
    plan_step_id: UUID
    incident_asset_id: UUID
    attempt: int
    status: str
    exit_code: int | None
    error_message: str | None
    queued_at: datetime
    started_at: datetime | None
    finished_at: datetime | None


class RunDetail(RunOut):
    step_no: int
    solution_title: str
    asset_name: str
    incident_code: str


class LogOut(ORM):
    id: int
    stream: str
    message: str
    logged_at: datetime


class ExecIncident(BaseModel):
    id: UUID
    code: str
    title: str
    status: str
    cve_id: str
    assets_count: int
    patched_count: int
    plan_steps: int


class StepHeader(BaseModel):
    plan_step_id: UUID
    step_no: int
    title: str
    version_no: int
    executor: str
    on_failure: str


class Cell(BaseModel):
    step_no: int
    status: str            # WAITING | QUEUED | RUNNING | SUCCEEDED | FAILED | CANCELLED
    run_id: UUID | None
    attempt: int | None
    error_message: str | None
    started_at: datetime | None = None
    finished_at: datetime | None = None
    chain: bool = False        # part of a one-click "Run": the next step follows automatically


class GridRow(BaseModel):
    incident_asset_id: UUID
    asset_name: str
    environment: str
    status: str
    cells: list[Cell]


class Grid(BaseModel):
    incident: ExecIncident
    can_run: bool
    steps: list[StepHeader]
    rows: list[GridRow]


class QueueResult(BaseModel):
    incident_asset_id: UUID
    asset_name: str
    outcome: str           # QUEUED | EXISTS | BLOCKED | DONE (whole plan already ran on the asset)
    step_no: int | None = None
    reason: str | None = None
    run: RunOut | None = None

from uuid import UUID

from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession

from bulwark.core.db import get_session
from bulwark.core.pagination import Page, PageParams
from bulwark.core.security import ANALYST, APPROVER, CurrentUser, get_current_user, require_roles
from bulwark.modules.solution import service
from bulwark.modules.solution.schemas import (SolutionCreate, SolutionDetail, SolutionOut, SolutionUpdate, Suggestion)

router = APIRouter(prefix="/solutions", tags=["solutions"])


@router.get("", response_model=Page[SolutionOut])
async def list_solutions(q: str | None = None,
                         status: str | None = Query(None, pattern="^(REVIEW_PENDING|APPROVED|REJECTED|CHANGES_REQUESTED|RETIRED)$"),
                         params: PageParams = Depends(), session: AsyncSession = Depends(get_session),
                         _: CurrentUser = Depends(get_current_user)):
    items, total = await service.list_solutions(session, params, q, status)
    return Page(items=items, total=total, page=params.page, size=params.size)


@router.get("/suggestions", response_model=list[Suggestion])
async def suggestions(incident_id: UUID, limit: int = Query(5, ge=1, le=20), session: AsyncSession = Depends(get_session),
                      _: CurrentUser = Depends(get_current_user)):
    """Nearby approved solutions for an incident (AI / similarity). Never returns unapproved solutions."""
    return await service.suggest_for_incident(session, incident_id, limit)


@router.post("", response_model=SolutionDetail, status_code=201)
async def create_solution(data: SolutionCreate, session: AsyncSession = Depends(get_session),
                          user: CurrentUser = Depends(require_roles(ANALYST))):
    """Creates the solution as REVIEW_PENDING and opens a review in Approvals -> Solution approvals."""
    return await service.create_solution(session, user, data)


@router.get("/{solution_id}", response_model=SolutionDetail)
async def get_solution(solution_id: UUID, session: AsyncSession = Depends(get_session),
                       _: CurrentUser = Depends(get_current_user)):
    return await service.get_solution(session, solution_id)


@router.patch("/{solution_id}", response_model=SolutionDetail)
async def update_solution(solution_id: UUID, data: SolutionUpdate, session: AsyncSession = Depends(get_session),
                          user: CurrentUser = Depends(require_roles(ANALYST))):
    """Editing an APPROVED solution creates a new version that goes back to REVIEW_PENDING."""
    return await service.update_solution(session, user, solution_id, data)


@router.post("/{solution_id}/retire", response_model=SolutionDetail)
async def retire_solution(solution_id: UUID, session: AsyncSession = Depends(get_session),
                          user: CurrentUser = Depends(require_roles(APPROVER))):
    return await service.retire_solution(session, user, solution_id)

from dataclasses import dataclass
from uuid import UUID

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from bulwark.core.audit import audit
from bulwark.core.errors import Conflict, NotFound
from bulwark.core.pagination import PageParams, count_rows
from bulwark.core.security import CurrentUser
from bulwark.modules.approvals.models import SolutionReview
from bulwark.modules.incident.models import FINISHED, Incident, IncidentPlanStep
from bulwark.modules.solution.models import Solution, SolutionVersion
from bulwark.modules.solution.schemas import (SolutionCreate, SolutionDetail, SolutionOut, SolutionUpdate, Suggestion,
                                              VersionOut)
from bulwark.modules.solution.suggest import get_provider
from bulwark.modules.vulnerabilities.models import Vulnerability
from bulwark.shared.models import User

CONTENT_FIELDS = ("title", "description", "executor", "job_spec", "applies_to", "risk_level",
                  "requires_reboot", "timeout_seconds", "max_retries")


def latest(s: Solution) -> SolutionVersion:
    return s.versions[-1]


def latest_approved(s: Solution) -> SolutionVersion | None:
    return next((v for v in reversed(s.versions) if v.status == "APPROVED"), None)


async def _names(session: AsyncSession, ids: set) -> dict:
    ids = {i for i in ids if i}
    if not ids:
        return {}
    return {u.id: u.full_name for u in (await session.execute(select(User).where(User.id.in_(ids)))).scalars()}


def _out(s: Solution, names: dict) -> SolutionOut:
    v = latest(s)
    return SolutionOut(id=s.id, title=s.title, description=s.description, is_retired=s.is_retired,
                       status="RETIRED" if s.is_retired else v.status, latest_version_no=v.version_no,
                       has_approved_version=latest_approved(s) is not None, executor=v.executor,
                       risk_level=v.risk_level, created_by_name=names.get(s.created_by), updated_at=s.updated_at)


async def get_model(session: AsyncSession, sid: UUID) -> Solution:
    s = await session.get(Solution, sid)
    if not s:
        raise NotFound("Solution not found")
    return s


async def list_solutions(session: AsyncSession, params: PageParams, q: str | None, status: str | None):
    stmt = select(Solution).join(SolutionVersion, SolutionVersion.id == Solution.current_version_id)
    if q:
        stmt = stmt.where(Solution.title.ilike(f"%{q}%") | Solution.description.ilike(f"%{q}%"))
    if status == "RETIRED":
        stmt = stmt.where(Solution.is_retired.is_(True))
    elif status == "APPROVED":     # usable in plans: retired excluded, any approved version counts
        stmt = stmt.where(Solution.is_retired.is_(False), Solution.id.in_(
            select(SolutionVersion.solution_id).where(SolutionVersion.status == "APPROVED")))
    elif status:
        stmt = stmt.where(Solution.is_retired.is_(False), SolutionVersion.status == status)
    total = await count_rows(session, stmt)
    rows = (await session.execute(stmt.order_by(Solution.updated_at.desc()).offset(params.offset).limit(params.size))).scalars().all()
    names = await _names(session, {s.created_by for s in rows})
    return [_out(s, names) for s in rows], total


async def get_solution(session: AsyncSession, sid: UUID) -> SolutionDetail:
    s = await get_model(session, sid)
    names = await _names(session, {s.created_by} | {v.created_by for v in s.versions})
    versions = []
    for v in s.versions:
        vo = VersionOut.model_validate(v)
        vo.created_by_name = names.get(v.created_by)
        versions.append(vo)
    return SolutionDetail(**_out(s, names).model_dump(), versions=versions)


def _new_review(session: AsyncSession, version_id, user: CurrentUser) -> None:
    session.add(SolutionReview(solution_version_id=version_id, requested_by=user.id, status="PENDING"))


async def add_solution(session: AsyncSession, user: CurrentUser, data: SolutionCreate) -> Solution:
    """New solution (v1, REVIEW_PENDING, queued for review) in the caller's transaction - not committed."""
    s = Solution(title=data.title, description=data.description, created_by=user.id)
    session.add(s)
    await session.flush()
    v = SolutionVersion(solution_id=s.id, version_no=1, status="REVIEW_PENDING", created_by=user.id,
                        **data.model_dump())
    session.add(v)
    await session.flush()
    s.current_version_id = v.id
    _new_review(session, v.id, user)
    audit(session, user.id, "solution.created", "solution", s.id, after={"title": s.title, "version": 1})
    return s


async def create_solution(session: AsyncSession, user: CurrentUser, data: SolutionCreate) -> SolutionDetail:
    s = await add_solution(session, user, data)
    await session.commit()
    await session.refresh(s)
    return await get_solution(session, s.id)


async def update_solution(session: AsyncSession, user: CurrentUser, sid: UUID, data: SolutionUpdate) -> SolutionDetail:
    s = await get_model(session, sid)
    if s.is_retired:
        raise Conflict("Solution is retired")
    cur = latest(s)
    changes = data.model_dump(exclude_unset=True)
    if cur.status == "REVIEW_PENDING":
        raise Conflict("This version is under review. Wait for the decision before editing.")
    if cur.status == "APPROVED":
        # approved content is immutable -> new version that must be reviewed again
        base = {f: getattr(cur, f) for f in CONTENT_FIELDS} | changes
        v = SolutionVersion(solution_id=s.id, version_no=cur.version_no + 1, status="REVIEW_PENDING",
                            created_by=user.id, **base)
        session.add(v)
        await session.flush()
        s.current_version_id = v.id
        s.title, s.description = v.title, v.description
        _new_review(session, v.id, user)
        audit(session, user.id, "solution.new_version", "solution", s.id, after={"version": v.version_no})
    else:   # REJECTED / CHANGES_REQUESTED -> fix in place and resubmit
        for k, val in changes.items():
            setattr(cur, k, val)
        cur.status = "REVIEW_PENDING"
        s.title, s.description = cur.title, cur.description
        _new_review(session, cur.id, user)
        audit(session, user.id, "solution.resubmitted", "solution", s.id, after={"version": cur.version_no})
    await session.commit()
    await session.refresh(s)
    return await get_solution(session, s.id)


async def retire_solution(session: AsyncSession, user: CurrentUser, sid: UUID) -> SolutionDetail:
    s = await get_model(session, sid)
    in_use = (await session.execute(
        select(func.count()).select_from(IncidentPlanStep)
        .join(Incident, Incident.id == IncidentPlanStep.incident_id)
        .join(SolutionVersion, SolutionVersion.id == IncidentPlanStep.solution_version_id)
        .where(SolutionVersion.solution_id == sid, Incident.status.notin_(FINISHED)))).scalar_one()
    if in_use:
        raise Conflict("Solution is used in the plan of an open incident")
    s.is_retired = True
    audit(session, user.id, "solution.retired", "solution", s.id)
    await session.commit()
    return await get_solution(session, s.id)


@dataclass
class _Cand:
    id: UUID
    version_id: UUID
    title: str
    executor: str
    text: str


async def suggest_for_incident(session: AsyncSession, incident_id: UUID, limit: int = 5) -> list[Suggestion]:
    inc = await session.get(Incident, incident_id)
    if not inc:
        raise NotFound("Incident not found")
    vuln = await session.get(Vulnerability, inc.vulnerability_id)
    in_plan = set((await session.execute(
        select(SolutionVersion.solution_id).join(IncidentPlanStep, IncidentPlanStep.solution_version_id == SolutionVersion.id)
        .where(IncidentPlanStep.incident_id == incident_id))).scalars())
    sols = (await session.execute(select(Solution).where(Solution.is_retired.is_(False)))).scalars().all()
    cands = []
    for s in sols:
        v = latest_approved(s)          # providers only ever see approved content
        if v and s.id not in in_plan:
            cands.append(_Cand(s.id, v.id, v.title, v.executor, f"{v.title} {v.description or ''} {v.applies_to or ''}"))
    provider = get_provider()
    query = f"{vuln.cve_id} {vuln.title} {vuln.description or ''} {inc.title} {inc.description or ''}"
    return [Suggestion(solution_id=c.id, solution_version_id=c.version_id, title=c.title, executor=c.executor,
                       score=score, source=provider.name, rationale=why)
            for c, score, why in provider.rank(query, cands)[:limit]]

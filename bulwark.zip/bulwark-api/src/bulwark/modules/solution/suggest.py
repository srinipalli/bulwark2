"""Pluggable 'find nearby solution' provider.

KeywordSuggestionProvider is a dependency-free baseline (token overlap). To use embeddings / an LLM,
implement SuggestionProvider.rank() and return it from get_provider(). Only APPROVED solutions are ever
passed in, so a provider can never surface something that has not passed review.
"""
import re
from typing import Protocol

_STOP = {"the", "and", "for", "with", "from", "that", "this", "via", "are", "was", "has", "can", "not", "all"}


def _tokens(text: str) -> set[str]:
    return {t for t in re.findall(r"[a-z0-9\.]+", text.lower()) if len(t) > 2 and t not in _STOP}


class Candidate(Protocol):
    id: object
    version_id: object
    title: str
    executor: str
    text: str


class SuggestionProvider(Protocol):
    name: str

    def rank(self, query: str, candidates: list) -> list[tuple[object, float, str]]: ...


class KeywordSuggestionProvider:
    name = "KEYWORD"

    def rank(self, query: str, candidates: list) -> list[tuple[object, float, str]]:
        q = _tokens(query)
        out = []
        for c in candidates:
            t = _tokens(c.text)
            if not q or not t:
                continue
            common = q & t
            if not common:
                continue
            score = len(common) / len(q | t)
            out.append((c, round(score, 4), "Shared terms: " + ", ".join(sorted(common)[:6])))
        return sorted(out, key=lambda x: x[1], reverse=True)


def get_provider() -> SuggestionProvider:
    return KeywordSuggestionProvider()

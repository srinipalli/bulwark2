import uuid
from datetime import datetime

from sqlalchemy import Boolean, DateTime, ForeignKey, Integer, SmallInteger, String, Text, func
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from bulwark.core.db import Base
from bulwark.shared.models import UUID_PK


class Solution(Base):
    __tablename__ = "solutions"
    __mapper_args__ = {"eager_defaults": True}
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), **UUID_PK)
    title: Mapped[str] = mapped_column(String)
    description: Mapped[str | None] = mapped_column(Text)
    is_retired: Mapped[bool] = mapped_column(Boolean, default=False)
    current_version_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("solution_versions.id", use_alter=True, name="fk_solutions_current_version"))
    created_by: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    versions: Mapped[list["SolutionVersion"]] = relationship(
        back_populates="solution", lazy="selectin", order_by="SolutionVersion.version_no",
        foreign_keys="SolutionVersion.solution_id")


class SolutionVersion(Base):
    __tablename__ = "solution_versions"
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), **UUID_PK)
    solution_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("solutions.id", ondelete="CASCADE"))
    version_no: Mapped[int] = mapped_column(Integer)
    title: Mapped[str] = mapped_column(String)
    description: Mapped[str | None] = mapped_column(Text)
    executor: Mapped[str] = mapped_column(String)
    job_spec: Mapped[dict] = mapped_column(JSONB, default=dict)
    applies_to: Mapped[str | None] = mapped_column(String)
    risk_level: Mapped[str] = mapped_column(String, default="MEDIUM")
    requires_reboot: Mapped[bool] = mapped_column(Boolean, default=False)
    timeout_seconds: Mapped[int] = mapped_column(Integer, default=1800)
    max_retries: Mapped[int] = mapped_column(SmallInteger, default=0)
    status: Mapped[str] = mapped_column(String, default="REVIEW_PENDING")
    created_by: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    solution: Mapped[Solution] = relationship(back_populates="versions", foreign_keys=[solution_id])

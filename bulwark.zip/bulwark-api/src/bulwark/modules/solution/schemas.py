from datetime import datetime
from typing import Literal
from uuid import UUID

from pydantic import BaseModel, Field

from bulwark.shared.schemas import ORM

Executor = Literal["ANSIBLE", "AWS_SSM", "SHELL", "HTTP"]
Risk = Literal["LOW", "MEDIUM", "HIGH"]


class SolutionCreate(BaseModel):
    title: str = Field(min_length=3, max_length=300)
    description: str | None = Field(default=None, max_length=10_000)
    executor: Executor
    job_spec: dict = {}
    applies_to: str | None = Field(default=None, max_length=500)
    risk_level: Risk = "MEDIUM"
    requires_reboot: bool = False
    timeout_seconds: int = Field(default=1800, gt=0, le=86_400)
    max_retries: int = Field(default=0, ge=0, le=5)


class SolutionUpdate(BaseModel):
    title: str | None = Field(default=None, min_length=3, max_length=300)
    description: str | None = Field(default=None, max_length=10_000)
    executor: Executor | None = None
    job_spec: dict | None = None
    applies_to: str | None = None
    risk_level: Risk | None = None
    requires_reboot: bool | None = None
    timeout_seconds: int | None = Field(default=None, gt=0, le=86_400)
    max_retries: int | None = Field(default=None, ge=0, le=5)


class VersionOut(ORM):
    id: UUID
    version_no: int
    title: str
    description: str | None
    executor: str
    job_spec: dict
    applies_to: str | None
    risk_level: str
    requires_reboot: bool
    timeout_seconds: int
    max_retries: int
    status: str
    created_at: datetime
    created_by_name: str | None = None


class SolutionOut(BaseModel):
    id: UUID
    title: str
    description: str | None
    is_retired: bool
    status: str                       # status of the latest version, or RETIRED
    latest_version_no: int
    has_approved_version: bool
    executor: str
    risk_level: str
    created_by_name: str | None
    updated_at: datetime


class SolutionDetail(SolutionOut):
    versions: list[VersionOut]


class Suggestion(BaseModel):
    solution_id: UUID
    solution_version_id: UUID
    title: str
    executor: str
    score: float
    source: str
    rationale: str

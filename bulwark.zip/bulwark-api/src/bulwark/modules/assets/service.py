from uuid import UUID

from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from bulwark.core.audit import audit
from bulwark.core.errors import Conflict, NotFound
from bulwark.core.pagination import PageParams, count_rows
from bulwark.core.security import CurrentUser
from bulwark.modules.assets.schemas import (AssetCreate, AssetDetail, AssetFacets, AssetIncidentRef, AssetOut,
                                            AssetUpdate, AssetVulnRef)
from bulwark.modules.incident.models import FINISHED, Incident, IncidentAsset
from bulwark.modules.vulnerabilities.models import Vulnerability, vulnerability_assets
from bulwark.shared.models import Asset

# correlated per-asset counts for the list
_VULNS = (select(func.count()).select_from(vulnerability_assets)
          .join(Vulnerability, Vulnerability.id == vulnerability_assets.c.vulnerability_id)
          .where(vulnerability_assets.c.asset_id == Asset.id, Vulnerability.is_active.is_(True))
          .correlate(Asset).scalar_subquery())
_OPEN_INCIDENTS = (select(func.count()).select_from(IncidentAsset)
                   .join(Incident, Incident.id == IncidentAsset.incident_id)
                   .where(IncidentAsset.asset_id == Asset.id, IncidentAsset.status != "EXCLUDED",
                          Incident.status.notin_(FINISHED))
                   .correlate(Asset).scalar_subquery())


def _out(a: Asset, vulns: int, incidents: int) -> AssetOut:
    o = AssetOut.model_validate(a)
    o.vulnerabilities_count, o.open_incidents_count = vulns, incidents
    return o


async def picker(session: AsyncSession, q: str | None, environment: str | None) -> list[Asset]:
    stmt = select(Asset).where(Asset.is_active.is_(True))
    if q:
        stmt = stmt.where(Asset.name.ilike(f"%{q}%"))
    if environment:
        stmt = stmt.where(Asset.environment == environment)
    return list((await session.execute(stmt.order_by(Asset.name).limit(500))).scalars().all())


async def list_assets(session: AsyncSession, params: PageParams, q: str | None, environment: str | None,
                      asset_type: str | None, owner_team: str | None, is_active: bool | None):
    stmt = select(Asset)
    if q:
        like = f"%{q}%"
        stmt = stmt.where(Asset.name.ilike(like) | Asset.hostname.ilike(like) | Asset.os_name.ilike(like)
                          | Asset.owner_team.ilike(like))
    if environment:
        stmt = stmt.where(Asset.environment == environment)
    if asset_type:
        stmt = stmt.where(Asset.asset_type == asset_type)
    if owner_team:
        stmt = stmt.where(Asset.owner_team == owner_team)
    if is_active is not None:
        stmt = stmt.where(Asset.is_active == is_active)
    total = await count_rows(session, stmt)
    rows = (await session.execute(stmt.add_columns(_VULNS, _OPEN_INCIDENTS).order_by(Asset.name)
                                  .offset(params.offset).limit(params.size))).all()
    return [_out(a, v, i) for a, v, i in rows], total


async def facets(session: AsyncSession) -> AssetFacets:
    async def distinct(col) -> list[str]:
        return [x for x in (await session.execute(select(col).where(col.isnot(None)).distinct().order_by(col))).scalars()]
    return AssetFacets(environments=await distinct(Asset.environment), owner_teams=await distinct(Asset.owner_team),
                       os_names=await distinct(Asset.os_name))


async def get_model(session: AsyncSession, aid: UUID) -> Asset:
    a = await session.get(Asset, aid)
    if not a:
        raise NotFound("Asset not found")
    return a


async def get_detail(session: AsyncSession, aid: UUID) -> AssetDetail:
    row = (await session.execute(select(Asset, _VULNS, _OPEN_INCIDENTS).where(Asset.id == aid)
                                 .execution_options(populate_existing=True))).first()
    if not row:
        raise NotFound("Asset not found")
    a, nv, ni = row
    vulns = (await session.execute(
        select(Vulnerability).join(vulnerability_assets, vulnerability_assets.c.vulnerability_id == Vulnerability.id)
        .where(vulnerability_assets.c.asset_id == aid).order_by(Vulnerability.is_active.desc(), Vulnerability.cve_id)
    )).scalars().all()
    incs = (await session.execute(
        select(Incident, IncidentAsset).join(IncidentAsset, IncidentAsset.incident_id == Incident.id)
        .where(IncidentAsset.asset_id == aid).order_by(Incident.incident_no.desc()).limit(100))).all()
    return AssetDetail(
        **_out(a, nv, ni).model_dump(),
        vulnerabilities=[AssetVulnRef(id=v.id, cve_id=v.cve_id, title=v.title, severity=v.severity, is_active=v.is_active)
                         for v in vulns],
        incidents=[AssetIncidentRef(id=i.id, code=i.code, title=i.title, severity=i.severity, status=i.status,
                                    asset_status=ia.status, patched_at=ia.patched_at) for i, ia in incs])


async def _name_taken(session: AsyncSession, name: str, except_id: UUID | None = None) -> bool:
    stmt = select(Asset.id).where(func.lower(Asset.name) == name.lower())
    if except_id:
        stmt = stmt.where(Asset.id != except_id)
    return (await session.execute(stmt)).first() is not None


async def create_asset(session: AsyncSession, user: CurrentUser, data: AssetCreate) -> AssetDetail:
    if await _name_taken(session, data.name):
        raise Conflict(f"An asset named '{data.name}' already exists")
    a = Asset(**data.model_dump(), is_active=True)
    session.add(a)
    try:
        await session.flush()
    except IntegrityError as e:
        await session.rollback()
        raise Conflict(f"An asset named '{data.name}' already exists") from e
    audit(session, user.id, "asset.created", "asset", a.id, after={"name": a.name, "environment": a.environment})
    await session.commit()
    return await get_detail(session, a.id)


async def update_asset(session: AsyncSession, user: CurrentUser, aid: UUID, data: AssetUpdate) -> AssetDetail:
    a = await get_model(session, aid)
    changes = data.model_dump(exclude_unset=True)
    for required in ("name", "asset_type", "environment", "attributes"):
        if required in changes and changes[required] is None:
            changes.pop(required)
    if "name" in changes and changes["name"] != a.name and await _name_taken(session, changes["name"], aid):
        raise Conflict(f"An asset named '{changes['name']}' already exists")
    before = {k: getattr(a, k) for k in changes}
    for k, v in changes.items():
        setattr(a, k, v)
    audit(session, user.id, "asset.updated", "asset", a.id, before=before, after=changes)
    try:
        await session.commit()
    except IntegrityError as e:
        await session.rollback()
        raise Conflict("Could not update asset") from e
    return await get_detail(session, aid)


async def set_active(session: AsyncSession, user: CurrentUser, aid: UUID, active: bool) -> AssetDetail:
    a = await get_model(session, aid)
    if a.is_active != active:
        if not active:
            busy = (await session.execute(
                select(Incident.incident_no).join(IncidentAsset, IncidentAsset.incident_id == Incident.id)
                .where(IncidentAsset.asset_id == aid, IncidentAsset.status.notin_(("EXCLUDED", "PATCHED")),
                       Incident.status.notin_(FINISHED)).limit(3))).scalars().all()
            if busy:
                raise Conflict("Cannot deactivate: the asset is still pending in open incident(s) "
                               + ", ".join(f"INC-{n}" for n in busy) + ". Patch or exclude it there first.")
        a.is_active = active
        audit(session, user.id, "asset.activated" if active else "asset.deactivated", "asset", a.id)
        await session.commit()
    return await get_detail(session, aid)

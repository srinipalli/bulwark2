from uuid import UUID

from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession

from bulwark.core.db import get_session
from bulwark.core.pagination import Page, PageParams
from bulwark.core.security import ANALYST, CurrentUser, get_current_user, require_roles
from bulwark.modules.assets import service
from bulwark.modules.assets.schemas import AssetCreate, AssetDetail, AssetFacets, AssetOut, AssetUpdate
from bulwark.shared.schemas import AssetRef

router = APIRouter(prefix="/assets", tags=["assets"])
writer = require_roles(ANALYST)


@router.get("", response_model=list[AssetRef])
async def picker(q: str | None = None, environment: str | None = None, session: AsyncSession = Depends(get_session),
                 _: CurrentUser = Depends(get_current_user)):
    """Active assets for the checkbox pickers on vulnerability / incident forms (unpaged, max 500)."""
    return await service.picker(session, q, environment)


@router.get("/inventory", response_model=Page[AssetOut])
async def list_assets(q: str | None = None, environment: str | None = None,
                      asset_type: str | None = Query(None, pattern="^(SYSTEM|APPLICATION)$"),
                      owner_team: str | None = None, is_active: bool | None = None, params: PageParams = Depends(),
                      session: AsyncSession = Depends(get_session), _: CurrentUser = Depends(get_current_user)):
    """Asset inventory (Assets tab): search name / hostname / OS / team, filter, page. Includes usage counts."""
    items, total = await service.list_assets(session, params, q, environment, asset_type, owner_team, is_active)
    return Page(items=items, total=total, page=params.page, size=params.size)


@router.get("/facets", response_model=AssetFacets)
async def facets(session: AsyncSession = Depends(get_session), _: CurrentUser = Depends(get_current_user)):
    """Distinct environments / owner teams / OS names for filter dropdowns and form suggestions."""
    return await service.facets(session)


@router.post("", response_model=AssetDetail, status_code=201)
async def create_asset(data: AssetCreate, session: AsyncSession = Depends(get_session), user: CurrentUser = Depends(writer)):
    return await service.create_asset(session, user, data)


@router.get("/{asset_id}", response_model=AssetDetail)
async def get_asset(asset_id: UUID, session: AsyncSession = Depends(get_session), _: CurrentUser = Depends(get_current_user)):
    """Asset with the vulnerabilities that affect it and the incidents it is part of."""
    return await service.get_detail(session, asset_id)


@router.patch("/{asset_id}", response_model=AssetDetail)
async def update_asset(asset_id: UUID, data: AssetUpdate, session: AsyncSession = Depends(get_session),
                       user: CurrentUser = Depends(writer)):
    return await service.update_asset(session, user, asset_id, data)


@router.post("/{asset_id}/activate", response_model=AssetDetail)
async def activate(asset_id: UUID, session: AsyncSession = Depends(get_session), user: CurrentUser = Depends(writer)):
    return await service.set_active(session, user, asset_id, True)


@router.post("/{asset_id}/deactivate", response_model=AssetDetail)
async def deactivate(asset_id: UUID, session: AsyncSession = Depends(get_session), user: CurrentUser = Depends(writer)):
    """Inactive assets disappear from the pickers. Blocked while the asset is still pending in an open incident."""
    return await service.set_active(session, user, asset_id, False)

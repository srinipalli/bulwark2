from datetime import datetime
from typing import Annotated, Literal
from uuid import UUID

from pydantic import BaseModel, StringConstraints

from bulwark.shared.schemas import ORM

AssetType = Literal["SYSTEM", "APPLICATION"]
Name = Annotated[str, StringConstraints(strip_whitespace=True, min_length=2, max_length=200)]
Env = Annotated[str, StringConstraints(strip_whitespace=True, min_length=2, max_length=50)]
Text = Annotated[str, StringConstraints(strip_whitespace=True, max_length=200)]


class AssetCreate(BaseModel):
    name: Name
    asset_type: AssetType
    environment: Env
    hostname: Text | None = None
    os_name: Text | None = None
    os_version: Text | None = None
    owner_team: Text | None = None
    attributes: dict = {}


class AssetUpdate(BaseModel):
    name: Name | None = None
    asset_type: AssetType | None = None
    environment: Env | None = None
    hostname: Text | None = None
    os_name: Text | None = None
    os_version: Text | None = None
    owner_team: Text | None = None
    attributes: dict | None = None


class AssetOut(ORM):
    id: UUID
    name: str
    asset_type: str
    environment: str
    hostname: str | None
    os_name: str | None
    os_version: str | None
    owner_team: str | None
    attributes: dict
    is_active: bool
    created_at: datetime
    updated_at: datetime
    vulnerabilities_count: int = 0      # active vulnerabilities affecting the asset
    open_incidents_count: int = 0       # open incidents where the asset is impacted (not excluded)


class AssetVulnRef(BaseModel):
    id: UUID
    cve_id: str
    title: str
    severity: str
    is_active: bool


class AssetIncidentRef(BaseModel):
    id: UUID
    code: str
    title: str
    severity: str
    status: str                         # incident status
    asset_status: str                   # this asset's status inside the incident
    patched_at: datetime | None


class AssetDetail(AssetOut):
    vulnerabilities: list[AssetVulnRef]
    incidents: list[AssetIncidentRef]


class AssetFacets(BaseModel):
    environments: list[str]
    owner_teams: list[str]
    os_names: list[str]

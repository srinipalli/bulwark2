from datetime import datetime
from typing import Literal
from uuid import UUID

from pydantic import BaseModel, Field

from bulwark.shared.schemas import ORM, AssetRef, UserRef

Severity = Literal["LOW", "MEDIUM", "HIGH", "CRITICAL"]
OnFailure = Literal["STOP_ASSET", "CONTINUE", "STOP_ALL"]


class IncidentCreate(BaseModel):
    vulnerability_id: UUID
    title: str | None = Field(default=None, min_length=3, max_length=300)
    description: str | None = Field(default=None, max_length=10_000)
    severity: Severity | None = None          # defaults to the vulnerability's severity
    assignee_id: UUID | None = None
    asset_ids: list[UUID] | None = None       # defaults to the vulnerability's affected assets


class IncidentUpdate(BaseModel):
    title: str | None = Field(default=None, min_length=3, max_length=300)
    description: str | None = Field(default=None, max_length=10_000)
    severity: Severity | None = None
    assignee_id: UUID | None = None


class StatusChange(BaseModel):
    status: Literal["OPEN", "PENDING_APPROVAL", "RESOLVED", "CLOSED"]     # see models.TRANSITIONS
    comment: str | None = Field(default=None, max_length=1000)


class AssetsReplace(BaseModel):
    asset_ids: list[UUID] = Field(min_length=1)


class ExcludeAsset(BaseModel):
    reason: str = Field(min_length=3, max_length=500)


class PlanStepIn(BaseModel):
    solution_id: UUID
    on_failure: OnFailure = "STOP_ASSET"


class PlanReplace(BaseModel):
    steps: list[PlanStepIn] = Field(min_length=1)


class PlanCopy(BaseModel):
    source_incident_id: UUID          # incident whose plan (solutions, order, on_failure) replaces this one's


class VulnRef(BaseModel):
    id: UUID
    cve_id: str
    title: str
    is_active: bool


class IncidentSummary(BaseModel):
    id: UUID
    code: str
    title: str
    description: str | None
    severity: str
    status: str
    vulnerability: VulnRef
    assignee: UserRef | None
    assets_count: int
    plan_steps: int
    patched_count: int
    created_at: datetime
    updated_at: datetime


class IncidentAssetOut(BaseModel):
    incident_asset_id: UUID
    asset: AssetRef
    status: str
    exclude_reason: str | None
    last_error: str | None


class PlanStepOut(BaseModel):
    plan_step_id: UUID
    step_no: int
    solution_id: UUID
    solution_version_id: UUID
    version_no: int
    title: str
    executor: str
    risk_level: str
    version_status: str
    on_failure: str


class ApprovalInfo(BaseModel):
    id: UUID
    status: str
    requested_by: str | None
    decided_by: str | None
    comment: str | None
    requested_at: datetime
    decided_at: datetime | None


class IncidentDetail(IncidentSummary):
    assets: list[IncidentAssetOut]
    plan: list[PlanStepOut]
    approval: ApprovalInfo | None
    editable: bool
    allowed_statuses: list[str] = []          # statuses POST /incidents/{id}/status accepts from the current one


class AiPlanStepOut(BaseModel):
    step_no: int
    solution_id: UUID
    solution_version_id: UUID          # the APPROVED version the AI picked
    version_no: int
    title: str
    executor: str
    risk_level: str
    requires_reboot: bool
    on_failure: str
    reason: str | None
    plannable: bool                    # still approved and not retired (Apply uses its latest approved version)
    latest_approved_version_no: int | None


class AiSolutionDraftOut(BaseModel):
    id: UUID
    position_after_step: int           # 0 = before step 1
    title: str
    problem: str
    executor: str
    applies_to: str | None
    proposed_procedure: list[str]
    risk_level: str
    requires_reboot: bool
    status: str                        # OPEN | IN_DEVELOPMENT | CREATED | REJECTED
    created_solution_id: UUID | None
    created_solution_title: str | None
    # live state of the solution built from the draft (its current version): REVIEW_PENDING | APPROVED |
    # CHANGES_REQUESTED | REJECTED | RETIRED; None while no solution exists
    created_solution_status: str | None = None
    created_solution_version_no: int | None = None
    created_solution_has_approved: bool = False       # some version is approved, so it can be planned
    updated_at: datetime | None


class AiPlanOut(BaseModel):
    """Current suggestion of the recommender's ai-planner engine (incident_ai_plans). Only a suggestion until applied."""
    plan_id: UUID
    outcome: str                       # FULL_PLAN | PARTIAL_PLAN | NO_MATCH | FAILED
    confidence: float | None
    rationale: str | None
    error: str | None
    llm_model: str
    catalog_size: int
    reused: bool                       # identical input to an earlier run: the earlier answer was reused
    review_status: str                 # NEW | APPLIED | DISMISSED
    reviewed_by: str | None
    review_comment: str | None
    reviewed_at: datetime | None
    generated_at: datetime
    steps: list[AiPlanStepOut]
    drafts: list[AiSolutionDraftOut]


class AiPlanApply(BaseModel):
    plan_id: UUID                      # the suggestion the user reviewed; rejected if a newer one replaced it


class AiPlanDismiss(BaseModel):
    plan_id: UUID
    comment: str | None = Field(default=None, max_length=1000)


class AiDraftUpdate(BaseModel):
    status: Literal["OPEN", "IN_DEVELOPMENT", "CREATED", "REJECTED"]
    created_solution_id: UUID | None = None      # required with CREATED: the solution built from the draft


class SimilarIncident(BaseModel):
    """An earlier incident found by the recommender (incident_similar_matches), with its plan."""
    incident_id: UUID
    code: str
    title: str
    cve_id: str
    status: str
    similarity: float
    rank: int
    engine: str
    matched_at: datetime
    plan: list[PlanStepOut]

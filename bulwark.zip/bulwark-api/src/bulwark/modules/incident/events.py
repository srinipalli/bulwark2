"""incident.* Kafka events. Same contract (schema_version 1.x) as bulwark-scan-ingestor's messages.incident_event, so the
solution recommender consumes incidents created in the UI exactly like scan-created ones. Keyed by incident id."""
import uuid
from datetime import datetime, timezone

from bulwark.core.security import CurrentUser
from bulwark.modules.incident.models import Incident
from bulwark.modules.vulnerabilities.models import Vulnerability
from bulwark.shared.models import Asset, User

SCHEMA_VERSION = "1.0"
INCIDENT_CREATED = "incident.created"
SYSTEM = "bulwark-api"


def _iso(d) -> str | None:
    return d.isoformat() if d else None


def incident_created(inc: Incident, v: Vulnerability, assets: list[Asset], creator: CurrentUser,
                     assignee: User | None) -> dict:
    return {
        "schema_version": SCHEMA_VERSION,
        # deterministic: a re-send carries the same id and consumers de-duplicate on it
        "event_id": str(uuid.uuid5(uuid.NAMESPACE_URL, f"bulwark/incident-event/{inc.id}/{INCIDENT_CREATED}/api")),
        "event_type": INCIDENT_CREATED,
        "occurred_at": _iso(inc.created_at),
        "produced_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "source": {"system": SYSTEM, "actor": {"id": str(creator.id), "email": creator.email}},
        "scan": None,
        "incident": {
            "id": str(inc.id), "incident_no": inc.incident_no, "code": inc.code, "title": inc.title,
            "description": inc.description, "severity": inc.severity, "status": inc.status,
            "assignee": {"id": str(assignee.id), "full_name": assignee.full_name} if assignee else None,
            "created_by": {"id": str(creator.id), "full_name": creator.name},
            "created_at": _iso(inc.created_at), "updated_at": _iso(inc.updated_at),
        },
        "vulnerability": {"id": str(v.id), "cve_id": v.cve_id, "title": v.title, "description": v.description,
                          "severity": v.severity, "cvss_score": None if v.cvss_score is None else float(v.cvss_score),
                          "published_at": _iso(v.published_at), "source": v.source, "is_active": v.is_active,
                          "db_action": "UNCHANGED"},
        "detection": None,
        "impacted_assets": [{"id": str(a.id), "name": a.name, "asset_type": a.asset_type, "environment": a.environment,
                             "hostname": a.hostname, "os_name": a.os_name, "os_version": a.os_version,
                             "owner_team": a.owner_team, "status": "PENDING"} for a in assets],
        "unresolved_assets": [],
        "change": {"action": "CREATED", "reopened": False, "previous_incident": None,
                   "assets_added": [a.name for a in assets], "changed_fields": {}},
    }

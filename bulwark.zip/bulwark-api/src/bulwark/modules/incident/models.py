import uuid
from datetime import datetime

from sqlalchemy import BigInteger, DateTime, ForeignKey, Identity, SmallInteger, String, Text, func
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from bulwark.core.db import Base
from bulwark.modules.solution.models import SolutionVersion
from bulwark.shared.models import UUID_PK, Asset

FINISHED = ("RESOLVED", "CLOSED")          # statuses after which the vulnerability may get a new incident
EDITABLE = ("OPEN", "REJECTED")            # plan / asset set can only change here
RUNNABLE = ("APPROVED", "IN_PROGRESS")     # execution allowed only here

# Manual status changes (Edit incident). APPROVED / REJECTED are only set by an approval decision, IN_PROGRESS by
# execution. OPEN from PENDING_APPROVAL withdraws the submission; from APPROVED / RESOLVED / CLOSED it reopens
# planning, so the plan has to be approved again before anything runs.
TRANSITIONS = {
    "OPEN": ("PENDING_APPROVAL", "CLOSED"),
    "REJECTED": ("OPEN", "PENDING_APPROVAL", "CLOSED"),
    "PENDING_APPROVAL": ("OPEN", "CLOSED"),
    "APPROVED": ("OPEN", "CLOSED"),
    "IN_PROGRESS": ("RESOLVED",),             # only when no job is queued or running
    "RESOLVED": ("OPEN", "CLOSED"),
    "CLOSED": ("OPEN",),
}


class Incident(Base):
    __tablename__ = "incidents"
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), **UUID_PK)
    incident_no: Mapped[int] = mapped_column(BigInteger, Identity(always=True), unique=True)
    vulnerability_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("vulnerabilities.id"))
    title: Mapped[str] = mapped_column(String)
    description: Mapped[str | None] = mapped_column(Text)
    severity: Mapped[str] = mapped_column(String)
    status: Mapped[str] = mapped_column(String, default="OPEN")
    assignee_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"))
    created_by: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"))
    submitted_by: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"))
    submitted_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    closed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    resolved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    __mapper_args__ = {"eager_defaults": True}

    assets: Mapped[list["IncidentAsset"]] = relationship(lazy="selectin", cascade="all, delete-orphan",
                                                         order_by="IncidentAsset.id")
    plan: Mapped[list["IncidentPlanStep"]] = relationship(lazy="selectin", cascade="all, delete-orphan",
                                                          order_by="IncidentPlanStep.step_no")

    @property
    def code(self) -> str:
        return f"INC-{self.incident_no}"


class IncidentAsset(Base):
    __tablename__ = "incident_assets"
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), **UUID_PK)
    incident_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("incidents.id", ondelete="CASCADE"))
    asset_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("assets.id"))
    status: Mapped[str] = mapped_column(String, default="PENDING")
    exclude_reason: Mapped[str | None] = mapped_column(Text)
    last_error: Mapped[str | None] = mapped_column(Text)
    patched_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    asset: Mapped[Asset] = relationship(lazy="selectin")


class IncidentPlanStep(Base):
    __tablename__ = "incident_plan_steps"
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), **UUID_PK)
    incident_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("incidents.id", ondelete="CASCADE"))
    step_no: Mapped[int] = mapped_column(SmallInteger)
    solution_version_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("solution_versions.id"))
    on_failure: Mapped[str] = mapped_column(String, default="STOP_ASSET")
    solution_version: Mapped[SolutionVersion] = relationship(lazy="selectin")

import json
import logging
from datetime import datetime, timezone
from uuid import UUID

from sqlalchemy import select, text
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import selectinload
from sqlalchemy.ext.asyncio import AsyncSession

from bulwark.core.audit import audit
from bulwark.core.config import get_settings
from bulwark.core.errors import Conflict, NotFound, Unprocessable
from bulwark.core.kafka import publisher
from bulwark.core.pagination import PageParams, count_rows
from bulwark.core.security import CurrentUser
from bulwark.modules.approvals.models import IncidentApproval
from bulwark.modules.execution.models import JobRun
from bulwark.modules.incident import events
from bulwark.modules.incident.models import EDITABLE, FINISHED, TRANSITIONS, Incident, IncidentAsset, IncidentPlanStep
from bulwark.modules.incident.schemas import (AiDraftUpdate, AiPlanApply, AiPlanDismiss, AiPlanOut, AiPlanStepOut,
                                              AiSolutionDraftOut, ApprovalInfo, AssetsReplace, IncidentAssetOut, IncidentCreate,
                                              IncidentDetail, IncidentSummary, IncidentUpdate, PlanCopy, PlanReplace,
                                              PlanStepIn, PlanStepOut, SimilarIncident, StatusChange, VulnRef)
from bulwark.modules.solution import service as solution_service
from bulwark.modules.solution.schemas import SolutionCreate
from bulwark.modules.vulnerabilities.models import Vulnerability
from bulwark.shared.models import Asset, User
from bulwark.shared.schemas import AssetRef, UserRef

log = logging.getLogger("bulwark.incident")


def now() -> datetime:
    return datetime.now(timezone.utc)


async def _users(session: AsyncSession, ids: set) -> dict:
    ids = {i for i in ids if i}
    if not ids:
        return {}
    return {u.id: u for u in (await session.execute(select(User).where(User.id.in_(ids)))).scalars()}


def _active_assets(i: Incident) -> list[IncidentAsset]:
    return [a for a in i.assets if a.status != "EXCLUDED"]


def maybe_resolve(i: Incident) -> None:
    """Roll-up: when every non-excluded asset is PATCHED the incident is RESOLVED."""
    act = _active_assets(i)
    if i.status in ("APPROVED", "IN_PROGRESS") and act and all(a.status == "PATCHED" for a in act):
        i.status, i.resolved_at = "RESOLVED", now()


async def _summaries(session: AsyncSession, incidents: list[Incident]) -> list[IncidentSummary]:
    vids = {i.vulnerability_id for i in incidents}
    vmap = {v.id: v for v in (await session.execute(select(Vulnerability).where(Vulnerability.id.in_(vids)))).scalars()} if vids else {}
    umap = await _users(session, {i.assignee_id for i in incidents})
    out = []
    for i in incidents:
        v, u = vmap[i.vulnerability_id], umap.get(i.assignee_id)
        act = _active_assets(i)
        out.append(IncidentSummary(
            id=i.id, code=i.code, title=i.title, description=i.description, severity=i.severity, status=i.status,
            vulnerability=VulnRef(id=v.id, cve_id=v.cve_id, title=v.title, is_active=v.is_active),
            assignee=UserRef(id=u.id, full_name=u.full_name) if u else None, assets_count=len(act),
            plan_steps=len(i.plan), patched_count=sum(1 for a in act if a.status == "PATCHED"),
            created_at=i.created_at, updated_at=i.updated_at))
    return out


async def get_model(session: AsyncSession, iid: UUID) -> Incident:
    i = await session.get(Incident, iid)
    if not i:
        raise NotFound("Incident not found")
    return i


async def get_detail(session: AsyncSession, iid: UUID) -> IncidentDetail:
    i = await get_model(session, iid)
    await session.refresh(i)
    # explicit loads: rows created earlier in this same session do not have their relationships populated
    assets = (await session.execute(select(IncidentAsset).where(IncidentAsset.incident_id == iid)
                                    .options(selectinload(IncidentAsset.asset)).order_by(IncidentAsset.id)
                                    .execution_options(populate_existing=True))).scalars().all()
    steps = (await session.execute(select(IncidentPlanStep).where(IncidentPlanStep.incident_id == iid)
                                   .options(selectinload(IncidentPlanStep.solution_version)).order_by(IncidentPlanStep.step_no)
                                   .execution_options(populate_existing=True))).scalars().all()
    base = (await _summaries(session, [i]))[0]
    appr = (await session.execute(select(IncidentApproval).where(IncidentApproval.incident_id == iid)
                                  .order_by(IncidentApproval.requested_at.desc()).limit(1))).scalar_one_or_none()
    umap = await _users(session, {appr.requested_by, appr.decided_by} if appr else set())
    approval = ApprovalInfo(
        id=appr.id, status=appr.status, requested_by=getattr(umap.get(appr.requested_by), "full_name", None),
        decided_by=getattr(umap.get(appr.decided_by), "full_name", None), comment=appr.comment,
        requested_at=appr.requested_at, decided_at=appr.decided_at) if appr else None
    return IncidentDetail(
        **base.model_dump(),
        assets=[IncidentAssetOut(incident_asset_id=a.id, asset=AssetRef.model_validate(a.asset), status=a.status,
                                 exclude_reason=a.exclude_reason, last_error=a.last_error) for a in assets],
        plan=_plan_out(steps), approval=approval, editable=i.status in EDITABLE,
        allowed_statuses=list(TRANSITIONS.get(i.status, ())))


def _plan_out(steps: list[IncidentPlanStep]) -> list[PlanStepOut]:
    return [PlanStepOut(plan_step_id=p.id, step_no=p.step_no, solution_id=p.solution_version.solution_id,
                        solution_version_id=p.solution_version_id, version_no=p.solution_version.version_no,
                        title=p.solution_version.title, executor=p.solution_version.executor,
                        risk_level=p.solution_version.risk_level, version_status=p.solution_version.status,
                        on_failure=p.on_failure) for p in steps]


# Written by the bulwark-inc-planner-solution-recommender service (its sql/10_recommender.sql); current run per engine only.
SIMILAR_MATCHES = text("""
SELECT m.similar_incident_id, m.similarity, m.rank, r.engine, r.created_at AS matched_at
  FROM incident_suggestion_runs r JOIN incident_similar_matches m ON m.run_id = r.id
 WHERE r.incident_id = :iid AND r.is_current
 ORDER BY m.rank, r.engine""")


async def similar_incidents(session: AsyncSession, iid: UUID) -> list[SimilarIncident]:
    await get_model(session, iid)
    # the tables belong to the recommender; a database where it was never set up simply has no matches
    if (await session.execute(text("SELECT to_regclass('incident_similar_matches')"))).scalar() is None:
        return []
    rows = (await session.execute(SIMILAR_MATCHES, {"iid": iid})).mappings().all()
    if not rows:
        return []
    incs = {i.id: i for i in (await session.execute(
        select(Incident).where(Incident.id.in_({r["similar_incident_id"] for r in rows})))).scalars()}
    base = {s.id: s for s in await _summaries(session, list(incs.values()))}
    return [SimilarIncident(incident_id=i.id, code=i.code, title=i.title, cve_id=base[i.id].vulnerability.cve_id,
                            status=i.status, similarity=r["similarity"], rank=r["rank"], engine=r["engine"],
                            matched_at=r["matched_at"], plan=_plan_out(i.plan))
            for r in rows if (i := incs.get(r["similar_incident_id"]))]


# Written by the recommender's ai-planner engine (its sql/11_ai_planner.sql); current run only.
AI_PLAN = text("""
SELECT p.*, r.created_at AS generated_at, u.full_name AS reviewed_by_name
  FROM incident_suggestion_runs r
  JOIN incident_ai_plans p ON p.run_id = r.id
  LEFT JOIN users u ON u.id = p.reviewed_by
 WHERE r.incident_id = :iid AND r.engine = 'ai-planner' AND r.is_current""")

AI_STEPS = text("""
SELECT s.step_no, s.solution_id, s.solution_version_id, s.on_failure, s.reason, sv.version_no, sv.title, sv.executor,
       sv.risk_level, sv.requires_reboot, sol.is_retired,
       (SELECT max(x.version_no) FROM solution_versions x
         WHERE x.solution_id = s.solution_id AND x.status = 'APPROVED') AS latest_approved_version_no
  FROM incident_ai_plan_steps s
  JOIN solution_versions sv ON sv.id = s.solution_version_id
  JOIN solutions sol ON sol.id = s.solution_id
 WHERE s.plan_id = :pid
 ORDER BY s.step_no""")

AI_DRAFTS = text("""
SELECT d.*, sol.title AS created_solution_title,
       CASE WHEN sol.is_retired THEN 'RETIRED' ELSE cv.status END AS created_solution_status,
       cv.version_no AS created_solution_version_no,
       EXISTS (SELECT 1 FROM solution_versions x WHERE x.solution_id = sol.id AND x.status = 'APPROVED') AS created_solution_has_approved
  FROM ai_solution_drafts d
  LEFT JOIN solutions sol ON sol.id = d.created_solution_id
  LEFT JOIN solution_versions cv ON cv.id = sol.current_version_id
 WHERE d.plan_id = :pid
 ORDER BY d.position_after_step, d.created_at, d.title""")


async def _current_ai_plan(session: AsyncSession, iid: UUID):
    # the tables belong to the recommender; a database where the ai-planner was never set up simply has no plan
    if (await session.execute(text("SELECT to_regclass('incident_ai_plans')"))).scalar() is None:
        return None
    return (await session.execute(AI_PLAN, {"iid": iid})).mappings().first()


async def _ai_steps(session: AsyncSession, pid: UUID):
    return (await session.execute(AI_STEPS, {"pid": pid})).mappings().all()


async def ai_plan(session: AsyncSession, iid: UUID) -> AiPlanOut | None:
    await get_model(session, iid)
    p = await _current_ai_plan(session, iid)
    if not p:
        return None
    steps = await _ai_steps(session, p["id"])
    drafts = (await session.execute(AI_DRAFTS, {"pid": p["id"]})).mappings().all()
    return AiPlanOut(
        plan_id=p["id"], outcome=p["outcome"], confidence=float(p["confidence"]) if p["confidence"] is not None else None,
        rationale=p["rationale"], error=p["error"], llm_model=p["llm_model"], catalog_size=p["catalog_size"],
        reused=p["reused_from_plan_id"] is not None, review_status=p["review_status"], reviewed_by=p["reviewed_by_name"],
        review_comment=p["review_comment"], reviewed_at=p["reviewed_at"], generated_at=p["generated_at"],
        steps=[AiPlanStepOut(step_no=s["step_no"], solution_id=s["solution_id"], solution_version_id=s["solution_version_id"],
                             version_no=s["version_no"], title=s["title"], executor=s["executor"], risk_level=s["risk_level"],
                             requires_reboot=s["requires_reboot"], on_failure=s["on_failure"], reason=s["reason"],
                             plannable=not s["is_retired"] and s["latest_approved_version_no"] is not None,
                             latest_approved_version_no=s["latest_approved_version_no"]) for s in steps],
        drafts=[AiSolutionDraftOut(
            id=d["id"], position_after_step=d["position_after_step"], title=d["title"], problem=d["problem"], executor=d["executor"],
            applies_to=d["applies_to"], risk_level=d["risk_level"], requires_reboot=d["requires_reboot"], status=d["status"],
            proposed_procedure=json.loads(d["proposed_procedure"]) if isinstance(d["proposed_procedure"], str) else d["proposed_procedure"],
            created_solution_id=d["created_solution_id"], created_solution_title=d["created_solution_title"],
            created_solution_status=d["created_solution_status"], created_solution_version_no=d["created_solution_version_no"],
            created_solution_has_approved=bool(d["created_solution_id"] and d["created_solution_has_approved"]),
            updated_at=d["updated_at"]) for d in drafts])


async def _reviewed_ai_plan(session: AsyncSession, iid: UUID, plan_id: UUID):
    p = await _current_ai_plan(session, iid)
    if not p:
        raise NotFound("There is no AI suggested plan for this incident")
    if str(p["id"]) != str(plan_id):
        raise Conflict("A newer AI suggestion replaced the one you reviewed. Reload and review it again.")
    return p


async def _solution_from_draft(session: AsyncSession, user: CurrentUser, i: Incident, d) -> UUID:
    """Turn an AI draft into a real solution (REVIEW_PENDING, queued under Approvals) and link the draft to it."""
    proc = json.loads(d["proposed_procedure"]) if isinstance(d["proposed_procedure"], str) else d["proposed_procedure"]
    desc = d["problem"]
    if proc:
        desc += "\n\nProposed procedure:\n" + "\n".join(f"{n}. {s}" for n, s in enumerate(proc, start=1))
    desc += f"\n\nDrafted by the AI planner for {i.code}. The job spec still has to be written before it can run."
    s = await solution_service.add_solution(session, user, SolutionCreate(
        title=d["title"][:300], description=desc[:10_000], executor=d["executor"], applies_to=(d["applies_to"] or None) and d["applies_to"][:500],
        risk_level=d["risk_level"], requires_reboot=d["requires_reboot"]))
    await session.execute(text("UPDATE ai_solution_drafts SET status = 'CREATED', created_solution_id = :s, updated_by = :u, "
                               "updated_at = now() WHERE id = :d"), {"s": s.id, "u": user.id, "d": d["id"]})
    return s.id


async def apply_ai_plan(session: AsyncSession, user: CurrentUser, iid: UUID, data: AiPlanApply) -> IncidentDetail:
    """Replace the incident's plan with the AI's suggestion in its order. Solutions still to develop (drafts that are not
    rejected) are created first as REVIEW_PENDING solutions - or the one already built from the draft is reused - and
    placed where the AI put them. The incident can only be submitted once every solution in the plan is approved."""
    i = await get_model(session, iid)
    _require_editable(i)
    p = await _reviewed_ai_plan(session, iid, data.plan_id)
    steps = await _ai_steps(session, p["id"])
    drafts = [d for d in (await session.execute(AI_DRAFTS, {"pid": p["id"]})).mappings().all() if d["status"] != "REJECTED"]
    if not steps and not drafts:
        raise Unprocessable("This AI suggestion has no plan steps and no solutions to develop")
    created, new = {}, []
    for d in drafts:
        if d["created_solution_id"]:
            created[d["id"]] = d["created_solution_id"]
        else:
            created[d["id"]] = await _solution_from_draft(session, user, i, d)
            new.append(str(created[d["id"]]))
    # the AI's order: a draft sits after the step numbered position_after_step (0 = before step 1)
    at = lambda pos: [PlanStepIn(solution_id=created[d["id"]]) for d in drafts if d["position_after_step"] == pos]  # noqa: E731
    order = at(0)
    for s in steps:
        order += [PlanStepIn(solution_id=s["solution_id"], on_failure=s["on_failure"])] + at(s["step_no"])
    placed = {x.solution_id for x in order}
    order += [PlanStepIn(solution_id=created[d["id"]]) for d in drafts if created[d["id"]] not in placed]
    plan = PlanReplace(steps=order)
    await _set_plan(session, i, plan, pending_ok=frozenset(created.values()))
    await session.execute(text("UPDATE incident_ai_plans SET review_status = 'APPLIED', reviewed_by = :u, reviewed_at = now(), "
                               "review_comment = NULL WHERE id = :pid"), {"u": user.id, "pid": p["id"]})
    audit(session, user.id, "incident.ai_plan_applied", "incident", i.id,
          after={"ai_plan": str(p["id"]), "llm_model": p["llm_model"], "solutions": [str(s.solution_id) for s in plan.steps],
                 "solutions_created": new})
    await session.commit()
    return await get_detail(session, iid)


async def dismiss_ai_plan(session: AsyncSession, user: CurrentUser, iid: UUID, data: AiPlanDismiss) -> AiPlanOut | None:
    await get_model(session, iid)
    p = await _reviewed_ai_plan(session, iid, data.plan_id)
    await session.execute(text("UPDATE incident_ai_plans SET review_status = 'DISMISSED', reviewed_by = :u, reviewed_at = now(), "
                               "review_comment = :c WHERE id = :pid"), {"u": user.id, "c": data.comment, "pid": p["id"]})
    audit(session, user.id, "incident.ai_plan_dismissed", "incident", iid, after={"ai_plan": str(p["id"]), "comment": data.comment})
    await session.commit()
    return await ai_plan(session, iid)


async def update_ai_draft(session: AsyncSession, user: CurrentUser, iid: UUID, draft_id: UUID, data: AiDraftUpdate) -> AiPlanOut | None:
    """Developer progress on a solution the AI said is missing (the solution itself is created via POST /solutions)."""
    await get_model(session, iid)
    if await _current_ai_plan(session, iid) is None:
        raise NotFound("There is no AI suggested plan for this incident")
    found = (await session.execute(text("SELECT id FROM ai_solution_drafts WHERE id = :d AND incident_id = :i"),
                                   {"d": draft_id, "i": iid})).first()
    if not found:
        raise NotFound("Draft not found")
    if data.status == "CREATED":
        if not data.created_solution_id:
            raise Unprocessable("created_solution_id is required when the status is CREATED")
        await solution_service.get_model(session, data.created_solution_id)
    await session.execute(text("UPDATE ai_solution_drafts SET status = :s, created_solution_id = COALESCE(:c, created_solution_id), "
                               "updated_by = :u, updated_at = now() WHERE id = :d"),
                          {"s": data.status, "c": data.created_solution_id, "u": user.id, "d": draft_id})
    audit(session, user.id, "incident.ai_draft_updated", "incident", iid,
          after={"draft": str(draft_id), "status": data.status,
                 "solution": str(data.created_solution_id) if data.created_solution_id else None})
    await session.commit()
    return await ai_plan(session, iid)


async def list_incidents(session: AsyncSession, params: PageParams, q: str | None, status: str | None,
                         severity: str | None, assignee_id: UUID | None):
    stmt = select(Incident).join(Vulnerability, Vulnerability.id == Incident.vulnerability_id)
    if q:
        like = f"%{q}%"
        stmt = stmt.where(Incident.title.ilike(like) | Incident.description.ilike(like) | Vulnerability.cve_id.ilike(like))
    if status:
        stmt = stmt.where(Incident.status == status)
    if severity:
        stmt = stmt.where(Incident.severity == severity)
    if assignee_id:
        stmt = stmt.where(Incident.assignee_id == assignee_id)
    total = await count_rows(session, stmt)
    rows = (await session.execute(stmt.order_by(Incident.incident_no.desc()).offset(params.offset).limit(params.size))).scalars().all()
    return await _summaries(session, list(rows)), total


async def _assets_by_ids(session: AsyncSession, ids: list[UUID]) -> list[Asset]:
    found = (await session.execute(select(Asset).where(Asset.id.in_(set(ids))))).scalars().all()
    if len(found) != len(set(ids)):
        raise Unprocessable("One or more asset_ids do not exist")
    return list(found)


async def create_incident(session: AsyncSession, user: CurrentUser, data: IncidentCreate) -> IncidentDetail:
    v = await session.get(Vulnerability, data.vulnerability_id)
    if not v:
        raise NotFound("Vulnerability not found")
    if not v.is_active:
        raise Unprocessable("Vulnerability is inactive. Activate it before creating an incident.")
    existing = (await session.execute(select(Incident).where(Incident.vulnerability_id == v.id,
                                                              Incident.status.notin_(FINISHED)))).scalar_one_or_none()
    if existing:
        raise Conflict(f"{existing.code} is already open for {v.cve_id}")
    assets = await _assets_by_ids(session, data.asset_ids) if data.asset_ids else list(v.assets)
    if not assets:
        raise Unprocessable("Incident needs at least one impacted asset")
    inc = Incident(vulnerability_id=v.id, title=data.title or f"{v.title} – remediation", description=data.description,
                   severity=data.severity or v.severity, assignee_id=data.assignee_id, created_by=user.id, status="OPEN")
    inc.assets = [IncidentAsset(asset_id=a.id, status="PENDING") for a in assets]
    session.add(inc)
    try:
        await session.flush()
    except IntegrityError as e:
        await session.rollback()
        raise Conflict("An open incident already exists for this vulnerability, or assignee is invalid") from e
    audit(session, user.id, "incident.created", "incident", inc.id, after={"vulnerability": v.cve_id})
    await session.commit()
    await _publish_created(session, user, inc, v, assets)
    return await get_detail(session, inc.id)


async def _publish_created(session: AsyncSession, user: CurrentUser, inc: Incident, v: Vulnerability,
                           assets: list[Asset]) -> None:
    """Runs after the commit: the incident exists even if Kafka is down, so a failed publish is logged, not raised."""
    assignee = await session.get(User, inc.assignee_id) if inc.assignee_id else None
    msg = events.incident_created(inc, v, assets, user, assignee)
    try:
        await publisher.publish(get_settings().kafka_topic_incidents, str(inc.id), msg,
                                {"event_type": msg["event_type"], "schema_version": events.SCHEMA_VERSION,
                                 "cve_id": v.cve_id})
    except Exception:
        log.exception("%s event for %s (%s) was not published", msg["event_type"], inc.code, inc.id)


async def update_incident(session: AsyncSession, user: CurrentUser, iid: UUID, data: IncidentUpdate) -> IncidentDetail:
    i = await get_model(session, iid)
    if i.status in FINISHED:
        raise Conflict("Finished incidents cannot be edited")
    changes = data.model_dump(exclude_unset=True)
    for k, val in changes.items():
        setattr(i, k, val)
    audit(session, user.id, "incident.updated", "incident", i.id, after={k: str(v) for k, v in changes.items()})
    try:
        await session.commit()
    except IntegrityError as e:
        await session.rollback()
        raise Unprocessable("Invalid assignee") from e
    return await get_detail(session, iid)


def _require_editable(i: Incident) -> None:
    if i.status not in EDITABLE:
        raise Conflict(f"Plan and assets are locked while the incident is {i.status}. "
                       "They can only change while it is OPEN or REJECTED.")


async def replace_assets(session: AsyncSession, user: CurrentUser, iid: UUID, data: AssetsReplace) -> IncidentDetail:
    i = await get_model(session, iid)
    _require_editable(i)
    assets = await _assets_by_ids(session, data.asset_ids)
    keep = {a.id for a in assets}
    i.assets = [a for a in i.assets if a.asset_id in keep] + [
        IncidentAsset(asset_id=a.id) for a in assets if a.id not in {x.asset_id for x in i.assets}]
    audit(session, user.id, "incident.assets_replaced", "incident", i.id, after={"asset_ids": [str(x) for x in keep]})
    await session.commit()
    return await get_detail(session, iid)


async def exclude_asset(session: AsyncSession, user: CurrentUser, iid: UUID, incident_asset_id: UUID, reason: str) -> IncidentDetail:
    i = await get_model(session, iid)
    if i.status in FINISHED:
        raise Conflict("Incident is finished")
    ia = next((a for a in i.assets if a.id == incident_asset_id), None)
    if not ia:
        raise NotFound("Asset is not part of this incident")
    live = (await session.execute(select(JobRun.id).where(JobRun.incident_asset_id == ia.id,
                                                          JobRun.status.in_(("QUEUED", "RUNNING"))).limit(1))).first()
    if live:
        raise Conflict("A job is queued or running on this asset")
    ia.status, ia.exclude_reason = "EXCLUDED", reason
    maybe_resolve(i)
    audit(session, user.id, "incident.asset_excluded", "incident", i.id, after={"asset": str(ia.asset_id), "reason": reason})
    await session.commit()
    return await get_detail(session, iid)


async def replace_plan(session: AsyncSession, user: CurrentUser, iid: UUID, data: PlanReplace) -> IncidentDetail:
    i = await get_model(session, iid)
    _require_editable(i)
    # solutions already planned but still awaiting review (e.g. from an AI draft) may stay while the plan is reordered
    await _set_plan(session, i, data, pending_ok=frozenset(p.solution_version.solution_id for p in i.plan))
    audit(session, user.id, "incident.plan_replaced", "incident", i.id, after={"solutions": [str(s.solution_id) for s in data.steps]})
    await session.commit()
    return await get_detail(session, iid)


async def clear_plan(session: AsyncSession, user: CurrentUser, iid: UUID) -> IncidentDetail:
    i = await get_model(session, iid)
    _require_editable(i)
    removed = [str(p.solution_version.solution_id) for p in i.plan]
    i.plan.clear()
    audit(session, user.id, "incident.plan_cleared", "incident", i.id, before={"solutions": removed})
    await session.commit()
    return await get_detail(session, iid)


async def copy_plan(session: AsyncSession, user: CurrentUser, iid: UUID, data: PlanCopy) -> IncidentDetail:
    """Override this incident's plan with another incident's (e.g. a similar incident from the recommender).
    Same rules as replace_plan: each solution is resolved to its latest APPROVED version."""
    i = await get_model(session, iid)
    _require_editable(i)
    if data.source_incident_id == iid:
        raise Unprocessable("An incident cannot copy its own plan")
    src = await get_model(session, data.source_incident_id)
    if not src.plan:
        raise Unprocessable(f"{src.code} has no solution plan to copy")
    steps = PlanReplace(steps=[PlanStepIn(solution_id=p.solution_version.solution_id, on_failure=p.on_failure) for p in src.plan])
    await _set_plan(session, i, steps, pending_ok=frozenset(s.solution_id for s in steps.steps))
    audit(session, user.id, "incident.plan_copied", "incident", i.id,
          after={"source": src.code, "solutions": [str(s.solution_id) for s in steps.steps]})
    await session.commit()
    return await get_detail(session, iid)


async def _set_plan(session: AsyncSession, i: Incident, data: PlanReplace, pending_ok: frozenset = frozenset()) -> None:
    """Each step is pinned to the solution's latest APPROVED version. Solutions in `pending_ok` that have no approved
    version yet are pinned to their latest version instead; submit_for_approval refuses the plan until it is approved."""
    ids = [s.solution_id for s in data.steps]
    if len(set(ids)) != len(ids):
        raise Unprocessable("A solution can appear only once in a plan")
    new_steps = []
    for n, step in enumerate(data.steps, start=1):
        sol = await solution_service.get_model(session, step.solution_id)
        await session.refresh(sol, ["versions"])          # also covers solutions created earlier in this transaction
        ver = solution_service.latest_approved(sol)
        if ver is None and sol.id in pending_ok:
            ver = solution_service.latest(sol)
        if sol.is_retired or ver is None:
            raise Unprocessable(f"Solution '{sol.title}' is not approved (or is retired) and cannot be planned")
        new_steps.append(IncidentPlanStep(step_no=n, solution_version_id=ver.id, on_failure=step.on_failure))
    i.plan.clear()
    await session.flush()              # delete old rows first: (incident_id, step_no) is unique
    i.plan.extend(new_steps)


async def plan_is_approved(session: AsyncSession, i: Incident) -> bool:
    return bool(i.plan) and all(p.solution_version.status == "APPROVED" for p in i.plan)


async def submit_for_approval(session: AsyncSession, user: CurrentUser, iid: UUID) -> IncidentDetail:
    i = await get_model(session, iid)
    _require_editable(i)
    if not i.plan:
        raise Unprocessable("Add at least one solution to the plan before submitting")
    if not _active_assets(i):
        raise Unprocessable("Incident has no impacted assets")
    if not await plan_is_approved(session, i):
        waiting = ", ".join(p.solution_version.title for p in i.plan if p.solution_version.status != "APPROVED")
        raise Unprocessable(f"Every solution in the plan must be an approved version. Waiting for solution approval: {waiting}")
    snapshot = [{"step_no": p.step_no, "solution_id": str(p.solution_version.solution_id),
                 "solution_version_id": str(p.solution_version_id), "version_no": p.solution_version.version_no,
                 "title": p.solution_version.title, "executor": p.solution_version.executor,
                 "on_failure": p.on_failure} for p in i.plan]
    session.add(IncidentApproval(incident_id=i.id, level=1, status="PENDING", requested_by=user.id, plan_snapshot=snapshot))
    i.status, i.submitted_by, i.submitted_at = "PENDING_APPROVAL", user.id, now()
    audit(session, user.id, "incident.submitted", "incident", i.id)
    await session.commit()
    return await get_detail(session, iid)


async def close_incident(session: AsyncSession, user: CurrentUser, iid: UUID) -> IncidentDetail:
    i = await get_model(session, iid)
    if i.status == "CLOSED":
        return await get_detail(session, iid)
    if i.status == "IN_PROGRESS":
        raise Conflict("Execution is in progress. Wait for it to finish or exclude the remaining assets.")
    if i.status == "PENDING_APPROVAL":
        await _cancel_pending_approvals(session, iid)
    i.status, i.closed_at = "CLOSED", now()
    audit(session, user.id, "incident.closed", "incident", i.id)
    await session.commit()
    return await get_detail(session, iid)


async def _cancel_pending_approvals(session: AsyncSession, iid: UUID) -> None:
    pend = (await session.execute(select(IncidentApproval).where(IncidentApproval.incident_id == iid,
                                                                  IncidentApproval.status == "PENDING"))).scalars().all()
    for a in pend:
        a.status, a.decided_at = "CANCELLED", now()


async def change_status(session: AsyncSession, user: CurrentUser, iid: UUID, data: StatusChange) -> IncidentDetail:
    """Manual status change from Edit incident, limited to models.TRANSITIONS. Submitting and closing reuse their
    own actions (and checks); approval decisions and IN_PROGRESS are never set here."""
    i = await get_model(session, iid)
    before, target = i.status, data.status
    if target == before:
        return await get_detail(session, iid)
    if target not in TRANSITIONS.get(before, ()):
        raise Conflict(f"An incident cannot be moved from {before} to {target}")
    if target == "PENDING_APPROVAL":
        return await submit_for_approval(session, user, iid)
    if target == "CLOSED":
        return await close_incident(session, user, iid)
    if target == "OPEN":
        if before in FINISHED:          # reopening: still only one unfinished incident per vulnerability
            other = (await session.execute(select(Incident).where(Incident.vulnerability_id == i.vulnerability_id,
                                                                   Incident.id != i.id, Incident.status.notin_(FINISHED)))).scalars().first()
            if other:
                raise Conflict(f"{other.code} is already open for this vulnerability")
            i.closed_at = i.resolved_at = None
        await _cancel_pending_approvals(session, iid)       # withdraws a pending submission
    elif target == "RESOLVED":
        live = (await session.execute(select(JobRun.id).join(IncidentAsset, IncidentAsset.id == JobRun.incident_asset_id)
                                      .where(IncidentAsset.incident_id == iid, JobRun.status.in_(("QUEUED", "RUNNING"))).limit(1))).first()
        if live:
            raise Conflict("Jobs are still queued or running. Wait for them to finish or cancel them first.")
        i.resolved_at = now()
    i.status = target
    audit(session, user.id, "incident.status_changed", "incident", i.id, before={"status": before},
          after={"status": target, "comment": data.comment})
    await session.commit()
    return await get_detail(session, iid)

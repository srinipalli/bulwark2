from uuid import UUID

from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession

from bulwark.core.db import get_session
from bulwark.core.pagination import Page, PageParams
from bulwark.core.security import ANALYST, OPERATOR, CurrentUser, get_current_user, require_roles
from bulwark.modules.incident import service
from bulwark.modules.incident.schemas import (AiDraftUpdate, AiPlanApply, AiPlanDismiss, AiPlanOut, AssetsReplace,
                                              ExcludeAsset, IncidentCreate, IncidentDetail, IncidentSummary, IncidentUpdate,
                                              PlanCopy, PlanReplace, SimilarIncident, StatusChange)

router = APIRouter(prefix="/incidents", tags=["incidents"])
STATUS_RE = "^(OPEN|PENDING_APPROVAL|APPROVED|REJECTED|IN_PROGRESS|RESOLVED|CLOSED)$"
writer = require_roles(ANALYST, OPERATOR)
# Solution plan changes: any signed-in user for now (incl. APPROVER). Tighten to e.g. require_roles(ANALYST, OPERATOR, APPROVER) later.
planner = get_current_user


@router.get("", response_model=Page[IncidentSummary])
async def list_incidents(q: str | None = None, status: str | None = Query(None, pattern=STATUS_RE),
                         severity: str | None = Query(None, pattern="^(LOW|MEDIUM|HIGH|CRITICAL)$"),
                         assignee_id: UUID | None = None, params: PageParams = Depends(),
                         session: AsyncSession = Depends(get_session), _: CurrentUser = Depends(get_current_user)):
    items, total = await service.list_incidents(session, params, q, status, severity, assignee_id)
    return Page(items=items, total=total, page=params.page, size=params.size)


@router.post("", response_model=IncidentDetail, status_code=201)
async def create_incident(data: IncidentCreate, session: AsyncSession = Depends(get_session),
                          user: CurrentUser = Depends(writer)):
    """One incident per vulnerability. Impacted assets default to the vulnerability's assets."""
    return await service.create_incident(session, user, data)


@router.get("/{incident_id}", response_model=IncidentDetail)
async def get_incident(incident_id: UUID, session: AsyncSession = Depends(get_session),
                       _: CurrentUser = Depends(get_current_user)):
    return await service.get_detail(session, incident_id)


@router.get("/{incident_id}/similar", response_model=list[SimilarIncident])
async def similar_incidents(incident_id: UUID, session: AsyncSession = Depends(get_session),
                            _: CurrentUser = Depends(get_current_user)):
    """Earlier incidents with a plan that the solution recommender matched to this one, best first."""
    return await service.similar_incidents(session, incident_id)


@router.get("/{incident_id}/ai-plan", response_model=AiPlanOut | None)
async def ai_plan(incident_id: UUID, session: AsyncSession = Depends(get_session),
                  _: CurrentUser = Depends(get_current_user)):
    """Current AI suggested plan (recommender ai-planner engine, Gemini Flash), or null when there is none yet."""
    return await service.ai_plan(session, incident_id)


@router.post("/{incident_id}/ai-plan/apply", response_model=IncidentDetail)
async def apply_ai_plan(incident_id: UUID, data: AiPlanApply, session: AsyncSession = Depends(get_session),
                        user: CurrentUser = Depends(planner)):
    """Replace the plan with the AI's suggestion in its order (only while OPEN or REJECTED). Solutions still to develop
    are created first (Review Pending) and placed where the AI put them; submit waits until they are approved."""
    return await service.apply_ai_plan(session, user, incident_id, data)


@router.post("/{incident_id}/ai-plan/dismiss", response_model=AiPlanOut | None)
async def dismiss_ai_plan(incident_id: UUID, data: AiPlanDismiss, session: AsyncSession = Depends(get_session),
                          user: CurrentUser = Depends(planner)):
    return await service.dismiss_ai_plan(session, user, incident_id, data)


@router.patch("/{incident_id}/ai-plan/drafts/{draft_id}", response_model=AiPlanOut | None)
async def update_ai_draft(incident_id: UUID, draft_id: UUID, data: AiDraftUpdate, session: AsyncSession = Depends(get_session),
                          user: CurrentUser = Depends(require_roles(ANALYST))):
    """Track a solution the AI says is missing: IN_DEVELOPMENT, CREATED (with the new solution's id) or REJECTED."""
    return await service.update_ai_draft(session, user, incident_id, draft_id, data)


@router.patch("/{incident_id}", response_model=IncidentDetail)
async def update_incident(incident_id: UUID, data: IncidentUpdate, session: AsyncSession = Depends(get_session),
                          user: CurrentUser = Depends(writer)):
    return await service.update_incident(session, user, incident_id, data)


@router.put("/{incident_id}/assets", response_model=IncidentDetail)
async def replace_assets(incident_id: UUID, data: AssetsReplace, session: AsyncSession = Depends(get_session),
                         user: CurrentUser = Depends(writer)):
    return await service.replace_assets(session, user, incident_id, data)


@router.post("/{incident_id}/assets/{incident_asset_id}/exclude", response_model=IncidentDetail)
async def exclude_asset(incident_id: UUID, incident_asset_id: UUID, data: ExcludeAsset,
                        session: AsyncSession = Depends(get_session), user: CurrentUser = Depends(writer)):
    return await service.exclude_asset(session, user, incident_id, incident_asset_id, data.reason)


@router.put("/{incident_id}/plan", response_model=IncidentDetail)
async def replace_plan(incident_id: UUID, data: PlanReplace, session: AsyncSession = Depends(get_session),
                       user: CurrentUser = Depends(planner)):
    """Ordered list of solutions (each resolved to its latest APPROVED version)."""
    return await service.replace_plan(session, user, incident_id, data)


@router.delete("/{incident_id}/plan", response_model=IncidentDetail)
async def clear_plan(incident_id: UUID, session: AsyncSession = Depends(get_session),
                     user: CurrentUser = Depends(planner)):
    """Remove every step of the plan (only while the incident is OPEN or REJECTED)."""
    return await service.clear_plan(session, user, incident_id)


@router.post("/{incident_id}/plan/copy-from", response_model=IncidentDetail)
async def copy_plan(incident_id: UUID, data: PlanCopy, session: AsyncSession = Depends(get_session),
                    user: CurrentUser = Depends(planner)):
    """Override the plan with another incident's plan (same solutions, order and on_failure)."""
    return await service.copy_plan(session, user, incident_id, data)


@router.post("/{incident_id}/submit", response_model=IncidentDetail)
async def submit_for_approval(incident_id: UUID, session: AsyncSession = Depends(get_session),
                              user: CurrentUser = Depends(writer)):
    return await service.submit_for_approval(session, user, incident_id)


@router.post("/{incident_id}/status", response_model=IncidentDetail)
async def change_status(incident_id: UUID, data: StatusChange, session: AsyncSession = Depends(get_session),
                        user: CurrentUser = Depends(writer)):
    """Manual status change (Edit incident). Allowed moves: see allowed_statuses in the incident detail."""
    return await service.change_status(session, user, incident_id, data)


@router.post("/{incident_id}/close", response_model=IncidentDetail)
async def close_incident(incident_id: UUID, session: AsyncSession = Depends(get_session),
                         user: CurrentUser = Depends(writer)):
    return await service.close_incident(session, user, incident_id)

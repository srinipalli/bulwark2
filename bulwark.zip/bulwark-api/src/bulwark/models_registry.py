"""Import every model module so SQLAlchemy can resolve all relationships / FKs."""
from bulwark.modules.approvals import models as _a  # noqa: F401
from bulwark.modules.execution import models as _e  # noqa: F401
from bulwark.modules.incident import models as _i  # noqa: F401
from bulwark.modules.solution import models as _s  # noqa: F401
from bulwark.modules.vulnerabilities import models as _v  # noqa: F401
from bulwark.shared import models as _shared  # noqa: F401

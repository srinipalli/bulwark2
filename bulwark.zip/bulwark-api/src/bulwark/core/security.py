from uuid import UUID

from fastapi import Depends
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from jose import JWTError, jwt
from pydantic import BaseModel
from sqlalchemy.dialects.postgresql import insert
from sqlalchemy.ext.asyncio import AsyncSession

from bulwark.core.config import get_settings
from bulwark.core.db import get_session
from bulwark.core.errors import AppError, Forbidden
from bulwark.shared.models import User

ADMIN, ANALYST, APPROVER, OPERATOR, VIEWER = "ADMIN", "ANALYST", "APPROVER", "OPERATOR", "VIEWER"
# Roles that pass every role check. APPROVER is included for now so approvers can do every operation;
# rules that are not role checks still apply (e.g. nobody approves their own incident).
FULL_ACCESS = {ADMIN, APPROVER}
bearer = HTTPBearer(auto_error=False)


class CurrentUser(BaseModel):
    id: UUID
    email: str
    name: str
    roles: set[str]

    def has_any(self, *roles: str) -> bool:
        return bool(self.roles & FULL_ACCESS) or bool(self.roles & set(roles))


class Unauthorized(AppError):
    status_code, code = 401, "unauthorized"


def decode_token(token: str) -> CurrentUser:
    s = get_settings()
    try:
        claims = jwt.decode(token, s.jwt_secret, algorithms=[s.jwt_algorithm], options={"verify_aud": False})
        return CurrentUser(id=UUID(claims["sub"]), email=claims["email"], name=claims.get("name", claims["email"]),
                           roles=set(claims.get("roles", [])))
    except (JWTError, KeyError, ValueError) as e:
        raise Unauthorized("Invalid or missing token") from e


async def get_current_user(creds: HTTPAuthorizationCredentials | None = Depends(bearer),
                           session: AsyncSession = Depends(get_session)) -> CurrentUser:
    if creds is None:
        raise Unauthorized("Missing bearer token")
    user = decode_token(creds.credentials)
    # keep a local users row so created_by / approver foreign keys always resolve
    await session.execute(
        insert(User).values(id=user.id, email=user.email, full_name=user.name, roles=sorted(user.roles))
        .on_conflict_do_update(index_elements=[User.id], set_={"full_name": user.name, "roles": sorted(user.roles)}))
    await session.commit()
    return user


def require_roles(*roles: str):
    async def dep(user: CurrentUser = Depends(get_current_user)) -> CurrentUser:
        if not user.has_any(*roles):
            raise Forbidden(f"Requires one of roles: {', '.join(roles)}")
        return user
    return dep

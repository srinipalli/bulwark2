from functools import lru_cache
from pathlib import Path

from pydantic import SecretStr
from pydantic_settings import BaseSettings, SettingsConfigDict

ROOT = Path(__file__).resolve().parents[3]                  # bulwark-api/
ENV_FILE = ROOT / ".env"                                    # bulwark-api/.env, whatever the working directory


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=ENV_FILE, extra="ignore")

    app_env: str = "local"
    database_url: str = "postgresql+asyncpg://bulwark:bulwark@localhost:5432/bulwark"
    jwt_secret: str = "change-me"
    jwt_algorithm: str = "HS256"
    cors_origins: list[str] = []
    worker_poll_seconds: float = 2.0
    stale_run_grace_seconds: int = 300
    simulate_executors: bool = True

    # Kafka (same settings as bulwark-scan-ingestor). Empty bootstrap servers = events are not published.
    kafka_bootstrap_servers: str = ""
    kafka_security_protocol: str = "PLAINTEXT"      # PLAINTEXT | SSL | SASL_PLAINTEXT | SASL_SSL
    kafka_sasl_mechanism: str = "SCRAM-SHA-256"     # PLAIN | SCRAM-SHA-256 | SCRAM-SHA-512
    kafka_sasl_username: str = ""
    kafka_sasl_password: SecretStr = SecretStr("")
    kafka_ssl_ca_file: str = ""                     # relative paths are resolved against bulwark-api/
    kafka_client_id: str = "bulwark-api"
    kafka_topic_incidents: str = "bulwark.incidents"
    kafka_delivery_timeout_ms: int = 30000
    kafka_socket_timeout_ms: int = 15000


@lru_cache
def get_settings() -> Settings:
    return Settings()

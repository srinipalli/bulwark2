from pathlib import Path


def schema_statements(path: Path) -> list[str]:
    """Split sql/schema.sql into single statements (file has no functions / dollar quoting)."""
    lines = [ln for ln in path.read_text().splitlines() if not ln.strip().startswith("--")]
    text = "\n".join(ln.split("--")[0] if "--" in ln else ln for ln in lines)
    return [s.strip() for s in text.split(";") if s.strip()]

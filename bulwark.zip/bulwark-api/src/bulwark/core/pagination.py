from typing import Generic, TypeVar

from fastapi import Query
from pydantic import BaseModel
from sqlalchemy import Select, func, select
from sqlalchemy.ext.asyncio import AsyncSession

T = TypeVar("T")


class PageParams:
    def __init__(self, page: int = Query(1, ge=1), size: int = Query(25, ge=1, le=100)):
        self.page, self.size = page, size

    @property
    def offset(self) -> int:
        return (self.page - 1) * self.size


class Page(BaseModel, Generic[T]):
    items: list[T]
    total: int
    page: int
    size: int


async def count_rows(session: AsyncSession, stmt: Select) -> int:
    return (await session.execute(select(func.count()).select_from(stmt.order_by(None).subquery()))).scalar_one()

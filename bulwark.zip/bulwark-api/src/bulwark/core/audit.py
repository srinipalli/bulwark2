from typing import Any
from uuid import UUID

from sqlalchemy.ext.asyncio import AsyncSession

from bulwark.shared.models import AuditLog


def audit(session: AsyncSession, actor_id: UUID | None, action: str, entity_type: str, entity_id: Any,
          before: dict | None = None, after: dict | None = None) -> None:
    """Append-only audit trail. Added to the caller's transaction."""
    session.add(AuditLog(actor_id=actor_id, action=action, entity_type=entity_type,
                         entity_id=str(entity_id), before=before, after=after))

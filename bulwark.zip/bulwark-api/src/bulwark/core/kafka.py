"""Kafka producer for domain events. Client settings mirror bulwark-scan-ingestor's KafkaPublisher.

Publishing is disabled (events are only logged) while KAFKA_BOOTSTRAP_SERVERS is empty, so the API runs without a broker.
"""
import asyncio
import json
import logging
from pathlib import Path

from bulwark.core.config import ROOT, get_settings

log = logging.getLogger("bulwark.kafka")


class PublishError(Exception):
    pass


class EventPublisher:
    def __init__(self):
        self._p = None

    @property
    def enabled(self) -> bool:
        return bool(get_settings().kafka_bootstrap_servers)

    def _producer(self):
        if self._p is None:
            from confluent_kafka import Producer  # imported lazily: not needed while publishing is disabled

            s = get_settings()
            cfg = {
                "bootstrap.servers": s.kafka_bootstrap_servers, "client.id": s.kafka_client_id,
                "security.protocol": s.kafka_security_protocol, "enable.idempotence": True, "acks": "all",
                "compression.type": "lz4", "linger.ms": 5, "delivery.timeout.ms": s.kafka_delivery_timeout_ms,
                "socket.timeout.ms": s.kafka_socket_timeout_ms, "error_cb": lambda e: log.error("kafka client error: %s", e),
            }
            if "SASL" in s.kafka_security_protocol:
                cfg.update({"sasl.mechanisms": s.kafka_sasl_mechanism, "sasl.username": s.kafka_sasl_username,
                            "sasl.password": s.kafka_sasl_password.get_secret_value()})
            if s.kafka_ssl_ca_file:
                ca = Path(s.kafka_ssl_ca_file)
                ca = ca if ca.is_absolute() else ROOT / ca
                if not ca.is_file():
                    raise PublishError(f"KAFKA_SSL_CA_FILE not found: {ca}")
                cfg["ssl.ca.location"] = str(ca)
            self._p = Producer(cfg)
        return self._p

    async def publish(self, topic: str, key: str, value: dict, headers: dict[str, str]) -> None:
        """Send one JSON message and wait for the broker acknowledgement (acks=all). Raises PublishError on failure."""
        if not self.enabled:
            log.info("kafka disabled, not publishing %s %s", headers.get("event_type"), key)
            return
        p = self._producer()
        outcome: dict = {}

        def on_delivery(err, _msg):
            outcome["err"] = err

        body = json.dumps(value, ensure_ascii=False, separators=(",", ":"), default=str).encode("utf-8")
        while True:
            try:
                p.produce(topic, key=key.encode(), value=body, headers=[(k, v.encode()) for k, v in headers.items()],
                          on_delivery=on_delivery)
                break
            except BufferError:                       # local queue full: let deliveries drain, then retry
                await asyncio.to_thread(p.poll, 0.5)
        await asyncio.to_thread(p.flush, get_settings().kafka_delivery_timeout_ms / 1000 + 5)
        if "err" not in outcome:
            raise PublishError("timed out waiting for the broker acknowledgement")
        if outcome["err"] is not None:
            raise PublishError(str(outcome["err"]))

    def close(self) -> None:
        if self._p is not None:
            self._p.flush(10)


publisher = EventPublisher()

import logging

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from sqlalchemy.exc import IntegrityError

log = logging.getLogger(__name__)


class AppError(Exception):
    status_code = 400
    code = "bad_request"

    def __init__(self, message: str, code: str | None = None):
        self.message = message
        if code:
            self.code = code
        super().__init__(message)


class NotFound(AppError):
    status_code, code = 404, "not_found"


class Conflict(AppError):
    status_code, code = 409, "conflict"


class Forbidden(AppError):
    status_code, code = 403, "forbidden"


class Unprocessable(AppError):
    status_code, code = 422, "unprocessable"


def install_error_handlers(app: FastAPI) -> None:
    @app.exception_handler(AppError)
    async def _app_error(_: Request, exc: AppError):
        return JSONResponse(status_code=exc.status_code, content={"error": {"code": exc.code, "message": exc.message}})

    # A database rule the service did not check first. Answer with JSON here: an unhandled 500 skips the CORS
    # middleware, so the browser would only report "cannot reach the API".
    @app.exception_handler(IntegrityError)
    async def _integrity_error(_: Request, exc: IntegrityError):
        rule = getattr(exc.orig, "constraint_name", None) or getattr(getattr(exc.orig, "__cause__", None), "constraint_name", None)
        log.warning("integrity error: %s", exc.orig)
        return JSONResponse(status_code=409, content={"error": {"code": "constraint_violation",
                            "message": f"The change breaks a database rule{f' ({rule})' if rule else ''}."}})

"""Seed demo assets and a couple of vulnerabilities:  python scripts/seed.py"""
import asyncio
import sys

sys.path.insert(0, "src")
import bulwark.models_registry  # noqa: E402,F401
from sqlalchemy import select  # noqa: E402

from bulwark.core.db import SessionLocal  # noqa: E402
from bulwark.modules.vulnerabilities.models import Vulnerability  # noqa: E402
from bulwark.shared.models import Asset  # noqa: E402

ASSETS = [("app-srv-01", "SYSTEM", "prod"), ("app-srv-02", "SYSTEM", "prod"), ("app-srv-03", "SYSTEM", "stage"),
          ("db-srv-01", "SYSTEM", "prod"), ("web-srv-07", "SYSTEM", "prod"), ("Billing API", "APPLICATION", "prod")]


async def main():
    async with SessionLocal() as s:
        existing = {a.name: a for a in (await s.execute(select(Asset))).scalars()}
        for n, t, e in ASSETS:
            if n not in existing:
                s.add(Asset(name=n, asset_type=t, environment=e))
        await s.flush()
        assets = {a.name: a for a in (await s.execute(select(Asset))).scalars()}
        if not (await s.execute(select(Vulnerability.id).limit(1))).first():
            v = Vulnerability(cve_id="CVE-2026-1187", title="OpenSSL heap overflow", severity="CRITICAL", cvss_score=9.1,
                              source="NVD", description="Heap overflow in X.509 parsing; remote code execution possible.")
            v.assets = [assets["app-srv-01"], assets["app-srv-02"], assets["db-srv-01"]]
            s.add(v)
        await s.commit()
    print("seeded")


asyncio.run(main())

"""Mint a JWT for local development:  python scripts/dev_token.py ravi ANALYST OPERATOR
Roles: ADMIN ANALYST APPROVER OPERATOR VIEWER. In production tokens come from your identity provider
(claims: sub=<uuid>, email, name, roles=[...]) signed with the same secret/algorithm configured here."""
import sys
import uuid

from jose import jwt

sys.path.insert(0, "src")
from bulwark.core.config import get_settings  # noqa: E402

name, roles = sys.argv[1], sys.argv[2:] or ["VIEWER"]
s = get_settings()
print(jwt.encode({"sub": str(uuid.uuid5(uuid.NAMESPACE_DNS, name)), "email": f"{name}@example.com",
                  "name": name.replace(".", " ").title(), "roles": roles}, s.jwt_secret, algorithm=s.jwt_algorithm))

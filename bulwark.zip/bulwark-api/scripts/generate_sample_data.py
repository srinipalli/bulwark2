"""Generate sql/02_sample_data.sql - realistic, internally consistent sample data (>= 50 rows per table).

    python scripts/generate_sample_data.py > sql/02_sample_data.sql

Deterministic (fixed seed + fixed 'now'), so re-running gives the same file.  Users are created with the same
id/email scheme as scripts/dev_token.py (uuid5(NAMESPACE_DNS, '<first.last>'), '<first.last>@example.com'), so
    python scripts/dev_token.py priya.nair APPROVER
logs in as a seeded user instead of creating a new one.
"""
import hashlib
import json
import random
import sys
import uuid
from datetime import datetime, timedelta, timezone

rnd = random.Random(20261023)
NOW = datetime(2026, 10, 23, 6, 0, 0, tzinfo=timezone.utc)
UTC = timezone.utc


def D(s, h=9, m=0):                       # date string -> aware datetime
    y, mo, d = map(int, s.split("-"))
    return datetime(y, mo, d, h, m, tzinfo=UTC)


def uid(*parts):
    return str(uuid.uuid5(uuid.NAMESPACE_URL, "bulwark-sample/" + "/".join(str(p) for p in parts)))


def hexid(seed, n=17):
    return hashlib.md5(seed.encode()).hexdigest()[:n]


def mins(a, b):
    return timedelta(minutes=rnd.randint(a, b))


# ------------------------------------------------------------------ SQL helpers
class Arr(list):
    pass


def lit(v):
    if v is None:
        return "NULL"
    if isinstance(v, bool):
        return "TRUE" if v else "FALSE"
    if isinstance(v, (int, float)):
        return repr(v)
    if isinstance(v, datetime):
        return "'" + v.astimezone(UTC).strftime("%Y-%m-%d %H:%M:%S+00") + "'"
    if isinstance(v, Arr):
        return "ARRAY[" + ",".join(lit(x) for x in v) + "]::text[]" if v else "'{}'::text[]"
    if isinstance(v, (dict, list)):
        return "'" + json.dumps(v, ensure_ascii=False).replace("'", "''") + "'::jsonb"
    return "'" + str(v).replace("'", "''") + "'"


OUT = []
COUNTS = {}


def emit(table, cols, rows, chunk=40):
    COUNTS[table] = COUNTS.get(table, 0) + len(rows)
    OUT.append(f"\n-- {table}: {len(rows)} rows")
    for i in range(0, len(rows), chunk):
        part = rows[i:i + chunk]
        body = ",\n".join("  (" + ", ".join(lit(r[c]) for c in cols) + ")" for r in part)
        OUT.append(f"INSERT INTO {table} ({', '.join(cols)}) VALUES\n{body};")


# ------------------------------------------------------------------ users (52)
FIRST = ["Aarav", "Priya", "Rohan", "Ananya", "Vikram", "Sneha", "Karthik", "Meera", "Arjun", "Divya", "Rahul", "Kavya", "Suresh",
         "Lakshmi", "Imran", "Fatima", "Daniel", "Sarah", "Michael", "Emily", "Wei", "Mei", "Carlos", "Elena", "Omar", "Hannah"]
LAST = ["Sharma", "Nair", "Reddy", "Iyer", "Patel", "Menon", "Gupta", "Rao", "Kulkarni", "Singh", "Desai", "Pillai", "Khan", "Joshi",
        "Banerjee", "Mehta", "Chandra", "Verma", "Krishnan", "Bose", "Shetty", "Naidu", "Thomas", "Fernandes", "Murthy", "Das"]
pairs = [(FIRST[i], LAST[(i * 7 + 3) % 26]) for i in range(26)] + [(FIRST[i], LAST[(i * 5 + 12) % 26]) for i in range(26)]
assert len({f + l for f, l in pairs}) == 52
users = []
for i, (f, l) in enumerate(pairs):
    slug = f"{f.lower()}.{l.lower()}"
    roles = ["VIEWER"]
    if i < 3: roles = ["ADMIN"]
    elif i < 15: roles = ["APPROVER"] + (["ANALYST"] if i < 6 else [])
    elif i < 31: roles = ["ANALYST"] + (["OPERATOR"] if i < 21 else [])
    elif i < 45: roles = ["OPERATOR"]
    users.append(dict(id=str(uuid.uuid5(uuid.NAMESPACE_DNS, slug)), email=f"{slug}@example.com", full_name=f"{f} {l}", roles=Arr(roles),
                      is_active=i < 50, created_at=D("2026-05-12", 9, i), updated_at=D("2026-05-12", 9, i)))
approvers = [u for u in users if "APPROVER" in u["roles"]]
analysts = [u for u in users if "ANALYST" in u["roles"]]
operators = [u for u in users if "OPERATOR" in u["roles"]]
admins = [u for u in users if "ADMIN" in u["roles"]]
UBYID = {u["id"]: u for u in users}


def approver_other_than(*ids):
    pool = [u for u in approvers if u["id"] not in ids]
    return rnd.choice(pool)


# ------------------------------------------------------------------ assets
assets = []


def add_asset(name, typ, env, os_name, os_ver, team, tags, attrs, host=True):
    a = dict(id=uid("asset", name), name=name, asset_type=typ, environment=env,
             hostname=(f"{name}.corp.example.com" if typ == "SYSTEM" else f"{name}.apps.example.com") if host else None,
             os_name=os_name, os_version=os_ver, owner_team=team, tags=set(tags.split(",")), attributes=attrs, is_active=True,
             created_at=D("2026-05-20", 10, len(assets) % 50), updated_at=D("2026-05-20", 10, len(assets) % 50))
    assets.append(a)


def ip(n):
    return f"10.{20 + n // 250}.{(n * 7) % 250}.{10 + n % 200}"


LIN = "linux,openssl,openssh,sudo,kernel,curl"
n = 0
for i in range(1, 7):
    n += 1
    add_asset(f"web-prod-{i:02d}", "SYSTEM", "prod", "Ubuntu", "22.04.4 LTS", "Platform Engineering",
              LIN + (",nginx,http2" if i <= 4 else ",httpd,php,http2"),
              {"ip": ip(n), "cloud": "aws", "region": "ap-south-1", "instance_id": "i-0" + hexid(f"web{i}"), "internet_facing": True, "criticality": "high"})
for i in range(1, 3):
    n += 1
    add_asset(f"web-uat-{i:02d}", "SYSTEM", "uat", "Ubuntu", "22.04.4 LTS", "Platform Engineering", LIN + ",nginx,http2",
              {"ip": ip(n), "cloud": "aws", "region": "ap-south-1", "instance_id": "i-0" + hexid(f"webu{i}"), "internet_facing": False, "criticality": "low"})
for i in range(1, 7):
    n += 1
    add_asset(f"app-prod-{i:02d}", "SYSTEM", "prod", "Red Hat Enterprise Linux", "8.9", "Application Support",
              LIN + ",java,tomcat" + (",struts" if i in (3, 4, 5) else ""),
              {"ip": ip(n), "cloud": "aws", "region": "ap-south-1", "instance_id": "i-0" + hexid(f"app{i}"), "runtime": "OpenJDK 11.0.22", "criticality": "high"})
for i in range(1, 3):
    n += 1
    add_asset(f"app-uat-{i:02d}", "SYSTEM", "uat", "Red Hat Enterprise Linux", "8.9", "Application Support", LIN + ",java,tomcat,struts",
              {"ip": ip(n), "cloud": "aws", "region": "ap-south-1", "instance_id": "i-0" + hexid(f"appu{i}"), "runtime": "OpenJDK 11.0.22", "criticality": "low"})
for i in range(1, 5):
    n += 1
    add_asset(f"db-prod-{i:02d}", "SYSTEM", "prod" if i < 4 else "dr", "Red Hat Enterprise Linux", "9.3", "Database Operations", LIN + ",postgres",
              {"ip": ip(n), "cloud": "aws", "region": "ap-south-1" if i < 4 else "ap-southeast-1", "instance_id": "i-0" + hexid(f"db{i}"), "engine": "PostgreSQL 15.6", "criticality": "critical"})
for i in range(1, 4):
    n += 1
    add_asset(f"build-dev-{i:02d}", "SYSTEM", "dev", "Fedora Linux", "40", "DevOps", "linux,xz,openssh,openssl,curl",
              {"ip": ip(n), "cloud": "on-prem", "role": "build agent", "criticality": "low"})
for i in range(1, 4):
    n += 1
    add_asset(f"ad-dc-{i:02d}", "SYSTEM", "prod" if i < 3 else "dr", "Windows Server", "2019 Datacenter", "Identity & Access", "windows,ad,print,smb",
              {"ip": ip(n), "cloud": "on-prem", "site": ["Mumbai", "Mumbai", "Chennai"][i - 1], "criticality": "critical"})
for i in range(1, 3):
    n += 1
    add_asset(f"exch-{i:02d}", "SYSTEM", "prod", "Windows Server", "2016 Standard", "Messaging", "windows,exchange,smb",
              {"ip": ip(n), "cloud": "on-prem", "product": "Exchange Server 2019 CU12", "internet_facing": True, "criticality": "high"})
for i in range(1, 5):
    n += 1
    add_asset(f"file-win-{i:02d}", "SYSTEM", "prod", "Windows Server", "2019 Standard", "End User Computing", "windows,smb,print,rdp",
              {"ip": ip(n), "cloud": "on-prem", "criticality": "medium"})
for i in range(1, 3):
    n += 1
    add_asset(f"legacy-win-{i:02d}", "SYSTEM", "dr", "Windows Server", "2008 R2 SP1", "End User Computing", "windows,rdp,smb",
              {"ip": ip(n), "cloud": "on-prem", "note": "scheduled for decommission FY27", "criticality": "low"})
NET = [("fw-fortigate", 4, "FortiGate 100F", "FortiOS", "7.0.12", "fortinet", "Network Security"),
       ("lb-f5", 3, "BIG-IP i5800", "BIG-IP TMOS", "15.1.8", "f5", "Network Engineering"),
       ("citrix-adc", 2, "NetScaler MPX 8200", "NetScaler ADC", "13.0-91.13", "citrix", "Network Engineering"),
       ("pa-fw", 2, "PA-3220", "PAN-OS", "10.2.7", "paloalto", "Network Security"),
       ("cisco-edge", 2, "Catalyst 9300", "Cisco IOS XE", "17.6.4", "cisco", "Network Engineering"),
       ("vpn-pulse", 2, "Pulse Secure PSA7000", "Pulse Connect Secure", "9.1R4", "pulse", "Network Security")]
for base, cnt, model, osn, osv, tag, team in NET:
    for i in range(1, cnt + 1):
        n += 1
        add_asset(f"{base}-{i:02d}", "SYSTEM", "prod" if i == 1 else ("dr" if i == cnt and cnt > 2 else "prod"), osn, osv, team, tag,
                  {"ip": ip(n), "model": model, "serial": hexid(base + str(i), 10).upper(), "criticality": "critical"})
TOOLS = [("jenkins-prod-01", "prod", "Jenkins", "2.426.2", "jenkins", "DevOps"), ("jenkins-uat-01", "uat", "Jenkins", "2.426.2", "jenkins", "DevOps"),
         ("gitlab-prod-01", "prod", "GitLab CE", "13.9.4", "gitlab", "DevOps"), ("gitlab-uat-01", "uat", "GitLab CE", "13.9.4", "gitlab", "DevOps"),
         ("teamcity-01", "prod", "TeamCity", "2023.05.2", "teamcity", "DevOps"), ("teamcity-02", "uat", "TeamCity", "2023.05.2", "teamcity", "DevOps"),
         ("confluence-prod-01", "prod", "Confluence Data Center", "8.4.1", "confluence", "Collaboration"),
         ("confluence-uat-01", "uat", "Confluence Data Center", "8.4.1", "confluence", "Collaboration"),
         ("moveit-prod-01", "prod", "MOVEit Transfer", "2022.1.5", "moveit", "Integration"), ("moveit-dr-01", "dr", "MOVEit Transfer", "2022.1.5", "moveit", "Integration"),
         ("barracuda-esg-01", "prod", "Barracuda ESG 900", "9.2.1", "barracuda", "Messaging"), ("barracuda-esg-02", "dr", "Barracuda ESG 900", "9.2.1", "barracuda", "Messaging")]
for nm, env, prod, ver, tag, team in TOOLS:
    n += 1
    add_asset(nm, "SYSTEM", env, "Ubuntu" if tag in ("jenkins", "gitlab", "teamcity", "confluence") else "Appliance", "20.04.6 LTS" if tag in ("jenkins", "gitlab", "teamcity", "confluence") else ver,
              team, tag + (",linux,openssl,openssh,sudo,kernel,curl" if tag in ("jenkins", "gitlab", "teamcity", "confluence") else ""),
              {"ip": ip(n), "product": prod, "product_version": ver, "criticality": "high" if env == "prod" else "low"})
APPS = [("payments-api", "prod", "java,log4j,spring,text4shell", "Payments", {"runtime": "Java 11", "framework": "Spring Boot 2.5.8", "log4j": "2.14.1", "commons-text": "1.9"}),
        ("payments-api-uat", "uat", "java,log4j,spring,text4shell", "Payments", {"runtime": "Java 11", "framework": "Spring Boot 2.5.8", "log4j": "2.14.1"}),
        ("claims-service", "prod", "java,log4j,spring", "Claims", {"runtime": "Java 8", "framework": "Spring Framework 5.3.15", "log4j": "2.13.3"}),
        ("claims-service-uat", "uat", "java,log4j,spring", "Claims", {"runtime": "Java 8", "framework": "Spring Framework 5.3.15"}),
        ("policy-engine", "prod", "java,log4j,text4shell", "Underwriting", {"runtime": "Java 11", "log4j": "2.15.0", "commons-text": "1.8"}),
        ("ledger-service", "prod", "java,spring", "Finance Systems", {"runtime": "Java 17", "framework": "Spring Cloud Gateway 3.1.0"}),
        ("auth-gateway", "prod", "java,spring", "Identity & Access", {"runtime": "Java 17", "framework": "Spring Cloud Function 3.2.2"}),
        ("notification-svc", "prod", "java,log4j", "Platform Engineering", {"runtime": "Java 11", "log4j": "2.14.0"}),
        ("reporting-svc", "prod", "java,log4j,text4shell", "Data & Analytics", {"runtime": "Java 11", "log4j": "2.16.0", "commons-text": "1.9"}),
        ("document-service", "prod", "java,spring,text4shell", "Claims", {"runtime": "Java 11", "framework": "Spring Framework 5.3.17", "commons-text": "1.9"}),
        ("partner-api-gateway", "prod", "java,spring", "Integration", {"runtime": "Java 17", "framework": "Spring Cloud Gateway 3.1.1"}),
        ("customer-portal", "prod", "node,libwebp", "Digital Channels", {"runtime": "Node 18.17", "package": "sharp 0.32.4 (libwebp 1.3.1)"}),
        ("customer-portal-uat", "uat", "node,libwebp", "Digital Channels", {"runtime": "Node 18.17", "package": "sharp 0.32.4"}),
        ("mobile-bff", "prod", "node,libwebp", "Digital Channels", {"runtime": "Node 18.17", "package": "sharp 0.32.4"}),
        ("admin-console", "prod", "node,libwebp", "Digital Channels", {"runtime": "Node 20.5", "package": "electron 25.3 (libwebp)"})]
for nm, env, tags, team, at in APPS:
    add_asset(nm, "APPLICATION", env, None, None, team, tags, dict(at, criticality="high" if env == "prod" else "low", deployment="kubernetes" if "java" in tags else "ecs-fargate"))
ABYID = {a["id"]: a for a in assets}

# ------------------------------------------------------------------ vulnerabilities (60)
V = [  # cve, title, cvss, tag, published, description
    ("CVE-2021-44228", "Apache Log4j2 JNDI remote code execution (Log4Shell)", 10.0, "log4j", "2021-12-10", "JNDI features in Log4j2 2.0-beta9 to 2.14.1 do not protect against attacker-controlled LDAP and other JNDI endpoints, allowing unauthenticated remote code execution via crafted log messages."),
    ("CVE-2021-45046", "Apache Log4j2 incomplete fix for Log4Shell in non-default configurations", 9.0, "log4j", "2021-12-14", "The fix for CVE-2021-44228 was incomplete in certain non-default Pattern Layout configurations, allowing information leak and remote code execution in some environments."),
    ("CVE-2022-22965", "Spring Framework RCE via data binding on JDK 9+ (Spring4Shell)", 9.8, "spring", "2022-04-01", "A Spring MVC or WebFlux application running on JDK 9+ may be vulnerable to remote code execution through data binding when deployed as a WAR on Tomcat."),
    ("CVE-2022-22963", "Spring Cloud Function SpEL expression injection", 9.8, "spring", "2022-04-01", "In Spring Cloud Function 3.1.6, 3.2.2 and older, a crafted spring.cloud.function.routing-expression header allows remote code execution."),
    ("CVE-2022-22947", "Spring Cloud Gateway code injection via actuator endpoint", 10.0, "spring", "2022-03-03", "Applications using Spring Cloud Gateway with the Gateway Actuator endpoint enabled and exposed are vulnerable to code injection through crafted routes."),
    ("CVE-2022-42889", "Apache Commons Text variable interpolation RCE (Text4Shell)", 9.8, "text4shell", "2022-10-13", "Apache Commons Text 1.5 through 1.9 perform variable interpolation, including script, dns and url lookups, which can lead to arbitrary code execution when untrusted input is interpolated."),
    ("CVE-2017-5638", "Apache Struts 2 Jakarta Multipart parser RCE", 10.0, "struts", "2017-03-11", "A crafted Content-Type header is evaluated as an OGNL expression by the Jakarta Multipart parser, allowing remote command execution."),
    ("CVE-2018-11776", "Apache Struts 2 namespace OGNL remote code execution", 9.8, "struts", "2018-08-22", "Struts 2 can execute attacker-supplied OGNL when no namespace is set for results or an action chain with wildcard namespaces is used."),
    ("CVE-2017-9805", "Apache Struts 2 REST plugin XStream deserialization RCE", 8.1, "struts", "2017-09-15", "The REST plugin uses XStreamHandler to deserialize XML payloads without type filtering, allowing remote code execution via crafted XML."),
    ("CVE-2014-0160", "OpenSSL TLS heartbeat information disclosure (Heartbleed)", 7.5, "openssl", "2014-04-07", "The TLS heartbeat extension in OpenSSL 1.0.1 before 1.0.1g lacks a bounds check, allowing remote attackers to read process memory including private keys."),
    ("CVE-2022-0778", "OpenSSL BN_mod_sqrt infinite loop denial of service", 7.5, "openssl", "2022-03-15", "Parsing a certificate with invalid explicit elliptic-curve parameters can cause an infinite loop in BN_mod_sqrt(), leading to denial of service."),
    ("CVE-2022-3602", "OpenSSL X.509 email address buffer overrun", 7.5, "openssl", "2022-11-01", "A buffer overrun in X.509 certificate verification of name constraints can be triggered by a malicious email address in OpenSSL 3.0.0-3.0.6."),
    ("CVE-2023-0286", "OpenSSL X.400 address type confusion", 7.4, "openssl", "2023-02-08", "A type confusion in X.400 address processing inside a GeneralName can allow reading memory contents or causing denial of service."),
    ("CVE-2024-6387", "OpenSSH sshd signal handler race condition (regreSSHion)", 8.1, "openssh", "2024-07-01", "A race condition in the sshd signal handler on glibc-based Linux can allow unauthenticated remote code execution as root."),
    ("CVE-2023-48795", "SSH prefix truncation attack (Terrapin)", 5.9, "openssh", "2023-12-18", "The SSH transport protocol with certain OpenSSH ciphers and ETM allows a man-in-the-middle to delete handshake messages and downgrade connection security."),
    ("CVE-2023-38408", "OpenSSH ssh-agent PKCS#11 provider code execution", 9.8, "openssh", "2023-07-20", "The PKCS#11 feature in ssh-agent before OpenSSH 9.3p2 has an insufficiently trustworthy search path, leading to remote code execution if an agent is forwarded to an attacker-controlled system."),
    ("CVE-2021-3156", "sudo heap-based buffer overflow (Baron Samedit)", 7.8, "sudo", "2021-01-26", "A heap overflow in sudoedit -s allows any local user to gain root privileges without authentication in sudo before 1.9.5p2."),
    ("CVE-2021-4034", "polkit pkexec local privilege escalation (PwnKit)", 7.8, "linux", "2022-01-28", "pkexec fails to handle an empty argument vector, allowing an unprivileged local user to gain root by exploiting out-of-bounds read and write."),
    ("CVE-2022-0847", "Linux kernel pipe buffer flag overwrite (Dirty Pipe)", 7.8, "kernel", "2022-03-10", "A flaw in the Linux kernel pipe buffer handling allows an unprivileged user to overwrite data in read-only files and escalate privileges."),
    ("CVE-2016-5195", "Linux kernel copy-on-write race condition (Dirty COW)", 7.0, "kernel", "2016-11-10", "A race condition in the way the Linux kernel handles copy-on-write breakage of private read-only memory mappings allows local privilege escalation."),
    ("CVE-2023-4911", "glibc dynamic loader buffer overflow (Looney Tunables)", 7.8, "linux", "2023-10-03", "A buffer overflow in ld.so's processing of the GLIBC_TUNABLES environment variable allows local privilege escalation to root."),
    ("CVE-2024-1086", "Linux kernel nf_tables use-after-free privilege escalation", 7.8, "kernel", "2024-01-31", "A use-after-free in the netfilter nf_tables component allows a local attacker to gain root privileges."),
    ("CVE-2023-38545", "curl SOCKS5 proxy handshake heap buffer overflow", 9.8, "curl", "2023-10-18", "A heap overflow in curl before 8.4.0 when the SOCKS5 proxy handshake is slow and a long hostname is passed to the proxy."),
    ("CVE-2014-6271", "GNU Bash environment variable command injection (Shellshock)", 9.8, "linux", "2014-09-24", "GNU Bash through 4.3 processes trailing strings after function definitions in environment variables, allowing remote code execution through CGI and other vectors."),
    ("CVE-2024-3094", "XZ Utils liblzma supply-chain backdoor", 10.0, "xz", "2024-03-29", "Malicious code in xz/liblzma 5.6.0 and 5.6.1 release tarballs modifies sshd authentication behaviour through the systemd linkage."),
    ("CVE-2023-44487", "HTTP/2 Rapid Reset denial of service", 7.5, "http2", "2023-10-10", "Clients can abuse HTTP/2 stream cancellation to cause excessive server resource consumption, resulting in a distributed denial of service."),
    ("CVE-2021-41773", "Apache HTTP Server 2.4.49 path traversal and file disclosure", 7.5, "httpd", "2021-10-05", "A path normalization change in Apache HTTP Server 2.4.49 allows path traversal to files outside the document root."),
    ("CVE-2021-42013", "Apache HTTP Server 2.4.49/2.4.50 path traversal and remote code execution", 9.8, "httpd", "2021-10-07", "The fix for CVE-2021-41773 was insufficient; with mod_cgi enabled, path traversal can lead to remote code execution."),
    ("CVE-2024-4577", "PHP-CGI argument injection on Windows locales", 9.8, "php", "2024-06-09", "Best-fit character conversion in PHP-CGI allows argument injection that can lead to source disclosure and remote code execution."),
    ("CVE-2017-0144", "Microsoft SMBv1 remote code execution (EternalBlue)", 8.1, "smb", "2017-03-16", "The SMBv1 server in Windows allows remote code execution via crafted packets; exploited at scale by WannaCry and NotPetya."),
    ("CVE-2020-1472", "Netlogon elevation of privilege (Zerologon)", 10.0, "ad", "2020-08-17", "A flaw in the Netlogon secure channel cryptography allows an unauthenticated attacker with network access to a domain controller to become domain administrator."),
    ("CVE-2021-34527", "Windows Print Spooler remote code execution (PrintNightmare)", 8.8, "print", "2021-07-02", "The Windows Print Spooler service improperly performs privileged file operations, allowing remote code execution with SYSTEM privileges."),
    ("CVE-2019-0708", "Remote Desktop Services remote code execution (BlueKeep)", 9.8, "rdp", "2019-05-16", "A pre-authentication wormable RCE in Remote Desktop Services affecting Windows 7, Server 2008 and Server 2008 R2."),
    ("CVE-2021-26855", "Microsoft Exchange Server SSRF (ProxyLogon)", 9.8, "exchange", "2021-03-02", "A server-side request forgery in Exchange allows an unauthenticated attacker to send arbitrary HTTP requests as the Exchange server; chained into RCE."),
    ("CVE-2021-34473", "Microsoft Exchange Server remote code execution (ProxyShell)", 9.8, "exchange", "2021-07-14", "Pre-authentication path confusion in Exchange Autodiscover; chained with CVE-2021-34523 and CVE-2021-31207 to achieve remote code execution."),
    ("CVE-2022-41082", "Microsoft Exchange Server RCE via PowerShell (ProxyNotShell)", 8.8, "exchange", "2022-10-03", "Authenticated attackers can achieve remote code execution through Exchange PowerShell remoting after chaining with CVE-2022-41040."),
    ("CVE-2018-13379", "Fortinet FortiOS SSL VPN path traversal", 9.8, "fortinet", "2019-06-04", "A path traversal in the FortiOS SSL VPN web portal allows unauthenticated attackers to download system files, including session files with plaintext credentials."),
    ("CVE-2022-40684", "Fortinet FortiOS and FortiProxy authentication bypass", 9.8, "fortinet", "2022-10-18", "An authentication bypass on the administrative interface using alternate path or channel allows unauthenticated administrative operations via crafted HTTP requests."),
    ("CVE-2023-27997", "Fortinet FortiOS SSL-VPN pre-authentication heap overflow", 9.8, "fortinet", "2023-06-13", "A heap-based buffer overflow in FortiOS SSL-VPN allows a remote attacker to execute arbitrary code via crafted requests."),
    ("CVE-2024-21762", "Fortinet FortiOS SSL VPN out-of-bounds write", 9.6, "fortinet", "2024-02-09", "An out-of-bounds write in sslvpnd allows a remote unauthenticated attacker to execute arbitrary code via specially crafted HTTP requests."),
    ("CVE-2022-1388", "F5 BIG-IP iControl REST authentication bypass", 9.8, "f5", "2022-05-05", "Undisclosed requests to BIG-IP iControl REST can bypass authentication and allow arbitrary command execution as root."),
    ("CVE-2023-46747", "F5 BIG-IP Configuration utility authentication bypass", 9.8, "f5", "2023-10-26", "An unauthenticated attacker with network access to the BIG-IP management port can achieve remote code execution through the Configuration utility."),
    ("CVE-2019-19781", "Citrix ADC and Gateway directory traversal", 9.8, "citrix", "2019-12-27", "A directory traversal vulnerability allows unauthenticated attackers to execute arbitrary code on Citrix ADC and Gateway appliances."),
    ("CVE-2023-3519", "Citrix ADC and Gateway unauthenticated remote code execution", 9.8, "citrix", "2023-07-19", "Unauthenticated RCE on Citrix NetScaler ADC and Gateway configured as a gateway (VPN, ICA Proxy, RDP Proxy) or AAA virtual server."),
    ("CVE-2024-3400", "Palo Alto PAN-OS GlobalProtect command injection", 10.0, "paloalto", "2024-04-12", "A command injection from arbitrary file creation in the GlobalProtect feature of PAN-OS lets an unauthenticated attacker execute code with root privileges on the firewall."),
    ("CVE-2023-20198", "Cisco IOS XE web UI privilege escalation", 10.0, "cisco", "2023-10-16", "A flaw in the web UI feature of Cisco IOS XE lets a remote unauthenticated attacker create an account with privilege level 15."),
    ("CVE-2024-23897", "Jenkins CLI arbitrary file read", 9.8, "jenkins", "2024-01-24", "Jenkins 2.441 and earlier use the args4j library, which replaces '@' followed by a file path with the file contents, allowing unauthenticated reads of arbitrary files."),
    ("CVE-2021-22205", "GitLab ExifTool image upload remote code execution", 10.0, "gitlab", "2021-04-23", "An unauthenticated attacker can achieve RCE through image parsing of crafted DjVu files uploaded to GitLab CE/EE."),
    ("CVE-2023-42793", "JetBrains TeamCity authentication bypass", 9.8, "teamcity", "2023-09-19", "In JetBrains TeamCity before 2023.05.4, authentication bypass allows remote code execution on the server."),
    ("CVE-2022-26134", "Atlassian Confluence OGNL injection", 9.8, "confluence", "2022-06-03", "An OGNL injection allows an unauthenticated attacker to execute arbitrary code on Confluence Server and Data Center."),
    ("CVE-2023-22515", "Atlassian Confluence Data Center broken access control", 10.0, "confluence", "2023-10-04", "Unauthenticated attackers can create Confluence administrator accounts and access the instance via the setup endpoints."),
    ("CVE-2023-34362", "Progress MOVEit Transfer SQL injection", 9.8, "moveit", "2023-06-02", "An SQL injection in MOVEit Transfer's web application allows an unauthenticated attacker to access the database and execute arbitrary code."),
    ("CVE-2023-2868", "Barracuda Email Security Gateway command injection", 9.8, "barracuda", "2023-05-24", "A remote command injection in the TAR file attachment scanning of Barracuda ESG 5.1.3.001 through 9.2.0.006."),
    ("CVE-2019-11510", "Pulse Connect Secure pre-authentication arbitrary file read", 10.0, "pulse", "2019-05-08", "An unauthenticated remote attacker can send a crafted URI to read arbitrary files, including cached credentials, on Pulse Connect Secure."),
    ("CVE-2023-4863", "libwebp heap buffer overflow in WebP lossless decoding", 8.8, "libwebp", "2023-09-12", "A heap overflow in the WebP image library lets a remote attacker perform an out-of-bounds memory write via a crafted WebP image."),
    ("CVE-2020-0601", "Windows CryptoAPI spoofing vulnerability (CurveBall)", 8.1, "windows", "2020-01-14", "crypt32.dll fails to validate ECC certificates properly, allowing attackers to spoof code-signing certificates and TLS trust."),
    ("CVE-2022-30190", "Microsoft Support Diagnostic Tool RCE (Follina)", 7.8, "windows", "2022-06-01", "A remote code execution vulnerability exists when MSDT is called via the URL protocol from an application such as Word."),
    ("CVE-2023-23397", "Microsoft Outlook elevation of privilege via NTLM leak", 9.8, "windows", "2023-03-14", "A crafted calendar item with a UNC path causes Outlook to leak the user's Net-NTLMv2 hash without user interaction."),
    ("CVE-2021-3449", "OpenSSL TLS renegotiation NULL pointer dereference", 5.9, "openssl", "2021-03-25", "A maliciously crafted renegotiation ClientHello message can crash an OpenSSL TLSv1.2 server."),
    ("CVE-2022-41741", "nginx ngx_http_mp4_module memory corruption", 7.8, "nginx", "2022-10-19", "A specially crafted mp4 file can cause memory corruption in the ngx_http_mp4_module worker process."),
]
assert len(V) == 60
NO_INCIDENT = {"CVE-2014-0160", "CVE-2016-5195", "CVE-2021-3449", "CVE-2022-41741"}
INACTIVE = {"CVE-2014-0160", "CVE-2016-5195", "CVE-2021-3449"}
SRC = ["NVD", "CISA KEV", "Qualys", "Tenable", "Rapid7 InsightVM", "NVD", "CISA KEV", "MANUAL"]
KEV = {"CVE-2021-44228", "CVE-2022-22965", "CVE-2022-22947", "CVE-2017-5638", "CVE-2017-0144", "CVE-2020-1472", "CVE-2021-34527", "CVE-2021-26855",
       "CVE-2018-13379", "CVE-2022-40684", "CVE-2022-1388", "CVE-2019-19781", "CVE-2023-3519", "CVE-2024-3400", "CVE-2023-20198", "CVE-2023-34362"}


def sev_of(c):
    return "CRITICAL" if c >= 9 else "HIGH" if c >= 7 else "MEDIUM" if c >= 4 else "LOW"


vulns = []
for i, (cve, title, cvss, tag, pub, desc) in enumerate(V):
    created = D("2026-06-01", 9, 0) + timedelta(hours=11 * i + rnd.randint(0, 5))
    if cve == "CVE-2022-41741":
        created = D("2026-10-21", 10, 40)
    cands = [a for a in assets if tag in a["tags"]]
    k = min(len(cands), 2 + i % 3)
    start = (i * 3) % len(cands)
    chosen = [cands[(start + j) % len(cands)] for j in range(k)]
    vulns.append(dict(id=uid("vuln", cve), cve_id=cve, title=title, description=desc, severity=sev_of(cvss), cvss_score=cvss,
                      source="CISA KEV" if cve in KEV else SRC[i % len(SRC)], published_at=D(pub, 0, 0), is_active=cve not in INACTIVE,
                      created_by=analysts[i % len(analysts)]["id"], created_at=created, updated_at=created, tag=tag, assets=chosen, idx=i))
VBY = {v["cve_id"]: v for v in vulns}
vuln_assets = [dict(vulnerability_id=v["id"], asset_id=a["id"]) for v in vulns for a in v["assets"]]

# ------------------------------------------------------------------ solutions
SOL = []   # dicts: key,title,desc,executor,risk,reboot,timeout,retries,spec,applies,vers,retired


def S(key, title, desc, executor, risk, spec, applies=None, reboot=False, timeout=1800, retries=0, vers=(), retired=False, first="APPROVED"):
    SOL.append(dict(first=first, key=key, title=title, desc=desc, executor=executor, risk=risk, spec=spec, applies=applies, reboot=reboot,
                    timeout=timeout, retries=retries, vers=list(vers), retired=retired))


PB = "playbooks/"
# generic building blocks
S("snap_aws", "Pre-patch EBS snapshot (AWS SSM Automation)", "Creates EBS snapshots of all attached volumes before any change, tagged with the incident number for rollback.", "AWS_SSM", "LOW",
  {"document": "AWS-CreateSnapshot", "parameters": {"VolumeId": ["{{volume_ids}}"], "Description": ["bulwark pre-patch {{incident_code}}"]}}, "AWS EC2 instances", timeout=900, retries=1)
S("snap_vm", "Pre-patch VM snapshot (vSphere)", "Takes a quiesced VMware snapshot before patching on-prem Windows servers; snapshot retained for 72 hours.", "ANSIBLE", "LOW",
  {"playbook": PB + "vmware/snapshot_create.yml", "inventory": "inventory/vcenter.yml", "extra_vars": {"quiesce": True, "retention_hours": 72}}, "On-prem VMware guests", timeout=900, retries=1)
S("drain_lb", "Drain node from load balancer", "Sets the F5 pool member to disabled and waits for active connections to drop to zero.", "HTTP", "LOW",
  {"method": "PATCH", "url": "https://lb-f5-01.corp.example.com/mgmt/tm/ltm/pool/~Common~{{pool}}/members/{{member}}", "body": {"session": "user-disabled"}, "expect_status": 200}, "Servers behind F5 pools", timeout=600)
S("restart_svc", "Restart application service", "Graceful restart of the application service via systemd with a 60s stop timeout, then waits for the listening port.", "SHELL", "MEDIUM",
  {"command": "systemctl restart {{service}} && timeout 120 bash -c 'until ss -ltn | grep -q :{{port}}; do sleep 2; done'", "shell": "bash", "become": True}, "Linux services", timeout=300, retries=1)
S("health_check", "Post-patch health check", "Calls the service health endpoint and fails the step if the response is not HTTP 200 with status UP within 2 minutes.", "HTTP", "LOW",
  {"method": "GET", "url": "https://{{hostname}}/actuator/health", "expect_status": 200, "expect_json": {"status": "UP"}, "retries": 6, "retry_delay_seconds": 20}, "All HTTP services", timeout=180)
S("rescan", "Post-patch vulnerability rescan (Qualys)", "Launches an authenticated Qualys scan on the asset and fails if the CVE is still detected.", "HTTP", "LOW",
  {"method": "POST", "url": "https://qualysapi.qg3.apps.qualys.com/api/2.0/fo/scan/", "params": {"action": "launch", "scan_title": "bulwark-{{incident_code}}", "ip": "{{ip}}", "option_id": "1234567"}, "poll": True}, "All assets", timeout=1800)
S("reboot", "Rolling reboot within maintenance window", "Reboots the host, waits for SSH/WinRM to return and verifies uptime; refuses to run outside the approved window.", "ANSIBLE", "HIGH",
  {"playbook": PB + "common/reboot_and_wait.yml", "extra_vars": {"reboot_timeout": 600, "enforce_window": True}}, "Linux and Windows servers", reboot=True, timeout=900, retries=1)
# java / app
S("log4j_up", "Upgrade Log4j2 to 2.17.2 across Java services", "Replaces log4j-core and log4j-api jars, removes the JndiLookup class from shaded jars, and restarts the container.", "ANSIBLE", "MEDIUM",
  {"playbook": PB + "java/upgrade_log4j.yml", "extra_vars": {"log4j_version": "2.17.1", "remove_jndilookup": True}}, "Java 8/11/17 services", timeout=1200, retries=1,
  vers=[("APPROVED", "2026-08-12", "Bump target to 2.17.2 (CVE-2021-44832 fix)", {"extra_vars": {"log4j_version": "2.17.2", "remove_jndilookup": True}})])
S("log4j_mit", "Interim mitigation: remove JndiLookup class from log4j-core", "Zips out org/apache/logging/log4j/core/lookup/JndiLookup.class and sets -Dlog4j2.formatMsgNoLookups=true until the upgrade lands.", "SHELL", "LOW",
  {"command": "find {{app_dir}} -name 'log4j-core-*.jar' -exec zip -q -d {} org/apache/logging/log4j/core/lookup/JndiLookup.class \\;", "shell": "bash", "become": True}, "Log4j 2.0-2.14.1", timeout=300, retired=True)
S("spring_fw", "Upgrade Spring Framework to 5.3.18", "Updates spring-framework BOM and redeploys the application artifact built by CI.", "ANSIBLE", "MEDIUM",
  {"playbook": PB + "java/upgrade_spring_framework.yml", "extra_vars": {"spring_framework_version": "5.3.18"}}, "Spring MVC / WebFlux apps", timeout=1500, retries=1)
S("spring_cloud", "Upgrade Spring Cloud Function and Gateway", "Upgrades spring-cloud-function to 3.2.3 and spring-cloud-gateway to 3.1.1, then disables the exposed gateway actuator endpoint.", "ANSIBLE", "MEDIUM",
  {"playbook": PB + "java/upgrade_spring_cloud.yml", "extra_vars": {"function_version": "3.2.3", "gateway_version": "3.1.1", "disable_gateway_actuator": True}}, "Spring Cloud apps", timeout=1500, retries=1,
  vers=[("REVIEW_PENDING", "2026-10-15", "Add canary deployment and automatic rollback", {"extra_vars": {"function_version": "3.2.3", "gateway_version": "3.1.2", "canary_percent": 10}})])
S("commons_text", "Upgrade Apache Commons Text to 1.10.0", "Bumps commons-text to 1.10.0 where the interpolation defaults are safe and rebuilds the service.", "ANSIBLE", "LOW",
  {"playbook": PB + "java/upgrade_dependency.yml", "extra_vars": {"group": "org.apache.commons", "artifact": "commons-text", "version": "1.10.0"}}, "Java apps", timeout=1200)
S("struts_up", "Upgrade Apache Struts to 2.5.33", "Replaces struts2-core and plugins, validates the struts.xml namespace configuration and redeploys the WAR.", "ANSIBLE", "HIGH",
  {"playbook": PB + "java/upgrade_struts.yml", "extra_vars": {"struts_version": "2.5.33"}}, "Struts 2.x web apps on Tomcat", timeout=1800, retries=1,
  vers=[("CHANGES_REQUESTED", "2026-09-02", "Add REST plugin removal", {}), ("REVIEW_PENDING", "2026-09-09", "Remove REST plugin when unused", {"extra_vars": {"struts_version": "2.5.33", "remove_rest_plugin": True}})])
S("struts_waf", "WAF virtual patch for Struts OGNL injection", "Pushes an F5 ASM signature set that blocks OGNL expressions in Content-Type and namespace parameters.", "HTTP", "LOW",
  {"method": "POST", "url": "https://lb-f5-01.corp.example.com/mgmt/tm/asm/signatures", "body": {"name": "struts-ognl-block", "mode": "blocking"}, "expect_status": 200}, "Struts apps behind F5 ASM", retired=True)
# linux
S("openssl_pkg", "Upgrade OpenSSL via OS package manager", "Applies the vendor security update for openssl/libssl using apt or dnf, then restarts services linked to libssl with needrestart.", "ANSIBLE", "MEDIUM",
  {"playbook": PB + "linux/package_security_update.yml", "extra_vars": {"packages": ["openssl", "libssl3"], "restart_dependent_services": True}}, "Ubuntu 20.04/22.04, RHEL 8/9, Fedora", timeout=1500, retries=1)
S("openssh_up", "Upgrade OpenSSH server to 9.8p1", "Installs the vendor-backported OpenSSH build, validates sshd_config with sshd -t and reloads sshd without dropping sessions.", "ANSIBLE", "MEDIUM",
  {"playbook": PB + "linux/upgrade_openssh.yml", "extra_vars": {"target_version": "9.8p1", "validate_config": True}}, "Linux servers", timeout=1200, retries=1,
  vers=[("REVIEW_PENDING", "2026-10-14", "Support Ubuntu 24.04 package names", {"extra_vars": {"target_version": "9.8p1", "validate_config": True, "supported_os": ["ubuntu-22.04", "ubuntu-24.04", "rhel-9"]}})])
S("ssh_ciphers", "Harden SSH ciphers (Terrapin mitigation)", "Disables chacha20-poly1305 and *-etm MACs in sshd_config and ssh_config until both ends support strict key exchange.", "ANSIBLE", "LOW",
  {"playbook": PB + "linux/ssh_cipher_hardening.yml", "extra_vars": {"disable_chacha": True, "disable_etm_macs": True}}, "OpenSSH 9.5 and earlier", timeout=600)
S("sudo_up", "Patch sudo to 1.9.5p2 or later", "Upgrades the sudo package and verifies the version string and /etc/sudoers syntax with visudo -c.", "AWS_SSM", "LOW",
  {"document": "AWS-RunShellScript", "parameters": {"commands": ["yum -y update sudo || apt-get -y install --only-upgrade sudo", "visudo -c"]}}, "Linux servers", timeout=600)
S("os_sec_update", "Apply OS security errata (polkit, glibc, bash)", "Installs security-classified updates only (yum --security / unattended-upgrade) and records the advisories applied.", "AWS_SSM", "MEDIUM",
  {"document": "AWS-RunPatchBaseline", "parameters": {"Operation": ["Install"], "RebootOption": ["NoReboot"]}}, "Amazon Linux, RHEL, Ubuntu", timeout=2400, retries=1)
S("kernel_up", "Kernel security update with staged reboot", "Installs the latest kernel from the vendor repo, sets it as default in GRUB and schedules a reboot in the next maintenance window.", "ANSIBLE", "HIGH",
  {"playbook": PB + "linux/kernel_update.yml", "extra_vars": {"reboot": False, "keep_previous_kernels": 2}}, "RHEL 8/9, Ubuntu LTS", timeout=2400, retries=1,
  vers=[("APPROVED", "2026-09-04", "Add livepatch where supported", {"extra_vars": {"reboot": False, "keep_previous_kernels": 2, "use_livepatch": True}}), ("CHANGES_REQUESTED", "2026-10-06", "Auto reboot for non-prod", {})])
S("curl_up", "Upgrade curl and libcurl to 8.4.0 or later", "Updates curl/libcurl packages and checks the SOCKS5 hostname handling regression test.", "SHELL", "LOW",
  {"command": "yum -y update curl libcurl || apt-get -y install --only-upgrade curl libcurl4", "shell": "bash", "become": True}, "Linux servers", timeout=600,
  vers=[("APPROVED", "2026-08-25", "Verify package signature", {"command": "rpm -K $(rpm -q curl) ; yum -y update curl libcurl || apt-get -y install --only-upgrade curl libcurl4"})])
S("xz_down", "Downgrade xz-utils to 5.4.6", "Removes the affected xz 5.6.0/5.6.1 packages, installs 5.4.6 and restarts sshd.", "SHELL", "MEDIUM",
  {"command": "dnf -y downgrade xz xz-libs xz-devel && systemctl restart sshd", "shell": "bash", "become": True}, "Fedora 40, Debian testing", timeout=600)
S("nginx_http2", "nginx HTTP/2 rapid reset mitigation", "Sets keepalive_requests 1000 and http2_max_concurrent_streams 128, validates with nginx -t and reloads.", "ANSIBLE", "LOW",
  {"playbook": PB + "web/nginx_http2_limits.yml", "extra_vars": {"keepalive_requests": 1000, "http2_max_concurrent_streams": 128}}, "nginx 1.18+", timeout=600)
S("nginx_up", "Upgrade nginx to 1.25.3", "Installs nginx from the official repository, performs a binary upgrade (USR2) without dropping connections.", "ANSIBLE", "MEDIUM",
  {"playbook": PB + "web/nginx_upgrade.yml", "extra_vars": {"nginx_version": "1.25.3", "zero_downtime": True}}, "nginx on Linux", timeout=900, retries=1,
  vers=[("APPROVED", "2026-09-18", "Pin to 1.26.x stable", {"extra_vars": {"nginx_version": "1.26.1", "zero_downtime": True}})])
S("httpd_up", "Upgrade Apache HTTP Server to 2.4.58", "Upgrades httpd, removes legacy 'Require all granted' on / and restarts the service gracefully.", "ANSIBLE", "MEDIUM",
  {"playbook": PB + "web/httpd_upgrade.yml", "extra_vars": {"httpd_version": "2.4.58", "graceful": True}}, "Apache httpd 2.4.x", timeout=900, retries=1)
S("php_up", "Upgrade PHP to 8.2.20", "Upgrades PHP and PHP-FPM, disables the CGI SAPI where not required.", "ANSIBLE", "MEDIUM",
  {"playbook": PB + "web/php_upgrade.yml", "extra_vars": {"php_version": "8.2.20", "disable_cgi": True}}, "PHP 8.x", timeout=900)
# windows
S("smbv1_off", "Disable SMBv1 and apply MS17-010", "Removes the SMB1Protocol feature, installs KB4012212/KB4012215 where missing and reports SMB signing state.", "ANSIBLE", "MEDIUM",
  {"playbook": PB + "windows/disable_smbv1.yml", "connection": "winrm", "extra_vars": {"kb": ["KB4012212", "KB4012215"]}}, "Windows Server 2008 R2 - 2019", reboot=True, timeout=1800, retries=1)
S("netlogon", "Netlogon secure channel enforcement (Zerologon)", "Installs the August 2020 cumulative update and sets FullSecureChannelProtection=1 on domain controllers.", "ANSIBLE", "HIGH",
  {"playbook": PB + "windows/zerologon_enforce.yml", "connection": "winrm", "extra_vars": {"enforcement": 1}}, "Domain controllers", reboot=True, timeout=2400)
S("spooler_off", "Disable Print Spooler on non-print servers", "Stops and disables the Spooler service on domain controllers and file servers, and installs the July 2021 out-of-band update.", "ANSIBLE", "LOW",
  {"playbook": PB + "windows/disable_spooler.yml", "connection": "winrm"}, "Windows Server 2012 R2 - 2022", timeout=900)
S("rdp_nla", "Enable NLA and install BlueKeep patch", "Requires Network Level Authentication and installs KB4499175 for Server 2008 R2.", "ANSIBLE", "MEDIUM",
  {"playbook": PB + "windows/rdp_nla_bluekeep.yml", "connection": "winrm", "extra_vars": {"kb": "KB4499175"}}, "Windows Server 2008 R2", reboot=True, timeout=1800)
S("exchange_su", "Install Exchange Server Security Update", "Puts the DAG member in maintenance mode, installs the cumulative security update, runs health checks and exits maintenance mode.", "ANSIBLE", "HIGH",
  {"playbook": PB + "windows/exchange_security_update.yml", "connection": "winrm", "extra_vars": {"maintenance_mode": True}}, "Exchange 2016/2019", reboot=True, timeout=5400,
  vers=[("APPROVED", "2026-09-21", "Run ExchangeHealthChecker before and after", {"extra_vars": {"maintenance_mode": True, "run_health_checker": True}})])
S("wsus_cu", "Windows cumulative update via WSUS", "Approves and installs the latest cumulative update for the target group and reports pending reboot state.", "ANSIBLE", "MEDIUM",
  {"playbook": PB + "windows/wsus_cumulative_update.yml", "connection": "winrm", "extra_vars": {"category": ["SecurityUpdates", "CriticalUpdates"]}}, "Windows Server 2016 - 2022", reboot=True, timeout=3600, retries=1,
  vers=[("REVIEW_PENDING", "2026-10-17", "Skip preview updates", {"extra_vars": {"category": ["SecurityUpdates"], "skip_preview": True}})])
# appliances / tools
S("forti_up", "Upgrade FortiOS to 7.2.8 via FortiManager", "Stages the firmware on FortiManager and triggers a rolling HA upgrade with automatic config backup.", "HTTP", "HIGH",
  {"method": "POST", "url": "https://fortimanager.corp.example.com/jsonrpc", "body": {"method": "exec", "params": [{"url": "/um/firmware/upgrade", "data": {"version": "7.2.8"}}]}, "poll": True, "expect_status": 200}, "FortiGate 100F/200F", reboot=True, timeout=3600,
  vers=[("APPROVED", "2026-09-10", "Upgrade to 7.2.9 (CVE-2024-21762 fixed)", {"body": {"method": "exec", "params": [{"url": "/um/firmware/upgrade", "data": {"version": "7.2.9"}}]}}), ("REVIEW_PENDING", "2026-10-19", "Add pre-upgrade config diff", {})])
S("f5_up", "Upgrade BIG-IP to 15.1.10.2 via iControl", "Installs the target software volume, copies the configuration and activates it on the standby unit first.", "HTTP", "HIGH",
  {"method": "POST", "url": "https://{{hostname}}/mgmt/tm/sys/software/image", "body": {"command": "install", "name": "BIGIP-15.1.10.2-0.0.2.iso", "volume": "HD1.2"}, "poll": True}, "BIG-IP 15.x", reboot=True, timeout=3600)
S("citrix_up", "Upgrade NetScaler ADC to 13.1-49.15", "Uploads the build, runs the pre-upgrade validation and performs a staged HA failover upgrade.", "HTTP", "HIGH",
  {"method": "POST", "url": "https://{{hostname}}/nitro/v1/config/systemfile", "body": {"filename": "build-13.1-49.15_nc_64.tgz"}, "poll": True}, "NetScaler MPX/SDX", reboot=True, timeout=3600)
S("pan_hotfix", "Apply PAN-OS 10.2.9-h1 hotfix", "Downloads and installs the hotfix on the passive HA peer, fails over, then upgrades the former active unit.", "HTTP", "HIGH",
  {"method": "GET", "url": "https://{{hostname}}/api/?type=op&cmd=<request><system><software><install><version>10.2.9-h1</version></install></software></system></request>", "poll": True}, "PAN-OS 10.x", reboot=True, timeout=3600)
S("iosxe_up", "Upgrade IOS XE and disable HTTP server", "Installs the fixed IOS XE image in install mode and applies 'no ip http server / no ip http secure-server'.", "ANSIBLE", "HIGH",
  {"playbook": PB + "network/iosxe_upgrade.yml", "connection": "network_cli", "extra_vars": {"image": "cat9k_iosxe.17.9.4a.SPA.bin", "disable_http_server": True}}, "Catalyst 9000", reboot=True, timeout=3600)
S("jenkins_up", "Upgrade Jenkins to 2.442 LTS", "Replaces jenkins.war, backs up JENKINS_HOME and restarts after quiescing running builds.", "ANSIBLE", "MEDIUM",
  {"playbook": PB + "devops/jenkins_upgrade.yml", "extra_vars": {"jenkins_version": "2.426.3", "backup_home": True}}, "Jenkins LTS", timeout=1800, retries=1)
S("gitlab_up", "Upgrade GitLab to 13.10.3", "Runs the omnibus upgrade path with background migrations check, then verifies repository integrity.", "SHELL", "HIGH",
  {"command": "gitlab-ctl pg-upgrade -V 13 || true; apt-get -y install gitlab-ce=13.10.3-ce.0 && gitlab-ctl reconfigure", "shell": "bash", "become": True}, "GitLab omnibus", reboot=False, timeout=3600)
S("teamcity_up", "Upgrade TeamCity to 2023.05.4", "Applies the TeamCity patch plugin and restarts the server; fallback is the full distribution upgrade.", "ANSIBLE", "MEDIUM",
  {"playbook": PB + "devops/teamcity_upgrade.yml", "extra_vars": {"version": "2023.05.4"}}, "TeamCity 2023.05.x", timeout=1800)
S("confluence_up", "Upgrade Confluence Data Center to 8.5.3", "Rolling node upgrade using zero-downtime mode; the setup endpoints are blocked at the reverse proxy first.", "ANSIBLE", "HIGH",
  {"playbook": PB + "collab/confluence_upgrade.yml", "extra_vars": {"version": "8.5.3", "zero_downtime": True}}, "Confluence DC", timeout=3600)
S("moveit_patch", "Apply MOVEit Transfer security patch", "Disables HTTP/HTTPS traffic, installs the vendor patch, validates files and re-enables traffic.", "ANSIBLE", "HIGH",
  {"playbook": PB + "windows/moveit_patch.yml", "connection": "winrm", "extra_vars": {"patch": "MOVEit2022.1.6"}}, "MOVEit Transfer 2021+", reboot=True, timeout=3600)
S("esg_patch", "Barracuda ESG security patch (BNSF-36456)", "Triggers the Barracuda central update service to download and apply the security patch and reboot.", "HTTP", "MEDIUM",
  {"method": "POST", "url": "https://{{hostname}}/cgi-mod/index.cgi", "body": {"action": "update", "patch": "BNSF-36456"}, "poll": True}, "Barracuda ESG 5.x-9.x", reboot=True, timeout=1800)
S("pulse_up", "Upgrade Pulse Connect Secure to 9.1R18", "Uploads the package via the admin API and installs it with automatic rollback if the health probe fails.", "HTTP", "HIGH",
  {"method": "POST", "url": "https://{{hostname}}/api/v1/system/maintenance/install", "body": {"package": "ps-pcs-9.1R18.pkg"}, "poll": True}, "Pulse Connect Secure 9.x", reboot=True, timeout=3600)
S("libwebp_up", "Rebuild Node images with libwebp 1.3.2 (sharp 0.32.6)", "Bumps sharp to 0.32.6 in the lockfile, rebuilds the container image and rolls it out through the CD pipeline.", "SHELL", "MEDIUM",
  {"command": "npm install sharp@0.32.6 --save-exact && npm audit --omit=dev && ./ci/build_and_deploy.sh", "shell": "bash"}, "Node.js services using sharp or electron", timeout=1800)
# not (yet) linked to an incident
S("tls_old_off", "Disable TLS 1.0/1.1 on load balancers", "Removes legacy TLS protocol versions from all client-ssl profiles on BIG-IP.", "HTTP", "MEDIUM",
  {"method": "PATCH", "url": "https://lb-f5-01.corp.example.com/mgmt/tm/ltm/profile/client-ssl/~Common~clientssl", "body": {"options": ["no-tlsv1", "no-tlsv1.1"]}, "expect_status": 200}, "BIG-IP client-ssl profiles", timeout=600,
  vers=[("REJECTED", "2026-08-30", "Phase 2 - include internal virtual servers", {})])
S("cis_ssh", "CIS baseline: SSH configuration hardening", "Applies CIS Level 1 sshd_config settings: PermitRootLogin no, MaxAuthTries 4, ClientAliveInterval 300.", "ANSIBLE", "LOW",
  {"playbook": PB + "linux/cis_ssh_baseline.yml", "extra_vars": {"profile": "level1"}}, "Linux servers", timeout=900)
S("rotate_svc", "Rotate service account credentials in Vault", "Rotates database and API service account secrets in HashiCorp Vault and restarts consumers with the new lease.", "SHELL", "HIGH",
  {"command": "vault write -f database/rotate-root/{{db}} && ./scripts/restart_consumers.sh {{db}}", "shell": "bash"}, "Vault-managed secrets", timeout=900)

S("docker_rebuild", "Rebuild container base images with patched OpenSSL", "Triggers the CI pipeline to rebuild all base images from the latest patched distro layers and opens deployment PRs.", "HTTP", "MEDIUM",
  {"method": "POST", "url": "https://jenkins-prod-01.corp.example.com/job/base-images/buildWithParameters", "params": {"REBUILD_ALL": "true"}, "expect_status": 201}, "Container base images", timeout=3600, first="REVIEW_PENDING")
S("acm_rotate", "Rotate expiring TLS certificates in ACM", "Requests renewed certificates in AWS Certificate Manager and updates the load balancer listeners.", "AWS_SSM", "MEDIUM",
  {"document": "AWS-ConfigureAWSPackage", "parameters": {"action": ["Install"], "name": ["acm-renew"]}}, "ALB/NLB listeners", timeout=900, first="CHANGES_REQUESTED")
S("laps_rollout", "Deploy Windows LAPS to member servers", "Installs and configures Windows LAPS so local administrator passwords are unique and rotated every 30 days.", "ANSIBLE", "MEDIUM",
  {"playbook": PB + "windows/laps_rollout.yml", "connection": "winrm", "extra_vars": {"rotation_days": 30}}, "Windows Server 2019+", timeout=1200, first="REVIEW_PENDING")
S("confluence_block", "Block Confluence setup endpoints at reverse proxy (interim)", "Adds a deny rule for /setup/* paths on the nginx reverse proxy in front of Confluence until the upgrade is done.", "ANSIBLE", "LOW",
  {"playbook": PB + "web/nginx_deny_path.yml", "extra_vars": {"paths": ["/setup/", "/server-info.action"]}}, "Confluence behind nginx", timeout=300, first="REJECTED")

TAGSOL = {"log4j": ["log4j_up", "log4j_mit"], "spring": ["spring_fw", "spring_cloud"], "text4shell": ["commons_text"], "struts": ["struts_up", "struts_waf"],
          "openssl": ["openssl_pkg"], "openssh": ["openssh_up", "ssh_ciphers"], "sudo": ["sudo_up"], "linux": ["os_sec_update"], "kernel": ["kernel_up"],
          "curl": ["curl_up"], "xz": ["xz_down"], "http2": ["nginx_http2"], "nginx": ["nginx_up"], "httpd": ["httpd_up"], "php": ["php_up"],
          "smb": ["smbv1_off"], "ad": ["netlogon"], "print": ["spooler_off"], "rdp": ["rdp_nla"], "exchange": ["exchange_su"], "windows": ["wsus_cu"],
          "fortinet": ["forti_up"], "f5": ["f5_up"], "citrix": ["citrix_up"], "paloalto": ["pan_hotfix"], "cisco": ["iosxe_up"], "jenkins": ["jenkins_up"],
          "gitlab": ["gitlab_up"], "teamcity": ["teamcity_up"], "confluence": ["confluence_up"], "moveit": ["moveit_patch"], "barracuda": ["esg_patch"],
          "pulse": ["pulse_up"], "libwebp": ["libwebp_up"]}
assert len(SOL) >= 50, len(SOL)

solutions, versions, reviews = [], [], []
SBYKEY = {}
for si, s in enumerate(SOL):
    creator = analysts[(si * 5 + 2) % len(analysts)]
    created = D("2026-06-02", 10, 0) + timedelta(hours=si * 11 + rnd.randint(0, 4))
    sid = uid("solution", s["key"])
    specs = [(s["first"], created, s["title"], s["desc"], s["spec"], None)]
    spec_now = s["spec"]
    for vi, (st, dstr, note, patch) in enumerate(s["vers"], start=2):
        spec_now = {**spec_now, **patch} if patch else spec_now
        specs.append((st, D(dstr, 11, 15), s["title"], s["desc"] + f" Revision {vi}: {note}.", spec_now, note))
    if s["key"] == "tls_old_off":
        specs[0] = ("REVIEW_PENDING", created, s["title"], s["desc"], s["spec"], None) if False else specs[0]
    vrecs = []
    for vi, (st, cdt, title, desc, spec, note) in enumerate(specs, start=1):
        vid = uid("solver", s["key"], vi)
        vc = analysts[(si * 5 + 2 + vi) % len(analysts)] if vi > 1 else creator
        vrec = dict(id=vid, solution_id=sid, version_no=vi, title=title, description=desc, executor=s["executor"], job_spec=spec, applies_to=s["applies"],
                    risk_level=s["risk"], requires_reboot=s["reboot"], timeout_seconds=s["timeout"], max_retries=s["retries"], status=st,
                    created_by=vc["id"], created_at=cdt, key=s["key"])
        versions.append(vrec)
        vrecs.append(vrec)
        # review
        req_at = cdt + timedelta(minutes=rnd.randint(20, 90))
        rv = dict(id=uid("solrev", s["key"], vi), solution_version_id=vid, level=1, status=("PENDING" if st == "REVIEW_PENDING" else st),
                  requested_by=vc["id"], reviewer_id=None, comment=None, requested_at=req_at, decided_at=None)
        if st != "REVIEW_PENDING":
            rev = approver_other_than(vc["id"])
            rv["reviewer_id"] = rev["id"]
            rv["decided_at"] = req_at + timedelta(hours=rnd.randint(4, 60))
            rv["comment"] = {
                "APPROVED": rnd.choice(["Reviewed playbook and rollback plan. Approved.", "Tested in UAT on two hosts, no regressions. Approved.", "Approved - change record CHG attached and rollback verified.",
                                        "Looks good. Dry run output reviewed.", "Approved for use in standard maintenance windows."]),
                "REJECTED": "Rejected: scope too broad for a single solution; split internal and external listeners and resubmit.",
                "CHANGES_REQUESTED": "Please add a rollback step and limit blast radius with a serial batch size before resubmitting.",
            }[st]
        rv["key"] = s["key"]
        reviews.append(rv)
        vrec["approved_at"] = rv["decided_at"] if st == "APPROVED" else None
    last = vrecs[-1]
    solutions.append(dict(id=sid, title=s["title"], description=s["desc"], is_retired=s["retired"], current_version_id=last["id"], created_by=creator["id"],
                          created_at=created, updated_at=max(r["created_at"] for r in vrecs), key=s["key"]))
    SBYKEY[s["key"]] = dict(sol=solutions[-1], versions=vrecs)
KIND = {"snap_aws": "snap", "snap_vm": "snap", "restart_svc": "post", "health_check": "post", "rescan": "post", "reboot": "reboot", "drain_lb": "post"}


def approved_version(key, at):
    vs = [v for v in SBYKEY[key]["versions"] if v["status"] == "APPROVED" and v["approved_at"] and v["approved_at"] <= at]
    return max(vs, key=lambda v: v["version_no"])


# ------------------------------------------------------------------ incidents
STATUS_PLAN = ["RESOLVED"] * 18 + ["CLOSED_A"] * 3 + ["CLOSED_B"] * 2 + ["IN_PROGRESS"] * 6 + ["APPROVED"] * 5 + ["PENDING_APPROVAL"] * 7 + ["REJECTED"] * 3 + ["OPEN"] * 12
rnd.shuffle(STATUS_PLAN)
inc_vulns = [v for v in vulns if v["cve_id"] not in NO_INCIDENT]
assert len(STATUS_PLAN) == len(inc_vulns) == 56

APPL = {"fortinet", "f5", "citrix", "paloalto", "cisco", "pulse", "barracuda"}
WIN = {"smb", "ad", "print", "rdp", "exchange", "windows"}
JAVA = {"log4j", "spring", "text4shell", "struts"}
TOOLS_T = {"jenkins", "gitlab", "teamcity", "confluence", "moveit"}


def plan_keys(v, status, idx):
    tag = v["tag"]
    spec = TAGSOL[tag]
    first = spec[0]
    extra = [spec[1]] if (len(spec) > 1 and idx % 3 == 0 and status in ("RESOLVED", "CLOSED_A")) else []
    if tag in APPL:
        return extra + [first, "health_check"] + (["rescan"] if idx % 2 == 0 else [])
    if tag in WIN:
        return ["snap_vm"] + extra + [first, "reboot"]
    if tag in JAVA or tag in ("libwebp",):
        return ["snap_aws"] + extra + [first, "restart_svc", "health_check"]
    if tag in TOOLS_T:
        return ["snap_aws", first, "health_check"] if tag != "moveit" else ["snap_vm", first, "health_check"]
    return ["snap_aws"] + extra + [first] + (["reboot"] if tag == "kernel" else []) + ["rescan"]


EXCL_REASONS = ["Host decommissioned in change CHG0048213", "Vendor-managed appliance; patched by supplier under SLA", "Application owner approved exemption until Q1 freeze ends",
                "Asset migrated to new platform; old instance isolated from network", "Compensating control in place (WAF rule + network segmentation)"]
APPROVE_COMMENTS = ["Approved for Saturday 22:00-02:00 IST window.", "Plan reviewed; snapshot step present. Approved.", "Approved - business owner has signed off on downtime.",
                    "Approved. Please run non-prod first and attach evidence.", "Approved for the standard Sunday patch window.", "Good plan, rollback is covered by the snapshot. Approved."]
REJECT_COMMENTS = ["Add a snapshot or backup step before the patch step.", "Plan runs the reboot before the health check; reorder and resubmit.",
                   "Not approved: production DB assets are included without a DBA sign-off. Remove or get DBA approval.", "Missing health check after the change; add it and resubmit."]

incidents, inc_assets, plan_steps, approvals, runs, logs, audit = [], [], [], [], [], [], []


def AUD(ts, actor, action, etype, eid, before=None, after=None):
    audit.append(dict(actor_id=actor, action=action, entity_type=etype, entity_id=str(eid), before=before, after=after, created_at=ts))


# audit for vulnerabilities + solutions
for v in vulns:
    AUD(v["created_at"], v["created_by"], "vulnerability.created", "vulnerability", v["id"], None, {"cve_id": v["cve_id"]})
    if not v["is_active"]:
        t = v["created_at"] + timedelta(days=rnd.randint(20, 90))
        v["updated_at"] = t
        AUD(t, admins[0]["id"], "vulnerability.deactivated", "vulnerability", v["id"], {"is_active": True}, {"is_active": False})
for s in solutions:
    AUD(s["created_at"], s["created_by"], "solution.created", "solution", s["id"], None, {"title": s["title"], "version": 1})
    if s["is_retired"]:
        AUD(s["updated_at"] + timedelta(days=30), admins[0]["id"], "solution.retired", "solution", s["id"])
for r in reviews:
    vv = next(x for x in versions if x["id"] == r["solution_version_id"])
    if vv["version_no"] > 1:
        AUD(vv["created_at"], vv["created_by"], "solution.new_version", "solution", vv["solution_id"], None, {"version": vv["version_no"]})
    if r["status"] != "PENDING":
        AUD(r["decided_at"], r["reviewer_id"], "solution." + r["status"].lower(), "solution_version", vv["id"], {"status": "REVIEW_PENDING"}, {"comment": r["comment"]})
for s in solutions:
    if s["is_retired"]:
        s["updated_at"] = s["updated_at"] + timedelta(days=30)

seq = []
for i, v in enumerate(inc_vulns):
    seq.append((v, STATUS_PLAN[i], i))


def rand_between(a, b):
    return a + timedelta(seconds=rnd.randint(0, int((b - a).total_seconds())))


def timeline(status):
    """Return dict of base times by status."""
    if status in ("RESOLVED", "CLOSED_A"):
        c = rand_between(D("2026-07-06", 8), D("2026-09-14", 8))
        sub = c + timedelta(hours=rnd.randint(20, 70))
        return dict(created=c, submitted=sub)
    if status == "CLOSED_B":
        c = rand_between(D("2026-08-05", 8), D("2026-09-20", 8))
        return dict(created=c, submitted=c + timedelta(days=1, hours=2))
    if status == "IN_PROGRESS":
        t0 = NOW - timedelta(hours=rnd.randint(4, 30), minutes=rnd.randint(0, 59))
        appr = t0 - timedelta(hours=rnd.randint(2, 9))
        sub = appr - timedelta(hours=rnd.randint(3, 20))
        return dict(created=sub - timedelta(hours=rnd.randint(20, 60)), submitted=sub, approved=appr, t0=t0)
    if status == "APPROVED":
        appr = NOW - timedelta(hours=rnd.randint(2, 60))
        sub = appr - timedelta(hours=rnd.randint(3, 30))
        return dict(created=sub - timedelta(hours=rnd.randint(20, 80)), submitted=sub, approved=appr)
    if status == "PENDING_APPROVAL":
        sub = NOW - timedelta(hours=rnd.randint(1, 70))
        return dict(created=sub - timedelta(hours=rnd.randint(18, 90)), submitted=sub)
    if status == "REJECTED":
        sub = NOW - timedelta(days=rnd.randint(2, 11), hours=rnd.randint(0, 20))
        return dict(created=sub - timedelta(hours=rnd.randint(20, 70)), submitted=sub, decided=sub + timedelta(hours=rnd.randint(3, 22)))
    c = NOW - timedelta(days=rnd.randint(0, 9), hours=rnd.randint(0, 20))
    return dict(created=c)


for k, (v, st, idx) in enumerate(seq):
    seq[k] = (v, st, idx, timeline(st))
seq.sort(key=lambda x: x[3]["created"])        # incident_no follows creation order

STEP_DUR = {"snap": (30, 120), "post": (6, 45), "reboot": (110, 260)}
PATCH_DUR = {"ANSIBLE": (90, 420), "AWS_SSM": (120, 600), "SHELL": (60, 300), "HTTP": (150, 900)}
FAIL_MSGS = {
    "ANSIBLE": [('fatal: [{h}]: UNREACHABLE! => {{"changed": false, "msg": "Failed to connect to the host via ssh: ssh: connect to host {h} port 22: Connection timed out", "unreachable": true}}', 4, "Host unreachable: SSH connection timed out"),
                ('fatal: [{h}]: FAILED! => {{"changed": false, "msg": "Failed to lock apt for exclusive operation: dpkg frontend lock is held by unattended-upgrades"}}', 2, "Package manager lock held by another process"),
                ('fatal: [{h}]: FAILED! => {{"changed": false, "msg": "Timeout (62s) waiting for privilege escalation prompt"}}', 2, "Privilege escalation timed out (become)")],
    "AWS_SSM": [("An error occurred (InvalidInstanceId) when calling SendCommand: Instances [{h}] not in a valid state for account", 1, "SSM agent not reachable"),
                ("Command timed out after {t} seconds; execution status: TimedOut", 124, "SSM command timed out")],
    "SHELL": [("Error: Transaction check error:\n  file /usr/lib64/libcrypto.so.1.1 from install of openssl-libs conflicts with file from package openssl-libs-1.1.1k", 1, "RPM transaction check failed (file conflict)"),
              ("E: Unable to correct problems, you have held broken packages.", 100, "apt dependency resolution failed")],
    "HTTP": [("HTTP 503 Service Unavailable from https://{h}/ (attempt 3/3)", 22, "Management endpoint returned 503 Service Unavailable"),
             ("HTTP 409 Conflict: another maintenance task is already running on target", 22, "Target busy: maintenance task already running")],
}


def worker_name():
    return f"bulwark-worker-{rnd.randint(1, 3):02d}:{rnd.randint(1200, 9800)}"


def make_log(executor, title, host, status, err, secs, started, finished, key, sol_title):
    L = []
    def add(off, stream, msg):
        L.append((min(started + timedelta(seconds=off), finished or started + timedelta(seconds=off)), stream, msg))
    if executor == "ANSIBLE":
        add(0, "stdout", f"PLAY [{sol_title}] ****************************************")
        add(2, "stdout", f"TASK [Gathering Facts] *** ok: [{host}]")
        if status == "FAILED":
            add(max(4, secs // 3), "stdout", "TASK [Run pre-flight checks] *** ok: [" + host + "]")
            add(max(6, secs // 2), "stderr", err)
            add(max(8, secs // 2 + 1), "stdout", f"PLAY RECAP *** {host} : ok=2 changed=0 unreachable={1 if 'UNREACHABLE' in err else 0} failed={0 if 'UNREACHABLE' in err else 1} skipped=0")
        else:
            add(secs // 4, "stdout", f"TASK [Run pre-flight checks] *** ok: [{host}]")
            add(secs // 2, "stdout", f"TASK [{sol_title}] *** changed: [{host}]")
            add(int(secs * .85), "stdout", f"TASK [Verify result] *** ok: [{host}]")
            add(secs - 1, "stdout", f"PLAY RECAP *** {host} : ok=6 changed=2 unreachable=0 failed=0 skipped=1")
    elif executor == "AWS_SSM":
        cid = hexid(key + "cid", 8) + "-" + hexid(key + "c2", 4) + "-4" + hexid(key + "c3", 3) + "-a" + hexid(key + "c4", 3) + "-" + hexid(key + "c5", 12)
        add(0, "stdout", f"SendCommand accepted: CommandId={cid} target={host}")
        add(5, "stdout", "Status: InProgress")
        if status == "FAILED":
            add(max(8, secs // 2), "stderr", err)
            add(max(9, secs - 1), "stdout", "Status: Failed" if "timed out" not in err else "Status: TimedOut")
        else:
            add(secs // 2, "stdout", "Output: Downloading and applying package updates ... done")
            add(secs - 1, "stdout", "Status: Success")
    elif executor == "SHELL":
        add(0, "stdout", f"+ ssh {host} 'bash -s'")
        add(3, "stdout", "Loaded plugins: security, langpacks\nResolving Dependencies" if status != "FAILED" else "Resolving Dependencies")
        if status == "FAILED":
            add(max(5, secs // 2), "stderr", err)
            add(max(6, secs - 1), "stdout", "exit status 1")
        else:
            add(secs // 2, "stdout", "Running transaction ... Updated 3 packages")
            add(secs - 1, "stdout", "exit status 0")
    else:
        add(0, "stdout", f"{title}: sending request for {host}")
        if status == "FAILED":
            add(max(3, secs // 2), "stderr", err)
            add(max(4, secs - 1), "stdout", "giving up after retries")
        else:
            add(2, "stdout", "HTTP 202 Accepted - task queued on target")
            add(secs // 2, "stdout", "poll: status=running")
            add(secs - 1, "stdout", "poll: status=succeeded")
    return L


def mk_run(inc, step, ia, attempt, status, queued, dur, op, err=None, running_since=None):
    v = SBYKEY[step["key"]]
    host = ia["asset"]["hostname"] or ia["asset"]["name"]
    r = dict(id=uid("run", inc["id"], step["id"], ia["id"], attempt), incident_id=inc["id"], plan_step_id=step["id"], incident_asset_id=ia["id"], attempt=attempt,
             status=status, idempotency_key=f"{step['id']}:{ia['id']}:{attempt}", exit_code=None, result=None, error_message=None, triggered_by=op["id"],
             locked_by=None, queued_at=queued, started_at=None, finished_at=None)
    if status == "QUEUED":
        return r
    started = running_since or (queued + timedelta(seconds=rnd.randint(3, 40)))
    r["started_at"] = started
    r["locked_by"] = worker_name()
    secs = int(dur)
    if status == "RUNNING":
        L = make_log(step["executor"], step["title"], host, "RUNNING", None, max(60, secs), started, None, r["id"], step["title"])
        L = L[:max(1, len(L) - 2)]
    else:
        r["finished_at"] = started + timedelta(seconds=secs)
        if status == "SUCCEEDED":
            r["exit_code"] = 0
            r["result"] = {"changed": True, "duration_seconds": secs, "executor": step["executor"], "target": host, "summary": "completed without errors"}
        else:
            msg, code, short = err
            r["exit_code"] = code
            r["error_message"] = short
            r["result"] = {"changed": False, "duration_seconds": secs, "executor": step["executor"], "target": host}
        L = make_log(step["executor"], step["title"], host, status, err[0] if err else None, secs, started, r["finished_at"], r["id"], step["title"])
    for ts, stream, m in L:
        logs.append(dict(job_run_id=r["id"], stream=stream, message=m, logged_at=ts, _ord=len(logs)))
    runs.append(r)
    return r


def pick_fail(executor, host, secs):
    msg, code, short = rnd.choice(FAIL_MSGS[executor])
    return (msg.format(h=host, t=secs), code, short)


def step_dur(step):
    if step["kind"] == "patch":
        a, b = PATCH_DUR[step["executor"]]
    else:
        a, b = STEP_DUR[step["kind"]]
    return rnd.randint(a, b)


for no, (v, st, idx, tl) in enumerate(seq, start=1):
    iid = uid("incident", v["cve_id"])
    creator = analysts[(idx * 3) % len(analysts)]
    assignee = rnd.choice(analysts + operators)
    n_assets = len(v["assets"])
    code = f"INC-{no}"
    names = ", ".join(a["name"] for a in v["assets"][:3]) + (f" and {n_assets - 3} more" if n_assets > 3 else "")
    short = v["title"].split(" (")[0]
    inc = dict(id=iid, vulnerability_id=v["id"], title=f"{v['cve_id']}: {short}",
               description=f"Remediate {v['cve_id']} ({short}) on {n_assets} impacted asset{'s' if n_assets != 1 else ''}: {names}. CVSS {v['cvss_score']}, severity {v['severity']}. "
                           f"{'Listed in CISA KEV - treat as actively exploited. ' if v['source'] == 'CISA KEV' else ''}Patch in the next approved maintenance window and confirm with a rescan.",
               severity=v["severity"], status={"CLOSED_A": "CLOSED", "CLOSED_B": "CLOSED"}.get(st, st), assignee_id=assignee["id"], created_by=creator["id"],
               submitted_by=None, submitted_at=None, closed_at=None, resolved_at=None, created_at=tl["created"], updated_at=tl["created"], code=code)
    incidents.append(inc)
    AUD(inc["created_at"], creator["id"], "incident.created", "incident", iid, None, {"vulnerability": v["cve_id"]})

    # impacted assets
    ias = []
    excluded_idx = None
    if st in ("RESOLVED", "CLOSED_A") and n_assets >= 3 and rnd.random() < 0.3:
        excluded_idx = n_assets - 1
    for j, a in enumerate(v["assets"]):
        ia = dict(id=uid("ia", iid, a["id"]), incident_id=iid, asset_id=a["id"], status="PENDING", exclude_reason=None, last_error=None, patched_at=None, asset=a)
        if st == "CLOSED_B":
            ia["status"], ia["exclude_reason"] = "EXCLUDED", rnd.choice(["Risk accepted by application owner until end-of-life", "False positive - package backported by vendor (RHSA applied)", EXCL_REASONS[4]])
        if j == excluded_idx:
            ia["status"], ia["exclude_reason"] = "EXCLUDED", rnd.choice(EXCL_REASONS)
            AUD(tl["created"] + timedelta(hours=3), creator["id"], "incident.asset_excluded", "incident", iid, None, {"asset": a["id"], "reason": ia["exclude_reason"]})
        ias.append(ia)
        inc_assets.append(ia)

    # plan
    pk = [] if st == "CLOSED_B" else plan_keys(v, st, idx)
    if st == "OPEN":
        pk = pk[: rnd.choice([0, 0, 1, 2])] if no % 12 != 0 else pk
        # OPEN incidents: draft plan only with the first steps
    steps = []
    plan_time = tl.get("submitted") or (tl["created"] + timedelta(hours=2))
    for sn, key in enumerate(pk, start=1):
        ver = approved_version(key, plan_time - timedelta(hours=1))
        kind = KIND.get(key, "patch")
        step = dict(id=uid("step", iid, sn), incident_id=iid, step_no=sn, solution_version_id=ver["id"], on_failure="CONTINUE" if kind == "post" and key != "restart_svc" else "STOP_ASSET",
                    key=key, kind=kind, executor=ver["executor"], title=SBYKEY[key]["sol"]["title"], version_no=ver["version_no"], solution_id=ver["solution_id"])
        steps.append(step)
        plan_steps.append(step)
    if pk:
        AUD(tl["created"] + timedelta(hours=1), creator["id"], "incident.plan_replaced", "incident", iid, None, {"solutions": [s["solution_id"] for s in steps]})
    snapshot = [{"step_no": s["step_no"], "solution_id": s["solution_id"], "solution_version_id": s["solution_version_id"], "version_no": s["version_no"], "title": s["title"],
                 "executor": s["executor"], "on_failure": s["on_failure"]} for s in steps]

    def add_approval(status, req_at, req_by, dec_at=None, dec_by=None, comment=None):
        approvals.append(dict(id=uid("appr", iid, len(approvals)), incident_id=iid, level=1, status=status, requested_by=req_by, decided_by=dec_by, comment=comment,
                              plan_snapshot=snapshot, requested_at=req_at, decided_at=dec_at))

    submitter = creator
    if st not in ("OPEN",):
        inc["submitted_by"], inc["submitted_at"] = submitter["id"], tl["submitted"]
        AUD(tl["submitted"], submitter["id"], "incident.submitted", "incident", iid, {"status": "OPEN"}, {"status": "PENDING_APPROVAL"})

    approved_at = None
    if st == "PENDING_APPROVAL":
        add_approval("PENDING", tl["submitted"], submitter["id"])
    elif st == "REJECTED":
        rv = approver_other_than(submitter["id"])
        add_approval("REJECTED", tl["submitted"], submitter["id"], tl["decided"], rv["id"], rnd.choice(REJECT_COMMENTS))
        AUD(tl["decided"], rv["id"], "incident.rejected", "incident", iid, {"status": "PENDING_APPROVAL"}, {"comment": approvals[-1]["comment"]})
        inc["updated_at"] = tl["decided"]
    elif st == "CLOSED_B":
        closed = tl["created"] + timedelta(days=rnd.randint(2, 9))
        if no % 2 == 0:
            add_approval("CANCELLED", tl["submitted"], submitter["id"], closed, None, "Cancelled: incident closed")
            inc["submitted_by"], inc["submitted_at"] = submitter["id"], tl["submitted"]
        inc["closed_at"] = closed
        inc["updated_at"] = closed
        AUD(closed, assignee["id"], "incident.closed", "incident", iid, {"status": "OPEN"}, {"status": "CLOSED"})
    elif st in ("APPROVED", "IN_PROGRESS", "RESOLVED", "CLOSED_A"):
        sub = tl["submitted"]
        if st in ("RESOLVED", "CLOSED_A") and no % 3 == 0:        # rejected once, fixed and resubmitted
            rv0 = approver_other_than(submitter["id"])
            dec0 = sub + timedelta(hours=rnd.randint(2, 20))
            add_approval("REJECTED", sub, submitter["id"], dec0, rv0["id"], rnd.choice(REJECT_COMMENTS))
            AUD(dec0, rv0["id"], "incident.rejected", "incident", iid, {"status": "PENDING_APPROVAL"}, {"comment": approvals[-1]["comment"]})
            sub = dec0 + timedelta(hours=rnd.randint(3, 26))
            AUD(sub, submitter["id"], "incident.submitted", "incident", iid, {"status": "REJECTED"}, {"status": "PENDING_APPROVAL"})
            inc["submitted_at"] = sub
        rv = approver_other_than(submitter["id"])
        approved_at = tl.get("approved") or (sub + timedelta(hours=rnd.randint(3, 40)))
        add_approval("APPROVED", sub, submitter["id"], approved_at, rv["id"], rnd.choice(APPROVE_COMMENTS))
        AUD(approved_at, rv["id"], "incident.approved", "incident", iid, {"status": "PENDING_APPROVAL"}, {"comment": approvals[-1]["comment"]})
        inc["updated_at"] = approved_at

    # ---------------- execution
    live = [ia for ia in ias if ia["status"] != "EXCLUDED"]
    op = rnd.choice(operators)
    if st in ("RESOLVED", "CLOSED_A"):
        t = approved_at + timedelta(hours=rnd.randint(3, 30))
        for step in steps:
            trigger = t
            ends = []
            AUD(trigger, op["id"], "execution.step_queued", "incident", iid, None, {"step_no": step["step_no"], "assets": len(live)})
            for ai, ia in enumerate(live):
                host = ia["asset"]["hostname"] or ia["asset"]["name"]
                q = trigger + timedelta(seconds=ai * 2)
                d = step_dur(step)
                if step["kind"] == "patch" and rnd.random() < 0.16:
                    err = pick_fail(step["executor"], host, d)
                    r1 = mk_run(inc, step, ia, 1, "FAILED", q, d * rnd.uniform(.3, .9), op, err)
                    q2 = r1["finished_at"] + timedelta(minutes=rnd.randint(8, 50))
                    AUD(q2, op["id"], "execution.step_queued", "incident", iid, None, {"step_no": step["step_no"], "assets": 1})
                    r2 = mk_run(inc, step, ia, 2, "SUCCEEDED", q2, step_dur(step), op)
                    ends.append(r2["finished_at"])
                    ia["_last"] = r2["finished_at"]
                else:
                    r = mk_run(inc, step, ia, 1, "SUCCEEDED", q, d, op)
                    ends.append(r["finished_at"])
                    ia["_last"] = r["finished_at"]
            t = max(ends) + timedelta(minutes=rnd.randint(2, 12))
        for ia in live:
            ia["status"], ia["patched_at"] = "PATCHED", ia["_last"]
        resolved = max(ia["patched_at"] for ia in live) + timedelta(minutes=rnd.randint(1, 8))
        inc["resolved_at"] = resolved
        inc["updated_at"] = resolved
        if st == "RESOLVED":
            inc["status"] = "RESOLVED"
        else:
            inc["closed_at"] = resolved + timedelta(days=rnd.randint(1, 5))
            inc["updated_at"] = inc["closed_at"]
            AUD(inc["closed_at"], assignee["id"], "incident.closed", "incident", iid, {"status": "RESOLVED"}, {"status": "CLOSED"})
    elif st == "IN_PROGRESS":
        scen = ["done", "running", "failed", "queued", "pending"]
        rot = no % 5
        scen = scen[rot:] + scen[:rot]
        t0 = tl["t0"]
        AUD(t0, op["id"], "execution.step_queued", "incident", iid, None, {"step_no": 1, "assets": len(live)})
        n = len(steps)
        for ai, ia in enumerate(live):
            sc = scen[ai % len(scen)] if ai < 5 else "pending"
            host = ia["asset"]["hostname"] or ia["asset"]["name"]
            patch_no = next(s["step_no"] for s in steps if s["kind"] == "patch")
            if sc == "done":
                upto = n
            elif sc == "pending":
                upto = 0
            elif sc in ("running", "queued"):
                upto = rnd.randint(1, max(1, n - 1)) - 1 if n > 1 else 0
                upto = max(upto, 1) if n > 2 else upto
            else:  # failed at the patch step
                upto = patch_no - 1
            tt = t0 + timedelta(seconds=ai * 3)
            for s in steps[:upto]:
                d = step_dur(s)
                r = mk_run(inc, s, ia, 1, "SUCCEEDED", tt, d, op)
                tt = r["finished_at"] + timedelta(seconds=rnd.randint(20, 120))
                ia["_last"] = r["finished_at"]
            if sc == "done":
                ia["status"], ia["patched_at"] = "PATCHED", ia["_last"]
            elif sc == "running":
                s = steps[upto]
                ia["status"] = "IN_PROGRESS"
                mk_run(inc, s, ia, 1, "RUNNING", NOW - timedelta(minutes=9), 400, op, running_since=NOW - timedelta(minutes=rnd.randint(2, 7)))
            elif sc == "queued":
                s = steps[upto]
                ia["status"] = "IN_PROGRESS"
                mk_run(inc, s, ia, 1, "QUEUED", NOW - timedelta(seconds=rnd.randint(20, 180)), 0, op)
            elif sc == "failed":
                s = steps[upto]
                d = step_dur(s)
                err = pick_fail(s["executor"], host, d)
                r = mk_run(inc, s, ia, 1, "FAILED", tt, d * .6, op, err)
                ia["status"], ia["last_error"] = "FAILED", err[2]
        inc["updated_at"] = NOW - timedelta(minutes=2)

# stable ordering for children
logs.sort(key=lambda r: (r["_ord"]))
inc_assets_clean = [{k: v for k, v in ia.items() if k in ("id", "incident_id", "asset_id", "status", "exclude_reason", "last_error", "patched_at")} for ia in inc_assets]

# audit ordering + integrity
audit.sort(key=lambda a: a["created_at"])
# anything in the future? clamp to NOW
for a in audit:
    if a["created_at"] > NOW:
        a["created_at"] = NOW
for r in runs:
    for f in ("queued_at", "started_at", "finished_at"):
        assert r[f] is None or r[f] <= NOW + timedelta(minutes=1), (r["id"], f, r[f])

# ------------------------------------------------------------------ emit
OUT.append("-- Bulwark sample data (generated by scripts/generate_sample_data.py - do not edit by hand).\n"
           "-- Run after sql/schema.sql (or after `alembic upgrade head`) on an EMPTY database.\n"
           "-- All data is fictional. CVE identifiers and titles are real public vulnerabilities; verify scores against NVD before reporting.\n"
           "-- 'Now' for the data set is 2026-10-23 06:00 UTC.\nBEGIN;")
emit("users", ["id", "email", "full_name", "roles", "is_active", "created_at", "updated_at"], users)
emit("assets", ["id", "name", "asset_type", "environment", "hostname", "os_name", "os_version", "owner_team", "attributes", "is_active", "created_at", "updated_at"], assets)
emit("vulnerabilities", ["id", "cve_id", "title", "description", "severity", "cvss_score", "source", "published_at", "is_active", "created_by", "created_at", "updated_at"], vulns)
emit("vulnerability_assets", ["vulnerability_id", "asset_id"], vuln_assets, 60)
emit("solutions", ["id", "title", "description", "is_retired", "current_version_id", "created_by", "created_at", "updated_at"],
     [dict(s, current_version_id=None) for s in solutions])
emit("solution_versions", ["id", "solution_id", "version_no", "title", "description", "executor", "job_spec", "applies_to", "risk_level", "requires_reboot", "timeout_seconds",
                          "max_retries", "status", "created_by", "created_at"], versions, 25)
OUT.append("\n-- solutions.current_version_id (circular FK, set after versions exist)\nUPDATE solutions s SET current_version_id = v.vid FROM (VALUES\n" +
           ",\n".join(f"  ({lit(s['id'])}::uuid, {lit(s['current_version_id'])}::uuid)" for s in solutions) + "\n) AS v(sid, vid) WHERE s.id = v.sid;")
emit("solution_reviews", ["id", "solution_version_id", "level", "status", "requested_by", "reviewer_id", "comment", "requested_at", "decided_at"], reviews)
emit("incidents", ["id", "vulnerability_id", "title", "description", "severity", "status", "assignee_id", "created_by", "submitted_by", "submitted_at", "closed_at", "resolved_at",
                   "created_at", "updated_at"], incidents)
emit("incident_assets", ["id", "incident_id", "asset_id", "status", "exclude_reason", "last_error", "patched_at"], inc_assets_clean, 60)
emit("incident_plan_steps", ["id", "incident_id", "step_no", "solution_version_id", "on_failure"], plan_steps, 60)
emit("incident_approvals", ["id", "incident_id", "level", "status", "requested_by", "decided_by", "comment", "plan_snapshot", "requested_at", "decided_at"], approvals, 20)
emit("job_runs", ["id", "incident_id", "plan_step_id", "incident_asset_id", "attempt", "status", "idempotency_key", "exit_code", "result", "error_message", "triggered_by",
                  "locked_by", "queued_at", "started_at", "finished_at"], runs, 40)
emit("job_run_logs", ["job_run_id", "stream", "message", "logged_at"], logs, 100)
emit("audit_logs", ["actor_id", "action", "entity_type", "entity_id", "before", "after", "created_at"], audit, 100)
OUT.append("\nCOMMIT;\n")
OUT.append("-- Row counts: " + ", ".join(f"{k}={v}" for k, v in COUNTS.items()))
sys.stdout.write("\n".join(OUT) + "\n")
print("-- rows:", COUNTS, file=sys.stderr)

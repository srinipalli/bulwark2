-- Drops every Bulwark table (including alembic_version) so sql/schema.sql can be applied from scratch.
-- WARNING: destroys data. Use on dev/test databases only. If you use Alembic, run `alembic upgrade head` afterwards instead of schema.sql.
DROP TABLE IF EXISTS job_run_logs, job_runs, incident_approvals, incident_plan_steps, incident_assets, incidents,
                     solution_reviews, solution_versions, solutions, vulnerability_assets, vulnerabilities, assets,
                     audit_logs, users, alembic_version CASCADE;

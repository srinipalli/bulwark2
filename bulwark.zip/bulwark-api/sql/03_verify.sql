-- Integrity checks for the sample data. Every query below must return ZERO rows.
-- Usage: psql -d bulwark -f sql/03_verify.sql   (the first block prints row counts)

\echo '== row counts (each table should be >= 50) =='
SELECT t, n, CASE WHEN n >= 50 THEN 'ok' ELSE 'TOO FEW' END AS check FROM (
  SELECT 'users' t, count(*) n FROM users UNION ALL SELECT 'assets', count(*) FROM assets
  UNION ALL SELECT 'vulnerabilities', count(*) FROM vulnerabilities UNION ALL SELECT 'vulnerability_assets', count(*) FROM vulnerability_assets
  UNION ALL SELECT 'solutions', count(*) FROM solutions UNION ALL SELECT 'solution_versions', count(*) FROM solution_versions
  UNION ALL SELECT 'solution_reviews', count(*) FROM solution_reviews UNION ALL SELECT 'incidents', count(*) FROM incidents
  UNION ALL SELECT 'incident_assets', count(*) FROM incident_assets UNION ALL SELECT 'incident_plan_steps', count(*) FROM incident_plan_steps
  UNION ALL SELECT 'incident_approvals', count(*) FROM incident_approvals UNION ALL SELECT 'job_runs', count(*) FROM job_runs
  UNION ALL SELECT 'job_run_logs', count(*) FROM job_run_logs UNION ALL SELECT 'audit_logs', count(*) FROM audit_logs) x;

\echo '== status distribution =='
SELECT 'incident' kind, status, count(*) FROM incidents GROUP BY status
UNION ALL SELECT 'solution_version', status, count(*) FROM solution_versions GROUP BY status
UNION ALL SELECT 'incident_approval', status, count(*) FROM incident_approvals GROUP BY status
UNION ALL SELECT 'job_run', status, count(*) FROM job_runs GROUP BY status
UNION ALL SELECT 'incident_asset', status, count(*) FROM incident_assets GROUP BY status ORDER BY 1, 2;

\echo '== 1. resolved/closed-after-resolution incident with a non-excluded asset that is not PATCHED =='
SELECT i.id FROM incidents i JOIN incident_assets a ON a.incident_id = i.id
WHERE i.resolved_at IS NOT NULL AND a.status NOT IN ('PATCHED','EXCLUDED');

\echo '== 2. plan step pinned to a solution version that is not APPROVED =='
SELECT p.id FROM incident_plan_steps p JOIN solution_versions v ON v.id = p.solution_version_id WHERE v.status <> 'APPROVED';

\echo '== 3. step N succeeded on an asset without step N-1 succeeded first (unless N-1 is CONTINUE) =='
SELECT r.id FROM job_runs r
JOIN incident_plan_steps s ON s.id = r.plan_step_id
JOIN incident_plan_steps prev ON prev.incident_id = s.incident_id AND prev.step_no = s.step_no - 1
WHERE r.status IN ('SUCCEEDED','RUNNING','QUEUED') AND prev.on_failure <> 'CONTINUE'
  AND NOT EXISTS (SELECT 1 FROM job_runs p WHERE p.plan_step_id = prev.id AND p.incident_asset_id = r.incident_asset_id
                  AND p.status = 'SUCCEEDED' AND p.finished_at <= r.queued_at);

\echo '== 4. impossible timestamps on runs =='
SELECT id FROM job_runs WHERE started_at < queued_at OR finished_at < started_at OR queued_at > TIMESTAMPTZ '2026-10-23 06:01+00';

\echo '== 5. incident status vs approval rows =='
SELECT i.id, i.status FROM incidents i WHERE
  (i.status = 'PENDING_APPROVAL' AND (SELECT count(*) FROM incident_approvals a WHERE a.incident_id = i.id AND a.status = 'PENDING') <> 1)
  OR (i.status IN ('APPROVED','IN_PROGRESS') AND NOT EXISTS (SELECT 1 FROM incident_approvals a WHERE a.incident_id = i.id AND a.status = 'APPROVED'))
  OR (i.status = 'REJECTED' AND NOT EXISTS (SELECT 1 FROM incident_approvals a WHERE a.incident_id = i.id AND a.status = 'REJECTED'))
  OR (i.status = 'OPEN' AND EXISTS (SELECT 1 FROM incident_approvals a WHERE a.incident_id = i.id));

\echo '== 6. PATCHED asset without a succeeded run for every plan step =='
SELECT a.id FROM incident_assets a WHERE a.status = 'PATCHED' AND
  (SELECT count(*) FROM incident_plan_steps s WHERE s.incident_id = a.incident_id) <>
  (SELECT count(*) FROM job_runs r WHERE r.incident_asset_id = a.id AND r.status = 'SUCCEEDED');

\echo '== 7. runs on incidents that cannot execute =='
SELECT r.id FROM job_runs r JOIN incidents i ON i.id = r.incident_id WHERE i.status NOT IN ('IN_PROGRESS','RESOLVED','CLOSED');

\echo '== 8. solutions.current_version_id is not the highest version =='
SELECT s.id FROM solutions s WHERE s.current_version_id IS DISTINCT FROM
  (SELECT v.id FROM solution_versions v WHERE v.solution_id = s.id ORDER BY v.version_no DESC LIMIT 1);

\echo '== 9. reviewer / approver without APPROVER (or ADMIN) role =='
SELECT r.id FROM solution_reviews r JOIN users u ON u.id = r.reviewer_id WHERE NOT (u.roles && ARRAY['APPROVER','ADMIN']);
SELECT a.id FROM incident_approvals a JOIN users u ON u.id = a.decided_by WHERE NOT (u.roles && ARRAY['APPROVER','ADMIN']);

\echo '== 10. review status does not match version status =='
SELECT v.id FROM solution_versions v JOIN solution_reviews r ON r.solution_version_id = v.id
WHERE (v.status = 'REVIEW_PENDING') <> (r.status = 'PENDING') OR (v.status <> 'REVIEW_PENDING' AND v.status <> r.status);

\echo '== 11. incident plan uses a version approved after the incident was submitted =='
SELECT p.id FROM incident_plan_steps p JOIN solution_versions v ON v.id = p.solution_version_id
JOIN solution_reviews r ON r.solution_version_id = v.id JOIN incidents i ON i.id = p.incident_id
WHERE r.decided_at > COALESCE(i.submitted_at, i.created_at + interval '2 hours');

\echo '== 12. incident impacted assets that are not linked to its vulnerability =='
SELECT a.id FROM incident_assets a JOIN incidents i ON i.id = a.incident_id
WHERE NOT EXISTS (SELECT 1 FROM vulnerability_assets va WHERE va.vulnerability_id = i.vulnerability_id AND va.asset_id = a.asset_id);

\echo '== 13. inactive vulnerability with an unfinished incident =='
SELECT v.id FROM vulnerabilities v JOIN incidents i ON i.vulnerability_id = v.id WHERE NOT v.is_active AND i.status NOT IN ('RESOLVED','CLOSED');

\echo '== 14. log lines outside their run window =='
SELECT l.id FROM job_run_logs l JOIN job_runs r ON r.id = l.job_run_id
WHERE l.logged_at < r.started_at OR (r.finished_at IS NOT NULL AND l.logged_at > r.finished_at) OR r.started_at IS NULL;

\echo '== 15. incident created before its vulnerability =='
SELECT i.id FROM incidents i JOIN vulnerabilities v ON v.id = i.vulnerability_id WHERE i.created_at < v.created_at;

\echo '== 16. failed runs that are the open FAILED state: shown for information (jobs_failed_open) =='
SELECT i.incident_no, a.status FROM incident_assets a JOIN incidents i ON i.id = a.incident_id WHERE a.status = 'FAILED' ORDER BY 1;

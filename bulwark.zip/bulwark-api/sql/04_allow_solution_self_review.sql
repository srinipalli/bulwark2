-- Approvers may decide (approve / reject / request changes) their own solution submissions.
-- Drops the "no self approval" CHECK on solution_reviews. Incident approvals keep theirs.
-- Safe to run more than once. Same change as Alembic revision 0002.
ALTER TABLE solution_reviews DROP CONSTRAINT IF EXISTS solution_reviews_check;

-- To restore the rule:
--   ALTER TABLE solution_reviews ADD CONSTRAINT solution_reviews_check CHECK (reviewer_id IS NULL OR reviewer_id <> requested_by) NOT VALID;

-- Approvers may decide (approve / reject) incident plans they submitted themselves.
-- Drops the "no self approval" CHECK on incident_approvals. Safe to run more than once. Same change as Alembic revision 0004.
ALTER TABLE incident_approvals DROP CONSTRAINT IF EXISTS incident_approvals_check;

-- To restore the rule:
--   ALTER TABLE incident_approvals ADD CONSTRAINT incident_approvals_check CHECK (decided_by IS NULL OR decided_by <> requested_by) NOT VALID;

#!/usr/bin/env bash
# Load the sample data set.
#   sql/load_sample_data.sh <database-url> [--reset | --fresh]
#     (no flag)  data only - target tables must be empty
#     --reset    TRUNCATE all data first (schema kept), then load
#     --fresh    DROP all tables, apply sql/schema.sql, then load (not for Alembic-managed databases)
# <database-url> is a plain libpq URL, e.g. postgresql://postgres:secret@localhost:5432/bulwark
set -euo pipefail
URL="${1:?usage: $0 <postgresql://user:pass@host:port/db> [--reset|--fresh]}"
MODE="${2:-}"
DIR="$(cd "$(dirname "$0")" && pwd)"
run() { psql "$URL" -v ON_ERROR_STOP=1 -q -f "$1"; }
case "$MODE" in
  --fresh) run "$DIR/00_drop_all.sql"; run "$DIR/schema.sql" ;;
  --reset) run "$DIR/00_truncate_data.sql" ;;
  "") ;;
  *) echo "unknown option $MODE" >&2; exit 2 ;;
esac
run "$DIR/02_sample_data.sql"
echo "Loaded. Running integrity checks (every section below should list 0 rows)..."
psql "$URL" -f "$DIR/03_verify.sql" | sed -n '/== 1\./,$p'

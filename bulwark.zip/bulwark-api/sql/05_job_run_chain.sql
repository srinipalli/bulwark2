-- One-click "Run" on the Execution tab: a chained run makes the worker queue the asset's next plan step when it finishes.
-- Additive and safe to run more than once. Same change as Alembic revision 0003.
ALTER TABLE job_runs ADD COLUMN IF NOT EXISTS chain BOOLEAN NOT NULL DEFAULT FALSE;

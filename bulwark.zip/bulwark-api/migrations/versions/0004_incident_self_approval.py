"""approvers may decide their own incident submissions (drop incident_approvals self-approval CHECK)

Revision ID: 0004
Revises: 0003
"""
from alembic import op

revision = "0004"
down_revision = "0003"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.get_bind().exec_driver_sql("ALTER TABLE incident_approvals DROP CONSTRAINT IF EXISTS incident_approvals_check")


def downgrade() -> None:
    # NOT VALID: approvals already decided by their submitter stay; new ones are checked again
    op.get_bind().exec_driver_sql("ALTER TABLE incident_approvals ADD CONSTRAINT incident_approvals_check "
                                  "CHECK (decided_by IS NULL OR decided_by <> requested_by) NOT VALID")

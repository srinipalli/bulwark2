"""approvers may review their own solution submissions (drop solution_reviews self-review CHECK)

Revision ID: 0002
Revises: 0001
"""
from alembic import op

revision = "0002"
down_revision = "0001"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.get_bind().exec_driver_sql("ALTER TABLE solution_reviews DROP CONSTRAINT IF EXISTS solution_reviews_check")


def downgrade() -> None:
    # NOT VALID: reviews already decided by their submitter stay; new ones are checked again
    op.get_bind().exec_driver_sql("ALTER TABLE solution_reviews ADD CONSTRAINT solution_reviews_check "
                                  "CHECK (reviewer_id IS NULL OR reviewer_id <> requested_by) NOT VALID")

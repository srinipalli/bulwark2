"""initial schema (sql/schema.sql is the single source of truth for revision 0001)

Revision ID: 0001
Revises:
"""
from pathlib import Path

from alembic import op

from bulwark.core.sqlutil import schema_statements

revision = "0001"
down_revision = None
branch_labels = None
depends_on = None

TABLES = ["audit_logs", "job_run_logs", "job_runs", "incident_approvals", "incident_plan_steps", "incident_assets",
          "incidents", "solution_reviews", "solutions", "solution_versions", "vulnerability_assets", "vulnerabilities",
          "assets", "users"]


def upgrade() -> None:
    bind = op.get_bind()
    for stmt in schema_statements(Path(__file__).resolve().parents[2] / "sql" / "schema.sql"):
        bind.exec_driver_sql(stmt)


def downgrade() -> None:
    bind = op.get_bind()
    bind.exec_driver_sql("ALTER TABLE solutions DROP CONSTRAINT IF EXISTS fk_solutions_current_version")
    for t in TABLES:
        bind.exec_driver_sql(f"DROP TABLE IF EXISTS {t} CASCADE")

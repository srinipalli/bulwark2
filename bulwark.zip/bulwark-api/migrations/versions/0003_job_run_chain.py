"""job_runs.chain: runs started by "Run" (whole plan) queue the asset's next step when they finish

Revision ID: 0003
Revises: 0002
"""
from alembic import op

revision = "0003"
down_revision = "0002"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.get_bind().exec_driver_sql("ALTER TABLE job_runs ADD COLUMN IF NOT EXISTS chain BOOLEAN NOT NULL DEFAULT FALSE")


def downgrade() -> None:
    op.get_bind().exec_driver_sql("ALTER TABLE job_runs DROP COLUMN IF EXISTS chain")

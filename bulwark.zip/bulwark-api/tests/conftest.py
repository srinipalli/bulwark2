import os
import uuid
from pathlib import Path

import pytest
import pytest_asyncio
from jose import jwt

TEST_URL = os.environ.get("TEST_DATABASE_URL")
if TEST_URL:
    os.environ["DATABASE_URL"] = TEST_URL
os.environ.setdefault("JWT_SECRET", "test-secret")
os.environ["SIMULATE_EXECUTORS"] = "true"
os.environ["KAFKA_BOOTSTRAP_SERVERS"] = ""          # never publish test incidents to a real topic

pytestmark = pytest.mark.skipif(not TEST_URL, reason="set TEST_DATABASE_URL (postgresql+asyncpg://...) to run")


@pytest_asyncio.fixture(scope="session", autouse=True, loop_scope="session")
async def schema():
    if not TEST_URL:
        pytest.skip("TEST_DATABASE_URL not set")
    from sqlalchemy import text

    from bulwark.core.db import engine
    from bulwark.core.sqlutil import schema_statements

    async with engine.begin() as c:
        await c.execute(text("DROP SCHEMA public CASCADE"))
        await c.execute(text("CREATE SCHEMA public"))
        for stmt in schema_statements(Path(__file__).parent.parent / "sql" / "schema.sql"):
            await c.exec_driver_sql(stmt)


def make_token(name: str, roles: list[str]) -> dict:
    uid = uuid.uuid5(uuid.NAMESPACE_DNS, name)
    tok = jwt.encode({"sub": str(uid), "email": f"{name}@example.com", "name": name.title(), "roles": roles},
                     os.environ["JWT_SECRET"], algorithm="HS256")
    return {"Authorization": f"Bearer {tok}"}


@pytest.fixture(scope="session")
def users():
    return {
        "ravi": make_token("ravi", ["ANALYST", "OPERATOR"]),
        "srini": make_token("srini", ["APPROVER"]),
        "meena": make_token("meena", ["ANALYST", "APPROVER"]),     # can both submit and approve (to test self-approval block)
        "viewer": make_token("viewer", ["VIEWER"]),
    }


@pytest_asyncio.fixture(scope="session", loop_scope="session")
async def client():
    import httpx

    from bulwark.main import app
    async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url="http://test") as c:
        yield c

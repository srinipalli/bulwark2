"""End-to-end business flow against a real PostgreSQL:
vulnerability -> solutions (review) -> incident -> plan -> incident approval -> execution (worker) -> resolved."""
import pytest

from bulwark.core.db import SessionLocal
from bulwark.modules.execution.worker import process_all
from bulwark.shared.models import Asset

pytestmark = pytest.mark.asyncio
P = "/api/v1"


async def seed_assets():
    async with SessionLocal() as s:
        a = [Asset(name=n, asset_type="SYSTEM", environment="prod") for n in ("app-01", "app-02", "db-01")]
        s.add_all(a)
        await s.commit()
        return [str(x.id) for x in a]


async def test_full_flow(client, users):
    ravi, srini, meena, viewer = users["ravi"], users["srini"], users["meena"], users["viewer"]
    asset_ids = await seed_assets()

    # --- auth
    assert (await client.get(f"{P}/vulnerabilities")).status_code == 401

    # --- vulnerabilities (with description), roles, duplicates
    body = {"cve_id": "CVE-2026-1187", "title": "OpenSSL heap overflow", "severity": "CRITICAL", "cvss_score": 9.1,
            "description": "Heap overflow in OpenSSL X.509 parsing allows remote code execution.", "asset_ids": asset_ids}
    assert (await client.post(f"{P}/vulnerabilities", json=body, headers=viewer)).status_code == 403
    r = await client.post(f"{P}/vulnerabilities", json=body, headers=ravi)
    assert r.status_code == 201, r.text
    vuln = r.json()
    assert vuln["description"].startswith("Heap overflow") and len(vuln["assets"]) == 3 and vuln["is_active"]
    assert (await client.post(f"{P}/vulnerabilities", json=body, headers=ravi)).status_code == 409
    r = await client.patch(f"{P}/vulnerabilities/{vuln['id']}", json={"description": "Updated description"}, headers=ravi)
    assert r.json()["description"] == "Updated description"

    # --- solutions are created REVIEW_PENDING
    def sol(title, spec=None, desc="openssl upgrade"):
        return {"title": title, "description": desc, "executor": "ANSIBLE", "job_spec": spec or {}, "risk_level": "LOW"}
    s1 = (await client.post(f"{P}/solutions", json=sol("Backup config and snapshot", desc="backup before patch"), headers=ravi)).json()
    s2 = (await client.post(f"{P}/solutions", json=sol("OpenSSL 3.2.4 upgrade", {"fail_on": ["db-01"]}), headers=ravi)).json()
    s3 = (await client.post(f"{P}/solutions", json=sol("Unreviewed thing"), headers=ravi)).json()
    assert s1["status"] == "REVIEW_PENDING" and s1["versions"][0]["version_no"] == 1

    # --- solution approvals tab: approver only, never your own
    reviews = (await client.get(f"{P}/approvals/solutions", headers=srini)).json()
    assert reviews["total"] == 3
    rid = {x["title"]: x["id"] for x in reviews["items"]}
    assert (await client.post(f"{P}/approvals/solutions/{rid['Backup config and snapshot']}/approve", headers=ravi)).status_code == 403
    own = (await client.post(f"{P}/solutions", json=sol("Meena's own solution"), headers=meena)).json()
    own_rid = next(x["id"] for x in (await client.get(f"{P}/approvals/solutions", headers=srini)).json()["items"] if x["title"] == "Meena's own solution")
    assert (await client.post(f"{P}/approvals/solutions/{own_rid}/approve", headers=meena)).status_code == 200   # approvers may approve their own solution
    assert (await client.post(f"{P}/approvals/solutions/{rid['Unreviewed thing']}/reject", json={}, headers=srini)).status_code == 422  # comment required
    for t in ("Backup config and snapshot", "OpenSSL 3.2.4 upgrade"):
        assert (await client.post(f"{P}/approvals/solutions/{rid[t]}/approve", headers=srini)).status_code == 200
    r = await client.post(f"{P}/approvals/solutions/{rid['Unreviewed thing']}/request-changes", json={"comment": "needs rollback"}, headers=srini)
    assert r.json()["status"] == "CHANGES_REQUESTED"
    assert (await client.get(f"{P}/solutions/{s1['id']}", headers=srini)).json()["status"] == "APPROVED"

    # --- incident (with description), one per vulnerability
    r = await client.post(f"{P}/incidents", json={"vulnerability_id": vuln["id"], "description": "Patch all prod hosts this week."}, headers=ravi)
    assert r.status_code == 201, r.text
    inc = r.json()
    assert inc["status"] == "OPEN" and inc["description"] == "Patch all prod hosts this week." and inc["assets_count"] == 3
    assert inc["code"].startswith("INC-")
    assert (await client.post(f"{P}/incidents", json={"vulnerability_id": vuln["id"]}, headers=ravi)).status_code == 409
    assert (await client.post(f"{P}/vulnerabilities/{vuln['id']}/deactivate", headers=ravi)).status_code == 409   # open incident

    # --- AI/similar suggestions only return approved solutions
    sug = (await client.get(f"{P}/solutions/suggestions", params={"incident_id": inc["id"]}, headers=ravi)).json()
    assert all(x["title"] != "Unreviewed thing" for x in sug) and any("OpenSSL" in x["title"] for x in sug)
    r = await client.get(f"{P}/incidents/{inc['id']}/similar", headers=ravi)   # recommender tables absent -> no matches
    assert r.status_code == 200 and r.json() == []
    r = await client.get(f"{P}/incidents/{inc['id']}/ai-plan", headers=ravi)   # ... and no AI plan
    assert r.status_code == 200 and r.json() is None
    r = await client.post(f"{P}/incidents/{inc['id']}/ai-plan/apply", json={"plan_id": inc["id"]}, headers=ravi)
    assert r.status_code == 404

    # --- plan: only approved solutions, ordered
    r = await client.put(f"{P}/incidents/{inc['id']}/plan", json={"steps": [{"solution_id": s3["id"]}]}, headers=ravi)
    assert r.status_code == 422
    r = await client.put(f"{P}/incidents/{inc['id']}/plan", json={"steps": [{"solution_id": s1["id"]}, {"solution_id": s2["id"], "on_failure": "STOP_ASSET"}]}, headers=ravi)
    assert r.status_code == 200, r.text
    assert [p["title"] for p in r.json()["plan"]] == ["Backup config and snapshot", "OpenSSL 3.2.4 upgrade"]
    r = await client.post(f"{P}/incidents/{inc['id']}/plan/copy-from", json={"source_incident_id": inc["id"]}, headers=ravi)
    assert r.status_code == 422                     # cannot copy its own plan
    r = await client.delete(f"{P}/incidents/{inc['id']}/plan", headers=ravi)
    assert r.status_code == 200 and r.json()["plan"] == []
    r = await client.put(f"{P}/incidents/{inc['id']}/plan", json={"steps": [{"solution_id": s1["id"]}, {"solution_id": s2["id"], "on_failure": "STOP_ASSET"}]}, headers=ravi)
    assert r.status_code == 200, r.text

    # --- cannot execute before incident approval
    r = await client.post(f"{P}/execution/incidents/{inc['id']}/steps/1/run", headers=ravi)
    assert r.status_code == 409

    # --- incident approval tab
    assert (await client.post(f"{P}/incidents/{inc['id']}/submit", headers=ravi)).json()["status"] == "PENDING_APPROVAL"
    assert (await client.put(f"{P}/incidents/{inc['id']}/plan", json={"steps": [{"solution_id": s1["id"]}]}, headers=ravi)).status_code == 409  # locked
    pend = (await client.get(f"{P}/approvals/incidents", headers=srini)).json()["items"]
    assert len(pend) == 1 and pend[0]["incident_description"] and len(pend[0]["plan"]) == 2
    assert (await client.post(f"{P}/approvals/incidents/{pend[0]['id']}/approve", headers=ravi)).status_code == 403
    r = await client.post(f"{P}/approvals/incidents/{pend[0]['id']}/approve", headers=srini)
    assert r.status_code == 200 and r.json()["status"] == "APPROVED"
    assert (await client.get(f"{P}/incidents/{inc['id']}", headers=ravi)).json()["status"] == "APPROVED"

    # --- execution: step order, idempotency, worker
    run1 = (await client.post(f"{P}/execution/incidents/{inc['id']}/steps/1/run", headers=ravi)).json()
    assert {x["outcome"] for x in run1} == {"QUEUED"} and len(run1) == 3
    again = (await client.post(f"{P}/execution/incidents/{inc['id']}/steps/1/run", headers=ravi)).json()
    assert {x["outcome"] for x in again} == {"EXISTS"}                                   # no duplicate runs
    blocked = (await client.post(f"{P}/execution/incidents/{inc['id']}/steps/2/run", headers=ravi)).json()
    assert {x["outcome"] for x in blocked} == {"BLOCKED"}                                # step 1 not finished yet
    assert (await client.get(f"{P}/incidents/{inc['id']}", headers=ravi)).json()["status"] == "IN_PROGRESS"
    assert await process_all() == 3
    grid = (await client.get(f"{P}/execution/incidents/{inc['id']}/grid", headers=ravi)).json()
    assert all(row["cells"][0]["status"] == "SUCCEEDED" for row in grid["rows"])

    run2 = (await client.post(f"{P}/execution/incidents/{inc['id']}/steps/2/run", headers=ravi)).json()
    assert {x["outcome"] for x in run2} == {"QUEUED"}
    await process_all()
    grid = (await client.get(f"{P}/execution/incidents/{inc['id']}/grid", headers=ravi)).json()
    st = {row["asset_name"]: row["cells"][1]["status"] for row in grid["rows"]}
    assert st == {"app-01": "SUCCEEDED", "app-02": "SUCCEEDED", "db-01": "FAILED"}
    failed_run = next(x for x in run2 if x["asset_name"] == "db-01")["run"]["id"]
    logs = (await client.get(f"{P}/execution/runs/{failed_run}/logs", headers=ravi)).json()
    assert any("simulated failure" in x["message"] for x in logs)

    # retry creates attempt 2; still fails; then the failing asset is excluded -> incident resolves
    ia = next(r["incident_asset_id"] for r in grid["rows"] if r["asset_name"] == "db-01")
    retry = (await client.post(f"{P}/execution/incidents/{inc['id']}/steps/2/run", json={"incident_asset_ids": [ia]}, headers=ravi)).json()
    assert retry[0]["outcome"] == "QUEUED" and retry[0]["run"]["attempt"] == 2
    await process_all()
    r = await client.post(f"{P}/incidents/{inc['id']}/assets/{ia}/exclude", json={"reason": "decommissioned"}, headers=ravi)
    assert r.status_code == 200 and r.json()["status"] == "RESOLVED" and r.json()["patched_count"] == 2

    # --- dashboard
    d = (await client.get(f"{P}/dashboard/summary", headers=viewer)).json()
    assert d["open_incidents"] == 0 and d["assets_patched"] == 2 and d["assets_patched_pct"] == 100
    assert d["solutions_pending_review"] == 1      # only Meena's own solution is still waiting

    # --- vulnerability activate / deactivate now allowed; inactive cannot get an incident
    assert (await client.post(f"{P}/vulnerabilities/{vuln['id']}/deactivate", headers=ravi)).json()["is_active"] is False
    assert (await client.post(f"{P}/incidents", json={"vulnerability_id": vuln["id"]}, headers=ravi)).status_code == 422
    assert (await client.post(f"{P}/vulnerabilities/{vuln['id']}/activate", headers=ravi)).json()["is_active"] is True

    # --- editing an approved solution creates v2 (REVIEW_PENDING) and keeps v1 usable
    r = await client.patch(f"{P}/solutions/{s2['id']}", json={"description": "now with rollback"}, headers=ravi)
    assert r.status_code == 200
    detail = r.json()
    assert [v["version_no"] for v in detail["versions"]] == [1, 2] and detail["status"] == "REVIEW_PENDING" and detail["has_approved_version"]
    assert (await client.patch(f"{P}/solutions/{s2['id']}", json={"description": "again"}, headers=ravi)).status_code == 409  # under review

# Bulwark API

Vulnerability → Incident → Solution → Approval → Execution backend. FastAPI + async SQLAlchemy + PostgreSQL.

## Layout: one folder per module
```
src/bulwark/
  main.py                      app factory, routers mounted under /api/v1
  core/                        config, db session, JWT security + roles, errors, pagination, audit
  shared/                      User, Asset, AuditLog models + common schemas
  modules/
    dashboard/       router.py service.py schemas.py                       GET /dashboard/*
    incident/        router.py service.py models.py schemas.py             /incidents/*
    approvals/       router.py service.py models.py schemas.py             /approvals/*   (incident + solution tabs)
    vulnerabilities/ router.py service.py models.py schemas.py             /vulnerabilities/*
    solution/        router.py service.py models.py schemas.py suggest.py  /solutions/*
    execution/       router.py service.py models.py schemas.py worker.py executors/   /execution/*
    assets/          router.py service.py schemas.py                       /assets/*   (inventory + form pickers)
    reference/       router.py                                             GET /users (assignee dropdown)
sql/schema.sql                 single source of truth for the database (applied by Alembic 0001)
migrations/                    Alembic (async)
scripts/                       dev_token.py, seed.py
tests/                         end-to-end flow test against real PostgreSQL
```

## Run it
```bash
cp .env.example .env
docker compose up -d db && alembic upgrade head      # or: docker compose up
python scripts/seed.py                               # demo assets + one vulnerability
uvicorn bulwark.main:app --app-dir src --reload      # API  -> http://localhost:8000/docs
PYTHONPATH=src python -m bulwark.modules.execution.worker   # job worker (separate process)
python scripts/dev_token.py ravi ANALYST OPERATOR    # JWT for Swagger "Authorize"
```
Test: `TEST_DATABASE_URL=postgresql+asyncpg://user@host/db pytest -q` (the target schema is dropped and recreated).

## Roles
`ANALYST` create/edit vulnerabilities, incidents, solutions · `OPERATOR` run jobs · `APPROVER` decide approvals ·
`ADMIN` everything · `VIEWER` read-only. Nobody can decide their own submission (API check + DB constraint).

## Business rules enforced in code and in the database
* One open incident per vulnerability (partial unique index). Inactive vulnerabilities cannot get incidents; a vulnerability with an open incident cannot be deactivated.
* Every solution (and every new version of one) starts `REVIEW_PENDING`; only `APPROVED` versions can be planned or suggested.
* Incident plan = ordered steps, each pinned to an approved solution version. Plan/assets lock after submit.
* Incident goes `OPEN → PENDING_APPROVAL → APPROVED → IN_PROGRESS → RESOLVED` (`REJECTED` returns to editing).
* Execution only for `APPROVED`/`IN_PROGRESS` incidents; step N runs on an asset only after step N-1 succeeded on it
  (unless step N-1 is `CONTINUE`). Re-running returns the existing run (no duplicates); a failed run can be retried (attempt+1).
* Incident auto-resolves when every non-excluded asset is patched.

## Endpoints
| Module | Endpoints |
|---|---|
| dashboard | `GET /dashboard/summary` · `GET /dashboard/attention` |
| incidents | `GET/POST /incidents` · `GET/PATCH /incidents/{id}` · `PUT /incidents/{id}/assets` · `POST /incidents/{id}/assets/{incident_asset_id}/exclude` · `PUT /incidents/{id}/plan` · `POST /incidents/{id}/submit` · `POST /incidents/{id}/close` |
| approvals | `GET /approvals/summary` · `GET /approvals/incidents` · `POST /approvals/incidents/{id}/approve｜reject` · `GET /approvals/solutions` · `POST /approvals/solutions/{id}/approve｜reject｜request-changes` |
| vulnerabilities | `GET/POST /vulnerabilities` · `GET/PATCH /vulnerabilities/{id}` · `POST /vulnerabilities/{id}/activate｜deactivate` |
| solutions | `GET/POST /solutions` · `GET/PATCH /solutions/{id}` · `POST /solutions/{id}/retire` · `GET /solutions/suggestions?incident_id=` |
| execution | `GET /execution/incidents` · `GET /execution/incidents/{id}/grid` · `POST /execution/incidents/{id}/steps/{n}/run` · `GET /execution/runs` · `GET /execution/runs/{id}` · `GET /execution/runs/{id}/logs?after_id=` · `POST /execution/runs/{id}/cancel` |
| assets | `GET /assets` (picker) · `GET /assets/inventory` · `GET /assets/facets` · `POST /assets` · `GET/PATCH /assets/{id}` · `POST /assets/{id}/activate｜deactivate` |
| reference | `GET /users` |

## What is real and what is a stub
* **Real, tested:** everything above, against PostgreSQL 16 (see `tests/test_flow.py`), including the queue worker (`FOR UPDATE SKIP LOCKED`, timeouts, stale-run recovery, auto-retry, STOP_ALL).
* **Simulated by default:** `SIMULATE_EXECUTORS=true` runs jobs through a simulator. For real patching set it to `false` and implement
  Ansible / AWS SSM in `modules/execution/executors/real.py` (until then those runs fail with a clear "not configured" error).
* **Suggestions:** `solution/suggest.py` is a keyword-overlap baseline behind a `SuggestionProvider` interface; plug in embeddings / an LLM there.
* **Auth:** the API validates JWTs (HS256 secret in config); issuing tokens is your identity provider's job.

## Sample data

`sql/` contains reset/load scripts and a 14-table sample data set (`sql/02_sample_data.sql`). See `sql/README.md`, or run
`make sample-data DB_URL=postgresql://user:pass@localhost:5432/bulwark`.

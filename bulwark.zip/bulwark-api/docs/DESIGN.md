# Database design changes (this revision)

| Change | Where |
|---|---|
| `description` added | `vulnerabilities.description`, `incidents.description` (TEXT, nullable) |
| Solution versioning + review | `solutions` (identity) · `solution_versions` (content + status) · `solution_reviews` (level-1 review) |
| Incident approval returns | `incident_approvals` (+ `plan_snapshot` JSONB of what was approved) |
| Incident → many assets | `incident_assets` (per-asset status, exclude reason) |
| Incident → ordered plan | `incident_plan_steps` (step_no, pinned `solution_version_id`, `on_failure`) |
| Execution per step × asset | `job_runs` (+ `job_run_logs`), unique live run per step+asset, never re-run after SUCCEEDED |
| Vulnerability ↔ assets | `vulnerability_assets` |
| Audit | `audit_logs` (append-only) |

Key constraints: one non-finished incident per vulnerability; one pending review/approval per target; reviewer ≠ requester (CHECK);
`UNIQUE (incident_id, step_no)`; status columns are TEXT + CHECK so values can evolve with a migration, not an enum rewrite.
